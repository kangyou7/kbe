import React from 'react';

import Search from '../common/Search';
import PagingView from '../common/PagingView';

import {TableThead, TableColgroup} from '../common/TableThead';

import {REST_API_URL} from '../../config/api-config.js';

/*다국어 모듈 시작*/
import { connect } from 'react-redux';
import { changeLangauge, mapStateToProps } from '../../language/Actions';
/*다국어 모듈 종료*/

class ContractTodoList extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            listThead : [
                {name:props.messages.contract_no,                sort:false, sortColumn:"", view:true, target:false, width:'4%'},
                {name:props.messages.contract_approval_status,   sort:true,  sortColumn:"aprv_step_code_name", view:true, target:true, width:'16%'},
                {name:props.messages.contract_contract_division, sort:true,  sortColumn:"ctrt_dstnct_code_name", view:true, target:true, width:'16%'},
                {name:props.messages.contract_customer_name,     sort:true,  sortColumn:"demnd_usr_name", view:true, target:true, width:'16%'},
                {name:props.messages.contract_customer_division, sort:true,  sortColumn:"customer_clas_code_name", view:true, target:true, width:'16%'},
                {name:props.messages.contract_submitter,         sort:true,  sortColumn:"reg_usr_name", view:true, target:true, width:'16%'},
                {name:props.messages.contract_submission_date,   sort:true,  sortColumn:"reg_date", view:true, target:true, width:'16%'}
            ],
            searchSelectOption : [
                {value:"", text: props.messages.contract_select},
                {value:"custom", text : props.messages.contract_customer_name},
                {value:"writer", text : props.messages.contract_submitter}
            ],
            list : [],
            pageInfo:{}
        }

        this.handleSearch = this.handleSearch.bind(this);
        this.handlePageChange = this.handlePageChange.bind(this);
        this.handleDetailView = this.handleDetailView.bind(this);
        this.handleSort = this.handleSort.bind(this);
    }

    //컴포넌트가 만들어지고 첫 렌더링을 다 마친 후 실행되는 메소드입니다.
	componentDidMount() {
        this.props.onRef(this)
        
        this.getList();
	}

	//컴포넌트가 DOM 에서 사라진 후 실행되는 메소드입니다.
	componentWillUnmount() {
		this.props.onRef(null)
	}


    //컴포넌트가 prop 을 새로 받았을 때 실행됩니다.
    componentWillReceiveProps(nextProps) {
        if(this.props.locale !== nextProps.locale) {
            let listThead = this.state.listThead;

            listThead[0].name = nextProps.messages.contract_no;
            listThead[1].name = nextProps.messages.contract_approval_status;
            listThead[2].name = nextProps.messages.contract_contract_division;
            listThead[3].name = nextProps.messages.contract_customer_name;
            listThead[4].name = nextProps.messages.contract_customer_division;
            listThead[5].name = nextProps.messages.contract_submitter;
            listThead[6].name = nextProps.messages.contract_submission_date;


            let searchSelectOption = this.state.searchSelectOption;

            searchSelectOption[0].text = nextProps.messages.contract_select;
            searchSelectOption[1].text = nextProps.messages.contract_customer_name;
            searchSelectOption[2].text = nextProps.messages.contract_submitter;
        }
    }

    handleSearch(searchInfo) {
        let pageInfo = this.state.pageInfo;
        pageInfo.searchKeyCode = searchInfo.searchKeyCode;
        pageInfo.searchKeyWord = searchInfo.searchKeyWord;
        this.setState({
            pageInfo : pageInfo
        })
        this.getList();
    }

    //페이지 변경 및 페이지 출력 갯수 변경
    handlePageChange(perPageNum, page) {
        let changePage = this.state.pageInfo;
        changePage.perPageNum = perPageNum;
        changePage.page = page;
        this.setState({
            pageInfo:changePage
        })

        this.getList();
    }

    handleDetailView(index) {
        let info = {
            ctrtNo : this.state.list[index].ctrtNo,
            tcktNo : this.state.list[index].tcktNo,
            aprvLineOrder : this.state.list[index].aprvLineOrder,
        }
        
        this.props.onDetailView(info);
    }

    handleSort(sort) {
        let sortPage = this.state.pageInfo;
        sortPage.sortColumn = sort.sortColumn;
        sortPage.sortType = sort.sortType;
        this.setState({
            pageInfo:sortPage
        })

        this.getList();
    }

    getList() {
        let data = this.state.pageInfo;

        data.loginUserNo = this.props.memberInfo.user_no;
        data.loginUserDstnctCode = this.props.memberInfo.user_dstnct_code;
        
        $.ajax({
            url: REST_API_URL + "/contract/TodoList",
            dataType: 'json',
            type: "post",
            data: data,
            cache: false,
            success: function(result) {
                this.setState({
                    list: result.response.list,
                    pageInfo : result.response.pageInfo
                });
            }.bind(this),
            error: function(xhr, status, err) {
                console.log(xhr + " : " + status + " : " + err);
            }.bind(this),
            xhrFields: {
              withCredentials: true
            }
        });
    }


    
    render() {
        const mapToComponent = (data, thead) => {
            if(data.length > 0) {
                return data.map((contract, i) => {//map
                    return(<tr key={i}>
                        <td style={thead[0].view ? {} : {display:'none'}}>{contract.rownum}</td>
                        <td style={thead[1].view ? {} : {display:'none'}}>{contract.aprvStepCodeName}</td>
                        <td style={thead[1].view ? {} : {display:'none'}}>{contract.ctrtDstnctCodeName}</td>
                        <td style={thead[2].view ? {} : {display:'none'}}><a href="javascript:;" onClick={() => {this.handleDetailView(i);}}>{contract.demndUsrName}</a></td>
                        <td style={thead[3].view ? {} : {display:'none'}}>{contract.customerClasCodeName}</td>
                        <td style={thead[4].view ? {} : {display:'none'}}>{contract.regUsrName}</td>
                        <td style={thead[5].view ? {} : {display:'none'}}>{contract.regDate}</td>
                    </tr>);
                });
            } else {
                return (
                    <tr>
                        <td className="noresults" colSpan={7}>
                            <div className="box_noresults">
                                <div className="ver_mid">
                                    <i className="ico ico_no_result"></i>
                                    <span className="lb">{this.props.messages.contract_there_are_no_results}</span>
                                </div>
                            </div>
                        </td>
                    </tr>
                );
            }
        }

        return (
                    <div id="tab-cont1" className="tab_content tab-cont">
						{/*S:content_body */}
						<div className="content_body">
							{/*S:content_inner */}
							<div className="content_inner">
								<div className="box_com term_wrap">
                                    <Search onSearch={this.handleSearch} searchSelectOption={this.state.searchSelectOption}/>
								</div>		
								
								<table className="tbl_col">
									<caption>결재 미처리 현황 목록</caption>

									<TableColgroup listThead={this.state.listThead} />
                                    <TableThead listThead={this.state.listThead} onSort={this.handleSort}/>
									
									<tbody>
                                        {mapToComponent(this.state.list, this.state.listThead)}
									</tbody>
								</table>
																
							</div>
							{/*E:content_inner */}
						</div>
						{/*E:content_body */}
						{/*S:content_bottom */}
						<PagingView pageInfo={this.state.pageInfo} onPageChange={this.handlePageChange}/>
						{/*E:content_bottom */}
					</div>
        );
    }
}

export default connect(mapStateToProps)(ContractTodoList);