import React from 'react';
import { Link } from 'react-router';
import ContractTodoList from './ContractTodoList';
import ContractTodoDetail from './ContractTodoDetail';

/*다국어 모듈 시작*/
import { connect } from 'react-redux';
import { changeLangauge, mapStateToProps } from '../../language/Actions';
/*다국어 모듈 종료*/


class ContractTodo extends React.Component {
    constructor(props) {
        super(props);
        this.state ={
            ctrtNo : "",
            tcktNo : "",
            aprvLineOrder : "",
            hdlOpinText : "",
            aprvResultCode : ""
        }

        this.handleTabsChange = this.handleTabsChange.bind(this);
        this.handleDetailView = this.handleDetailView.bind(this);
        this.handleApproval = this.handleApproval.bind(this);
        this.handleApprovalResult = this.handleApprovalResult.bind(this);
        this.handleChange = this.handleChange.bind(this);
    }

    componentDidMount() {
        $("#tab-cont1").show();
        $("#tab-cont2").hide();
        $(".fr").hide();

        if ( $('.ui-sel').length > 0 ){
            $('.ui-sel').each(function(){
                $(this).selectric();//초기화
            });	
        }
    }
    
    handleTabsChange(tab) {
        if(tab === 'Detail') {
            if(this.state.ctrtNo === "") {
                alert("계약 정보를 선택하세요.");
            } else {
                $("#tab-cont1").hide();
                $("#tab-cont2").show();
                $(".fr").show();

                $(".tabs li").eq(0).removeClass('on');
                $(".tabs li").eq(1).addClass('on');
            }
        } else {
            $("#tab-cont1").show();
            $("#tab-cont2").hide();
            $(".fr").hide();
            $(".tabs li").eq(0).addClass('on');
            $(".tabs li").eq(1).removeClass('on');
        }
    }

    handleDetailView(info) {
        let nextState = this.state;

        nextState.ctrtNo = info.ctrtNo;
        nextState.tcktNo = info.tcktNo,
        nextState.aprvLineOrder = info.aprvLineOrder;

        this.setState(nextState);

        this.handleTabsChange('Detail');
        this.contractTodoDetail.getContract(this.state.ctrtNo);
    }

    handleChange(e) {
        this.state.hdlOpinText = e.target.value;
	}

    handleApproval(type) {
        if(type == "R") {
            if(!confirm("반려하시겠습니까?")) {
                return;
            } 
        } else if(type == "A") {
            if(!confirm("승인하시겠습니까?")) {
                return;
            } 
        } else {
            return;
        }

        this.state.aprvResultCode = type;

        this.contractTodoDetail.approval(this.state);
    }
    handleApprovalResult() {
        this.state.ctrtNo = "";
        this.state.tcktNo = "";
        this.state.aprvLineOrder = "";
        this.state.hdlOpinText = "";
        this.state.aprvResultCode = "";
        
        this.handleTabsChange('List');

        this.contractTodoList.getList();
    }

    render() {
        return (
            <section className="body">

                {/*S:wrapper */}
                <div className="wrapper">

                    {/*S:page_header */}
                    <div className="page_header">
                        <h2 className="ptitle">{this.props.messages.contract_approval_processing_status}</h2>
                        <div className="page_nav">
                            {/*<ul>
                                <li><Link to="/">Home</Link></li>
                                <li><Link to="/contract">{this.props.messages.contract_contract_management}</Link></li>
                                <li className="here">{this.props.messages.contract_approval_processing_status}</li>
                            </ul>*/}
                        </div>
                    </div>
                    {/*E:page_header */}

                    {/*S:content_wrap */}
                    <div className="content_wrap">
                        {/*S:content_outbox */}
                        <div className="content_outbox">
                            {/*S:tab_wrap */}
                            <div className="tab_wrap tab-wrap">
                                {/*S:tab_header */}
                                <div className="box_both tab_header">		
                                    <div className="fl">
                                        <ul className="tabs">
                                            <li className="tab_item tab-item on">
                                                <a href="javascript:;" onClick={() => {this.handleTabsChange('List')}} className="tab-link"><span>{this.props.messages.contract_list}</span></a>
                                            </li>
                                            <li className="tab_item tab-item">
                                                <a href="javascript:;" className="tab-link"><span>{this.props.messages.contract_detail}</span></a>
                                            </li>
                                        </ul>
                                    </div>
                                    <div className="fr">
                                        <div className="btn_group">
                                            <button type="button" className="btn_pos" onClick={() => {this.handleApproval('R')}}>{this.props.messages.contract_reject}</button>
                                            <button type="button" className="btn_black" onClick={() => {this.handleApproval('A')}}>{this.props.messages.contract_approved}</button>
                                        </div>
                                    </div>
                                </div>
                                {/*E:tab_header */}

                                {/*S:tab_content 활성화시 display:block/none  */}
                                <ContractTodoList onRef={ref => (this.contractTodoList = ref)} onDetailView={this.handleDetailView}/>
                                {/*E:tab_content  */}	

                                {/*S:tab_content 활성화시 display:block/none  */}
                                <ContractTodoDetail onRef={ref => (this.contractTodoDetail = ref)} command={this.state.comment} onCommentChange={this.handleChange} onApprovalResult={this.handleApprovalResult}/>
                                {/*E:tab_content  */}	
                            </div>
                            {/*E:tab_wrap */}
                        </div>
                        {/*E:content_outbox */}
                    </div>
                    {/*E:content_wrap */}
                </div>
                {/*E:wrapper */}
            </section>
        );
    }
}

export default connect(mapStateToProps)(ContractTodo);
