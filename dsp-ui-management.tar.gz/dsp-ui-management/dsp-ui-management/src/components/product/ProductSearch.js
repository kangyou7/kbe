import React from 'react';

import {REST_API_URL} from '../../config/api-config.js';

/*다국어 모듈 시작*/
import { connect } from 'react-redux';
import { changeLangauge, mapStateToProps } from '../../language/Actions';
/*다국어 모듈 종료*/

class ProductSearch extends React.Component {

    constructor(props) {
        super(props);

        this.state = {
            searchName:"",
            selectKey:-1,
            sortColumn : "",
            sortType : "",
            product : []
        }

        
        this.handleChange = this.handleChange.bind(this);
        this.handleSearch = this.handleSearch.bind(this); 
    }

    //컴포넌트가 만들어지고 첫 렌더링을 다 마친 후 실행되는 메소드입니다.
	componentDidMount() {
		this.props.onRef(this)
	}

	//컴포넌트가 DOM 에서 사라진 후 실행되는 메소드입니다.
	componentWillUnmount() {
		this.props.onRef(null)
	}

    handleChange(e) {
        let nextState = {};
        nextState[e.target.name]=e.target.value;
        this.setState(nextState);
    }

    handleProductSelect(key) {
        $("#productBody tr").removeClass();
        $("#productBody tr").eq(key).addClass('selected');
    }

    handleSearch() {
        this.getProduct();
    }

    handleSort(sortColumn, sortType) {
        this.setState({
            sortColumn : sortColumn,
            sortType : sortType
        });

        this.getProduct();
    }
    
    getProduct() {
        $.ajax({
            url: REST_API_URL + "/product/getProductSearch",
            dataType: 'json',
            type: "post",
            data: {
                searchKeyWord:this.state.searchName,
                sortColumn : this.state.sortColumn,
                sortType : this.state.sortType
            },
            cache: false,
            success: function(result) {
                this.setState({
                    selectKey : -1,
                    product: result.response.product
                });
            }.bind(this),
                error: function(xhr, status, err) {
                console.log(xhr + " : " + status + " : " + err);
            }.bind(this),
            xhrFields: {
              withCredentials: true
            }
        });
    }

    complete() {
        if(this.state.selectKey < 0) {
            alert("선택하세요");
            return
        }
        let product = this.state.product[this.state.selectKey];

        this.props.onProductSearchComplete(product);
        this.hide();
    }

    hide() {
        layer_close(".pop-prod-load");
    }

    show() {
        this.setState({
            searchName:"",
            selectKey:-1,
            sortColumn : "",
            sortType : "",
            product : []
        })
        layer_open(".pop-prod-load");
    }

    

    render() {

        const mapToProduct = (data) => {
            if(data.length > 0) {
                return data.map((item, i) => {//map
                    return(
                        <tr key={i} onClick={() => {this.setState ({selectKey : i}); this.handleProductSelect(i)}}>
                            <td>{item.productDstnctCodeName}</td>
                            <td>{item.productUsePurposeCodeName}</td>
                            <td>{item.productName}</td>
                            <td>{item.regDate}</td>
                        </tr>
                    );
                });
            } else {
                return (
                    <tr>
                        <td className="noresults" colSpan={4}>
                            <div className="box_noresults">
                                <div className="ver_mid">													
                                    <i className="ico ico_no_result"></i>
                                    <span className="lb">{this.props.messages.contract_there_are_no_results}</span>
                                </div>
                            </div>
                        </td>
                    </tr>
                );
            }
        }

        return(
            <div className="lpopup">
                <div className="dimmed"></div>
                <div className="popup_layer pop_prod_load pop-prod-load mid">
                    <div className="pop_container">
                        <div className="pop_header">
                            <h1>{this.props.messages.product_loading_products}</h1>
                        </div>
                        {/*pop_contents */}
                        <div className="pop_contents scroll_wrap search_form">
                            {/*pop_inner */}
                            <div className="pop_inner">
                                <div className="psearch_form">
                                    <input type="text" className="ui_input" name="searchName" value={this.state.searchName} onChange={this.handleChange}/>
                                    <a href="javascript:;" className="btn_pos" onClick={this.handleSearch}>{this.props.messages.contract_search_2}</a>
                                </div>
                                <div className="scroll_wrap">
                                    <table className="tbl_col">
                                        <caption>상품 불러오기 목록</caption>
                                        <colgroup>
                                            <col style={{width:'15%'}} />
                                            <col style={{width:'15%'}} />
                                            <col style={{width:'auto'}} />
                                            <col style={{width:'33%'}} />
                                        </colgroup>
                                        
                                        <thead>
                                            <tr>
                                                <th scope="col">{this.props.messages.product_division}</th>
                                                <th scope="col">{this.props.messages.product_usage}</th>
                                                <th scope="col">
                                                    <span className="tbl_sort_group ">
                                                        <span className="lb">{this.props.messages.product_product_name}</span>
                                                        <a className="btn_sort btn_up" href="javascript:;" onClick={() => {this.handleSort('product_nm', 'asc')}}>
                                                            <i className="ico ico_btn_sort_up"><span className="offscreen">▲</span></i>
                                                        </a>
                                                        <a className="btn_sort  btn_down" href="javascript:;" onClick={() => {this.handleSort('product_nm', 'desc')}}>
                                                            <i className="ico ico_btn_sort_down"><span className="offscreen">▼</span></i>
                                                        </a>
                                                    </span>
                                                </th>
                                                <th scope="col">
                                                    <span className="tbl_sort_group ">
                                                        <span className="lb">{this.props.messages.product_registration_date}</span>
                                                        <a className="btn_sort btn_up" href="javascript:;" onClick={() => {this.handleSort('regist_dt', 'asc')}}>
                                                            <i className="ico ico_btn_sort_up"><span className="offscreen">▲</span></i>
                                                        </a>
                                                        <a className="btn_sort  btn_down" href="javascript:;" onClick={() => {this.handleSort('regist_dt', 'desc')}}>
                                                            <i className="ico ico_btn_sort_down"><span className="offscreen">▼</span></i>
                                                        </a>
                                                    </span>
                                                </th>
                                            </tr>
                                        </thead>
                                        
                                        <tbody id="productBody">
                                            {/*S : 리스트 */}
                                            {mapToProduct(this.state.product)}
                                            {/*E : 리스트 */}
                                            
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            {/*// pop_inner */}
                        </div>	
                        {/*// pop_contents*/}
                        <div className="pop_bottom">
                            <button type="button" className="pbtn_black" onClick={() => {this.complete();}}>{this.props.messages.product_ok}</button>
                        </div>
                    </div>{/*// pop_container */}
                    <a href="javascript:;" onClick={() => {this.hide();}} className="btn_pop_close"><span className="offscreen">{this.props.messages.ticket_close}</span></a>
                </div>{/*// popup_layer */}
            </div>
        );
    }
}

export default connect(mapStateToProps)(ProductSearch);