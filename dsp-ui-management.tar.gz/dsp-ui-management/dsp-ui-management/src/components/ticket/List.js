import React from 'react';

import Search from '../common/Search';
import PagingView from '../common/PagingView';
import ColumnChange from '../common/ColumnChange';

import {TableThead, TableColgroup} from '../common/TableThead';

import {REST_API_URL} from '../../config/api-config.js';

/*다국어 모듈 시작*/
import { connect } from 'react-redux';
import { changeLangauge, mapStateToProps } from '../../language/Actions';
/*다국어 모듈 종료*/

class List extends React.Component {
    constructor(props) {
        super(props);
    
        this.state = {
            listThead : [
                {name:props.messages.contract_no,             sort:false, sortColumn:"", view:true, target:false, width:'4%'},
                {name:props.messages.ticket_ticket_id,        sort:true,  sortColumn:"tckt_no", view:true, target:true, width:'12%'},
                {name:props.messages.ticket_division,         sort:true,  sortColumn:"tckt_clas_code_name", view:true, target:true, width:'12%'},
                {name:props.messages.ticket_ticket_name,      sort:true, sortColumn:"tckt_name", view:true, target:true, width:'12%'},
                {name:props.messages.ticket_ticket_status_2,  sort:true, sortColumn:"tckt_status_code_name", view:true, target:true, width:'12%'},
                {name:props.messages.ticket_priority,         sort:true, sortColumn:"prior_code", view:true, target:true, width:'12%'},
                {name:props.messages.ticket_provider_name,   sort:true, sortColumn:"prvdr_name", view:true, target:true, width:'12%'},
                {name:props.messages.ticket_customer_name,    sort:true, sortColumn:"custm_name", view:true, target:true, width:'12%'},
                {name:props.messages.ticket_transaction_date, sort:true, sortColumn:"mod_date", view:true, target:true, width:'12%'}
            ],
            searchSelectOption : [
                {value:"", text: props.messages.contract_select},
                {value:"tckt_status_code_name", text : props.messages.ticket_ticket_status_2},
                {value:"custm_name", text : props.messages.ticket_customer_name},
                {value:"prvdr_name", text : props.messages.ticket_provider_name},
                {value:"mod_date", text : props.messages.ticket_transaction_date},
            ],
            list : [],
            pageInfo:{

            }
        }

        this.handlePageChange = this.handlePageChange.bind(this);
        this.handleColumnChange = this.handleColumnChange.bind(this);
        this.handleSort = this.handleSort.bind(this);
        this.handleSearch = this.handleSearch.bind(this);
        this.handleDetailView = this.handleDetailView.bind(this);
    }

    //컴포넌트가 만들어지고 첫 렌더링을 다 마친 후 실행되는 메소드입니다.
    componentDidMount() {
        this.props.onRef(this);
        this.getList();
    }

    //컴포넌트가 DOM 에서 사라진 후 실행되는 메소드입니다.
    componentWillUnmount() {
        this.props.onRef(null)
    }

    //컴포넌트가 prop 을 새로 받았을 때 실행됩니다.
    componentWillReceiveProps(nextProps) {
        if(this.props.locale !== nextProps.locale) {
            let listThead = this.state.listThead;

            listThead[0].name = nextProps.messages.contract_no;
            listThead[1].name = nextProps.messages.ticket_ticket_id;
            listThead[2].name = nextProps.messages.ticket_division;
            listThead[3].name = nextProps.messages.ticket_ticket_name;
            listThead[4].name = nextProps.messages.ticket_ticket_status_2;
            listThead[5].name = nextProps.messages.ticket_priority;
            listThead[6].name = nextProps.messages.ticket_ticket_manager;
            listThead[7].name = nextProps.messages.ticket_customer_name;
            listThead[8].name = nextProps.messages.ticket_transaction_date;

            let searchSelectOption = this.state.searchSelectOption;

            searchSelectOption[0].text = nextProps.messages.contract_select;
            searchSelectOption[1].text = nextProps.messages.ticket_ticket_status_2;
            searchSelectOption[2].text = nextProps.messages.ticket_customer_name;
        }
    }


    //항목변경 팝업에서 항목 변경 후 state 정보 변경
    handleColumnChange(changeThead) {
        this.setState({
            listThead : changeThead
        });
    }
    //리스트 정렬
    handleSort(sort) {
        let sortPage = this.props.pageInfo;
        sortPage.sortColumn = sort.sortColumn;
        sortPage.sortType = sort.sortType;
        /*this.setState({
            pageInfo:sortPage
        })*/

        //this.getList();
        this.props.onPageInfoChange(sortPage, true);
    }
    //검색
    handleSearch(searchInfo) {
        let pageInfo = this.props.pageInfo;
        pageInfo.searchKeyCode = searchInfo.searchKeyCode;
        pageInfo.searchKeyWord = searchInfo.searchKeyWord;
        /*this.setState({
            pageInfo : pageInfo
        })*/
        //this.getList();
        this.props.onPageInfoChange(pageInfo, true);
    }
    //페이지 변경 및 페이지 출력 갯수 변경
    handlePageChange(perPageNum, page) {

        let changePage = this.props.pageInfo;
        changePage.perPageNum = perPageNum;
        changePage.page = page;

        /*this.setState({
            pageInfo:changePage
        })*/

        //this.getList();
        this.props.onPageInfoChange(changePage, true);
    }

    getList() {

        let data = this.props.pageInfo;

        data.loginUserNo = this.props.memberInfo.user_no;
        data.loginUserDstnctCode = this.props.memberInfo.user_dstnct_code;

        $.ajax({
            url: REST_API_URL + "/ticket/List",
            dataType: 'json',
            type: "post",
            data: data,
            cache: false,
            success: function(result) {
                this.props.onPageInfoChange(result.response.pageInfo, false);
                this.setState({
                    list: result.response.list//,
                    //pageInfo : result.pageInfo
                });

            }.bind(this),
            error: function(xhr, status, err) {
                    console.log(xhr + " : " + status + " : " + err);
            }.bind(this),
			xhrFields: {
			  withCredentials: true
			}
        });
    }

    handleDetailView(index) {
        let tcktNo = this.state.list[index].tcktNo;
        //let isApproval = this.state.list[index].tcktStatusCode == '03' ? true : false;
        let isApproval = this.state.list[index].approverYn == 'Y' ? true : false;

        this.props.onDetailView(tcktNo, isApproval);
    }
    
    render() {
        const mapToList = (data, thead) => {
            if(data.length > 0) {
                return data.map((item, i) => {//map
                    return(
                        <tr key={i}>
                            <td style={thead[0].view ? {} : {display:'none'}}>{item.rownum}</td>
                            <td style={thead[1].view ? {} : {display:'none'}}>{item.tcktNo}</td>
                            <td style={thead[2].view ? {} : {display:'none'}}>{item.tcktClasCodeName}</td>
                            <td style={thead[3].view ? {} : {display:'none'}}>
                                {item.tcktClasCode == 'M' ? (<a href="javascript:;" onClick={() => {this.handleDetailView(i);}}>{item.tcktName}</a>) : item.tcktName }
                            </td>
                            <td style={thead[4].view ? {} : {display:'none'}}>{item.tcktStatusCodeName}</td>
                            <td style={thead[5].view ? {} : {display:'none'}}>{item.priorCode}</td>
                            <td style={thead[6].view ? {} : {display:'none'}}>{item.prvdrName}</td>
                            <td style={thead[7].view ? {} : {display:'none'}}>{item.custmName}</td>
                            <td style={thead[8].view ? {} : {display:'none'}}>{item.modDate}</td>
                        </tr>
                    );
                });
            } else {
                let colspan = thead.length;
                for(var i = 0; i<thead.length; i++) {
                    colspan -= thead[i].view ? 0 : 1;
                }
                return (
                    <tr>
                        <td className="noresults" colSpan={colspan}>
                            <div className="box_noresults">
                                <div className="ver_mid">													
                                    <i className="ico ico_no_result"></i>
                                    <span className="lb">검색결과가 없습니다.</span>
                                </div>
                            </div>
                        </td>
                    </tr>
              );
            }
          }
        return(
            <div id="tab-cont1" className="tab_content tab-cont" style={{display:'block'}}>
                {/*S:content_body */}
                <div className="content_body">
                    {/*S:content_inner */}
                    <div className="content_inner">
                        <div className="box_com term_wrap">
                            
                            <Search onSearch={this.handleSearch} searchSelectOption={this.state.searchSelectOption} searchInfo={{"searchKeyCode":this.props.pageInfo.searchKeyCode, "searchKeyWord":this.props.pageInfo.searchKeyWord}}/>

                            <div className="fr">
                                <a href="javascript:;" onClick={() => this.props.onDisplaySetting('C')} className="btn_black">{this.props.messages.ticket_register_a_ticket}</a>
                                <span className="gap"></span>
                                <a href="javascript:;" className="btn_pos" onClick={() => this.columnChange.show()}>{this.props.messages.contract_change_item}</a>
                                {/*<ul className="sort_wrap">
                                    <li className="active"><a href="javascript:;">List</a></li>
                                    <li><a href="javascript:;">Tree</a></li>
                                </ul>*/}
                            </div>
                        </div>			
                        
                        
                        <table className="tbl_col">
                            <caption>티켓 현황 목록</caption>

                            <TableColgroup listThead={this.state.listThead} />
                            <TableThead listThead={this.state.listThead} onSort={this.handleSort}/>
                            
                            <tbody>

                                {mapToList(this.state.list, this.state.listThead)}
                               
                            </tbody>
                        </table>
                    </div>
                    {/*E:content_inner */}
                </div>
                {/*E:content_body */}
                
                <PagingView pageInfo={this.props.pageInfo} onPageChange={this.handlePageChange} />

                <ColumnChange onRef={ref => (this.columnChange = ref)} listThead={this.state.listThead} onColumnChange={this.handleColumnChange} />

            </div>

        )
    }
}

export default connect(mapStateToProps)(List);
