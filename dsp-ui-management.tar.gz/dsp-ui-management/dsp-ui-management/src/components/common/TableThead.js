import React from 'react';


class TableThead extends React.Component {
    constructor(props) {
        super(props);

        this.handleSort = this.handleSort.bind(this);
    }

    handleSort(key, type) {
        let sort = {
            sortColumn : this.props.listThead[key].sortColumn,
            sortType : type
        }
        this.props.onSort(sort);
    }

    handleCheckAll() {
        
        $("input[name='listCheck']").prop("checked", $("#listChkAll").is(":checked"));
    }


    render() {
        const mapToListThead = (data) => {
            return data.map((title, i) => {
                if (title.checkbox) {
                    return (
                        <th key={i} scope="col" className="ui_only_chk">
                            <span className="input_ico_box">
                                <input type="checkbox" name="chk_box" id="listChkAll" onClick={() => {this.handleCheckAll()}}/>
                                <label htmlFor="listChkAll"></label>
                            </span>
                        </th>
                    );
                } else {
                    if(!title.sort) {
                        return(
                            <th scope="col" key={i} style={title.view ? {} : {display:'none'}}> {title.name} </th>
                        );
                    } else {
                        return(
                            <th scope="col" key={i} style={title.view ? {} : {display:'none'}}>
                                <span className="tbl_sort_group">
                                    <span className="lb">{title.name}</span>
                                    {/* rownum 을 반대로 가져와야되서 sort를 반대로 함*/}
                                    <a className="btn_sort btn_up" href="javascript:;" onClick={() => {this.handleSort(i, 'desc')}}>
                                        <i className="ico ico_btn_sort_up"><span className="offscreen">▲</span></i>
                                    </a>
                                    <a className="btn_sort  btn_down" href="javascript:;" onClick={() => {this.handleSort(i, 'asc')}}>
                                        <i className="ico ico_btn_sort_down"><span className="offscreen">▼</span></i>
                                    </a>
                                </span>
                            </th>
                        );
                    }
                }
            });
        }
        return (
            <thead>
                <tr>
                    {mapToListThead(this.props.listThead)}
                </tr>
            </thead>
        )
    }
}


class TableColgroup extends React.Component {
    constructor(props) {
        super(props);
    }



    render() {
        const mapToListThead = (data) => {
            return data.map((title, i) => {
                return(
                    <col key={i} style={title.view ? {width : title.width} : {display:'none'}}/>
                );
            });
        }
        return (
            <colgroup>
                {mapToListThead(this.props.listThead)}
            </colgroup>
        )
    }
}


module.exports = {
    TableThead,
    TableColgroup
}