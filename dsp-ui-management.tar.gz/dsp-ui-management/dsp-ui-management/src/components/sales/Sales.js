import React from 'react';
import { Link } from 'react-router';
import List from './List';
import Detail from './Detail';

/*다국어 모듈 시작*/
import { connect } from 'react-redux';
import { changeLangauge, mapStateToProps } from '../../language/Actions';
/*다국어 모듈 종료*/

class Sales extends React.Component {
    constructor(props) {
        super(props);
    
        this.state = {
            displadyState : "L",
            salesSeq : "",
            pageInfo : {},
            listThead : [
                {name:props.messages.contract_no,                     sort:false, sortColumn:"", view:true, target:false, width:'3%'},
                {name:props.messages.sales_provider_name,             sort:true,  sortColumn:"sply_usr_name", view:true, target:true, width:'auto'},
                {name:props.messages.sales_customer_name,             sort:true,  sortColumn:"demnd_usr_name", view:true, target:true, width:'8%'},
                {name:props.messages.sales_contract_id,               sort:true, sortColumn:"ctrt_no", view:true, target:true, width:'8%'},
                {name:props.messages.sales_billing_start_date,        sort:true, sortColumn:"billing_str_date", view:true, target:true, width:'8%'},
                {name:props.messages.sales_billing_end_date,          sort:true, sortColumn:"billing_end_date", view:true, target:true, width:'8%'},
                {name:props.messages.sales_traffic_up_basic_total,    sort:true, sortColumn:"traffic_up1", view:true, target:true, width:'8%'},
                {name:props.messages.sales_traffic_down_basic_total,  sort:true, sortColumn:"traffic_down1", view:true, target:true, width:'8%'},
                {name:props.messages.sales_storage_basic_total,       sort:true, sortColumn:"storage_capacity1", view:true, target:true, width:'8%'},
                {name:props.messages.sales_billing_month,             sort:true, sortColumn:"adjust_ym", view:true, target:true, width:'8%'},
                {name:props.messages.sales_sales_amount,              sort:true, sortColumn:"thmon_fee_sum_amt", view:true, target:true, width:'8%'},
                {name:props.messages.sales_billing_division,          sort:true, sortColumn:"adjust_dstnct_code_name", view:true, target:true, width:'8%'},
                {name:props.messages.sales_purchasing_status,         sort:true, sortColumn:"rect_status_code_name", view:true, target:true, width:'8%'}
            ],
            searchSelectOption : [
                {value:"", text : props.messages.product_select},
                {value:"provider", text : props.messages.sales_provider_name},
                {value:"custom", text : props.messages.sales_customer_name},
                {value:"contract", text : props.messages.sales_contract_id},
            ]
        }

        this.handleDisplaySetting = this.handleDisplaySetting.bind(this);

        this.handlePageInfoChange = this.handlePageInfoChange.bind(this);

        this.handleDetailView = this.handleDetailView.bind(this);
    }

    componentDidMount() {
        if(this.props.location.query.salesSeq != undefined || this.props.location.query.salesSeq != null || this.props.location.query.salesSeq === '') {
            this.handleDetailView(this.props.location.query.salesSeq);
        }
	}

    //컴포넌트가 prop 을 새로 받았을 때 실행됩니다.
    componentWillReceiveProps(nextProps) {
        if(this.props.locale !== nextProps.locale) {
            let listThead = this.state.listThead;

            listThead[0].name = nextProps.messages.contract_no;
            listThead[1].name = nextProps.messages.sales_provider_name;
            listThead[2].name = nextProps.messages.sales_customer_name;
            listThead[3].name = nextProps.messages.sales_contract_id;
            listThead[4].name = nextProps.messages.sales_billing_start_date;
            listThead[5].name = nextProps.messages.sales_billing_end_date;
            listThead[6].name = nextProps.messages.sales_traffic_up_basic_total;
            listThead[7].name = nextProps.messages.sales_traffic_down_basic_total;
            listThead[8].name = nextProps.messages.sales_storage_basic_total;
            listThead[9].name = nextProps.messages.sales_billing_month;
            listThead[10].name = nextProps.messages.sales_sales_amount;
            listThead[11].name = nextProps.messages.sales_billing_division;
            listThead[12].name = nextProps.messages.sales_purchasing_status;

            let searchSelectOption = this.state.searchSelectOption;

            searchSelectOption[0].text = nextProps.messages.product_select;
            searchSelectOption[1].text = nextProps.messages.sales_provider_name;
            searchSelectOption[2].text = nextProps.messages.sales_customer_name;
            searchSelectOption[3].text = nextProps.messages.sales_contract_id;
        }
    }
    handleDisplaySetting(state) {
        this.setState({displadyState : state});
    }

    handlePageInfoChange(pageInfo, reload) {
        this.setState({
            pageInfo : pageInfo
        });

        if(reload) {
            this.list.getList();
        }
    }

    handleDetailView(salesSeq) {
        this.state.salesSeq = salesSeq;
        
        this.handleDisplaySetting('D');
    }

    render() {
        return (

            <section className="body">
                
                <div className="wrapper">
                    
                    <div className="page_header">
                        <h2 className="ptitle">{this.props.messages.sales_sales_status}</h2>
                        <div className="page_nav">
                            {/*<ul>
                                <li><Link to="/">Home</Link></li>
                                <li><a href="javascript:;" onClick={() => this.setState({displadyState:'L'})}>{this.props.messages.sales_sales_management}</a></li>
                                <li className="here">{this.props.messages.sales_sales_status}</li>
                            </ul>*/}
                        </div>
                    </div>

                    <div className="content_wrap">
                        <div className="content_outbox">
                            <div className="tab_wrap tab-wrap">
                                <div className="box_both tab_header">		
                                    <div className="fl">
                                        <ul className="tabs">
                                            <li className={this.state.displadyState == 'L' ? "tab_item tab-item on" : "tab_item tab-item"}>
                                                <a href="javascript:;" onClick={() => this.setState({displadyState:'L'})} className="tab-link"><span>{this.props.messages.product_list}</span></a>
                                            </li>
                                            <li className={this.state.displadyState != 'L' ? "tab_item tab-item on" : "tab_item tab-item"}>
                                                <a href="javascript:;" className={this.state.displadyState == 'L' ? "tab-link disabled" : "tab-link"}><span>{this.props.messages.product_detail}</span></a>
                                            </li>
                                        </ul>
                                    </div>
                                    <div className="fr">
                                        <div className="btn_group" style={this.state.displadyState === 'D' ? {} : {display:'none'}}>
                                            <button type="button" className="btn_black" onClick={() => this.setState({displadyState:'L'})}>{this.props.messages.sales_ok}</button>
                                        </div>
                                    </div>
                                </div>
                                {this.state.displadyState == 'L' 
                                    ? <List onRef={ref => (this.list = ref)} onDisplaySetting={this.handleDisplaySetting} 
                                                       onDetailView={this.handleDetailView}
                                                       pageInfo={this.state.pageInfo} 
                                                       onPageInfoChange={this.handlePageInfoChange}
                                                       listThead={this.state.listThead}
                                                       searchSelectOption={this.state.searchSelectOption}
                                                       /> 
                                    : <Detail onRef={ref => (this.detail = ref)} 
                                                onDisplaySetting={this.handleDisplaySetting} 
                                                salesSeq={this.state.salesSeq}/>}
                            </div>
                        </div>
                    </div>
                </div>

            </section>



        );
    }
}

export default connect(mapStateToProps)(Sales);
