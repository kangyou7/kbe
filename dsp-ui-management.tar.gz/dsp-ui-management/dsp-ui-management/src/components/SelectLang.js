import React from 'react';
import { connect } from 'react-redux';
import { changeLangauge } from '../language/Actions';

class SelectLang extends React.Component{

    constructor(props){
        super(props);
    }

    componentDidMount() {
        if ( $('.ui-sel').length > 0 ){
            $('.ui-sel').each(function(){
                $(this).selectric();//초기화
            });	
        }

        let self = this;
        $(".sel_lang").on("change", function(obj){
            self.props.changeLangauge(obj);
        })
        
    }

	render(){
		return (
            <span className="util_lan">
                <select className="ui-sel sel_lang" onChange={this.props.changeLangauge}>
                {/*<select className="ui_sel_black" onChange={this.props.changeLangauge}>*/}
                    <option value="KO">Korean</option>
                    <option value="EN">English</option>
                </select>
                {/*<div className="dropbox_menu dropbox-menu">
					<a href="javascript:;" onClick="javascript:funcLangsDropMenu();" className="btn_open btn-open">Korean</a>
					 <ul class="menu_list">
						<li className="active"><a href="javascript:;" onClick="javascript:funcLangsDropMenuChange($(this));" >Korean</a></li>
						<li><a href="javascript:;" onClick="javascript:funcLangsDropMenuChange($(this));" >English</a></li>
					</ul>
                </div>*/}
            </span>
        );
	}
	
} 

let mapDispatchToProps = (dispatch) => {
    return {
        changeLangauge: (event) => dispatch(changeLangauge(event.target.value))
    };
}

export default connect(undefined, mapDispatchToProps)(SelectLang);