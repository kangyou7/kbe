import React from 'react';

import { Link } from 'react-router';

import ApprovalLineSetting from '../common/ApprovalLineSetting';
import AttachFile from '../common/AttachFile';

import {REST_API_URL} from '../../config/api-config.js';

/*다국어 모듈 시작*/
import { connect } from 'react-redux';
import { changeLangauge, mapStateToProps } from '../../language/Actions';
/*다국어 모듈 종료*/


class ContractTodoDetail extends React.Component {
    constructor(props) {
		super(props);

        this.state = {
            approvalLine : [],

			svcAplcDate : "", //serviceApplicationDt : "",
			splyUsrNo : "", //providerId : "",
			splyUsrName : "",//providerNm
			customerManager : "",
			ctrtStrDate : "", //contractStartDt : "",
			ctrtEndDate : "", //contractEndDt : "",
			svcStrDate : "", //serviceStartDt : "",
			svcEndDate : "", //serviceEndDt : "",
			billingSetleDayCode : "", //chargeType : "",
			billingSetleDayCodeName : "", //chargeTypeNm : "",
			billingMethodCode : "", //chargeApproveDt : "",
			billingMethodCodeName : "", //chargeApproveNm : "",
			billingStrDate : "", //chargeStartDt : "",
			billingEndDate : "", //chargeEndDt : "",
			bizFetuMemoText : "", //salesNothing : "",
			ctrtIssueMemoText : "", //contractIssue : "",
			demndUsrNo : "", //cstmrId : "",
			demndUsrName : "", ///cstmrNm : "",
            customerClasCode : "",
            ceoName : "",
            bizno : "",
            coAddr : "",
            hmpageUrl : "",
            coName : "",
            chargeUsrName : "",
            chargeUsrEmail : "",
            chargeUsrDept : "",
            chargeUsrTel : "",
			chargeUsrMobileNo : "",
			

			nextTcktDlngUsrNo : "",
            ticketNextNm : "",
            ticketNextDept : "",
            ticketNextCblePhonNo : "",
            ticketNextMoblPhonNo : "",
            ticketNextEmail : "",
            ticketNextPositionNm : "",

			productNo : "", //productId : "",
			productName : "", //productNm : "",
            lastSumAmt : "",
            totalSumAmt : "",

            tempSaveYn: "",
			attachFileId : "",
			ctrtDstnctCode : "",

            goods : [],

            files: []
        }
	}
	
	//컴포넌트가 만들어지고 첫 렌더링을 다 마친 후 실행되는 메소드입니다.
	componentDidMount() {
		this.props.onRef(this)
	}

	//컴포넌트가 DOM 에서 사라진 후 실행되는 메소드입니다.
	componentWillUnmount() {
		this.props.onRef(null)
	}

    getContract(ctrtNo) {
        $.ajax({
            url: REST_API_URL + "/contract/getContract",
            dataType: 'json',
            type: "post",
            data: {
                ctrtNo:ctrtNo
            },
            cache: false,
            success: function(result) {
				console.log(result);
				this.setState(result.response.contract);
				if(result.response.contract.productInfo != null) {
					this.setState({
						productName : result.response.contract.productInfo.productName,
						lastSumAmt : result.response.contract.productInfo.lastSumAmt,
						totalSumAmt : ""
					})
				}
            }.bind(this),
            error: function(xhr, status, err) {
              console.log(xhr + " : " + status + " : " + err);
            }.bind(this),
			xhrFields: {
			  withCredentials: true
			}
        });
	}
	
	approval(data) {
		if(data.hdlOpinText == "") {
			alert("의견을 입력하세요");
			return;
		}
		
        $.ajax({
            url: REST_API_URL + "/contract/Approval",
            dataType: 'json',
            type: "post",
            data: data,
            cache: false,
            success: function(result) {
                alert("처리되었습니다.");
                this.props.onApprovalResult();
            }.bind(this),
            error: function(xhr, status, err) {
                alert("오류가 발생하였습니다.");
                console.log(xhr + " : " + status + " : " + err);
            }.bind(this),
			xhrFields: {
			  withCredentials: true
			}
		});
    }
    
    render() {
        const mapToFiles = (data) => {
			return data.map((item, i) => {//map
				return(
					<span className="file_item" key={i}>
						<a href="javascript:;" className="title"><span>{item.originalFileName}</span></a>
					</span>
				);
			});
		}
        return (


			<div id="tab-cont2" className="tab_content tab-cont no_paging">
				{/* S:content_body */}
				<div className="content_body">
					{/* S:content_inner */}
					<div className="content_inner">

						<ApprovalLineSetting onRef={ref => (this.approvalLineSetting = ref)} 
											approvalLine={this.state.approvalLine} 
											isChange={false} 
											isComment={true} 
											isCommentView={true}
											onCommentChange={this.props.onCommentChange}/>

                        <div className="box_com">
                            <div className="fl">
                                <h3 className="ctitle">{this.props.messages.contract_ticket_manager_information}</h3>
                            </div>
                        </div>
						{/* S:Table */}
                        <table className="tbl_row">
                            <caption>티켓 담당자 정보 목록</caption>
                            <colgroup>
                                <col style={{width:'10%'}}/>
                                <col style={{width:'40%'}}/>
                                <col style={{width:'10%'}}/>
                                <col style={{width:'40%'}}/>
                            </colgroup>
                            <tbody>
								<tr>
									<th scope="row">{this.props.messages.contract_name}</th>
									<td className="input" colSpan="3">
										{this.state.ticketNextNm}
									</td>
								</tr>
								<tr>
									<th scope="row">{this.props.messages.contract_e_mail}</th>
									<td className="input">{this.state.ticketNextEmail}</td>
									<th className="row">{this.props.messages.contract_position}</th>
									<td className="input">{this.state.ticketNextPositionNm}</td>
								</tr>
								<tr>
									<th scope="row">{this.props.messages.contract_phone}</th>
									<td className="input">{this.state.ticketNextCblePhonNo}</td>
									<th scope="row">{this.props.messages.contract_cell_phone}</th>
									<td className="input">{this.state.ticketNextMoblPhonNo}</td>
								</tr>
                            </tbody>
                        </table>
                        {/* E:Table */}
						
						<br/>
						<div className="box_com">
							<div className="fl">
								<h3 className="ctitle">{this.props.messages.contract_contract_information}</h3>
							</div>
						</div>
						
						{/* S:Table */}
						<table className="tbl_row">
							<caption>계약 정보 테이블</caption>
							<colgroup>
								<col style={{width:'10%'}}/>
								<col style={{width:'40%'}}/>
								<col style={{width:'10%'}}/>
								<col style={{width:'40%'}}/>
							</colgroup>
							<tbody>
								<tr>
									<th scope="row">{this.props.messages.contract_contract_division} <span className="tc_red">*</span></th>
									<td>{this.state.ctrtDstnctCodeName}</td>
									<th scope="row">{this.props.messages.contract_service_application_date} <span className="tc_red">*</span></th>
									<td>{this.state.svcAplcDate}</td>
								</tr>
								<tr>
									<th scope="row">{this.props.messages.contract_provider} <span className="tc_red">*</span></th>
									<td>{this.state.splyUsrName}</td>
									<th scope="row">{this.props.messages.contract_customer_manager}</th>
									<td>{this.state.customerManager}</td>
								</tr>
								<tr>
									<th scope="row">{this.props.messages.contract_contract_start_date} <span className="tc_red">*</span></th>
									<td>{this.state.ctrtStrDate}</td>
									<th scope="row">{this.props.messages.contract_contract_end_date} <span className="tc_red">*</span></th>
									<td>{this.state.ctrtEndDate}</td>
								</tr>
								<tr>
									<th scope="row">{this.props.messages.contract_service_start_date} <span className="tc_red">*</span></th>
									<td>{this.state.svcStrDate}</td>
									<th scope="row">{this.props.messages.contract_service_end_date} <span className="tc_red">*</span></th>
									<td>{this.state.svcEndDate}</td>
								</tr>
								<tr>
									<th scope="row">{this.props.messages.contract_billing} <span className="tc_red">*</span></th>
									<td>{this.state.billingMethodCodeName}</td>
									<th scope="row">{this.props.messages.contract_billing_date}({this.props.messages.contract_monthly}) <span className="tc_red">*</span></th>
									<td>{this.state.billingSetleDayCodeName}</td>
								</tr>
								<tr>
									<th scope="row">{this.props.messages.contract_billing_start_date} <span className="tc_red">*</span></th>
									<td>{this.state.billingStrDate}</td>
									<th scope="row">{this.props.messages.contract_billing_end_date} <span className="tc_red">*</span></th>
									<td>{this.state.billingEndDate}</td>
								</tr>
								<tr>
									<th scope="row">{this.props.messages.contract_sales_remark}</th>
									<td>{this.state.bizFetuMemoText}</td>
									<th scope="row">{this.props.messages.contract_contract_issue}</th>
									<td>{this.state.ctrtIssueMemoText}</td>
								</tr>
								<tr>
									<th scope="row">{this.props.messages.contract_attached}</th>
									<td className="input" colSpan={3}>
										<AttachFile onRef={ref => (this.attachFile = ref)} 
													attachFileId={this.state.attachFileId} 
													files={this.state.attachFile} 
													onChange={this.handleFileChange} 
													onUploadResult={this.handleContractSave}
													isFileSearch={false}/>
									</td>
								</tr>
							</tbody>
						</table>
						{/* E:Table */}
						
						<div className="box_com">
							<div className="fl">
								<h3 className="ctitle">{this.props.messages.contract_customer_information}</h3>
							</div>
						</div>
						
						{/* S:Table */}
						<table className="tbl_row">
							<caption>고객 정보 테이블</caption>
							<colgroup>
								<col style={{width:'10%'}}/>
								<col style={{width:'40%'}}/>
								<col style={{width:'10%'}}/>
								<col style={{width:'40%'}}/>
							</colgroup>
							<tbody>
								<tr>
									<th scope="row">{this.props.messages.contract_customer_name} <span className="tc_red">*</span></th>
									<td>{this.state.demndUsrName}</td>
									<th scope="row">{this.props.messages.contract_customer_division} <span className="tc_red">*</span></th>
									<td>{this.state.customerClasCodeName}</td>
								</tr>
								<tr>
									<th scope="row">{this.props.messages.contract_representative_1}</th>
									<td>{this.state.ceoName}</td>
									<th scope="row">{this.props.messages.contract_business_number}</th>
									<td>{this.state.bizno}</td>
								</tr>
								<tr>
									<th scope="row">{this.props.messages.contract_address} <span className="tc_red">*</span></th>
									<td>{this.state.coAddr}</td>
									<th scope="row">{this.props.messages.contract_web_url}</th>
									<td>{this.state.hmpageUrl}</td>
								</tr>
								<tr>
									<th scope="row">{this.props.messages.contract_manager_name} </th>
									<td>{this.state.chargeUsrName}</td>
									<th scope="row">{this.props.messages.contract_e_mail} </th>
									<td>{this.state.chargeUsrEmail}</td>
								</tr>
								<tr>
									<th scope="row">{this.props.messages.contract_company_name_1}</th>
									<td>{this.state.coName}</td>
									<th scope="row">{this.props.messages.contract_department}</th>
									<td>{this.state.chargeUsrDept}</td>
								</tr>
								<tr>
									<th scope="row">{this.props.messages.contract_phone}</th>
									<td>{this.state.chargeUsrTel}</td>
									<th scope="row">{this.props.messages.contract_cell_phone} </th>
									<td>{this.state.chargeUsrMobileNo}</td>
								</tr>
							</tbody>
						</table>
						{/* E:Table */}
						
						<div className="box_com">
							<div className="fl">
								<h3 className="ctitle">{this.props.messages.contract_product_information}</h3>
							</div>
						</div>
						
						{/* DESC : 상품 정보 영역 기획 최종 아님. 변경 될 수 있음 */}
						{/* S:상품 결과 있는 경우 */}
						{/* S:Table*/}
						<table className="tbl_row">
							<caption>상품 정보 목록</caption>
							<colgroup>
								<col style={{width:'10%'}}/>
								<col style={{width:'40%'}}/>
								<col style={{width:'10%'}}/>
								<col style={{width:'40%'}}/>
							</colgroup>
							<tbody>
								<tr>
									<th scope="row">상품명</th>
									<td colSpan={3} >
                                        <div className="box_com" style={{marginBottom:'-7px', marginTop:'-7px', marginRight:'-10px'}}>
                                            <div className="fl" style={{marginTop:'5px'}}>
                                                {this.state.productName}
                                            </div>
                                            <div className="fr">
                                                {/*<button type="button" className="tbtn_pos">자세히</button>*/}
                                                {
                                                this.state.productNo != null && this.state.productNo != ''
                                                ?
                                                <Link to={{ pathname: "/popupDetail", query: { item:'product', productNo: this.state.productNo } }} className="tbtn_pos" target="_blank">자세히</Link>
                                                :
                                                ''
                                                }
                                            </div>
                                        </div>
                                    </td>
								</tr>
								<tr>
									<th scope="row">월 과금액</th>
									<td>{this.state.lastSumAmt}</td>
									<th scope="row">계약기간 합계금액</th>
									<td>{this.state.totalSumAmt}</td>
								</tr>
							</tbody>
						</table>
						
						
						{/* E:Table */}
						{/* S:상품 결과 있는 경우 */}
						
						
						
					</div>
					{/* E:content_inner */}
				</div>
				{/* E:content_body */}
				
			</div>



        );
    }
}

export default connect(mapStateToProps)(ContractTodoDetail);
