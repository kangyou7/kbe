import React from 'react';
import { Link } from 'react-router';
import { browserHistory } from 'react-router';

import axios from 'axios';

import VendorList from './VendorList';
import VendorDetail from './VendorDetail';
import BulkUpload from '../common/BulkUpload';

import {REST_API_URL} from '../../config/api-config.js';
/*다국어 모듈 시작*/
import { connect } from 'react-redux';
import { changeLangauge, mapStateToProps } from '../../language/Actions';
/*다국어 모듈 종료*/

class Vendor extends React.Component {
  constructor(props) {
    super(props);

    this.state ={
      assetSeq : "",
      file : null,
      buttonDispladyState : "L",
      listThead : [

        {name:"checkbox",  sort:false, view:true, target:false, checkbox:true, width:'5%'},
        {name:"NO",        sort:false, sortColumn:"rownum", view:true, target:false, width:'5%'},
        {name:props.messages.vendor_vendor_name,  sort:false, sortColumn:"equipVendorName", view:true, target:true, width:'15%'},
        {name:props.messages.vendor_vendor_no,  sort:false, sortColumn:"equipVendorNo", view:true, target:true, width:'15%'},
        {name:props.messages.vendor_business_no,     sort:false, sortColumn:"bizNo", view:true, target:true, width:'15%'},
        {name:props.messages.vendor_total_count_of_equipments,   sort:true, sortColumn:"equipModelCnt", view:true, target:true, width:'15%'},
        {name:props.messages.vendor_registrant,     sort:true, sortColumn:"userName", view:true, target:true, width:'15%'},
        {name:props.messages.vendor_registrantion_date,   sort:true, sortColumn:"regDate", view:true, target:true, width:'15%'}
      ]
    }

    this.handleTabsChange = this.handleTabsChange.bind(this);
    this.handleDetailView = this.handleDetailView.bind(this);
    this.handleExcelDownload = this.handleExcelDownload.bind(this);

    this.handleBulkUploadPopup = this.handleBulkUploadPopup.bind(this);
    this.handleBulkUpload = this.handleBulkUpload.bind(this);
    this.handleBulkUploadSample = this.handleBulkUploadSample.bind(this);
    this.handleBulkFileChange = this.handleBulkFileChange.bind(this);

    this.handleDisplaySetting = this.handleDisplaySetting.bind(this);
    
  }

  handleTabsChange(tab) {

    if(tab === 'Detail') {
      if(this.state.vendorSeq === "") {
        alert("리스트의 벤더 정보를 선택하세요.");
      } else {
        $("#tab-cont1").hide();
        //$(".fr").hide();
        $("#tab-cont2").show();

        $("#groupList").hide();
        $("#groupCreate").show();

        $(".tabs li").eq(0).removeClass('on');
        $(".tabs li").eq(1).addClass('on');

        $(".tabs li").eq(1).find("a").removeClass('disabled');

        this.setState({
          buttonDispladyState : tab
        })
      }
    } else {
      if(this.state.buttonDispladyState != 'L') {
        if (confirm(this.props.messages.user_leave_page)) {
          //location.href="/vendor";
          //browserHistory.push('/vendor');
          this.goVendor();
        } 
      } else {
        // browserHistory.push('/vendor');
        this.goVendor();
      }
      
    }
  }

  goVendor(){
      $("#tab-cont1").show();
      $(".fr").show();
      $("#tab-cont2").hide();
      $(".tabs li").eq(0).addClass('on');
      $(".tabs li").eq(1).removeClass('on');

      $("#groupList").show();
      $("#groupCreate").hide();
      this.handleDisplaySetting('L');
  }
  
  handleDetailView(vendorSeq) {
    this.state.vendorSeq = vendorSeq;
    this.handleTabsChange('Detail');
    this.vendorDetail.getVendor(vendorSeq);
  }

  handleExcelDownload() {
    this.vendorList.getExcelDownload();
  }
  
  componentDidMount() {
    $("#tab-cont1").show();
    $(".fr").show();
    $("#tab-cont2").hide();
  }

  componentWillReceiveProps(nextProps) {
    if(this.props.locale !== nextProps.locale) {
        let listThead = this.state.listThead;

        listThead[2].name = nextProps.messages.vendor_vendor_name;
        listThead[3].name = nextProps.messages.vendor_business_no;
        listThead[4].name = nextProps.messages.vendor_total_count_of_equipments;
        listThead[5].name = nextProps.messages.vendor_registrant;
        listThead[6].name = nextProps.messages.vendor_registrantion_date;
    }
  }

  handleBulkFileChange(file) {
    this.setState({
      file : file
    });
  }

  handleBulkUploadPopup() {
    this.bulkUpload.show();

    this.setState({
      file : null
    });
  }

  handleBulkUpload() {
    console.log(this.state);
    if(this.state.file == null || this.state.file.length < 1) {
      alert("파일을 선택하세요.");
      return;
    }
    this.bulkUpload.uploadButtonToggle();
		let formData = new FormData();

		formData.append("file", this.state.file);
		

		axios.post(REST_API_URL +"/assets/VendorBulkUpload", formData, {withCredentials : true}, {
			headers: { "X-Requested-With": "XMLHttpRequest" },
		})
		.then( response => { 
      if(response.data.response.error != undefined && response.data.response.error) {
        alert("등록 도중 오류가 발생하였습니다. 관리자에게 문의바랍니다.");
      } else {
        if(response.data.response.bulkUploadError === undefined) {
          alert("파일이 등록되었습니다.");
          this.bulkUpload.hide();
          this.vendorList.getList();
        } else {
          
          let msg = "";
          msg += "첨부하신 파일에서 잘못된 정보가 입력되었습니다.\n";
          msg += "파일 수정 후 다시 등록 해 주세요.\n\n";
          msg += "(오류 : ";

          $.each(response.data.response.bulkUploadError, function(i, el) {
            msg += (i == 0 ? "": ", ") + el.rowIndex + "행";
          });
          msg += ")";
          
          alert(msg);
        }
      }
      this.bulkUpload.uploadButtonToggle();
		})
		.catch( response => { console.log(response); this.bulkUpload.uploadButtonToggle(); } );
  }

  handleBulkUploadSample() {
    var form = "<form action='" + REST_API_URL + "/assets/VendorBulkUploadSampleDownload' method='post'>"; 
    form += "</form>"; 
    jQuery(form).appendTo("body").submit().remove();
  }

  handleDisplaySetting(state) {

    console.log(state);


    // if(state === 'T') {
    //   $("#groupList").hide();
    //   $("#groupCreate").show();
    // }

    this.setState({buttonDispladyState : state});
  }

  render() {
    const fncBtnInfo = this.props.memberInfo.dspUserFncBtnInfo;
        return (
          <section className="body">

            <div className="wrapper">

              <div className="page_header">
                <h2 className="ptitle">{this.props.messages.vendor_vendor_status}</h2>
                <div className="page_nav">
                  {/*<ul>
                    <li><a href="/">Home</a></li>
                    <li><a href="/assets">{this.props.messages.assets_management}</a></li>
                    <li className="here">{this.props.messages.vendor_vendor_status}</li>
                  </ul>*/}
                </div>
              </div>
              <div className="content_wrap">

                <div className="content_outbox">

                  <div className="tab_wrap tab-wrap">

                    <div className="box_both tab_header">
                      <div className="fl">
                        <ul className="tabs">
                          <li className="tab_item tab-item on">
                            <a href="javascript:;" onClick={() => {this.handleTabsChange('List')}} className="tab-link"><span>{this.props.messages.common_list}</span></a>
                          </li>
                          <li className="tab_item tab-item">
                            <a href="javascript:;" className="tab-link disabled"><span>{this.props.messages.common_detail}</span></a>
                          </li>
                        </ul>
                      </div>
                      <div className="fr">
                        <div className="btn_group" id="groupList">
                          <button disabled={fncBtnInfo['funcXlxDwldYn']=='N'} type="button" className="ibtn_pos" onClick={this.handleExcelDownload}><i className="ico_btn_xls"></i>{this.props.messages.common_excel_download}</button>
                          <button disabled={fncBtnInfo['funcFileUploadYn']=='N'} type="button" className="ibtn_pos" onClick={this.handleBulkUploadPopup}><i className="ico_btn_write"></i>{this.props.messages.common_bulk_upload}</button>
                        </div>
                        <div className="btn_group" id="groupCreate" style={{display: 'none'}}>
                          <button type="button" className="btn_pos" onClick={() => {this.vendorDetail.handleInitState()}}>{this.props.messages.common_reset}</button>
                          {/* <button type="button" className="btn_pos" onClick={() => {this.handleSave('T')}}>임시저장</button> */}
                          <button disabled={fncBtnInfo['funcModYn']=='N'} type="button" className="btn_black" onClick={() => {this.vendorDetail.handleSave()}}>{this.props.messages.assets_ok}</button>
                        </div>
                      </div>
                    </div>

                    <VendorList onRef={ref => (this.vendorList = ref)} onDetailView={this.handleDetailView} listThead={this.state.listThead}/>

                    <VendorDetail onRef={ref => (this.vendorDetail = ref)} onDisplaySetting={this.handleDisplaySetting}/>

                  </div>

                </div>

              </div>

            </div>

            <BulkUpload onRef={ref => (this.bulkUpload = ref)} onBulkUpload={this.handleBulkUpload} onBulkUploadSample={this.handleBulkUploadSample} onFileChange={this.handleBulkFileChange}/>
          </section>
        );
    }
}

export default connect(mapStateToProps)(Vendor);
