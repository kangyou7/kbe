/*jshint esversion: 6 */
import React from 'react';

import { Link } from 'react-router';
import { browserHistory } from 'react-router';

import Calendar from '../common/Calendar';
import CodeSelect from '../common/CodeSelect';
import AttachFile from '../common/AttachFile';

import {TableThead, TableColgroup} from '../common/TableThead';

import {REST_API_URL} from '../../config/api-config.js';

import ChargeUsrCreate  from '../provider/ChargeUsrCreate';


/*다국어 모듈 시작*/
import { connect } from 'react-redux';
import { changeLangauge, mapStateToProps, actionlogin } from '../../language/Actions';
import { isNull } from 'util';
/*다국어 모듈 종료*/

/* 유효성 체크 */
import validator from 'validator';

const initialState = {
    custmNo : 0,
    custmClasCode : "",
    customerClasCode : "",
    coName : "",
    ceoName : "",
    bizno : "",
    coAddr : "",
    hmpageUrl : "",
    chargeUsrSeq : 0,
    chargeUsrName : "",
    chargeUsrDeptName : "",
    chargeUsrPositName : "",
    chargeUsrEmail : "",
    chargeUsrTel : "",
    chargeUsrMobileNo : "",
    chargeUsrClasCode : "",
    rpsntYn : "",
    files: [],
    attachFile : [],
};

class CustomerCreate extends React.Component {

	constructor(props) {
        super(props);
        
        let { messages } = this.props;

        // this.state = $.extend(true, {}, initialState);
        this.state = {
            custmNo : 0,
            custmClasCode : "",
            customerClasCode : "",
            coName : "",
            ceoName : "",
            bizno : "",
            coAddr : "",
            hmpageUrl : "",
            useYn : "",

            chargeUsrSeq : 0,
            chargeUsrName : "",
            chargeUsrDeptName : "",
            chargeUsrPositName : "",
            chargeUsrEmail : "",
            chargeUsrTel : "",
            chargeUsrMobileNo : "",
            chargeUsrClasCode : "",
            loginUserNo:0,

            files: [],
            attachFile : [],
        };

        this.handleInitState = this.handleInitState.bind(this);
		this.handleChange = this.handleChange.bind(this);
        this.handleFileChange = this.handleFileChange.bind(this);
        this.handlecustomerSave = this.handlecustomerSave.bind(this);
    }

	handleInitState() {
        const init = initialState;

        this.setState($.extend(true, {}, initialState));
    }

    handleSave(temp){
		if(!this.validationChecke()) {
			return;
		}

		if(this.state.files.length > 0) {
			this.attachFile.fileUpload();
		} else {
			this.handlecustomerSave(null);
		}
    }

    handlecustomerSave(attachFile) {

        if(!this.validationChecke()){
            return false;
        }

        //if(attachFile.lenght > 0){
        //    this.setState({
        //        attachFile : attachFile
        //    });
        //}

        let memberInfo = JSON.parse(localStorage.getItem("memberInfo"));
        
        let params ={
            custmNo : this.state.custmNo,
            customerClasCode : this.state.customerClasCode,
            coName : this.state.coName,
            ceoName : this.state.ceoName,
            bizno : this.state.bizno,
            coAddr : this.state.coAddr,
            hmpageUrl : this.state.hmpageUrl,
            chargeUsrSeq : this.state.chargeUsrSeq,
            chargeUsrName : this.state.chargeUsrName,
            chargeUsrDeptName : this.state.chargeUsrDeptName,
            chargeUsrPositName : this.state.chargeUsrPositName,
            chargeUsrEmail : this.state.chargeUsrEmail,
            chargeUsrTel : this.state.chargeUsrTel,
            chargeUsrMobileNo : this.state.chargeUsrMobileNo,
            loginUserNo : memberInfo.user_no,
            attachFile :  attachFile,
        };

        console.log(JSON.stringify(params));

		$.ajax({
			url: REST_API_URL + "/customer/save",
			dataType: 'json',
			type: "post",
			data:  {paramJson : JSON.stringify(params)},
			cache: false,
			processData : true, /*querySTring make false*/
			success: function(result) {
                
                alert("등록 되었습니다.", this.goCustomer());
                
                
			}.bind(this),
				error: function(xhr, status, err) {
                    alert(JSON.stringify(xhr.responseJSON.message));
				console.log(xhr + " : " + status + " : " + err);
			}.bind(this),
            xhrFields: {
              withCredentials: true
            }
        });
        
    }
    goCustomer(){
        browserHistory.push("/customer");
    }

	validationChecke() {
        if(this.state.coName.trim()  == "") {
            alert("고객(사)명을 입력하세요.");
            return false;
        }

        if(this.state.customerClasCode  == "") {
            alert("고객 구분을 선택하세요");
            return false;
        }

        if(this.state.bizno.trim()  == "") {
            alert("사업자번호를 입력 하세요");
            return false;
        }

        if(!validator.isNumeric(this.state.bizno)) {
            alert("사업자번호는 숫자만 입력바랍니다.");
            return false;
        }

        if(this.state.coAddr.trim() == "") {
            alert("주소를 입력하세요.");
            return false;
        }

        if(this.state.chargeUsrName.trim() == "") {
            alert("담당자 이름을 입력하세요.");
            return false;
        }

        if(this.state.chargeUsrEmail.trim() == "") {
            alert("담당자 E-mail을 입력하세요.");
            return false;
        }else {
            if (!validator.isEmail(this.state.chargeUsrEmail)) {
                alert("이메일 형식이 잘못 입력 되었습니다.");
                return false;
            }
        }

        if(this.state.chargeUsrMobileNo.trim() == "") {
            alert("휴대폰 번호를 입력하세요.");
            return false;
        }

        // if(this.state.files.length == 0){
        //     alert("파일을 첨부하세요.");
        //     return false;
        // }

		
		return true;

	}

	handleChange(e) {
		if(e.target.name === "fileUpload") {
            let files = this.state.files;
            
			files.push(e.target.files[0]);
			this.setState({
				files : files
			});
			
		} else {
			let nextState = {};
			nextState[e.target.name]=e.target.value;
			this.setState(nextState);
		}
    }
    
	handleFileChange(files) {
		this.setState({
			files : files
		});
    }
	
	handleFileRemove(key) {
		let {files} = this.state.files;
		files.splice(key, 1);
		this.state.files = files;
    }
    
    //컴포넌트가 만들어지고 첫 렌더링을 다 마친 후 실행되는 메소드입니다.
	componentDidMount() {
        this.props.onRef(this);
        $("#tab-cont1").show();
    }
    
    //컴포넌트가 DOM 에서 사라진 후 실행되는 메소드입니다.
	componentWillUnmount() {
		this.props.onRef(null);
    }

    maxLengthCheck(e){
        e.target.value = e.target.value.replace(/[^0-9]/g,"");
        if(e.target.value.length > e.target.maxLength){
          e.target.value = e.target.value.slice(0, e.target.maxLength);
        }
    }
    
    render() {
        const {custmNo} = this.state;
        const enabled = custmNo > 0 ;
        return (
            <div id="tab-cont3" className="tab_content tab-cont" style={{display:'block'}}>
                {/* S:content_body */}
                <div className="content_body">
                    {/* S:content_inner */}
                    <div className="content_inner">
                    
                        <div className="box_com">
                            <div className="fl">
                                <h3 className="ctitle">
                                    {this.props.messages.customer_detail_title}
                                </h3>
                            </div>
                            <div className="fr">
                                <div className="desc">
                                    <span className="tc_red">*</span> {this.props.messages.contract_reguired}
                                </div>
                            </div>
                        </div>

                        {/* S:Table */}
                        <table className="tbl_row">
                            <caption>{this.props.messages.customer_detail_title}</caption>
                            <colgroup>
                                <col style={{width:'10%'}}/>
                                <col style={{width:'40%'}}/>
                                <col style={{width:'10%'}}/>
                                <col style={{width:'40%'}}/>
                            </colgroup>
                            <tbody>
                                <tr>
                                    <th scope="row">{this.props.messages.customer_name} <span className="tc_red">*</span></th>
                                    <td className="input" colSpan={3}>
                                        <input type="text" className="ui_input" name="coName" value={this.state.coName }  onChange={this.handleChange}/>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">{this.props.messages.clas_code_title} <span className="tc_red">*</span></th>
                                    <td  className="input">
                                        <ul className="ip_list">
                                            <li>
                                                <span className="input_ico_box">
                                                    <input type="radio" name="customerClasCode" id={"customer_rdo_1"} value="01" checked={this.state.customerClasCode === "01"} onChange={this.handleChange}/>
                                                    {<label htmlFor={"customer_rdo_1"}>{this.props.messages.clas_code_01}</label>}
                                                </span>
                                            </li>
                                            <li>
                                                <span className="input_ico_box">
                                                    <input type="radio" name="customerClasCode" id={"customer_rdo_2"}  value="02" checked={this.state.customerClasCode === "02"} onChange={this.handleChange}/>
                                                    {<label htmlFor={"customer_rdo_2"}>{this.props.messages.clas_code_02}</label>}
                                                </span>
                                            </li>
                                        </ul>
                                    </td>
                                    <th scope="row">{this.props.messages.customer_ceo_name}</th>
                                    <td className="input">
                                        <input type="text" className="ui_input" name="ceoName" value={this.state.ceoName } onChange={this.handleChange} maxLength={100} />
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row" >{this.props.messages.customer_bizno}<span className="tc_red">*</span></th>
                                    <td className="input" colSpan={3}>
                                        <input type="text" className="ui_input" name="bizno" value={this.state.bizno}  onChange={this.handleChange} maxLength={50} />
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row" >{this.props.messages.customer_addr} <span className="tc_red">*</span></th>
                                    <td className="input" colSpan={3}>
                                        <input type="text" className="ui_input" name="coAddr" value={this.state.coAddr}  onChange={this.handleChange} maxLength={500}/>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row" >{this.props.messages.customer_weburl} </th>
                                    <td className="input" colSpan={3}>
                                        <input type="text" className="ui_input" name="hmpageUrl" value={this.state.hmpageUrl}  onChange={this.handleChange} maxLength={200} />
                                    </td>
                                </tr>
                                {/* 담당자 영역 */}
                                <tr>
                                    <th scope="row" >{this.props.messages.customer_charge_usr_name} <span className="tc_red">*</span></th>
                                    <td className="input">
                                        <input type="text" className="ui_input" name="chargeUsrName" value={this.state.chargeUsrName}  onChange={this.handleChange} maxLength={100} />
                                    </td>
                                    <th scope="row" >{this.props.messages.customer_charge_usr_email} <span className="tc_red">*</span></th>
                                    <td className="input">
                                        <input type="text" className="ui_input" name="chargeUsrEmail" value={this.state.chargeUsrEmail}  onChange={this.handleChange} maxLength={50} />
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row" >{this.props.messages.customer_charge_usr_dept_name }</th>
                                    <td className="input">
                                        <input type="text" className="ui_input" name="chargeUsrDeptName" value={this.state.chargeUsrDeptName}  onChange={this.handleChange} maxLength={100} />
                                    </td>
                                    <th scope="row" >{this.props.messages.customer_charge_usr_posit_name}</th>
                                    <td className="input">
                                        <input type="text" className="ui_input" name="chargeUsrPositName" value={this.state.chargeUsrPositName}  onChange={this.handleChange} maxLength={100} />
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">{this.props.messages.customer_tel}</th>
                                    <td className="input">
                                        <input type="text" className="ui_input" name="chargeUsrTel" value={this.state.chargeUsrTel} maxLength={20} onChange={this.handleChange} onInput={ this.maxLengthCheck.bind(this)} />
                                    </td>

                                    <th scope="row">{this.props.messages.customer_charge_usr_mobile_no}<span className="tc_red">*</span></th>
                                    <td className="input">
                                        <input type="text" className="ui_input" name="chargeUsrMobileNo" value={this.state.chargeUsrMobileNo} maxLength={20} onChange={this.handleChange} onInput={ this.maxLengthCheck.bind(this)}/>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">{this.props.messages.contract_attached}</th>
                                    <td className="input" colSpan={3}>
                                        <AttachFile onRef={ref => (this.attachFile = ref)} 
                                            files={this.state.files} 
                                            onChange={this.handleFileChange}
                                            setFileExtension={['.jpg', '.pdf', '.jpeg']} 
                                            setFileMaxSize={20} 
                                            onUploadResult={this.handlecustomerSave}
                                            isFileSearch={true}
                                            setLimitCnt={3}
                                        />
                                        <span style={{color:"red"}}>{this.props.messages.customer_file_desc}</span>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                        {/* E:Table */}
                    </div>
                    {/* E:content_inner */}
                    
                </div>
                {/* E:content_body */}
            </div>
        );
    }
}

export default connect(mapStateToProps)(CustomerCreate);

