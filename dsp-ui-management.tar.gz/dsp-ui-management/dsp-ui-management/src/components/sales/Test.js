import React from 'react';
import http from 'http';

/*다국어 모듈 시작*/
import { connect } from 'react-redux';
import { changeLangauge, mapStateToProps } from '../../language/Actions';
/*다국어 모듈 종료*/

class Test extends React.Component {
    constructor(props) {
        super(props);
    
        this.state = {
        }

    }

   
   

    render() {
        return (

            <section className="body">
                
                <div>dfsdfdsfsdfdsfsdfsd</div>
                {console.log(this)}

            </section>



        );
    }
}

export default connect(mapStateToProps)(Test);
