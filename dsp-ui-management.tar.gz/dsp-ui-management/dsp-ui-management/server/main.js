import express from 'express';
import path from 'path';
import url from 'url';

import webpack from 'webpack';
import WebpackDevServer from 'webpack-dev-server';

//import morgan from 'morgan'; // HTTP REQUEST LOGGER
import bodyParser from 'body-parser'; // PARSE HTML BODY

import axios from 'axios';

//import mongoose from 'mongoose';
//import session from 'express-session';

//import api from './routes';

const router = express.Router();

const app = express();
const port = 3000;
const devPort = 8080;

//app.use(morgan('dev'));
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

app.use('/', express.static(path.join(__dirname, './../public')));

/*app.get('/test', function(req,res){
    return res.send('pong');
})*/



app.post('/paymentNoti',function(req,res){
    console.log("결제 결과");

    /*카드, 이체 공통 리턴*/
    console.log("1 " + req.body.Resultcd);				/* 결과코드 */  
    console.log("2 " + req.body.Resultmsg);			    /* 결과메세지 */  
    console.log("3 " + req.body.Svcid);					/* 서비스아이디 */  
    console.log("4 " + req.body.Mobilid);				/* 모빌리언스 거래번호 */
    console.log("5 " + req.body.Signdate);				/* 결제일자 */
    console.log("6 " + req.body.Tradeid);				/* 상점거래번호 */
    console.log("7 " + req.body.Prdtnm);				/* 상품명 */
    console.log("8 " + req.body.Prdtprice);				/* 상품가격 */
    console.log("9 " + req.body.Userid);				/* 사용자ID */
    console.log("10 " + req.body.MSTR);					/* 가맹점 전달 콜백변수 */

    /*카드 리턴*/
    console.log("11 " + req.body.CASH_GB); 				/* 결제수단(CN)*/
    console.log("12 " + req.body.Install);				/* 할부개월 */
    console.log("13 " + req.body.MxHASH);				/* 결과값 검증 hash데이터 */
    console.log("14 " + req.body.Payeremail);			/* 결제자이메일 */
    console.log("15 " + req.body.CardNum);				/* 결제 카드번호 */
    console.log("16 " + req.body.CardCd);				/* 결제 카드코드 */
    console.log("17 " + req.body.CardNm);				/* 결제 카드사명 */

    /*이체 리턴 */
    console.log("18 " + req.body.Mrchid);                 /*[   8byte 고정] 상점ID*/


    /*axios.post('http://localhost:8081/sales/test', { 
            test1: req.body.test1,
            test2: req.body.test2,
            test3: req.body.test3,
            test4: req.body.test4,
            test5: req.body.test5
        }
    )
    .then( response => { console.log(response) } )
    .catch( response => { console.log(response) } );
    */

    
    //res.redirect("/test");

    res.send("ACK=200OKOK")
    
});

app.post('/paymentOk', function(req, res) {
    //완료 화면 호출
    //http:/dfsdfds
    console.log("paymentOk");
    console.log("paymentOk");
    console.log("paymentOk");
    console.log("paymentOk");
    console.log("paymentOk");
    console.log("paymentOk");
});


app.post('/test', function(req, res) {
    console.log("1 " + req.body.test1);
    console.log("2 " + req.body.test2);
    console.log("3 " + req.body.test3);
    console.log("4 " + req.body.test4);
    console.log("5 " + req.body.test5);

    

    /*req.props.location.query = {
        test1 : req.body.test1,
        test2 : req.body.test2,
        test3 : req.body.test3,
        test4 : req.body.test4,
        test5 : req.body.test5
    }*/

    //res.redirect("/test");
    req.query ={
        test1 : req.body.test1,
        test2 : req.body.test2,
        test3 : req.body.test3,
        test4 : req.body.test4,
        test5 : req.body.test5
    };


    

    //res.redirect("/test");
    //res.sendFile(path.resolve(__dirname, './../public/index.html'));

    //get으로 호출됨.
    res.redirect(url.format({
        pathname:"/test",
        query : {
            test1 : req.body.test1,
            test2 : req.body.test2,
            test3 : req.body.test3,
            test4 : req.body.test4,
            test5 : req.body.test5
        }
    }))

});
//심사등록

app.get('*', (req, res) => {
    res.sendFile(path.resolve(__dirname, './../public/index.html'));
});




app.use(function(err, req, res, next) {
  console.error(err.stack);
  res.status(500).send('Something broke!');
});




app.listen(port, () => {
    console.log('Express is listening on port', port);
});


module.exports = router;

if(process.env.NODE_ENV == 'development') {
    console.log('Server is running on development mode');
    const config = require('../webpack.dev.config');
    const compiler = webpack(config);
    const devServer = new WebpackDevServer(compiler, config.devServer);
    devServer.listen(
        devPort, () => {
            console.log('webpack-dev-server is listening on port', devPort);
        }
    );
}
