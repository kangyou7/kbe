import React from 'react';
import { Link } from 'react-router';
import List from './List';
import Detail from './Detail';
import Create from './Create';

/*다국어 모듈 시작*/
import { connect } from 'react-redux';
import { changeLangauge, mapStateToProps } from '../../language/Actions';
/*다국어 모듈 종료*/

class Ticket extends React.Component {
    constructor(props) {
        super(props);
    
        this.state ={
            tcktNo : "",
            displadyState : "L",
            aprvResultCode : "A",
            pageInfo : {}
        }
    
        this.handleDisplaySetting = this.handleDisplaySetting.bind(this);
        this.handleDetailView = this.handleDetailView.bind(this);
        this.handleListReload = this.handleListReload.bind(this);
        this.handleApproval = this.handleApproval.bind(this);
        this.handlePageInfoChange = this.handlePageInfoChange.bind(this);
    }

    handleDisplaySetting(state) {
        if(this.state.displadyState == 'C') {
            if (!confirm("이 페이지에서 나가시겠습니까?\n작성중인 내용이 저장되지 않습니다.")) {
                return;
            }
        } 
        this.setState({displadyState : state});
    }

    componentDidMount() {
        if ( $('.ui-sel').length > 0 ){
            $('.ui-sel').each(function(){
                $(this).selectric();//초기화
            });	
        }

        if(this.props.location.pathname == "/ticketCreate") {
            this.handleDisplaySetting('C');
        } else {
            this.handleDisplaySetting('L');
        }
    }

    componentWillReceiveProps(nextProps) {
        if(nextProps.location.pathname == "/ticketCreate") {
            this.handleDisplaySetting('C');
        } else {
            this.handleDisplaySetting('L');
        }
    }

    handleDetailView(tcktNo, isApproval) {
        //A이면 Complete상태라 승인 할 수있는 승인 버튼 출력하기 위함.
        this.handleDisplaySetting(isApproval ? 'A' : 'D');
        this.setState({
            tcktNo : tcktNo
        });
    }

    handleListReload() {
        //this.handleDisplaySetting('L');
        this.setState({
            displadyState : 'L'
        })
        this.list.getList();
    }

    handlePageInfoChange(pageInfo, reload) {
        this.setState({
            pageInfo : pageInfo
        });

        if(reload) {
            this.list.getList();
        }
    }

    handleApproval(type) {
        if(type == "A") {
            if(!confirm("승인하시겠습니까?")) {
                return;
            } 
        } else {
            return;
        }

        this.detail.approval(this.state);
        
        
    }

    render() {
        return (



            <section className="body">
                
                {/*S:wrapper */}
                <div className="wrapper">
                    
                    {/*S:page_header */}
                    <div className="page_header">
                        <h2 className="ptitle">{this.state.displadyState == 'C' ? this.props.messages.ticket_register_a_ticket : this.props.messages.ticket_ticket_status_1}</h2>
                        <div className="page_nav">
                            {/*<ul>
                                <li><Link to="/">Home</Link></li>
                                <li><a href="javascript:;" onClick={() => this.setState({displadyState:'L'})}>{this.props.messages.ticket_ticket_management}</a></li>
                                <li className="here">{this.state.displadyState == 'C' ? this.props.messages.ticket_register_a_ticket : this.props.messages.ticket_ticket_status_1}</li>
                            </ul>*/}
                        </div>
                    </div>
                    {/*E:page_header */}
                    
                    {/*S:content_wrap */}
                    <div className="content_wrap">
                        {/*S:content_outbox */}
                        <div className="content_outbox">
                            {/*S:tab_wrap */}
                            <div className="tab_wrap tab-wrap">
                                {/*S:tab_header */}
                                <div className="box_both tab_header">		
                                    <div className="fl">
                                        <ul className="tabs">
                                            <li className={this.state.displadyState == 'L' ? "tab_item tab-item on" : "tab_item tab-item"}>
                                                <a href="javascript:;" onClick={() => this.handleDisplaySetting('L')} className="tab-link"><span>{this.props.messages.ticket_list}</span></a>
                                            </li>
                                            <li className={this.state.displadyState != 'L' ? "tab_item tab-item on" : "tab_item tab-item"}>
                                                {/*Com : tab disabled 처리시 스타일 > a영역 disabled 클래스 추가 */}
                                                <a href="javascript:;" className={this.state.displadyState == 'L' ? "tab-link disabled" : "tab-link"}><span>{this.props.messages.ticket_detail}</span></a>
                                            </li>
                                        </ul>
                                    </div>
                                    <div className="fr">
                                        <div className="btn_group" style={this.state.displadyState === 'C' ? {} : {display:'none'}}>
                                            <a href="javascript:;" className="btn_pos" onClick={() => this.create.handleMainEvent('RESET')}>{this.props.messages.ticket_reset}</a>
                                            <a href="javascript:;" className="btn_black" onClick={() => this.create.handleMainEvent('SAVE')}>{this.props.messages.ticket_ok}</a>
                                        </div>
                                        <div className="btn_group" style={this.state.displadyState === 'A' ? {} : {display:'none'}}>
                                            <a href="javascript:;" className="btn_pos" onClick={() => this.setState({displadyState:'L'})}>{this.props.messages.ticket_cancel}</a>
                                            <a href="javascript:;" className="btn_black" onClick={() => {this.handleApproval('A')}}>{this.props.messages.ticket_approval}</a>
                                        </div>
                                    </div>
                                </div>
                                {/*E:tab_header */}
                                
                                {/*S:tab_content 활성화시 display:block/none  */}
                                {this.state.displadyState == 'L' 
                                    ? <List onRef={ref => (this.list = ref)} onDisplaySetting={this.handleDisplaySetting} onDetailView={this.handleDetailView} pageInfo={this.state.pageInfo} onPageInfoChange={this.handlePageInfoChange}/> 
                                    : this.state.displadyState == 'C' 
                                        ? <Create onRef={ref => (this.create = ref)} onDisplaySetting={this.handleDisplaySetting} onListReload={this.handleListReload}/>
                                        : <Detail onRef={ref => (this.detail = ref)} onDisplaySetting={this.handleDisplaySetting} tcktNo={this.state.tcktNo} onListReload={this.handleListReload}/>}
                                {/*E:tab_content  */}	
                                
                                {/*S:tab_content 활성화시 display:block/none  */}
                                
                                {/*E:tab_content  */}	
                            </div>
                            {/*E:tab_wrap */}
                        </div>
                        {/*E:content_outbox */}
                    </div>
                    {/*E:content_wrap */}
                </div>
                {/*E:wrapper */}

            </section>



        );
    }
}

export default connect(mapStateToProps)(Ticket);
