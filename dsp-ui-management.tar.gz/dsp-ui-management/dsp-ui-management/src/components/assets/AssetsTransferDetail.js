import React from 'react';


import ApprovalLineSetting from '../common/ApprovalLineSetting';

import CustomerSearch from '../common/CustomerSearch';
import ModelSearch from '../common/ModelSearch';

import Calendar from '../common/Calendar';
import CodeSelect from '../common/CodeSelect';
import AttachFile from '../common/AttachFile';

import {REST_API_URL} from '../../config/api-config.js';

import axios from 'axios';

/*다국어 모듈 시작*/
import { connect } from 'react-redux';
import { changeLangauge, mapStateToProps } from '../../language/Actions';
/*다국어 모듈 종료*/


class AssetsTransferDetailView extends React.Component {
    constructor(props) {
        super(props);

        this.state = {

            equipTransferDstinctCode : "",

            equipTransferDate : "",

            equipChgContent : "",

            assetsNo : "",

            regDate : ""
            
        }

        this.handleChange = this.handleChange.bind(this);

        this.handleModelSave = this.handleModelSave.bind(this);
        
        this.handleInitState = this.handleInitState.bind(this);
        
    }

    handleInitState() {
		
		//this.setState(this.this.initState);
		this.setState({

            equipTransferClasSeCode : "",

            equipTransferDate : "",

            equipChgContent : ""
		});
	}

    handleChange(e) {
		let nextState = {};
		nextState[e.target.name]=e.target.value;
		this.setState(nextState);
	}
    
    getAssetsTransfer(assetsNo, regDate, equipTransferSeq) {
        
        $.ajax({
            url: REST_API_URL+"/assets/TransferDetail",
            dataType: 'json',
            type: "post",
            data: {
                assetsNo:assetsNo,
                regDate:regDate,
                equipTransferSeq:equipTransferSeq
            },
            xhrFields : {
                withCredentials : true
            },
            success: function(result) {
                this.setState(result.response.transfer);
                this.setState(result.response.assets);
                /*this.setState({
                    regDate : result.response.transfer.regDate
                })*/
                this.setState({
                    regDate : regDate
                })

            }.bind(this),
                error: function(xhr, status, err) {
                console.log(xhr + " : " + status + " : " + err);
            }.bind(this)
        });
    }

	handleModelSave() {

		if (this.validationCheck()) {
            let data = this.state;
            
            let qStr = "변경하시겠습니까?";
            let aStr = "변경되었습니다.";


            let param = new Object();
            param.equipTransferDstinctCode = data.equipTransferDstinctCode;
            param.equipTransferDate = data.equipTransferDate;
            param.equipChgContent = data.equipChgContent;
            param.assetsNo = data.assetsNo;
            param.regDate = data.regDate;
            param.equipTransferSeq = data.equipTransferSeq;

			if (confirm(qStr)) {

                let memberInfo = JSON.parse(localStorage.getItem("memberInfo"));
                param.loginUserNo = memberInfo.user_no;
                
				$.ajax({
					url: REST_API_URL+"/assets/TransferUpdate",
					dataType: 'json',
					type: "post",
					data: {paramJson : JSON.stringify(param)},
					xhrFields : {
                        withCredentials : true
                    },
		
					success: function(result) {
						
						if (result.response == "SUCCESS") {
                            alert(aStr);
                            location.href = "/assetsTransfer";
						} else {
							alert("변경 도중 오류가 발생하였습니다. 관리자에게 문의바랍니다.");
							return;
						}
		
					}.bind(this),
						error: function(xhr, status, err) {
						console.log(xhr + " : " + status + " : " + err);
					}.bind(this)
				});
			}		
		}
	}

	handleSave() {

		this.handleModelSave();
		
    }
    
    handleCancle() {
        location.href = "/assetsTransfer";
    }

	validationCheck() {

		if(this.state.equipTransferDate == "") {
			alert("장비 이관일을 선택해 주세요.");
			return false;
		}
		
		return true;
	}

    componentDidMount() {
        this.props.onRef(this)
		$("#tab-cont2").show();

		this.handleInitState();
    }
    
    componentWillUnmount() {
        this.props.onRef(null)
      }


    render() {

        return (
			<div id="tab-cont2" className="tab_content tab-cont no_paging">
  
                <div className="content_body">

                    <div className="content_inner">
                        <div className="box_com">
                            <div className="fl">
                                <h3 className="ctitle">{this.props.messages.assetstransfer_transferring_information}</h3>
                            </div>
                            <div className="fr">
                                <div className="desc">
                                    <span className="tc_red">*</span> {this.props.messages.assets_required}
                                </div>
                            </div>
                        </div>
                        
                        <table className="tbl_row">
                            <caption>이관 정보 목록</caption>
                            <colgroup>
                                <col style={{width: '10%'}}/>
                                <col style={{width: '40%'}}/>
                                <col style={{width: '10%'}}/>
                                <col style={{width: '40%'}}/>
                            </colgroup>
                            <tbody>
                                {/* <tr>
                                    <th scope="row">{this.props.messages.assetstransfer_requester}</th>
                                    <td className="input">
                                        <input type="text" className="ui_input" value={this.state.transferReqUsrName} onChange={this.handleChange} readOnly/>
                                    </td>
                                    <th scope="row">{this.props.messages.assetstransfer_request_date} <span className="tc_red">*</span></th>
                                    <td className="input">
                                        <div className="date_box">
                                            <Calendar className="ui_cal" 
                                            dateFormat="YYYY-MM-DD"
                                            selected={this.state.equipTransferReqDate}
                                            onChange={(data) => this.setState({equipTransferReqDate: data})}/>
                                        </div>
                                    </td>
                                </tr> */}
                                <tr>
                                    <th scope="row">{this.props.messages.assets_transfer_equipments_division}</th>
                                    <td className="input">
                                        <input type="text" className="ui_input" value={this.state.equipTransferDstinctCode} onChange={this.handleChange} readOnly/>
                                    </td>
                                    <th scope="row">{this.props.messages.assets_transferring_date} <span className="tc_red">*</span></th>
                                    <td className="input">
                                        <div className="date_box">
                                            <Calendar className="ui_cal" 
                                            dateFormat="YYYY-MM-DD"
                                            name="equipTransferDate"
                                            selected={this.state.equipTransferDate}
                                            onChange={(data) => this.setState({equipTransferDate: data})}/>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">{this.props.messages.assets_transfer_comment}</th>
                                    <td className="input" colSpan={3}>
                                        <input type="text" className="ui_input" name="equipChgContent" value={this.state.equipChgContent} onChange={this.handleChange}/>
                                    </td>
                                </tr>
                            </tbody>
                        </table>

                        <div className="box_com">
                            <div className="fl">
                                <h3 className="ctitle">{this.props.messages.assets_information}</h3>
                            </div>
                            <div className="fr">
                                <div className="desc">
                                    <span className="tc_red">*</span> {this.props.messages.assets_required}
                                </div>
                            </div>
                        </div>

                        <table className="tbl_row">
                            <caption>자산 정보 목록</caption>
                            <colgroup>
                                <col style={{width: '10%'}}/>
                                <col style={{width: '40%'}}/>
                                <col style={{width: '10%'}}/>
                                <col style={{width: '40%'}}/>
                            </colgroup>
                            <tbody>
                                <tr>
                                    <th scope="row">{this.props.messages.assets_model_name}</th>
                                    <td className="input">
                                        
                                        {this.state.equipModelName}
                                        
                                    </td>
                                    <th scope="row">{this.props.messages.assets_type}</th>
                                    <td className="input">

                                        {this.state.equipClasName}
                                        
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">{this.props.messages.assets_vendor_name}</th>
                                    <td className="input">

                                        {this.state.equipVendorName}
                                        
                                    </td>
                                    <th scope="row">{this.props.messages.assets_possesion}</th>
                                    <td className="input">
                                        {this.state.assetsOwnerSeNm}
                                        
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">{this.props.messages.assets_serial_no}</th>
                                    <td className="input" colSpan={3}>
                                       {this.state.assetsNatvNoValue}
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">{this.props.messages.assets_license_termination_date}</th>
                                    <td className="input">
                                         {this.state.licExpDate}
                                    </td>
                                    <th scope="row">{this.props.messages.assets_acquisition_date}</th>
                                    <td className="input">
                                        {this.state.getDate}
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">{this.props.messages.assets_acquisition_cost}</th>
                                    <td className="input">
                                        {this.state.getPrice}
                                    </td>
                                    <th scope="row">{this.props.messages.assets_asset_code}</th>
                                    <td className="input">
                                        {this.state.assetsMgmtCode}
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">{this.props.messages.assets_firmware_version}</th>
                                    <td className="input">
                                        {this.state.firmwareVer}
                                    </td>
                                    <th scope="row">{this.props.messages.assets_signature_version}</th>
                                    <td className="input">
                                        {this.state.signatureVer}
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">{this.props.messages.assets_remark}</th>
                                    <td className="input" colSpan={3}>
                                        <textarea className="ui_textarea" readOnly value={this.state.assetsDesc} onChange={this.handleChange}></textarea>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        );
    }
}

export default connect(mapStateToProps)(AssetsTransferDetailView);