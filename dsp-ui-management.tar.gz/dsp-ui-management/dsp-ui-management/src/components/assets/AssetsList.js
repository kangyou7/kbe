import React from 'react';

import { Link } from 'react-router';
import { browserHistory } from 'react-router';

import PagingView from '../common/PagingView';
import ColumnChange from '../common/ColumnChange';
import {TableThead, TableColgroup} from '../common/TableThead';
//import TableThead from '../common/TableThead';

import AssetsStatusChange from './AssetsStatusChange';
import AssetsTransferPopup from './AssetsTransferPopup';

import {REST_API_URL} from '../../config/api-config.js';

/*다국어 모듈 시작*/
import { connect } from 'react-redux';
import { changeLangauge, mapStateToProps } from '../../language/Actions';
/*다국어 모듈 종료*/


class AssetsList extends React.Component {

  constructor(props) {
    super(props);

    this.state = {
      searchKeyCode : "",
      searchKeyWord : "",
      checkedIndex : "",
      checkedAssetsNo : "",
      checkedAssetsStatus : "",
      listThead : [
        {name:"checkbox",  sort:false, view:true, target:false, checkbox:true, width:'5%'},
        {name:"NO",        sort:false, sortColumn:"rownum", view:true, target:false, width:'5%'},
        {name:props.messages.assets_state,  sort:true, sortColumn:"assetsCurStatusSeNm", view:true, target:true, width:'13%'},
        {name:props.messages.assets_possesion,     sort:true, sortColumn:"assetsOwnerSeNm", view:true, target:true, width:'13%'},
        {name:props.messages.assets_type,   sort:true, sortColumn:"equipClasName", view:true, target:true, width:'13%'},
        {name:props.messages.assets_vendor_name,   sort:true, sortColumn:"equipVendorName", view:true, target:true, width:'13%'},
        {name:props.messages.assets_model_name,     sort:true, sortColumn:"equipModelName", view:true, target:true, width:'13%'},
        {name:props.messages.assets_serial_no,   sort:true, sortColumn:"assetsNatvNoValue", view:true, target:true, width:'13%'},
        {name:props.messages.assets_manager,   sort:true, sortColumn:"regUsrNo", view:true, target:true, width:'10%'},
        {name:props.messages.assets_processing_date, sort:true, sortColumn:"runDt", view:true, target:true, width:'12%'}
        // {name:"출고처", sort:true, sortColumn:"wrplResNoCustomerNm", view:true, target:true}
      ],
      list : [],
      pageInfo:{
        //totalCount : 0,
        //perPageNum : 0,
        //page : 0
      }
    }
    this.handleChange = this.handleChange.bind(this);
    this.handleSearch = this.handleSearch.bind(this);
    this.handlePageChange = this.handlePageChange.bind(this);

    this.handleColumnChangeView = this.handleColumnChangeView.bind(this);
    this.handleColumnChange = this.handleColumnChange.bind(this);
    this.handleDetailView = this.handleDetailView.bind(this);
    this.handleSort = this.handleSort.bind(this);
    this.handleDelete = this.handleDelete.bind(this);
    this.handleCheckBoxClick = this.handleCheckBoxClick.bind(this);

    this.handleStatusChangeView = this.handleStatusChangeView.bind(this);
    this.handleStatusdestroy = this.handleStatusdestroy.bind(this);

    this.handleTransferView = this.handleTransferView.bind(this);
    
  }

  handleChange(e) {
    let nextState = {};
    nextState[e.target.name]=e.target.value;
    this.setState(nextState);
  }

  getList() {

    let data = this.state.pageInfo;

    data.loginUserNo = this.props.memberInfo.user_no;
    data.loginUserDstnctCode = this.props.memberInfo.user_dstnct_code;
    
    $.ajax({
      url: REST_API_URL+"/assets/List",
      dataType: 'json',
      type: "post",
      data: data,
      xhrFields : {
        withCredentials : true
      },

      success: function(result) {
        this.setState({
          list: result.response.list,
          pageInfo : result.response.pageInfo
        });

        $("#listChkAll").prop("checked",false);
        $("input[name='listCheck']").prop("checked",false);
        
      }.bind(this),
      error: function(xhr, status, err) {
        console.log(xhr + " : " + status + " : " + err);
      }.bind(this)
    });
  }

  getExcelDownload() {
    var form = "<form action='" + REST_API_URL + "/assets/ExcelDownload' method='post'>"; 
    form += "<input type='hidden' name='sortColumn' value='"+this.state.pageInfo.sortColumn+"' />"; 
    form += "<input type='hidden' name='sortType' value='"+this.state.pageInfo.sortType+"' />"; 
    form += "<input type='hidden' name='searchKeyCode' value='"+this.state.pageInfo.searchKeyCode+"' />"; 
    form += "<input type='hidden' name='searchKeyWord' value='"+this.state.pageInfo.searchKeyWord+"' />"; 

    form += "<input type='hidden' name='loginUserDstnctCode' value='"+this.props.memberInfo.user_dstnct_code+"' />"; 
    form += "</form>"; 
    jQuery(form).appendTo("body").submit().remove(); 
  }

  handleSearch() {
    let pageInfo = this.state.pageInfo;
    pageInfo.searchKeyCode = this.state.searchKeyCode;
    pageInfo.searchKeyWord = this.state.searchKeyWord;
    this.setState({
      pageInfo : pageInfo
    })
    this.getList();
  }



  //페이지 변경 및 페이지 출력 갯수 변경
  handlePageChange(perPageNum, page) {

    let changePage = this.state.pageInfo;
    changePage.perPageNum = perPageNum;
    changePage.page = page;
    this.setState({
      pageInfo:changePage
    })


    this.getList();

  }

  handleSort(sort) {
    let sortPage = this.state.pageInfo;
    sortPage.sortColumn = sort.sortColumn;
    sortPage.sortType = sort.sortType;
    this.setState({
        pageInfo:sortPage
    })

    this.getList();
}


  //항목변경 팝업 호출
  handleColumnChangeView(e) {
    this.columnChange.show();
 }

 //항목변경 팝업에서 항목 변경 후 state 정보 변경
 handleColumnChange(changeThead) {
   this.setState({
     listThead : changeThead
   });
 }

 handleStatusChangeView(e) {
   //console.log($(e.target).hasClass("disabled"));
   if (!$(e.target).hasClass("disabled")) {
    if ($(e.target).attr("id") == "btnStockChange") {
      this.setState({
        checkedAssetsStatus : "stockchange"
      });
    } else {
      this.setState({
        checkedAssetsStatus : "notUse"
      });
    }
  
    this.assetsStatusChange.show();
   }
}

handleStatusdestroy() {
  if ( !$("#btnDestroy").hasClass("disabled") ) {
    let param = new Object();

    param.assetsNo = this.state.list[this.state.checkedIndex].assetsNo;
    param.assetsCurStatusSeCode = this.state.list[this.state.checkedIndex].assetsCurStatusSeCode;
    param.updateAssetStatusCode = 'destroy';
    param.assetsDesc = this.state.list[this.state.checkedIndex].assetsDesc;

    let memberInfo = JSON.parse(localStorage.getItem("memberInfo"));

    param.loginUserNo = memberInfo.user_no;
    
    $.ajax({
        url: REST_API_URL+"/assets/UpdateStatus",
        dataType: 'json',
        type: "post",
        data: {paramJson : JSON.stringify(param)},
        xhrFields : {
          withCredentials : true
        },
        success: function(result) {
          if (result.response == "SUCCESS") {
              alert("폐기처리 되었습니다.");
              this.getList();
          } else {
              alert("폐기처리 중 오류발생.. 관리자에게 문의바랍니다.");
              return;
          }
        }.bind(this),
            error: function(xhr, status, err) {
            console.log(xhr + " : " + status + " : " + err);
        }.bind(this)
    });
  }
}

handleTransferView(e) {
  if (!$("#btnEquipMove").hasClass("disabled") ) {
    this.assetsTransferPopup.show();
  }
}

 handleDetailView(index) {
   this.props.onDetailView(this.state.list[index].assetsNo);
 }
 
 //선택항목 삭제
 handleDelete() {
   var reqParam;
   var checkedAssets = "";

   $("input[name='listCheck']").each(function() {
     if ( $(this).is(":checked") ) {

      if (checkedAssets != "") {
        checkedAssets += "|" + $(this).val();
      } else {
        checkedAssets = $(this).val();
      }
     }
   });

   if (checkedAssets == "") {
     alert("삭제할 대상을 선택하시기 바랍니다.");
   } else {
     if (confirm("삭제하시겠습니까?")) {
      reqParam = new Object();
      reqParam.assetsNo = checkedAssets;
      $.ajax({
        url: REST_API_URL+"/assets/Delete",
        dataType: 'json',
        type: "post",
        data: reqParam,
        xhrFields : {
					withCredentials : true
        },
        success: function(result) {
          console.log(result.response.message);
          if ( result.response.message == "SUCCESS" ) {
            alert("삭제 되었습니다.");
            this.getList();
            return;
          } else {
            alert("ERROR..! 관리자에게 문의 바랍니다.");
            return;
          }
          
        }.bind(this),
        error: function(xhr, status, err) {
          console.log(xhr + " : " + status + " : " + err);
        }.bind(this)
        });
     }
   }
 }

 handleCheckBoxClick(e) {

  
  if ($("input[name='listCheck']:checked").length == 1) {

    var value = "";
    var idx = "";
    var statusCode = "";

    value = $("input[name='listCheck']:checked").val();
    idx = $("input[name='listCheck']:checked").attr("id");
    statusCode = $("input[name='listCheck']:checked").next().next().val();

    this.setState({
      checkedAssetsNo : value,
      checkedIndex : idx
    });
  
     //var statusCode = $(e.target).next().next().val();
     
     if ( statusCode == "join") {
  
        $("#btnStockChange").removeClass("disabled");
        $("#btnNotuse").addClass("disabled");
        $("#btnDestroy").addClass("disabled");
        $("#btnEquipMove").addClass("disabled");
      
      //불용
      //1. 재고상태로 변경가능
      //2. 폐기상태로 변경가능
     } else if ( statusCode == "notUse" ) {
  
        $("#btnStockChange").removeClass("disabled");
        $("#btnNotuse").addClass("disabled");
        $("#btnDestroy").removeClass("disabled");
        $("#btnEquipMove").addClass("disabled");
      
      //서비스
      //1. 재고상태로 변경가능
      //2. 장비이관 가능 -> status 변경은없다.
      } else if ( statusCode == "service" ) {
  
        $("#btnStockChange").removeClass("disabled");
        $("#btnNotuse").addClass("disabled");
        $("#btnDestroy").addClass("disabled");
        $("#btnEquipMove").removeClass("disabled");
      
      //폐기
      //1. status 변경불가
      } else if ( statusCode == "destroy") {
  
        $("#btnStockChange").addClass("disabled");
        $("#btnNotuse").addClass("disabled");
        $("#btnDestroy").addClass("disabled");
        $("#btnEquipMove").addClass("disabled");
      
      //재고
      //1. 불용상태로 변경가능
      } else {
        $("#btnStockChange").addClass("disabled");
        $("#btnNotuse").removeClass("disabled");
        $("#btnDestroy").addClass("disabled");
        $("#btnEquipMove").addClass("disabled");
      }
  } else {
    $("#btnStockChange").addClass("disabled");
    $("#btnNotuse").addClass("disabled");
    $("#btnDestroy").addClass("disabled");
    $("#btnEquipMove").addClass("disabled");
  }
 }


  //페이지 로딩 시 목록 조회
  componentDidMount() {
    this.props.onRef(this)
    this.getList();

    $("#listChkAll").click(function () {
      $("#btnStockChange").addClass("disabled");
      $("#btnNotuse").addClass("disabled");
      $("#btnDestroy").addClass("disabled");
      $("#btnEquipMove").addClass("disabled");
    });
  }

  componentWillUnmount() {
    this.props.onRef(null)
  }

  render() {
    const fncBtnInfo = this.props.memberInfo.dspUserFncBtnInfo;
      const mapToComponent = (data, thead) => {
        if(data.length > 0) {
          return data.map((assets, i) => {//map
            return(<tr key={i}>
              
              <td className="ui_only_chk">
                  <span className="input_ico_box">
                    <input type="checkbox" name="listCheck" id={i} value={assets.assetsNo} onClick={this.handleCheckBoxClick}/>
                    <label htmlFor={i}></label>
                    <input type="hidden" name="assetsCurStatusSeCode" value={assets.assetsCurStatusSeCode}/>
                  </span>
							</td>
              <td style={thead[1].view ? {} : {display:'none'}}>{assets.rownum}</td>
              <td style={thead[2].view ? {} : {display:'none'}}>{assets.assetsCurStatusSeNm}</td>
              <td style={thead[3].view ? {} : {display:'none'}}>{assets.assetsOwnerSeNm}</td>
              <td style={thead[4].view ? {} : {display:'none'}}>{assets.equipClasName}</td>
              <td style={thead[5].view ? {} : {display:'none'}}>{assets.equipVendorName}</td>
              <td style={thead[6].view ? {} : {display:'none'}}><a href="javascript:;" onClick={() => {this.handleDetailView(i);}}>{assets.equipModelName}</a></td>
              <td style={thead[7].view ? {} : {display:'none'}}>{assets.assetsNatvNoValue}</td>
              <td style={thead[8].view ? {} : {display:'none'}}>{assets.regUsrNo}</td>
              <td style={thead[9].view ? {} : {display:'none'}}>{assets.runDt}</td>
              {/* <td style={thead[9].view ? {} : {display:'none'}}>{assets.wrplResNoCustomerNm}</td> */}
            </tr>);
          });
        } else {
          return (
            <tr>
              <td className="noresults" colSpan={9}>
                <div className="box_noresults">
                  <div className="ver_mid">
                    <i className="ico ico_no_result"></i>
                    <span className="lb">{this.props.messages.common_no_data}</span>
                  </div>
                </div>
              </td>
            </tr>
          );
        }
      }

      return (
          <div id="tab-cont1" className="tab_content tab-cont" >

            <div className="content_body">

              <div className="content_inner">


                <div className="box_com term_wrap">
                    {/* <Search onSearch={this.handleSearch}/> */}
                  
                  <div className="fl">
                    <select className="ui_sel" name="searchKeyCode" value={this.state.searchKeyCode} onChange={this.handleChange} >
                      <option value="">{this.props.messages.assets_select}</option>
                      <option value="equipKnd">{this.props.messages.assets_type}</option>
                      <option value="vendorNm">{this.props.messages.assets_vendor_name}</option>
                      <option value="modelNm">{this.props.messages.assets_model_name}</option>
                      <option value="serialNo">{this.props.messages.assets_serial_no}</option>
                  </select>
										<span className="input_search_box" style={{marginLeft: '6px'}}>
                      <input type="text" className="ui_input" name="searchKeyWord" value={this.state.searchKeyWord} onChange={this.handleChange}/>
                      <a id="searchAssets" className="btn_search" href="javascript:void(0);"
                      onClick={this.handleSearch}><span className="offscreen">검색</span></a>
                    </span>

										<span className="gap"></span>
                    <button disabled={fncBtnInfo['funcModYn']=='N'} type="button" className="btn_pos disabled" id="btnStockChange" onClick={this.handleStatusChangeView}>{this.props.messages.assets_conversion_inventory}</button>
                    <button disabled={fncBtnInfo['funcModYn']=='N'} type="button" className="btn_pos disabled" id="btnNotuse" onClick={this.handleStatusChangeView}>{this.props.messages.assets_disuse}</button>
                    <button disabled={fncBtnInfo['funcModYn']=='N'} type="button" className="btn_pos disabled" id="btnDestroy" onClick={this.handleStatusdestroy}>{this.props.messages.assets_discard_equipments}</button>
                    <button disabled={fncBtnInfo['funcModYn']=='N'} type="button" className="btn_pos disabled" id="btnEquipMove" onClick={this.handleTransferView}>{this.props.messages.assets_transfer_equipments}</button>
		
									</div>

                    

                    <div className="fr">
                    <button disabled={fncBtnInfo['funcDelYn']=='N'} type="button" className="btn_pos" id="btnDelete" onClick={this.handleDelete}>{this.props.messages.assets_delete}</button>
                    <Link to="/assetsCreate" className="gnb_link"><button disabled={fncBtnInfo['funcRegYn']=='N'} type="button" className="btn_black">{this.props.messages.assets_registration}</button></Link>
                    <span className="gap"></span>
                    <button type="button" className="btn_pos" onClick={this.handleColumnChangeView}>{this.props.messages.assets_change_item}</button>
                    {/*<ul className="sort_wrap">
                        <li className="active"><button type="button">List</button></li>
                        <li><button type="button">Tree</button></li>
                    </ul>*/}
                    </div>
                </div>


                <table className="tbl_col">
                  <caption>자산 현황 목록</caption>
                  <TableColgroup listThead={this.props.listThead} />
                  <TableThead listThead={this.props.listThead} onSort={this.handleSort}/>

                  <tbody id="contractTbody">

                    {mapToComponent(this.state.list, this.props.listThead)}


                  </tbody>
                </table>

              </div>

            </div>

            <PagingView pageInfo={this.state.pageInfo} onPageChange={this.handlePageChange}/>

            <ColumnChange onRef={ref => (this.columnChange = ref)} listThead={this.props.listThead} onColumnChange={this.handleColumnChange} />
            
            <AssetsStatusChange onRef={ref => (this.assetsStatusChange = ref)} assetsNo={this.state.checkedAssetsNo} checkedAssetsStatus={this.state.checkedAssetsStatus} onStatusChange={this.handleStatusChange}/>
            <AssetsTransferPopup onRef={ref => (this.assetsTransferPopup = ref)} assetsNo={this.state.checkedAssetsNo}/>
          </div>

      );
    }
}


export default connect(mapStateToProps)(AssetsList);
