/*jshint esversion: 6 */
import React, {bindActionCreators} from 'react';
import {REST_API_URL} from '../../config/api-config.js';
import { Map, List } from 'immutable';
/*다국어 모듈 시작*/
import { connect } from 'react-redux';
import { changeLangauge, mapStateToProps, actionlogin } from '../../language/Actions';
/*다국어 모듈 종료*/
class PopupGroup extends React.Component {

    constructor(props) {
        super(props);

        this.state = {
            keyWord:"",
            selectKey:-1,
            response : []
        }

        this.handleChange = this.handleChange.bind(this);
        this.handleSearch = this.handleSearch.bind(this);
    }

    componentDidMount(){
        this.props.onRef(this)
    }

    //컴포넌트가 DOM 에서 사라진 후 실행되는 메소드입니다.
	componentWillUnmount() {
		this.props.onRef(null)
	}

    handleChange(e) {
        let nextState = {};
        nextState[e.target.name]=e.target.value;
        this.setState(nextState);
    }

    handleAuthotSelect(key) {
        $("#authotBody tr").removeClass();
        $("#authotBody tr").eq(key).addClass('selected');
    }

    handleSearch() {
        this.getAuthotGroup();
    }

    
    getAuthotGroup() {
        $.ajax({
            url: REST_API_URL + "/user/group/search",
            dataType: 'json',
            type: "post",
            cache: false,
            data:{'keyWord': this.state.keyWord},
            success: function(result) {
                this.setState({
                    selectKey : -1,
                    response: result.response
                });
            }.bind(this),
            error: function(xhr, status, err) {
                console.log(JSON.stringify(xhr.responseJSON.message));
                console.log(xhr + " : " + status + " : " + err);
            }.bind(this),
            xhrFields: {
              withCredentials: true
            }
        });
    }

    complete() {
        if(this.state.selectKey < 0) {
            alert("선택하세요");
            return;
        }
        let response = this.state.response[this.state.selectKey];

        this.props.onAuthotComplete(response);
        this.hide();
    }

    hide() {
        layer_close(".pop_search_group");
    }

    show(keyWord) {

        let nextState = ({
            keyWord:keyWord,
            selectKey:-1,
            response : []
        });

        this.setState(nextState);
        
        layer_open(".pop_search_group");
    }

    render() {

        const mapToCustm = (data) => {
            if(data.length > 0) {
                return data.map((item, i) => {  //map
                    return(
                        <tr key={i} onClick={() => {this.setState ({selectKey : i}); this.handleAuthotSelect(i)}}
                            onDoubleClick={()=>{this.setState ({selectKey : i}); this.handleAuthotSelect(i); this.complete()}} >
                            <td>{item.groupName}</td>
                            <td>{item.roleName}</td>
                            <td>{item.levelName}</td>
                        </tr>
                    );
                });
            } else {
                return (
                    <tr>
                        <td className="noresults" colSpan={4}>
                            <div className="box_noresults">
                                <div className="ver_mid">													
                                    <i className="ico ico_no_result"></i>
                                    <span className="lb">검색 결과가 없습니다.</span>
                                </div>
                            </div>
                        </td>
                    </tr>
                );
            }
        }

        return(
            <div className="lpopup">
                <div className="dimmed"></div>
                <div className="popup_layer pop_search_group pop-search-group mid">
                    <div className="pop_container">
                        <div className="pop_header">
                            <h1>그룹 검색</h1>
                        </div>
                        {/*pop_contents */}
                        <div className="pop_contents scroll_wrap search_form">
                            {/*pop_inner */}
                            <div className="pop_inner">
                                <div className="psearch_form">
                                    <input type="hidden" />
                                    <input type="text" className="ui_input" name="keyWord" value={this.state.keyWord} onChange={this.handleChange}/>
                                    <a href="javascript:;" className="btn_pos" onClick={this.handleSearch}>검색</a>
                                </div>
                                
                                <table className="tbl_col">
                                    <caption>그룹 검색</caption>
                                    <colgroup>
                                        <col style={{width:'33%'}} />
                                        <col style={{width:'33%'}} />
                                        <col style={{width:'33%'}} />
                                    </colgroup>
                                    
                                    <thead>
                                        <tr>
                                            <th scope="col">그룹명</th>
                                            <th scope="col">Role</th>
                                            <th scope="col">Level</th>
                                        </tr>
                                    </thead>
                                    
                                    <tbody id="authotBody">
                                        {/*S : 리스트 */}
                                        {mapToCustm(this.state.response)}
                                        {/*E : 리스트 */}
                                        
                                    </tbody>
                                </table>
                            </div>
                            {/*// pop_inner */}
                        </div>	
                        {/*// pop_contents*/}
                        <div className="pop_bottom">
                            <button type="button" className="pbtn_black" onClick={() => {this.complete()}}>확인</button>
                        </div>
                    </div>{/*// pop_container */}
                    <a href="javascript:;" onClick={() => {this.hide();}} className="btn_pop_close"><span className="offscreen">닫기</span></a>
                </div>{/*// popup_layer */}
            </div>
        );
    }
}

export default connect(mapStateToProps)(PopupGroup);


