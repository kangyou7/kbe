import React from 'react';

import { Link } from 'react-router';
import { browserHistory } from 'react-router';

import PagingView from '../common/PagingView';
import ColumnChange from '../common/ColumnChange';
import {TableThead, TableColgroup} from '../common/TableThead';
//import TableThead from '../common/TableThead';

import {REST_API_URL} from '../../config/api-config.js';

/*다국어 모듈 시작*/
import { connect } from 'react-redux';
import { changeLangauge, mapStateToProps } from '../../language/Actions';
/*다국어 모듈 종료*/


class CntrlScheduleList extends React.Component {

  constructor(props) {
    super(props);

    this.state = {
      searchKeyCode : "",
      searchKeyWord : "",
      checkedIndex : "",
      checkedCntrlScheNo : "",
      list : [],
      pageInfo:{
        //totalCount : 0,
        //perPageNum : 0,
        //page : 0
      }
    }

    this.handleChange = this.handleChange.bind(this);
    this.handleSearch = this.handleSearch.bind(this);
    this.handlePageChange = this.handlePageChange.bind(this);

    this.handleColumnChangeView = this.handleColumnChangeView.bind(this);
    this.handleColumnChange = this.handleColumnChange.bind(this);
    this.handleDetailView = this.handleDetailView.bind(this);
    this.handleSort = this.handleSort.bind(this);
    this.handleDelete = this.handleDelete.bind(this);
    this.handleCheckBoxClick = this.handleCheckBoxClick.bind(this);
    this.handleCheckAll = this.handleCheckAll.bind(this);
  }

  handleChange(e) {
    let nextState = {};
    nextState[e.target.name]=e.target.value;
    this.setState(nextState);
  }

  getList() {
    
    $.ajax({
      url: REST_API_URL+"/cntrl/List",
      dataType: 'json',
      type: "post",
      data: this.state.pageInfo,
      xhrFields : {
        withCredentials : true
      },
      success: function(result) {
        
        this.setState({
          list: result.response.list,
          pageInfo : result.response.pageInfo
        });
      }.bind(this),
      error: function(xhr, status, err) {
        console.log(xhr + " : " + status + " : " + err);
      }.bind(this)
    });
  }

  getExcelDownload() {
    var form = "<form action='" + REST_API_URL + "/assets/MtnceEntpExcelDownload' method='post'>"; 
    form += "<input type='hidden' name='sortColumn' value='"+this.state.pageInfo.sortColumn+"' />"; 
    form += "<input type='hidden' name='sortType' value='"+this.state.pageInfo.sortType+"' />"; 
    form += "<input type='hidden' name='searchKeyCode' value='"+this.state.pageInfo.searchKeyCode+"' />"; 
    form += "<input type='hidden' name='searchKeyWord' value='"+this.state.pageInfo.searchKeyWord+"' />"; 
    form += "</form>"; 
    jQuery(form).appendTo("body").submit().remove(); 
  }

  handleSearch() {
    let pageInfo = this.state.pageInfo;
    pageInfo.searchKeyCode = this.state.searchKeyCode;
    pageInfo.searchKeyWord = this.state.searchKeyWord;
    this.setState({
      pageInfo : pageInfo
    })
    this.getList();
  }



  //페이지 변경 및 페이지 출력 갯수 변경
  handlePageChange(perPageNum, page) {

    let changePage = this.state.pageInfo;
    changePage.perPageNum = perPageNum;
    changePage.page = page;
    this.setState({
      pageInfo:changePage
    })


    this.getList();

  }

  handleSort(sort) {
    let sortPage = this.state.pageInfo;
    sortPage.sortColumn = sort.sortColumn;
    sortPage.sortType = sort.sortType;
    this.setState({
        pageInfo:sortPage
    })

    this.getList();
}


  //항목변경 팝업 호출
  handleColumnChangeView(e) {
    this.columnChange.show();
 }

 //항목변경 팝업에서 항목 변경 후 state 정보 변경
 handleColumnChange(changeThead) {
   this.setState({
     listThead : changeThead
   });
 }

 handleDetailView(index) {
   this.props.onDetailView(this.state.list[index].cntrlScheNo);
 }
 
 //선택항목 삭제
 handleDelete() {
   var reqParam;
   var checkedSchedule = "";

   $("input[name='listCheck']").each(function() {
     if ( $(this).is(":checked") ) {

      if (checkedSchedule != "") {
        checkedSchedule += "|" + $(this).val();
      } else {
        checkedSchedule = $(this).val();
      }
     }
   });

   if (checkedSchedule == "") {
     alert("삭제할 대상을 선택하시기 바랍니다.");
   } else {
     if (confirm("삭제하시겠습니까?")) {
      reqParam = new Object();
      reqParam.cntrlScheNo = checkedSchedule;
      $.ajax({
        url: REST_API_URL+"/cntrl/Delete",
        dataType: 'json',
        type: "post",
        data: reqParam,
        xhrFields : {
          withCredentials : true
        },
        success: function(result) {
          if ( result.response == "SUCCESS" ) {
            alert("삭제 되었습니다.");
            this.getList();
            return;
          } else {
            alert("ERROR..! 관리자에게 문의 바랍니다.");
            return;
          }
          
        }.bind(this),
        error: function(xhr, status, err) {
          console.log(xhr + " : " + status + " : " + err);
        }.bind(this)
        });
     }
   }
 }

 handleCheckAll(e) {
   console.log(e);
  $("input[name='listCheck']").prop("checked", $(e.target).is(":checked"));
 }

 handleCheckBoxClick(e) {
  this.setState({
    checkedAssetsSeq : $(e.target).val(),
    checkedIndex : $(e.target).attr("id")
  });
}

  //페이지 로딩 시 목록 조회
  componentDidMount() {
    this.props.onRef(this)
    this.getList();
  }

  componentWillUnmount() {
    this.props.onRef(null)
  }

  render() {
    const fncBtnInfo = this.props.memberInfo.dspUserFncBtnInfo;
      const mapToComponent = (data) => {
        if(data.length > 0) {
          return data.map((schedule, i) => {//map

            if (schedule.fileCnt != "0") {
              return(<tr key={i}>
              
                <td className="ui_only_chk">
                    <span className="input_ico_box">
                      <input type="checkbox" name="listCheck" id={i} value={schedule.cntrlScheNo} onClick={this.handleCheckBoxClick}/>
                      <label htmlFor={i}></label>
                    </span>
                </td>
  
                <td>{schedule.rownum}</td>
                <td className="input"><i className="ico_file"></i></td>
                <td><a href="javascript:;" onClick={() => {this.handleDetailView(i);}}>{schedule.scheTitle}</a></td>
                <td>{schedule.regUsrSeq}</td>
                <td>{schedule.regDate}</td>
              </tr>);
            } else {
              return(<tr key={i}>
              
                <td className="ui_only_chk">
                    <span className="input_ico_box">
                      <input type="checkbox" name="listCheck" id={i} value={schedule.cntrlScheNo} onClick={this.handleCheckBoxClick}/>
                      <label htmlFor={i}></label>
                    </span>
                </td>
  
                <td>{schedule.rownum}</td>
                <td></td>
                <td><a href="javascript:;" onClick={() => {this.handleDetailView(i);}}>{schedule.scheTitle}</a></td>
                <td>{schedule.regUsrSeq}</td>
                <td>{schedule.regDate}</td>
              </tr>);
            }
            
          });
        } else {
          return (
            <tr>
              <td className="noresults" colSpan={7}>
                <div className="box_noresults">
                  <div className="ver_mid">
                    <i className="ico ico_no_result"></i>
                    <span className="lb">{this.props.messages.common_no_data}</span>
                  </div>
                </div>
              </td>
            </tr>
          );
        }
      }

      return (
          <div id="tab-cont1" className="tab_content tab-cont" >

            <div className="content_body">

              <div className="content_inner">


                <div className="box_com term_wrap">
                  <div className="fl">
                    <select className="ui_sel" name="searchKeyCode" value={this.state.searchKeyCode} onChange={this.handleChange} >
                      <option value="">{this.props.messages.contract_select}</option>
                      <option value="scheTitle">{this.props.messages.main_title}</option>
                      <option value="regUsrSeq">{this.props.messages.main_writer}</option>
                    </select>
                  </div>
                    <span className="input_search_box" style={{marginLeft: '6px'}}>
                    <input type="text" className="ui_input" name="searchKeyWord" value={this.state.searchKeyWord} onChange={this.handleChange}/>
                    <a id="searchAssets" className="btn_search" href="javascript:void(0);"
                    onClick={this.handleSearch}><span className="offscreen">검색</span></a>
                    </span>

                    <div className="fr">
                    <button disabled={fncBtnInfo['funcDelYn']=='N'} type="button" className="btn_pos" id="btnDelete" onClick={this.handleDelete}>{this.props.messages.cntrl_delete}</button>
                    <Link to="/cntrlScheduleCreate" className="gnb_link"><button disabled={fncBtnInfo['funcRegYn']=='N'} type="button" className="btn_black">{this.props.messages.cntrl_monitoring_schedule_registration}</button></Link>
                    </div>
                </div>


                <table className="tbl_col">
                  <caption>관제 스케줄 관리</caption>
                  <colgroup>
                    <col style={{width : "2%"}}/>
                    <col style={{width : "3%"}}/>
                    <col style={{width : "2%"}}/>
                    <col style={{width : "67%"}}/>
                    <col style={{width : "7%"}}/>
                    <col style={{width : "15%"}}/>
                  </colgroup>
                  <thead>
                    <tr>
                      <th scope="col" className="ui_only_chk">
                          <span className="input_ico_box">
                              <input type="checkbox" name="chk_box" id="listChkAll" onClick={this.handleCheckAll}/>
                              <label htmlFor="listChkAll"></label>
                          </span>
                      </th>
                      <th scope="col">No</th>
                      <th scope="col" className="input"><i className="ico_file"></i></th>
                      <th scope="col">{this.props.messages.cntrl_title}</th>
                      <th scope="col">{this.props.messages.cntrl_registrant}</th>
                      <th scope="col">{this.props.messages.cntrl_registration_date}</th>
                    </tr>
                  </thead>
                  
                  {/* <TableColgroup listThead={this.state.listThead} />
                  <TableThead listThead={this.state.listThead} onSort={this.handleSort}/> */}

                  <tbody id="contractTbody">

                    {mapToComponent(this.state.list)}


                  </tbody>
                </table>

              </div>

            </div>

            <PagingView pageInfo={this.state.pageInfo} onPageChange={this.handlePageChange}/>

            {/* <ColumnChange ref="columnChange" listThead={this.state.listThead} onColumnChange={this.handleColumnChange} /> */}
            
          </div>

      );
    }
}

export default connect(mapStateToProps)(CntrlScheduleList);
