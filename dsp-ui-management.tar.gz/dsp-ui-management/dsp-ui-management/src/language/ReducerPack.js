/*jshint esversion: 6 */
import { CHANGE_LANG } from './Actions';
import { combineReducers } from 'redux';

import languageEN from './en.json';
import languageKO from './ko.json';

const defaultState = {
    language : "KO",
    messages : languageKO
};

const loginState = {
    memberInfo : {
        user_no : null,
        user_name : "",
        user_id : "",
        login_time : "",
        user_cls_code : "",
        custm_no : null,
        mobile_no : "",
        posit_name : "",
        menus:  [
		],
    }
};

const changeLang = (state = defaultState , action) => {

    switch (action.type){
        case 'CHANGE_LANG' :
         /*return $.extend( state, {
            language : action.lang,
            messages : checkLang(action.lang)            
         }); break;*/

         return Object.assign({}, state, {
            language : action.lang,
            messages : checkLang(action.lang)            
         }); break;

         default:
         return state;
    }
}

function checkLang(lang){

    switch(lang){
        case 'KO': return languageKO; break;
        case 'EN': return languageEN; break;
        default: return languageKO; break;
    }
}

const loginAction = ( state = loginState , action ) => {

    const { memberInfo } =  action;

    switch (action.type){
        case 'LOG_IN' :
            let returnValue = $.extend(state, {
                memberInfo : memberInfo
            });
            return returnValue;
            break;
         default:
         return state;
    }
}

const ReducerPack = combineReducers({
    changeLang, 
    loginAction
});

export default ReducerPack;