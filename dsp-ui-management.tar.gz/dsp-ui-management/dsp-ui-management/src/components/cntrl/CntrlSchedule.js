import React from 'react';
import { Link } from 'react-router';
import { browserHistory } from 'react-router';

import axios from 'axios';

import CntrlScheduleList from './CntrlScheduleList';
import CntrlScheduleDetail from './CntrlScheduleDetail';

import {REST_API_URL} from '../../config/api-config.js';

/*다국어 모듈 시작*/
import { connect } from 'react-redux';
import { changeLangauge, mapStateToProps } from '../../language/Actions';
/*다국어 모듈 종료*/


class CntrlSchedule extends React.Component {
  constructor(props) {
    super(props);

    this.state ={
      cntrlScheNo : "",
      file : null,
      buttonDispladyState : "L"
    }

    this.handleTabsChange = this.handleTabsChange.bind(this);
    this.handleDetailView = this.handleDetailView.bind(this);
    this.handleExcelDownload = this.handleExcelDownload.bind(this);

    this.handleDisplaySetting = this.handleDisplaySetting.bind(this);
    
  }

  handleTabsChange(tab) {

    if(tab === 'Detail') {
      if(this.state.vendorSeq === "") {
        alert("리스트의 스케줄을 선택하세요.");
      } else {
        $("#tab-cont1").hide();
        //$(".fr").hide();
        $("#tab-cont2").show();

        $("#groupList").hide();
        $("#groupCreate").show();

        $(".tabs li").eq(0).removeClass('on');
        //$(".tabs li").eq(0).find("a");
        $(".tabs li").eq(1).addClass('on');
        $(".tabs li").eq(1).find("a").removeClass('disabled');
      }
    } else {
      if (confirm("이 페이지에서 나가시겠습니까?\n작성중인 내용이 저장되지 않습니다.")) {
        location.href="/cntrlSchedule";
      }
      // $("#tab-cont1").show();
      // //$(".fr").show();
      // $("#tab-cont2").hide();
      // $(".tabs li").eq(0).addClass('on');
      // $(".tabs li").eq(1).removeClass('on');

      // $("#groupList").show();
      // $("#groupCreate").hide();
      // this.handleDisplaySetting('L');
    }
  }
  
  handleDetailView(cntrlScheNo) {
    this.state.cntrlScheNo = cntrlScheNo;
    this.handleTabsChange('Detail');
    this.cntrlScheduleDetail.getSchedule(cntrlScheNo);
  }

  handleExcelDownload() {
    this.mtnceEntpList.getExcelDownload();
  }
  
  componentDidMount() {
    $("#tab-cont1").show();
    $(".fr").show();
    $("#tab-cont2").hide();
  }


  handleDisplaySetting(state) {

    console.log(state);


    // if(state === 'T') {
    //   $("#groupList").hide();
    //   $("#groupCreate").show();
    // }

    this.setState({buttonDispladyState : state});
  }

  render() {
    const fncBtnInfo = this.props.memberInfo.dspUserFncBtnInfo;
        return (
          <section className="body">

            <div className="wrapper">

              <div className="page_header">
                <h2 className="ptitle">{this.props.messages.cntrl_monitoring_schedule}</h2>
                <div className="page_nav">
                  {/*<ul>
                    <li><a href="/">Home</a></li>
                    <li><a href="/cntrlSchedule">{this.props.messages.cntrl_monitoring_service_management}</a></li>
                    <li className="here">{this.props.messages.cntrl_monitoring_schedule}</li>
                  </ul>*/}
                </div>
              </div>
              <div className="content_wrap">

                <div className="content_outbox">

                  <div className="tab_wrap tab-wrap">

                    <div className="box_both tab_header">
                      <div className="fl">
                        <ul className="tabs">
                          <li className="tab_item tab-item on">
                            <a href="javascript:;" onClick={() => {this.handleTabsChange('List')}} className="tab-link"><span>{this.props.messages.common_list}</span></a>
                          </li>
                          <li className="tab_item tab-item">
                            <a href="javascript:;" className="tab-link disabled"><span>{this.props.messages.common_detail}</span></a>
                          </li>
                        </ul>
                      </div>
                      <div className="fr">
                        <div className="btn_group" id="groupCreate" style={{display: 'none'}}>
                          <button type="button" className="btn_pos" onClick={() => {this.cntrlScheduleDetail.handleInitState()}}>{this.props.messages.common_reset}</button>
                          {/* <button type="button" className="btn_pos" onClick={() => {this.handleSave('T')}}>임시저장</button> */}
                          <button disabled={fncBtnInfo['funcModYn']=='N'}  type="button" className="btn_black" onClick={() => {this.cntrlScheduleDetail.handleSave()}}>{this.props.messages.cntrl_ok}</button>
                        </div>
                      </div>
                    </div>

                    <CntrlScheduleList onRef={ref => (this.cntrlScheduleList = ref)} onDetailView={this.handleDetailView}/>

                    <CntrlScheduleDetail onRef={ref => (this.cntrlScheduleDetail = ref)} onDisplaySetting={this.handleDisplaySetting}/>

                  </div>

                </div>

              </div>

            </div>

          </section>
        );
    }
}

export default connect(mapStateToProps)(CntrlSchedule);
