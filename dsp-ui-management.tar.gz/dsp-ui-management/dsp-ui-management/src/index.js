/*jshint esversion: 6 */
import React from 'react';
import ReactDOM from 'react-dom';
import { Router, Route, IndexRoute, browserHistory } from 'react-router';
import { createStore } from 'redux';
import { Provider } from 'react-redux';

import ReducerPack from './language/ReducerPack';

import LoginPage from './components/LoginPage';
import App from './components/App';
import Main from './Main';
import ErrorPage from './components/ErrorPage';


import Contract from './components/contract/Contract';
import ContractTodo from './components/contract/ContractTodo';
import User from './components/user/User';

import Ticket from './components/ticket/Ticket';
import Product from './components/product/Product';
import Sales from './components/sales/Sales';
import PaymentList from './components/sales/PaymentList';
import PaymentResult from './components/sales/PaymentResult';
import { userInfo } from 'os';
import DspLogin from './components/login/DspLogin';

import Assets from './components/assets/Assets';
import AssetsCreate from './components/assets/AssetsCreate';

import AssetsTransfer from './components/assets/AssetsTransfer';

import AssetsGroupByVendor from './components/assets/AssetsGroupByVendor';

import Vendor from './components/assets/Vendor';
import VendorCreate from './components/assets/VendorCreate';

import ProviderMst from './components/provider/ProviderMst';
import CustomerMst from './components/customer/CustomerMst';

import MtnceEntp from './components/assets/MtnceEntp';
import MtnceEntpCreate from './components/assets/MtnceEntpCreate';
import UserClasRadio from './components/user/UserClasRadio';
import UserConfirm from './components/user/UserConfirm';
import UserList from './components/user/UserList';
import UserCreate from './components/user/UserCreate';
import UserDetail from './components/user/UserDetail';
import AuthGroup from './components/user/AuthGroup';

import CntrlSchedule from './components/cntrl/CntrlSchedule';
import CntrlScheduleCreate from './components/cntrl/CntrlScheduleCreate';

import MonitoringNotice from './components/notice/MonitoringNotice' ;
import MonitoringNoticeCreate from './components/notice/MonitoringNoticeCreate' ;

import ProviderNotice from './components/notice/ProviderNotice'; 
import ProviderNoticeCreate from './components/notice/ProviderNoticeCreate' ;

import ProcessNotice from './components/notice/ProcessNotice'; 
import ProcessNoticeCreate from './components/notice/ProcessNoticeCreate'; 

import PopupDetail from './components/common/PopupDetail';


import Test from './components/sales/Test';
import Test1 from './components/sales/Test1';
import Test2 from './components/sales/Test2';
import Test3 from './components/sales/Test3';

const store = createStore(ReducerPack);

ReactDOM.render(
  <Provider store = {store}>
      <Router history={browserHistory}>
      <Route path="/login" component={DspLogin}/>
      <Route path="/" component={App}>
        <IndexRoute component={Main}/>
        <Route path="/contract" component={Contract}/>
        {/*<Route path="/contract/:type" component={Contract}/>*/}
        <Route path="/contractCreate" component={Contract}/>
        <Route path="/ContractTodo" component={ContractTodo}/>
        <Route path="/userlist" component={UserList}/> {/* 사용자 현황 목록 화면 */}
        <Route path="/userdetail" component={UserDetail}/> {/* 사용자 현황 목록 화면 */}
        <Route path="/usercreate" component={UserCreate}/> {/* 사용자 등록 화면 */}
        <Route path="/userconfirm" component={UserConfirm}/> {/* 사용자 등록 성공 화면 */}
        <Route path="/ticket" component={Ticket}/>
        <Route path="/ticketCreate" component={Ticket}/>
        <Route path="/product" component={Product}/>
        <Route path="/productCreate" component={Product}/>
        <Route path="/sales" component={Sales}/>
        <Route path="/paymentList" component={PaymentList}/>
        <Route path="/assets" component={Assets}/>
        <Route path="/assetsCreate" component={AssetsCreate}/>
        <Route path="/assetsTransfer" component={AssetsTransfer}/>
        <Route path="/vendor" component={Vendor}/>
        <Route path="/vendorCreate" component={VendorCreate}/>
        <Route path="/mtnceEntp" component={MtnceEntp}/>
        <Route path="/mtnceEntpCreate" component={MtnceEntpCreate}/>
        <Route path="/assetsGroupByVendor" component={AssetsGroupByVendor}/>
        <Route path="/cntrlSchedule" component={CntrlSchedule}/>
        <Route path="/cntrlScheduleCreate" component={CntrlScheduleCreate}/>
        <Route path="/monitoringNotice" component={MonitoringNotice}/>
        <Route path="/monitoringNoticeCreate" component={MonitoringNoticeCreate}/>
        <Route path="/providerNotice" component={ProviderNotice}/>
        <Route path="/providerNoticeCreate" component={ProviderNoticeCreate}/>
        <Route path="/processNotice" component={ProcessNotice}/>
        <Route path="/processNoticeCreate" component={ProcessNoticeCreate}/>
        <Route path="/provider" component={ProviderMst}/>
        <Route path="/customer" component={CustomerMst}/>
        <Route path="/group" component={AuthGroup} />
      </Route>
      
      <Route path="/popupDetail" component={PopupDetail}/>
      
      <Route path="/paymentResult" component={PaymentResult} />
      <Route path="/test" component={Test} />
      <Route path="/test1" component={Test1}/>
      <Route path="/test2" component={Test2}/>
      <Route path="/test3" component={Test3}/>
      <Route path="*" component={ErrorPage}/>
    </Router>
  </Provider>
  ,
  document.getElementById('root')
);