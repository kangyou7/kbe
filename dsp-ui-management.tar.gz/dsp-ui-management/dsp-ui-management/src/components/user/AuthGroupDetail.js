/*jshint esversion: 6 */
import React from 'react';

import Calendar from '../common/Calendar';
import CodeSelect from '../common/CodeSelect';
import AttachFile from '../common/AttachFile';

import {TableThead, TableColgroup} from '../common/TableThead';
import { Link, browserHistory } from 'react-router';

import {REST_API_URL} from '../../config/api-config.js';

/*다국어 모듈 시작*/
import { connect } from 'react-redux';
import { changeLangauge, mapStateToProps, actionlogin } from '../../language/Actions';
import { isNull } from 'util';
import { parse } from 'query-string';
/*다국어 모듈 종료*/

class AuthGroupDetail extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            listThead : [
                {name:'', sort:false, sortColumn:'', view:true, target:false, width:'4%'},
                {name:props.messages.auth_group_no,       sort:false, sortColumn:'', view:true, target:true, width:'12%'},
                {name:props.messages.auth_group_clas_name,       sort:false, sortColumn:'', view:true, target:true, width:'12%'},
                {name:props.messages.auth_group_status_name,      sort:false, sortColumn:'', view:true, target:true, width:'12%'},
                {name:props.messages.auth_group_role_name,        sort:false, sortColumn:'', view:true, target:true, width:'12%'},
                {name:props.messages.auth_group_user_name,  sort:false, sortColumn:'', view:true, target:true, width:'12%'},
                {name:props.messages.auth_group_user_id,      sort:false, sortColumn:'', view:true, target:true, width:'12%'},
                {name:props.messages.auth_group_co_name,  sort:false, sortColumn:'', view:true, target:true, width:'12%'},
                {name:props.messages.auth_group_mobile_no,  sort:false, sortColumn:'', view:true, target:true, width:'12%'},
                {name:props.messages.auth_group_reg_date,  sort:false, sortColumn:'', view:true, target:true, width:'12%'},
                {name:props.messages.auth_group_access_date,  sort:false, sortColumn:'', view:true, target:true, width:'12%'},
            ],
            groupSeq: 0,
            groupName: '',
            groupDesc: '',
            roleSeq: 0,
            levelSeq: 0,
            funcRegYn: '',
            funcModYn: '',
            funcDelYn: '',
            funcFileUploadYn: '',
            funcXlxDwldYn: '',
            funcAssignYn: '',
            aprvConfYn:'',
            memberList : [],
            menuList:[
                {groupSeq : this.props.groupSeq, authotSeq : 1, useYn : 'N'},
                {groupSeq : this.props.groupSeq, authotSeq : 2, useYn : 'N'},
                {groupSeq : this.props.groupSeq, authotSeq : 3, useYn : 'N'},
                {groupSeq : this.props.groupSeq, authotSeq : 4, useYn : 'N'},
                {groupSeq : this.props.groupSeq, authotSeq : 5, useYn : 'N'},
                {groupSeq : this.props.groupSeq, authotSeq : 6, useYn : 'N'},
                {groupSeq : this.props.groupSeq, authotSeq : 7, useYn : 'N'},
                {groupSeq : this.props.groupSeq, authotSeq : 8, useYn : 'N'},
                {groupSeq : this.props.groupSeq, authotSeq : 9, useYn : 'N'},
            ],
            checkSave : true 
        };

        this.handleChange = this.handleChange.bind(this);
        this.handleCheck = this.handleCheck.bind(this);

        this.handleCreateComplete = this.handleCreateComplete.bind(this);
        this.handleDeleteUsr = this.handleDeleteUsr.bind(this);

    }

    handleCheck(){
        let groupName = "";
        groupName = this.state.groupName;
        groupName = groupName.trim();

        if(!groupName){
            alert("그룹명을 입력하세요.");
            return false;
        }
        
        $.ajax({
			url: REST_API_URL + '/user/group/check',
			dataType: 'json',
			type: 'post',
			data:  {groupName:groupName},
			cache: false,
			processData : true, /*querySTring make false*/
			success: function(result) {

                if(result.response){
                    alert('사용 가능한 그룹명 입니다.');
                    this.setState({
                        checkSave : true
                    });
                }else{
                    alert('중복된 그룹명 입니다.');
                }
    
			}.bind(this),
				error: function(xhr, status, err) {
				console.log(xhr + ' : ' + status + ' : ' + err);
			}.bind(this),
            xhrFields: {
              withCredentials: true
            }
		});
    }

    handleChange(e) {

        let nextState = {};
        let _param = '';
        _param = e.target.name;
        let _value = e.target.value;
        let _menuList = [];
        
        if(_param == 'menu_all'){
            if($('#'+_param).prop('checked')){
                $('#menu_1').prop('checked',true);
                $('#menu_2').prop('checked',true);
                $('#menu_3').prop('checked',true);
                $('#menu_4').prop('checked',true);
                $('#menu_5').prop('checked',true);
                $('#menu_6').prop('checked',true);
                $('#menu_7').prop('checked',true);
                $('#menu_8').prop('checked',true);
                $('#menu_9').prop('checked',true);
                _menuList = [
                    {groupSeq : this.state.groupSeq, authotSeq : 1, useYn : 'Y'},
                    {groupSeq : this.state.groupSeq, authotSeq : 2, useYn : 'Y'},
                    {groupSeq : this.state.groupSeq, authotSeq : 3, useYn : 'Y'},
                    {groupSeq : this.state.groupSeq, authotSeq : 4, useYn : 'Y'},
                    {groupSeq : this.state.groupSeq, authotSeq : 5, useYn : 'Y'},
                    {groupSeq : this.state.groupSeq, authotSeq : 6, useYn : 'Y'},
                    {groupSeq : this.state.groupSeq, authotSeq : 7, useYn : 'Y'},
                    {groupSeq : this.state.groupSeq, authotSeq : 8, useYn : 'Y'},
                    {groupSeq : this.state.groupSeq, authotSeq : 9, useYn : 'Y'},
                ];
            }else{
                $('#menu_1').prop('checked',false);
                $('#menu_2').prop('checked',false);
                $('#menu_3').prop('checked',false);
                $('#menu_4').prop('checked',false);
                $('#menu_5').prop('checked',false);
                $('#menu_6').prop('checked',false);
                $('#menu_7').prop('checked',false);
                $('#menu_8').prop('checked',false);
                $('#menu_9').prop('checked',false);
                _menuList = [
                    {groupSeq : this.state.groupSeq, authotSeq : 1, useYn : 'N'},
                    {groupSeq : this.state.groupSeq, authotSeq : 2, useYn : 'N'},
                    {groupSeq : this.state.groupSeq, authotSeq : 3, useYn : 'N'},
                    {groupSeq : this.state.groupSeq, authotSeq : 4, useYn : 'N'},
                    {groupSeq : this.state.groupSeq, authotSeq : 5, useYn : 'N'},
                    {groupSeq : this.state.groupSeq, authotSeq : 6, useYn : 'N'},
                    {groupSeq : this.state.groupSeq, authotSeq : 7, useYn : 'N'},
                    {groupSeq : this.state.groupSeq, authotSeq : 8, useYn : 'N'},
                    {groupSeq : this.state.groupSeq, authotSeq : 9, useYn : 'N'},
                ];
            }
            this.setState({
                menuList : _menuList
            });
        }
        else if(_param =='funcAllYn'){
            if($('#'+_param).prop('checked')){
                $('#funcRegYn').prop('checked',true);
                $('#funcModYn').prop('checked',true);
                $('#funcDelYn').prop('checked',true);
                $('#funcFileUploadYn').prop('checked',true);
                $('#funcXlxDwldYn').prop('checked',true);
                $('#funcAssignYn').prop('checked',true);
                nextState = {
                    funcRegYn : 'Y',
                    funcModYn : 'Y',
                    funcDelYn : 'Y',
                    funcFileUploadYn : 'Y',
                    funcXlxDwldYn : 'Y',
                    funcAssignYn : 'Y',
                };
            }else{
                $('#funcRegYn').prop('checked',false);
                $('#funcModYn').prop('checked',false);
                $('#funcDelYn').prop('checked',false);
                $('#funcFileUploadYn').prop('checked',false);
                $('#funcXlxDwldYn').prop('checked',false);
                $('#funcAssignYn').prop('checked',false);
                nextState = {
                    funcRegYn : 'N',
                    funcModYn : 'N',
                    funcDelYn : 'N',
                    funcFileUploadYn : 'N',
                    funcXlxDwldYn : 'N',
                    funcAssignYn : 'N',
                };
            }
            this.setState(nextState);
                
        }else if(_param.indexOf('menu')!=-1){
            let _menuList = this.state.menuList.slice();
            if($('#'+_param).prop('checked')){
                _menuList[_value-1].useYn ='Y';
            }else{
                _menuList[_value-1].useYn='N';
            }
            this.setState({
                menuList : _menuList
            });
        }else if(_param.indexOf('func')!=-1){
            if($('#'+_param).prop('checked')){
                nextState[_param]='Y';
            }else{
                nextState[_param]='N';
            }
            this.setState(nextState);
        }else if(_param=='aprvConfYn'){
            if($('#'+_param).prop('checked')){
                nextState[_param]='Y';
            }else{
                nextState[_param]='N';
            }
            this.setState(nextState);
        }else if(_param=='groupName'){
            nextState={
                checkSave : false,
                groupName : _value
            };
            this.setState(nextState);
        }else{
            nextState[_param]=_value;
            this.setState(nextState);
        }

	}

    componentWillReceiveProps(nextProps) {
        if(this.props.locale !== nextProps.locale) {
            let listThead = this.state.listThead;
            listThead[0].name = '';
            listThead[1].name = nextProps.messages.auth_group_no;
            listThead[2].name = nextProps.messages.auth_group_clas_name;
            listThead[3].name = nextProps.messages.auth_group_status_name;
            listThead[4].name = nextProps.messages.auth_group_role_name;
            listThead[5].name = nextProps.messages.auth_group_user_name;
            listThead[6].name = nextProps.messages.auth_group_user_id;
            listThead[7].name = nextProps.messages.auth_group_co_name;
            listThead[8].name = nextProps.messages.auth_group_mobile_no;
            listThead[9].name = nextProps.messages.auth_group_reg_date;
            listThead[10].name = nextProps.messages.auth_group_access_date;
        }
    }
    
    //컴포넌트가 만들어지고 첫 렌더링을 다 마친 후 실행되는 메소드입니다.
    componentDidMount() {

        if(this.props.location === undefined || this.props.location.query === undefined || this.props.location.query.groupSeq === undefined) {
            this.props.onRef(this);

            this.setState({
                menuList : [
                    {groupSeq : this.props.groupSeq, authotSeq : 1, useYn : 'N'},
                    {groupSeq : this.props.groupSeq, authotSeq : 2, useYn : 'N'},
                    {groupSeq : this.props.groupSeq, authotSeq : 3, useYn : 'N'},
                    {groupSeq : this.props.groupSeq, authotSeq : 4, useYn : 'N'},
                    {groupSeq : this.props.groupSeq, authotSeq : 5, useYn : 'N'},
                    {groupSeq : this.props.groupSeq, authotSeq : 6, useYn : 'N'},
                    {groupSeq : this.props.groupSeq, authotSeq : 7, useYn : 'N'},
                    {groupSeq : this.props.groupSeq, authotSeq : 8, useYn : 'N'},
                    {groupSeq : this.props.groupSeq, authotSeq : 9, useYn : 'N'},
                ],
                checkSave : true
            });
            this.getAuthotGroup(this.props.groupSeq);
        } else {
            this.setState({
                menuList : [
                    {groupSeq : this.props.location.query.groupSeq, authotSeq : 1, useYn : 'N'},
                    {groupSeq : this.props.location.query.groupSeq, authotSeq : 2, useYn : 'N'},
                    {groupSeq : this.props.location.query.groupSeq, authotSeq : 3, useYn : 'N'},
                    {groupSeq : this.props.location.query.groupSeq, authotSeq : 4, useYn : 'N'},
                    {groupSeq : this.props.location.query.groupSeq, authotSeq : 5, useYn : 'N'},
                    {groupSeq : this.props.location.query.groupSeq, authotSeq : 6, useYn : 'N'},
                    {groupSeq : this.props.location.query.groupSeq, authotSeq : 7, useYn : 'N'},
                    {groupSeq : this.props.location.query.groupSeq, authotSeq : 8, useYn : 'N'},
                    {groupSeq : this.props.location.query.groupSeq, authotSeq : 9, useYn : 'N'},
                ],
                checkSave : true
            });
            this.getAuthotGroup(this.props.location.query.groupSeq);
        }
    }

    //컴포넌트가 DOM 에서 사라진 후 실행되는 메소드입니다.
	componentWillUnmount() {
		if(this.props.location === undefined || this.props.location.query === undefined || this.props.location.query.groupSeq === undefined) {
            this.props.onRef(null);
        }
	}

    getAuthotGroup() {

            $.ajax({
                url: REST_API_URL + '/user/group/select',
                dataType: 'json',
                type: 'post',
                data: {groupSeq : parseInt(this.props.groupSeq)},
                cache: false,
                processData : true, /*querySTring make false*/
                success: function(result) {

                    this.props.onDisplaySetting('R');
                    this.setResponseData(result);
                    this.setResponseMenu(result.response.menuList);
                    this.setResponseMember(result.response.memberList);
                    
            }.bind(this),
            error: function(xhr, status, err) {
              console.log(xhr + ' : ' + status + ' : ' + err);
            }.bind(this),
            xhrFields: {
              withCredentials: true
            }
        });
    }

    setResponseData(result){

        this.setState({
            groupSeq: result.response.groupInfo.groupSeq,
            groupName: result.response.groupInfo.groupName,
            groupDesc: result.response.groupInfo.groupDesc,
            roleSeq: result.response.groupInfo.roleSeq,
            levelSeq: result.response.groupInfo.levelSeq,
            funcRegYn: result.response.groupInfo.funcRegYn,
            funcModYn: result.response.groupInfo.funcModYn,
            funcDelYn: result.response.groupInfo.funcDelYn,
            funcFileUploadYn: result.response.groupInfo.funcFileUploadYn,
            funcXlxDwldYn: result.response.groupInfo.funcXlxDwldYn,
            funcAssignYn: result.response.groupInfo.funcAssignYn,
            aprvConfYn : result.response.groupInfo.aprvConfYn,
        });

        if(result.response.groupInfo.funcRegYn=='Y'){
            $('#funcRegYn').prop('checked',true);
        }
        if(result.response.groupInfo.funcModYn=='Y'){
            $('#funcModYn').prop('checked',true);
        }
        if(result.response.groupInfo.funcDelYn=='Y'){
            $('#funcDelYn').prop('checked',true);
        }
        if(result.response.groupInfo.funcFileUploadYn=='Y'){
            $('#funcFileUploadYn').prop('checked',true);
        }
        if(result.response.groupInfo.funcXlxDwldYn=='Y'){
            $('#funcXlxDwldYn').prop('checked',true);
        }
        if(result.response.groupInfo.funcAssignYn=='Y'){
            $('#funcAssignYn').prop('checked',true);
        }
        if(result.response.groupInfo.aprvConfYn=='Y'){
            $('#aprvConfYn').prop('checked',true);
        }
        
    }

    setResponseMenu(result){
        let _result = result.slice();
        if(result.length > 0){
            let _menuList = [];
            _menuList = this.state.menuList.slice();

            for(let i=0; i<_result.length;i++){
                let _index =0;
                let _value ='';
                _value = _result[i].useYn;
                _index = (_result[i].authotSeq)-1;
                if(typeof _value === 'undefined'){
                    _menuList[i].useYn='N';
                }else{
                    _menuList[i].useYn=_value;
                }
                if(_result[i].useYn=='Y'){
                    $('#menu_'+_result[i].authotSeq).prop('checked',true);
                }
            }

            this.setState({
                menuList : _menuList,
            });

            console.log(JSON.stringify(_menuList));
        }
        
    }

    setResponseMember(result){
        this.setState({
            memberList : result,
        });
    }

	handleSave() {

        if(!confirm('변경된 내용을 저장하시겠습니까?')){
            return true;
        }

        if(this.state.checkSave != true){
            alert('그룹명 중복을 확인 하세요.');
            return false;
        }

        if(this.state.roleSeq < 1){
            alert('Role를 선택 하세요.');
            return false;
        }

        if(this.state.levelSeq < 1){
            alert('Level을 선택 하세요.');
            return false;
        }
        
        let { menuList } = this.state;

        let _param = {list : []};

        _param.list = menuList;



		$.ajax({
			url: REST_API_URL + '/user/group/menusave',
			dataType: 'json',
			type: 'post',
			data: { paramJson : JSON.stringify(_param) },
			cache: false,
			processData : true, /*querySTring make false*/
			success: function(result) {
                this.handleSaveFunc();
			}.bind(this),
				error: function(xhr, status, err) {
				console.log(xhr + ' : ' + status + ' : ' + err);
			}.bind(this),
            xhrFields: {
              withCredentials: true
            }
		});
    }

    handleSaveFunc(){
        

        let _param = {};
        _param = {
            groupSeq : this.state.groupSeq,
            groupName : this.state.groupName,
            groupDesc : this.state.groupDesc,
            levelSeq : this.state.levelSeq,
            roleSeq : this.state.roleSeq,
            funcRegYn : this.state.funcRegYn,
            funcModYn : this.state.funcModYn,
            funcDelYn : this.state.funcDelYn,
            funcFileUploadYn : this.state.funcFileUploadYn,
            funcXlxDwldYn : this.state.funcXlxDwldYn,
            funcAssignYn : this.state.funcAssignYn,
            aprvConfYn : this.state.aprvConfYn,
        };

		$.ajax({
			url: REST_API_URL + '/user/group/funcsave',
			dataType: 'json',
			type: 'post',
			data:  _param,
			cache: false,
			processData : true, /*querySTring make false*/
			success: function(result) {
                location.href='/group';
			}.bind(this),
			error: function(xhr, status, err) {
				console.log(xhr + ' : ' + status + ' : ' + err);
			}.bind(this),
            xhrFields: {
              withCredentials: true
            }
		});
    }
    
    //  사용자 그룹 해제후 조회
    handleCreateComplete(){

        let _param = {
            groupSeq : this.state.groupSeq,
            loginUserNo : this.props.memberInfo.user_no,
            dspDefaultTZ : this.props.memberInfo.dspDefaultTZ,
        };
        

        $.ajax({
            url: REST_API_URL + '/user/group/userlist',
            dataType: 'json',
            type: 'post',
            data:  _param,
            cache: false,
            processData : true, /*querySTring make false*/
            success: function(result) {
                this.setState({
                    memberList : result.response
                });
            }.bind(this),
            error: function(xhr, status, err) {
                console.log(xhr + ' : ' + status + ' : ' + err);
            }.bind(this),
            xhrFields: {
                withCredentials: true
            }
		});
    }

    handleDeleteUsr(){
        const _self = this;

        let deleteList = {list:[]};

        $('input[name=chk_box]:checked').each(function(){
            deleteList.list.push({
                userNo : parseFloat($(this).val()),
                groupSeq : _self.state.groupSeq,
                loginUserNo : _self.props.memberInfo.user_no,
            });
        });

        if(deleteList.list.length>0){
            if(!confirm('선택한 항목을 삭제하시겠습니까?')){
                return false;
            }

            console.log();
            $.ajax({
                url: REST_API_URL+'/user/group/userdelete',
                dataType : 'json',
                type : 'POST',
                data : {paramJson : JSON.stringify(deleteList)},
                cache: false,
                success:function(result){
                    alert('삭제 되었습니다.');
                    this.handleCreateComplete();
                }.bind(this),
                error:function(xhr, status, err){
                    console.log(xhr + ' : '+ status +' :' + err);
                }.bind(this),
                xhrFields: {
                  withCredentials: true
                }
            });
        }
        else{
            alert('선택된 사용자가 없습니다.');
        }  
    }

    render() {
        const fncBtnInfo = this.props.memberInfo.dspUserFncBtnInfo;
        const mapToComponent = (data, thead) => {
            if(data.length > 0) {
              return data.map((member, i) => {//map
                return(
                    <tr key={i}>
                        <td className='ui_only_chk'>
                            <span className='input_ico_box'>
                                <input 
                                    type='checkbox' 
                                    name='chk_box' 
                                    id={'ip-chk1-'+member.userNo} 
                                    value={member.userNo}   
                                    />
                                <label htmlFor={'ip-chk1-'+member.userNo}/>
                            </span>
                        </td>
                        <td style={thead[1].view ? {} : {display:'none'}}>{i+1}</td>
                        <td style={thead[2].view ? {} : {display:'none'}}>{member.userDstnctName}</td>
                        <td style={thead[3].view ? {} : {display:'none'}}>{member.userStatusName}</td>
                        <td title={member.roleName} style={thead[4].view ? {} : {display:'none'}}>{member.roleName}</td>
                        <td style={thead[5].view ? {} : {display:'none'}}>{member.userName}</td>
                        <td style={thead[6].view ? {} : {display:'none'}}>{member.userId}</td>
                        <td style={thead[7].view ? {} : {display:'none'}}>{member.coName}</td>
                        <td style={thead[8].view ? {} : {display:'none'}}>{member.mobileNo}</td>
                        <td style={thead[9].view ? {} : {display:'none'}}>{member.regDate}</td>
                        <td style={thead[10].view ? {} : {display:'none'}}>{member.accessDate}</td>
                    </tr>
                );
              });
            } else {
                let colSpan = thead.length;
                for(var i = 0; i<thead.length; i++) {
                    colSpan -= thead[i].view ? 0 : 1;
                }
                return (
                    <tr>
                    <td className='noresults' colSpan={colSpan}>
                        <div className='box_noresults'>
                        <div className='ver_mid'>
                            <i className='ico ico_no_result'></i>
                            <span className='lb'>{this.props.messages.auth_group_there_are_no_results}</span>
                        </div>
                        </div>
                    </td>
                    </tr>
                );
            }
          }
        return (
            <div id='tab-cont3' className='tab_content tab-cont' style={{display:'block'}}>
                {/* S:content_body */}
                <div className='content_body'>
                    {/* S:content_inner */}
                    <div className='content_inner'>
                    
                        <div className='box_com'>
                            <div className='fl'>
                                <h3 className='ctitle'>
                                    {this.props.messages.customer_detail_title}
                                </h3>
                            </div>
                            <div className='fr'>
                                <div className='desc'>
                                    <span className='tc_red'>*</span> {this.props.messages.contract_reguired}
                                </div>
                            </div>
                        </div>

                        {/* S:Table */}
                        <table className='tbl_row'>
                            <caption>기본 정보 목록</caption>
                            <colgroup>
                                <col style={{width:'10%'}}/>
                                <col style={{width:'40%'}}/>
                                <col style={{width:'10%'}}/>
                                <col style={{width:'40%'}}/>
                            </colgroup>
                            <tbody>
                                <tr>
                                    <th scope='row'>{this.props.messages.user_group_registrant}</th>
                                    <td>{this.props.memberInfo.user_name}</td>
                                    <th scope='row'>{this.props.messages.auth_group_name} <span className='tc_red'>*</span></th>
                                    <td className='input'>
                                        <span className='input_btn_box'>
                                            <input type='text' className='ui_input' name='groupName' value={this.state.groupName} onChange={this.handleChange}/>
                                            <button type='button' className='tbtn_pos' onClick={this.handleCheck}>{this.props.messages.auth_validity_check}</button>
                                        </span>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope='row'>{this.props.messages.user_group_information}</th>
                                    <td colSpan={3} className='input'>
                                        <textarea className='ui_textarea' name='groupDesc' value={this.state.groupDesc} onChange={this.handleChange} />
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                        {/* E:Table */}

                        <div className='box_com'>
                            <div className='fl'>
                                <h3 className='ctitle'>{this.props.messages.auth_group_charge_usr_info}</h3>
                            </div>
                            <div className='fr'>
                                <button type='button' className='btn_pos' 
                                    disabled={fncBtnInfo['funcDelYn']=='N'} 
                                    onClick={this.handleDeleteUsr}>{this.props.messages.auth_group_charge_usr_delete}
                                </button>
                            </div>
                        </div>
                        <table className='tbl_col'>
                            <caption>{this.props.messages.auth_group_charge_usr_info}</caption>
                            <TableColgroup listThead={this.state.listThead} />
                            <TableThead listThead={this.state.listThead} onSort={this.handleSort}/>
                            <tbody id='contractTbody'>
                                {mapToComponent(this.state.memberList, this.state.listThead)}
                            </tbody>
                        </table>

                        <div className='box_com'>
                            <div className='fl'>
                                <h3 className='ctitle'>{this.props.messages.user_authorization_information}</h3>
                            </div>
                        </div>
                        {/* S:Table */}
                        <table className='tbl_row'>
                            <caption>권한 정보 목록</caption>
                            <colGroup>
                                <col style={{width:'10%'}}/>
                                <col style={{width:'40%'}}/>
                                <col style={{width:'10%'}}/>
                                <col style={{width:'40%'}}/>
                            </colGroup>
                            <tbody>
                                <tr>
                                    <th scope='row'>Role <span className='tc_red'>*</span></th>
                                    <td className='input'>
                                        <select className="ui_sel" name="roleSeq" value={this.state.roleSeq} onChange={this.handleChange} >
                                            <option value="">{this.props.messages.user_select}</option>
                                            {/* TODO. A0801187 */}
                                            <option value={1}>{this.props.messages.user_system_management}</option>
                                            <option value={2}>{this.props.messages.user_authority_management}</option>
                                            <option value={3}>{this.props.messages.user_contract_management}</option>
                                            <option value={4}>{this.props.messages.user_customer_management}</option>
                                            <option value={5}>Provider</option>
                                            <option value={6}>{this.props.messages.user_customer}</option>
                                            <option value={7}>{this.props.messages.user_sales}</option>
                                        </select>
                                    </td>
                                    <th scope='row'>Level <span className='tc_red'>*</span></th>
                                    <td className='input'>
                                        <select className="ui_sel" name="levelSeq" value={this.state.levelSeq} onChange={this.handleChange} >
                                            {/* Com : disabled처리시 disabled='disabled' 추가 */}
                                            <option value="">{this.props.messages.user_select}</option>
                                            <option value={1}>{this.props.messages.user_team_lead}</option>
                                            <option value={2}>{this.props.messages.user_part_lead}</option>
                                            <option value={3}>{this.props.messages.user_member}</option>
                                        </select>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope='row'>{this.props.messages.user_access_authorization} <span className='tc_red'>*</span></th>
                                    <td colSpan={3} className='input'>
                                        <ul className='ip_list'>
                                            <li>
                                                <span className='input_ico_box'>
                                                    <input type='checkbox' name='menu_all' id='menu_all' onClick={this.handleChange}  />
                                                    <label htmlFor='menu_all'>{this.props.messages.auth_group_all_menu}</label>
                                                </span>
                                            </li>
                                            <li className='f_clear'>
                                                <span className='input_ico_box'>
                                                    <input type='checkbox' name='menu_1' id='menu_1' onChange={this.handleChange} value={1} />
                                                    <label htmlFor='menu_1'>{this.props.messages.gnb_top_menu_contract}</label>
                                                </span>
                                            </li>
                                            <li>
                                                <span className='input_ico_box'>
                                                    <input type='checkbox' name='menu_2' id='menu_2'  onChange={this.handleChange} value={2}/>
                                                    <label htmlFor='menu_2'>{this.props.messages.gnb_top_menu_assets}</label>
                                                </span>
                                            </li>
                                            <li>
                                                <span className='input_ico_box'>
                                                    <input type='checkbox' name='menu_3' id='menu_3' onChange={this.handleChange} value={3}/>
                                                    <label htmlFor='menu_3'>{this.props.messages.gnb_top_menu_product}</label>
                                                </span>
                                            </li>
                                            <li>
                                                <span className='input_ico_box'>
                                                    <input type='checkbox' name='menu_4' id='menu_4' onChange={this.handleChange} value={4}/>
                                                    <label htmlFor='menu_4'>{this.props.messages.gnb_top_menu_ticket}</label>
                                                </span>
                                            </li>
                                            <li>
                                                <span className='input_ico_box'>
                                                    <input type='checkbox' name='menu_5' id='menu_5' value='' onChange={this.handleChange} value={5}/>
                                                    <label htmlFor='menu_5'>{this.props.messages.gnb_top_menu_provider}</label>
                                                </span>
                                            </li>
                                            <li>
                                                <span className='input_ico_box'>
                                                    <input type='checkbox' name='menu_6' id='menu_6' value='' onChange={this.handleChange} value={6}/>
                                                    <label htmlFor='menu_6'>{this.props.messages.gnb_top_menu_cntrlSchedule}</label>
                                                </span>
                                            </li>
                                            <li>
                                                <span className='input_ico_box'>
                                                    <input type='checkbox' name='menu_7' id='menu_7' value='' onChange={this.handleChange} value={7}/>
                                                    <label htmlFor='menu_7'>{this.props.messages.gnb_top_menu_monitoringNotice}</label>
                                                </span>
                                            </li>
                                            <li>
                                                <span className='input_ico_box'>
                                                    <input type='checkbox' name='menu_8' id='menu_8' value='' onChange={this.handleChange} value={8}/>
                                                    <label htmlFor='menu_8'>{this.props.messages.gnb_top_menu_userlist}</label>
                                                </span>
                                            </li>
                                            <li>
                                                <span className='input_ico_box'>
                                                    <input type='checkbox' name='menu_9' id='menu_9' value='' onChange={this.handleChange} value={9}/>
                                                    <label htmlFor='menu_9'>{this.props.messages.gnb_top_menu_sales}</label>
                                                </span>
                                            </li>
                                        </ul>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope='row'>{this.props.messages.user_authorization} <span className='tc_red'>*</span></th>
                                    <td colSpan='3' className='input'>
                                        <ul className='ip_list'>
                                            <li>
                                                <span className='input_ico_box'>
                                                    <input type='checkbox' name='funcAllYn' id='funcAllYn' onChange={this.handleChange} />
                                                    <label htmlFor='funcAllYn'>{this.props.messages.user_all}</label>
                                                </span>
                                            </li>
                                            <li className='f_clear'>
                                                <span className='input_ico_box'>
                                                    <input type='checkbox' name='funcRegYn' id='funcRegYn' onChange={this.handleChange} />
                                                    <label htmlFor='funcRegYn'>{this.props.messages.user_registration1}</label>
                                                </span>
                                            </li>
                                            <li>
                                                <span className='input_ico_box'>
                                                    <input type='checkbox' name='funcModYn' id='funcModYn' onChange={this.handleChange} />
                                                    <label htmlFor='funcModYn'>{this.props.messages.user_modification}</label>
                                                </span>
                                            </li>
                                            <li>
                                                <span className='input_ico_box'>
                                                    <input type='checkbox' name='funcDelYn' id='funcDelYn' onChange={this.handleChange} />
                                                    <label htmlFor='funcDelYn'>{this.props.messages.user_delete}</label>
                                                </span>
                                            </li>
                                            <li>
                                                <span className='input_ico_box'>
                                                    <input type='checkbox' name='funcFileUploadYn' id='funcFileUploadYn' onChange={this.handleChange} />
                                                    <label htmlFor='funcFileUploadYn'>{this.props.messages.contract_file_upload}</label>
                                                </span>
                                            </li>
                                            <li>
                                                <span className='input_ico_box'>
                                                    <input type='checkbox' name='funcXlxDwldYn' id='funcXlxDwldYn' onChange={this.handleChange} />
                                                    <label htmlFor='funcXlxDwldYn'>{this.props.messages.contract_excel_download}</label>
                                                </span>
                                            </li>
                                            <li>
                                                <span className='input_ico_box'>
                                                    <input type='checkbox' name='funcAssignYn' id='funcAssignYn' onChange={this.handleChange} />
                                                    <label htmlFor='funcAssignYn'>{this.props.messages.user_assign}</label>
                                                </span>
                                            </li>
                                        </ul>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope='row'>{this.props.messages.auth_group_approval_authorization} <span className='tc_red'>*</span></th>
                                    <td colSpan='3' className='input'>
                                        <ul className='ip_list'>
                                            <li>
                                                <span className='input_ico_box'>
                                                    <input type='checkbox' name='aprvConfYn' id='aprvConfYn' onChange={this.handleChange} />
                                                    <label htmlFor='aprvConfYn'>{this.props.messages.user_approval}</label>
                                                </span>
                                            </li>
                                        </ul>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                        {/* E:Table */}
                    </div>
                    {/* E:content_inner */}
                </div>
                {/* E:content_body */}
            </div>
        );
    }
}

export default connect(mapStateToProps)(AuthGroupDetail);