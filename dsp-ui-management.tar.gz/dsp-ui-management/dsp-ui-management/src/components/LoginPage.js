import React from 'react';

class LoginPage extends React.Component {
    render() {
        return (
            <div>
                <h2>Login</h2>
            </div>
        );
    }
}

export default LoginPage;
