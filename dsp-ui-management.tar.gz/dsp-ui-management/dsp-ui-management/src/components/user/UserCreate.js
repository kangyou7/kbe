/*jshint esversion: 6 */
import React, { PureComponent  } from 'react';
import { Link, browserHistory } from 'react-router';
import PropTypes from 'prop-types';

import UserClasRadio from './UserClasRadio';

import PopupCustm from '../common/PopupCustm';

import { connect } from 'react-redux';
import { changeLangauge, mapStateToProps, actionlogin } from '../../language/Actions';

import { Map, List } from 'immutable';
import { REST_API_URL } from '../../config/api-config.js';
import { REST_AUTH_URL } from '../../config/api-config.js';

const initializationState = {
  data : Map({
    mode : 'none',
    userNo : 0,
    userName : "",
    userClasCode : "03",
    userEmail : "",
    pwd : "",
    newPwd : "",
    custmNo : 0,
    coName : "",
    userdeptNo  : "",
    posit  : "",
    title  : "",
    coTel  : "",
    mobileNo  : "",
    userStatusCode  : "",
    acsExpDate  : "",
    useYn  : "",
    regUsrNo  : "",
    userId  : "",
    expirationToken  : "",
    duplicate : "none",
    user_dstnct_code : "",
  })
};


class UserCreate extends PureComponent {

  constructor(props) {
    super(props);
    this.state = $.extend(true, {}, initializationState);

    this.handleChange = this.handleChange.bind(this);
    this.checkDuplicate = this.checkDuplicate.bind(this);
    this.handleCustmComplete = this.handleCustmComplete.bind(this);
    this.handleUserSave = this.handleUserSave.bind(this);
    this.handleResetClick = this.handleResetClick.bind(this);
  }

  componentDidMount(){
    this.handleResetClick();
  }

  handleResetClick(){
    this.state = $.extend(true, {}, initializationState);
    let {data} = this.state;
    let {user_dstnct_code} = JSON.parse(localStorage.getItem('memberInfo'));

    console.log("로그인 사용자 레벨 "+user_dstnct_code);
    if(user_dstnct_code == '01'){
      this.setState({
       data : data.set('userClasCode','01').set('user_dstnct_code','01'),
      });
    }
    console.log(JSON.stringify(this.state));
    this.forceUpdate();
  }

  handleCustmComplete(response){
    const {data} = this.state;
    this.setState({
      data:data.set('coName', response.coName).set('custmNo',response.custmNo).set('mode','insert')
    });
  }

  handleChange(e){
    const {data} = this.state;

    console.log(e.target.name +":"+e.target.value);
    if(e.target.name === 'userClasCode'){
      const {value} = e.target;
      this.setState({
        data: data.set('userClasCode', value).set('mode','insert')
      });
    }
    else if(e.target.name==='userId'){
      this.setState({
      data: data.set('userId',  e.target.value).set('mode','insert').set('duplicate','none')
    });
    }
     else{
      this.setState({
        data: data.set(e.target.name,  e.target.value).set('mode','insert')
      });
    }
  }

  maxLengthCheck(e){
    e.target.value = e.target.value.replace(/[^0-9]/g,"");

    if(e.target.value.length > e.target.maxLength){
      e.target.value = e.target.value.slice(0, e.target.maxLength);
    }
  }

  handleUserSave() {
    let memberInfo = JSON.parse(localStorage.getItem("memberInfo"));
    const {data} = this.state;
    console.log("전달 파라미터 : "+JSON.stringify(data));

    if(!this.validationCheck()){
      return false;
    }

    let _param = {
      userNo : data.get("userNo"),
      userName :data.get("userName"),
      userClasCode : data.get("userClasCode"),
      userEmail : data.get("userEmail"),
      pwd : data.get("pwd"),
      custmNo : data.get("custmNo"),
      userdeptNo  : data.get("userdeptNo"),
      posit  : data.get("posit"),
      title  : data.get("title"),
      coTel  : data.get("coTel"),
      mobileNo  : data.get("mobileNo"),
      userStatusCode  : data.get("userStatusCode"),
      regUsrNo  : memberInfo.user_no,
      userId  : data.get("userId"),
    };
    
    $.ajax({
      url: REST_AUTH_URL+"/insert",
      dataType : "json",
      type : "POST",
      data:  _param,
      cache: false,
      xhrFields: { withCredentials: true },
      success:function(result){
          browserHistory.push("/userconfirm");
      }.bind(this),
      error:function(xhr, status, err){
        console.log(JSON.stringify(xhr) + " : "+ JSON.stringify(status) +" :" + JSON.stringify(err));
      }.bind(this),
    });
  }

  checkDuplicate(){
    let param = this.state.data.get('userId');

    if(!param){
      alert('아이디를 등록하세요.');
      return false;
    }

    const {data} = this.state;
    console.log(param);

    $.ajax({
      url: REST_API_URL+"/user/check",
      dataType : "json",
      type : "POST",
      data : {userEmail : param},
      cache: false,
      xhrFields: { withCredentials: true },
      success:function(result){
        console.log(result.response);

        this.setState({
          data:data.set('duplicate', result.response)
        });

      }.bind(this),
      error:function(xhr, status, err){
        console.log(xhr + " : "+ status +" :" + err);
      }.bind(this),
    });
  }
  
  validationCheck(){
    const {data} = this.state;
    const email = data.get('userId');
    const pwd = data.get('pwd');
    const newPwd = data.get('newPwd');
    const custmNo = data.get('custmNo');
    const coTel = data.get('coTel');
    const mobileNo = data.get('mobileNo');
    const duplicate = data.get('duplicate');

    const userName = data.get('userName');

    const userClasCode = data.get('userClasCode');

    const password_pattern = /^(?=(.*\d){1})(.*\S)(?=.*[a-zA-Z\S])[0-9a-zA-Z\S]{10,}$/;  // 영문 숫자 특수문자 1개 이상 10자리까지
    const consecutive_str = /(\w)\1\1\1/; //  연속된 3자리 (숫자 && 문자)
    const email_pattern = /^(([^<>()\[\]\.,;:\s@\"]+(\.[^<>()\[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()\.,;\s@\"]+\.{0,1})+[^<>()\.,;:\s@\"]{2,})$/; //  email 형식
    
    if(!userName.trim()){
      alert('이름을 입력하세요.');
      return false;
    }

    if(!email.trim()){
      console.log(email);
      alert('ID를 입력하세요.');
      return false;
    }else{
      if(!email_pattern.test(email)){
        alert("ID는 이메일 형식으로 입력하세요.");
        return false;
      }
      if(duplicate!==true){
        alert("ID 중복을 확인하세요.");
        return false;
      }
    }

    //  "", null, undefined, 0, NaN ==> false
    if(!pwd){
      alert('비밀번호를 입력하세요.');
      return false;
    }
    else if(!newPwd){
      alert("입력하신 비밀번호를 확인하세요.");
      return false;
    }
    else{
      if(!password_pattern.test(pwd)){
        alert("비밀번호는 연속된 숫자 또는 문자열을 사용하여 입력하실 수 없으며 10자리, 영문+숫자+특수문자 조합으로 ID와 다르게 입력해주시기 바랍니다.");
        return false;
      }
      if(consecutive_str.test(pwd)){
        alert("비밀번호는 연속된 숫자 또는 문자열을 사용하여 입력하실 수 없으며 10자리, 영문+숫자+특수문자 조합으로 ID와 다르게 입력해주시기 바랍니다.");
        return false;
      }
      if(!this.stck(pwd, 3)){
        alert("비밀번호는 연속된 숫자 또는 문자열을 사용하여 입력하실 수 없으며 10자리, 영문+숫자+특수문자 조합으로 ID와 다르게 입력해주시기 바랍니다.");
        return false;
      }
      if(newPwd!==pwd){
        alert("비밀번호와 비밀번호 확인 정보가 일치하지 않습니다.");
        return false;
      }
    }

    if(userClasCode!='03'){
      if(custmNo < 1){
        alert('회사를 선택하세요.');
        return false;
      }
    }
    if(!mobileNo.trim()){
      alert("휴대폰 번호를 입력하세요.");
      return false;
    }

    console.log('check 완료');

    return true;
  }

  //연속된 문자 카운트
  stck(str, limit) {
    let o, d, p, n = 0, l = limit == null ? 4 : limit;

    for (var i = 0; i < str.length; i++) {
      var c = str.charCodeAt(i);
      if (i > 0 && (p = o - c) > -2 && p < 2 && (n = p == d ? n + 1 : 0) > l - 3) 
        return false;
      d = p, o = c;
    }
    return true;
  }
  render(){
    const fncBtnInfo = this.props.memberInfo.dspUserFncBtnInfo;

    const { data } = this.state;
    const { handleChange } = this;
    const { checkDuplicate } = this;
    const { handleUserSave } = this;
    const { handleResetClick } = this;

    const memberInfo = storage.get('memberInfo');

    const userNo = data.get('userNo');
    const userClasCode = data.get('userClasCode');
    const userName = data.get('userName');
    const userEmail = data.get('userId');
    const pwd = data.get('pwd');
    const newPwd = data.get('newPwd');
    const custmNo = data.get('custmNo');
    const coName = data.get('coName');
    const dept = data.get('dept');
    const posit = data.get('posit');
    const title = data.get('title');
    const coTel = data.get('coTel');
    const mobileNo = data.get('mobileNo');
    const userStatusCode = data.get('userStatusCode');
    const acsExpDate = data.get('acsExpDate');
    const useYn = data.get('useYn');
    const regUsrNo = data.get('regUsrNo');
    const userId = data.get('userId');
    const expirationToken = data.get('expirationToken');
    const duplicate = data.get('duplicate');
    
    return(
      <section className="body">
      <div className="wrapper">
        <div className="page_header">
          <h2 className="ptitle">{this.props.messages.user_registration}</h2>
          <div className="page_nav">
            {/*<ul>
              <li><Link to="/">Home</Link></li>
              <li><Link to="/userlist">{this.props.messages.user_management}</Link></li>
              <li className="here">{this.props.messages.user_registration}</li>
            </ul>*/}
          </div>
        </div>
        <div className="content_wrap">
          <div className="content_outbox">
            <div className="tab_wrap tab-wrap">
              <div className="box_both tab_header">
                <div className="fl">
                  <ul className="tabs">
                    <li className="tab_item tab-item on">
                      <a href="#tab-cont2" onClick="" className="tab-link"><span>{this.props.messages.user_detail}</span></a>
                    </li>
                  </ul>
                </div>
                <div className="fr">
                  <div className="btn_group">
                    <button className="btn_pos" onClick={handleResetClick}>{this.props.messages.user_reset}</button>
                    <button className="btn_black" 
                            onClick={handleUserSave}
                            // disabled={fncBtnInfo['funcRegYn']=='N'} 
                            disabled={duplicate === false ? true :fncBtnInfo['funcRegYn']=='N'?true:''} >{this.props.messages.user_ok}</button>
                  </div>
                </div>
              </div>

              <div id="tab-cont1" className="tab_content tab-cont no_paging" style={{display:'block'}}>
                <div className="content_body">
                  <div className="content_inner">
                    <div className="box_com">
                      <div className="fl">
                        <h3 className="ctitle">{this.props.messages.user_user_information}</h3>
                        <span className="gap"></span>
                        <span className="guide">{this.props.messages.user_approval1}</span>
                      </div>
                      <div className="fr">
                        <div className="desc">
                          <span className="tc_red">*</span> {this.props.messages.contract_reguired}
                        </div>
                      </div>
                    </div>

                    <table className="tbl_row">
                      <caption>사용자 정보 목록</caption>
                      <colgroup>
                        <col style={{width:'10%'}}/>
                        <col style={{width:'40%'}}/>
                        <col style={{width:'10%'}}/>
                        <col style={{width:'40%'}}/>
                      </colgroup>
                      <tbody>
                        <tr>
                          <th scope="row">{this.props.messages.user_division1} <span className="tc_red">*</span></th>
                            <td colSpan="3" className="input">
                            <ul className="ip_list">
                              <li>
                                <span className="input_ico_box" style={memberInfo.user_dstnct_code=='01'?{display:'none'}:{}}>
                                  <input type="radio" id="userClasCode1" name="userClasCode" value="03" checked={data.get('userClasCode') === '03'} onChange={handleChange}/>
                                  <label htmlFor="userClasCode1">{this.props.messages.user_infosec}</label>
                                </span>
                              </li>
                              <li>
                                <span className="input_ico_box">
                                  <input type="radio" id="userClasCode2" name="userClasCode" value="01" checked={data.get('userClasCode')  === '01'} onChange={handleChange}/>
                                  <label htmlFor="userClasCode2">Provider</label>
                                </span>
                              </li>
                              <li>
                                <span className="input_ico_box">
                                  <input type="radio" id="userClasCode3" name="userClasCode" value="02" checked={data.get('userClasCode')  === '02'} onChange={handleChange}/>
                                  <label htmlFor="userClasCode3">Customer</label>
                                </span>
                              </li>
                            </ul>
                          </td>
                        </tr>
                        <tr>
                          <th scope="row">{this.props.messages.user_name} <span className="tc_red">*</span></th>
                          <td colSpan="3" className="input">
                            <input type="text" className="ui_input" name="userName" onChange={handleChange} value={userName} maxLength={100}/>
                          </td>
                        </tr>
                        <tr>
                          <th scope="row">ID <span className="tc_red">*</span></th>
                          <td colSpan="3" className="input">
                            <span className="input_btn_box">
                              <input type="text" className="ui_input" name="userId" onChange={handleChange} value={userId} maxLength={50} placeholder="example@email.com"/>
                              <button className="tbtn_pos" onClick={checkDuplicate}>{this.props.messages.user_validity_check}</button>
                              </span>
                            <span className="tt" style={ duplicate === 'none' ? {display:'inline-block'}:{display:'none'} }>아이디를 입력 하세요.</span>
                            <span className="tt tc_red" style={ duplicate === false ?{display:'inline-block'}:{display:'none'}}>이미 사용중인 ID 입니다.</span>
                            <span className="tt tc_blue" style={ duplicate === true ?{display:'inline-block'}:{display:'none'}}>사용 가능한 ID입니다.</span>
                          </td>
                        </tr>
                        <tr>
                          <th scope="row">{this.props.messages.user_password}<span className="tc_red">*</span></th>
                          <td colSpan="3" className="input">
                            <input type="password" className="ui_input" placeholder={this.props.messages.user_password_message} name="pwd" onChange={handleChange}
                              disabled={duplicate === false ?'disabled':''} value={pwd}/>
                          </td>
                        </tr>
                        <tr>
                          <th scope="row">{this.props.messages.user_confirm_password} <span className="tc_red">*</span></th>
                          <td colSpan="3" className="input">
                            <input type="password" className="ui_input" placeholder={this.props.messages.user_re_enter_password} name="newPwd" onChange={handleChange}
                              disabled={duplicate === false ?'disabled':''} value={newPwd} />
                          </td>
                        </tr>
                        <tr>
                          <th scope="row">{this.props.messages.user_company_name}<span className="tc_red">*</span></th>
                          <td  className="input">
                              <span className="input_btn_box">
                                  <input type="hidden" name="custmNo" 
                                    value={custmNo} onChange={handleChange} />
                                  <input type="text" className="ui_input" name="coName" value={coName} onChange={handleChange} disabled={duplicate === "false"?'disabled':''} value={coName}/>
                                  <button type="button" disabled={duplicate === false?'disabled':''}  className="tbtn_pos" disabled={userClasCode==='03'} onClick={() => {this.popupCustm.show()}}>{this.props.messages.contract_customer_searching_1}</button>
                              </span>
                          </td>
                          <th scope="row">{this.props.messages.user_division}</th>
                          <td className="input">
                            <input type="text" className="ui_input"  name="dept" maxLength={100}
                              onChange={handleChange} disabled={duplicate === false?'disabled':''} value={dept}/>
                          </td>
                        </tr>
                        <tr>
                          <th scope="row">{this.props.messages.user_division2}</th>
                          <td className="input">
                            <input type="text" className="ui_input"  name="title" maxLength={100}
                              onChange={handleChange} disabled={duplicate === false?'disabled':''} value={title}/>
                          </td>
                          <th scope="row">{this.props.messages.user_position}</th>
                          <td className="input">
                            <input type="text" className="ui_input"  name="posit"  maxLength={100}
                              onChange={handleChange} disabled={duplicate === false?'disabled':''} value={posit}/>
                          </td>
                        </tr>
                        <tr>
                          <th scope="row">{this.props.messages.user_business_phone}</th>
                          <td className="input">
                            <input type="number" className="ui_input" placeholder="'-' 없이 입력" name="coTel" 
                              onChange={handleChange} 
                              disabled={duplicate === false?'disabled':''} 
                              onInput={this.maxLengthCheck.bind(this)}
                              maxLength={20}
                              value={coTel}/>
                          </td>
                          <th scope="row">{this.props.messages.user_cell_phone} <span className="tc_red">*</span></th>
                          <td className="input">
                            <input type="text" className="ui_input" placeholder="'-' 없이 입력" name="mobileNo" 
                            onChange={handleChange} 
                            disabled={duplicate === false?'disabled':''} 
                            onInput={this.maxLengthCheck.bind(this)}
                            maxLength={20}
                            value={mobileNo}/>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <PopupCustm 
        onRef={ref => (this.popupCustm = ref)}
        coName={coName}
        setUserClasCode={data.get('userClasCode')}
        onCustmComplete={this.handleCustmComplete}/>
      </section>
    );
  }
}
export default connect(mapStateToProps)(UserCreate);