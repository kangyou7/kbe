//  로그인 이후 이동 URI

const hostname = window && window.location && window.location.hostname;

// Default 및 loacl 변수 선언
let siteUrl='';
let restApiUrl='';
let restAuthUrl='';
let testVar='';
let siteDomain = "localhost";

const active = process.env.active;

console.log("process.env.active = ["+active+"]");

  switch (active) {
    case 'dev': //  상용 서버 변수 선언
      siteUrl = 'https://'+hostname+"";
      restApiUrl = 'https://api.secudiumiot.com/manage';
      restAuthUrl= 'https://api.secudiumiot.com/auth';
      siteDomain = "secudiumiot.com";
      testVar = 'dev';
      break;
  
    case 'stg': //  상용 서버 변수 선언
      siteUrl = 'https://'+hostname;
      restApiUrl = 'https://api.secudiumiot.com/manage';
      restAuthUrl= 'https://api.secudiumiot.com/auth';
      siteDomain = "secudiumiot.com";
      testVar = 'stg';
      break;
    
    case 'prd': //  상용 서버 변수 선언
      siteUrl = 'https://'+hostname+"";
      restApiUrl = 'https://api.secudiumiot.com/manage';
      restAuthUrl= 'https://api.secudiumiot.com/auth';
      siteDomain = "secudiumiot.com";
      testVar = 'prd';
      break;

    case 'local': //  상용 서버 변수 선언
      siteUrl ='http://localhost:8080';
      restApiUrl ='http://localhost:8081';
      restAuthUrl= 'https://api.secudiumiot.com/auth';
      testVar = 'loc';
      break;
  
    default:
      siteUrl ='http://'+hostname+':8080';
      restApiUrl ='http://'+hostname+':8081';
      restAuthUrl ='http://'+hostname+':8083';
      testVar = 'loc';
      break;
  }

let mainUiUri="/";

export const SITE_URL = `${siteUrl}`;
export const REST_API_URL = `${restApiUrl}`;
export const REST_AUTH_URL = `${restAuthUrl}`;
export const TEST_VAR = `${testVar}`;
export const DSP_MNG_HOME = `${mainUiUri}`;
export const SITE_DOMAIN = `${siteDomain}`;
export const ACTIVE = active;