import React from 'react';
import { Link } from 'react-router';

/*다국어 모듈 시작*/
import { connect } from 'react-redux';
import { changeLangauge, mapStateToProps } from '../../language/Actions';
/*다국어 모듈 종료*/

class PaymentResult extends React.Component {
    constructor(props) {
        super(props);
    
        this.state = {
        }

        
    }

    paymentOk() {
        opener.location.reload(true);  
        //opener.location.href = "/sales?salesSeq=" + this.props.location.query.salesSeq;
        self.close();  
    }

    render() {
        return (

            <section className="body">
                
                결제처리 결과<br/>

                {
                    this.props.location.query.Resultcd === '0000' 
                    ? 
                        <div>결제처리되었습니다.</div>
                    :
                        <div>{this.props.location.query.Resultmsg}</div>
                }

                <button onClick={()=>this.paymentOk()}>확인</button>
                {/*<Link to={{ pathname: "/sales", query: { salesSeq: this.props.location.query.salesSeq } }} className="btn_pos" target="opener">상품상세</Link>*/}
                
            </section>
        );
    }
}

export default connect(mapStateToProps)(PaymentResult);
