import React from 'react';
import { Link } from 'react-router';
import Search from './Search';
import PagingView from '../common/PagingView';
import ColumnChange from '../common/ColumnChange';

import {TableThead, TableColgroup} from '../common/TableThead';

import {REST_API_URL} from '../../config/api-config.js';

/*다국어 모듈 시작*/
import { connect } from 'react-redux';
import { changeLangauge, mapStateToProps } from '../../language/Actions';
/*다국어 모듈 종료*/

class PaymentList extends React.Component {
    constructor(props) {
        super(props);
    
        this.state = {
            displadyState : "L",
            salesSeq : "",
            pageInfo : {},
            listThead : [
                {name:props.messages.contract_no,                                 sort:false, sortColumn:"", view:true, target:false, width:'3%'},
                {name:props.messages.sales_provider_name,                         sort:true,  sortColumn:"sply_usr_name", view:true, target:true, width:'10%'},
                {name:props.messages.sales_customer_name,                         sort:true,  sortColumn:"demnd_usr_name", view:true, target:true, width:'10%'},
                {name:props.messages.sales_contract_id,                           sort:true, sortColumn:"ctrt_no", view:true, target:true, width:'10%'},
                {name:props.messages.sales_product_name,                          sort:true, sortColumn:"product_name", view:true, target:true, width:'10%'},
                {name:props.messages.sales_payment_method,                        sort:true, sortColumn:"setle_way_clas_code_name", view:true, target:true, width:'10%'},
                {name:props.messages.sales_card +'/' + props.messages.sales_bank, sort:true, sortColumn:"setle_way_co_name", view:true, target:true, width:'10%'},
                {name:props.messages.sales_transaction_date,                      sort:true, sortColumn:"setle_conf_dt", view:true, target:true, width:'auto'},
                {name:props.messages.sales_cancellation_date,                     sort:true, sortColumn:"setle_cnl_dt", view:true, target:true, width:'9%'},
                {name:props.messages.sales_transaction_amount,                    sort:true, sortColumn:"last_setle_amt", view:true, target:true, width:'9%'},
                {name:props.messages.sales_transaction_status,                    sort:true, sortColumn:"setle_deal_status_code_name", view:true, target:true, width:'9%'}
            ],
            searchSelectOption : [
                {value:"",         text : props.messages.product_select},
                {value:"provider", text : props.messages.sales_provider_name},
                {value:"custom",   text : props.messages.sales_customer_name},
                {value:"contract", text : props.messages.sales_contract_id},
            ],
            list : []
        }


        this.handleColumnChange = this.handleColumnChange.bind(this);
        this.handleSearch = this.handleSearch.bind(this);
        this.handleSort = this.handleSort.bind(this);
        this.handlePageChange = this.handlePageChange.bind(this);
    }

    //컴포넌트가 만들어지고 첫 렌더링을 다 마친 후 실행되는 메소드입니다.
	componentDidMount() {
        this.getList();
    }
    
    //컴포넌트가 prop 을 새로 받았을 때 실행됩니다.
    componentWillReceiveProps(nextProps) {
        if(this.state.locale !== nextProps.locale) {
            let listThead = this.state.listThead;

            listThead[0].name = nextProps.messages.contract_no;
            listThead[1].name = nextProps.messages.sales_provider_name;
            listThead[2].name = nextProps.sales_customer_name;
            listThead[3].name = nextProps.sales_contract_id;
            listThead[4].name = nextProps.sales_product_name;
            listThead[5].name = nextProps.sales_payment_method;
            listThead[6].name = nextProps.sales_card +'/' + props.messages.sales_bank;
            listThead[7].name = nextProps.sales_transaction_date;
            listThead[8].name = nextProps.sales_cancellation_date;
            listThead[9].name = nextProps.sales_transaction_amount;
            listThead[10].name = nextProps.sales_transaction_status;

            let searchSelectOption = this.state.searchSelectOption;

            searchSelectOption[0].text = nextProps.messages.product_select;
            searchSelectOption[1].text = nextProps.messages.sales_provider_name;
            searchSelectOption[2].text = nextProps.messages.sales_customer_name;
            searchSelectOption[3].text = nextProps.messages.sales_contract_id;
        }
    }

    //항목변경 팝업에서 항목 변경 후 state 정보 변경
    handleColumnChange(changeThead) {
        this.setState({
            listThead : changeThead
        });
    }
    
    handleSearch(searchInfo) {
        let pageInfo = this.state.pageInfo;
        pageInfo.adjustYmStr = searchInfo.adjustYmStr;
        pageInfo.adjustYmEnd = searchInfo.adjustYmEnd;
        pageInfo.splyUsrNo = searchInfo.splyUsrNo;
        pageInfo.demndUsrNo = searchInfo.demndUsrNo;
        pageInfo.setleWayClasCode = searchInfo.setleWayClasCode;
        pageInfo.searchKeyCode = searchInfo.searchKeyCode;
        pageInfo.searchKeyWord = searchInfo.searchKeyWord;
        
        this.setState({
            pageInfo : pageInfo
        });

        this.getList();
    }

    handleSort(sort) {
        let pageInfo = this.state.pageInfo;
        pageInfo.sortColumn = sort.sortColumn;
        pageInfo.sortType = sort.sortType;

        this.setState({
            pageInfo : pageInfo
        });

        this.getList();
    }

    //페이지 변경 및 페이지 출력 갯수 변경
    handlePageChange(perPageNum, page) {
        let pageInfo = this.state.pageInfo;
        pageInfo.perPageNum = perPageNum;
        pageInfo.page = page;
   
        this.setState({
            pageInfo : pageInfo
        });

        this.getList();
    }



    getList() {
        
        let data = this.state.pageInfo;

        data.loginUserNo = this.props.memberInfo.user_no;
        data.loginUserDstnctCode = this.props.memberInfo.user_dstnct_code;

        $.ajax({
            url: REST_API_URL + "/sales/PaymentList",
            dataType: 'json',
            type: "post",
            data: data,
            cache: false,
            success: function(result) {
                this.setState({
                    pageInfo : result.response.pageInfo,
                    list: result.response.list
                });
            }.bind(this),
            error: function(xhr, status, err) {
                console.log(xhr + " : " + status + " : " + err);
            }.bind(this),
			xhrFields: {
			  withCredentials: true
			}
        });
    }

    

    render() {

        const mapToList = (data, thead) => {
            if(data.length > 0) {
                return data.map((item, i) => {//map
                    return(
                        <tr key={i}>
                            <td style={thead[0].view ? {} : {display:'none'}}>{item.rownum}</td>
                            <td style={thead[1].view ? {} : {display:'none'}}>{item.splyUsrName}</td>
                            <td style={thead[2].view ? {} : {display:'none'}}>{item.demndUsrName}</td>
                            <td style={thead[3].view ? {} : {display:'none'}}>{item.ctrtNo}</td>
                            <td style={thead[4].view ? {} : {display:'none'}}>{item.productName}</td>
                            <td style={thead[5].view ? {} : {display:'none'}}>{item.setleWayClasCodeName}</td>
                            <td style={thead[6].view ? {} : {display:'none'}}>{item.setleWayCoName}</td>
                            <td style={thead[7].view ? {} : {display:'none'}}>{item.setleConfDt}</td>
                            <td style={thead[8].view ? {} : {display:'none'}}>{item.setleCnlDt}</td>
                            <td style={thead[9].view ? {} : {display:'none'}}>{item.lastSetleAmt}</td>
                            <td style={thead[10].view ? {} : {display:'none'}}>{item.setleDealStatusCodeName}</td>
                        </tr>
                    );
                });
            } else {
                let colspan = thead.length;
                for(var i = 0; i<thead.length; i++) {
                    colspan -= thead[i].view ? 0 : 1;
                }
                return (
                    <tr>
                        <td className="noresults" colSpan={colspan}>
                            <div className="box_noresults">
                                <div className="ver_mid">
                                    <i className="ico ico_no_result"></i>
                                    <span className="lb">{this.props.messages.product_search}</span>
                                </div>
                            </div>
                        </td>
                    </tr>
                );
            }
        }


        return (

            <section className="body">
                
                <div className="wrapper">
                    
                    <div className="page_header">
                        <h2 className="ptitle">{this.props.messages.sales_billing_status}</h2>
                        <div className="page_nav">
                            {/*<ul>
                                <li><Link to="/">Home</Link></li>
                                <li><Link to="/sales">{this.props.messages.sales_sales_management}</Link></li>
                                <li className="here">{this.props.messages.sales_billing_status}</li>
                            </ul>*/}
                        </div>
                    </div>

                    <div className="content_wrap">
                        <div className="content_outbox">
                            <div className="tab_wrap tab-wrap">
                                <div className="box_both tab_header">		
                                    <div className="fl">
                                        <ul className="tabs">
                                            <li className={this.state.displadyState == 'L' ? "tab_item tab-item on" : "tab_item tab-item"}>
                                                <a href="javascript:;" onClick={() => this.setState({displadyState:'L'})} className="tab-link"><span>{this.props.messages.product_list}</span></a>
                                            </li>
                                            <li className={this.state.displadyState != 'L' ? "tab_item tab-item on" : "tab_item tab-item"}>
                                                <a href="javascript:;" className={this.state.displadyState == 'L' ? "tab-link disabled" : "tab-link"}><span>{this.props.messages.product_detail}</span></a>
                                            </li>
                                        </ul>
                                    </div>
                                    <div className="fr">
                                    </div>
                                </div>
                                
                                <div id="tab-cont1" className="tab_content tab-cont" style={{display:'block'}}>
                                    {/* S:content_body */}
                                    <div className="content_body sales_container">
                                        {/* S:content_inner */}
                                        <div className="content_inner">
                                            <Search onSearch={this.handleSearch} 
                                                    searchSelectOption={this.state.searchSelectOption} 
                                                    searchInfo={this.state.pageInfo}
                                                    searchItem='payment'
                                            />
                                            
                                            <div className="box_com">
                                                <div className="fr">
                                                    <a href="javascript:;" className="btn_pos" onClick={() => this.columnChange.show()}>{this.props.messages.contract_change_item}</a>
                                                    {/*<ul className="sort_wrap">
                                                        <li className="active"><a href="javascript:;">List</a></li>
                                                        <li><a href="javascript:;">Tree</a></li>
                                                    </ul>*/}
                                                </div>
                                            </div>			
                                            
                                            {/* S : tbl_col */}
                                            <table className="tbl_col">
                                                <caption>매출현황 목록</caption>
                                                <TableColgroup listThead={this.state.listThead} />
                                                <TableThead listThead={this.state.listThead} onSort={this.handleSort}/>
                                                
                                                
                                                
                                                <tbody>
                                                    {mapToList(this.state.list, this.state.listThead)}
                                                </tbody>
                                            </table>
                                            {/* E : tbl_col */}
                                        </div>
                                        {/* E:content_inner */}
                                    </div>
                                    

                                    <PagingView pageInfo={this.state.pageInfo} onPageChange={this.handlePageChange}/>

                                    <ColumnChange onRef={ref => (this.columnChange = ref)} listThead={this.state.listThead} onColumnChange={this.handleColumnChange} />

                                </div>




                            </div>
                        </div>
                    </div>
                </div>

            </section>



        );
    }
}

export default connect(mapStateToProps)(PaymentList);
