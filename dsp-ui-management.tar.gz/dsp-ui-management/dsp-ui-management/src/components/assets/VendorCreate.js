import React from 'react';

import { browserHistory } from 'react-router';

import ApprovalLineSetting from '../common/ApprovalLineSetting';

import ModelRegist from './ModelRegist';

import Calendar from '../common/Calendar';
import CodeSelect from '../common/CodeSelect';
import AttachFile from '../common/AttachFile';

import {REST_API_URL} from '../../config/api-config.js';

import axios from 'axios';
/*다국어 모듈 시작*/
import { connect } from 'react-redux';
import { changeLangauge, mapStateToProps } from '../../language/Actions';
/*다국어 모듈 종료*/

import validator from 'validator';


class VendorCreate extends React.Component {

	constructor(props) {
		super(props);

		this.state = {
			equipVendorName : "",
			bizNo : "",
			chargeUsrName : "",
			chargeUsrPosit : "",
			chargeUsrEmail : "",
			chargeUsrTel : "",
			chargeUsrMobileNo : "",
			models : []
		}

		this.handleChange = this.handleChange.bind(this);

		this.handleModelSave = this.handleModelSave.bind(this);

		/*모델 등록*/
		this.handleModelComplete = this.handleModelComplete.bind(this);

		this.handleDelete = this.handleDelete.bind(this);
		
	}

	handleInitState() {
		
		this.setState({
			equipVendorName : "",
			bizNo : "",
			chargeUsrName : "",
			chargeUsrPosit : "",
			chargeUsrEmail : "",
			chargeUsrTel : "",
			chargeUsrMobileNo : "",
			models : []
		});

		this.modelRegist.handleInitState("ALL");
	}

	handleModelComplete(model) {
		
		let modelArray = this.state.models;
		modelArray.push(model);

		this.setState({
			models: modelArray
		});
	}

	handleModelSave() {

		if (this.validationCheck()) {
			let data = this.state;

			if (confirm("등록하시겠습니까?")) {

				let memberInfo = JSON.parse(localStorage.getItem("memberInfo"));
				data.loginUserNo = memberInfo.user_no;
		
				$.ajax({
					url: REST_API_URL+"/assets/VendorCreate",
					dataType: 'json',
					type: "post",
					xhrFields : {
						withCredentials : true
					},
					data: {paramJson : JSON.stringify(data)},
		
					success: function(result) {
						
						if (result.response == "SUCCESS") {
							alert("등록되었습니다.");
							location.href="/vendor";
						} else {
							alert("등록 도중 오류가 발생하였습니다. 관리자에게 문의바랍니다.");
							return;
						}
		
					}.bind(this),
						error: function(xhr, status, err) {
						console.log(xhr + " : " + status + " : " + err);
					}.bind(this)
				});
			}		
		}
	}

	handleSave() {

		this.handleModelSave();
		
	}

	validationCheck() {
		
		if(validator.trim(this.state.equipVendorName) == "") {
			alert("벤더명을 입력해 주세요.");
			return false;
		} else {
			if (!validator.isLength(this.state.equipVendorName,{min:0, max: 100})) {
				alert("벤더명은 100자 이내로 입력바랍니다.");
				return false;
			}
		}

		if(validator.trim(this.state.bizNo) == "") {
			alert("사업자 등록번호를 입력해 주세요.");
			return false;
		} else {
			if (!validator.isLength(this.state.bizNo,{min:0, max: 50})) {
				alert("사업자 등록번호는 50자 이내로 입력바랍니다.");
				return false;
			}

			if(validator.isNumeric(this.state.bizNo) == "") {
				alert("사업자 등록번호는 숫자만 입력바랍니다.");
				return false;
			}
		}

		if(validator.trim(this.state.chargeUsrName) == "") {
			alert("담당자 이름을 입력해 주세요.");
			return false;
		} else {
			if (!validator.isLength(this.state.chargeUsrName,{min:0, max: 100})) {
				alert("담당자 이름은 100자 이내로 입력바랍니다.");
				return false;
			}
		}

		if(validator.trim(this.state.chargeUsrEmail) == "") {
			alert("담당자 이메일을 입력해 주세요.");
			return false;
		} else {
			if (!validator.isEmail(this.state.chargeUsrEmail)) {
				alert("이메일 형식으로 입력 바랍니다.");
				return false;
			}
			if (!validator.isLength(this.state.chargeUsrEmail,{min:0, max: 50})) {
				alert("담당자 이메일은 50자 이내로 입력바랍니다.");
				return false;
			}
		}

		if(validator.trim(this.state.chargeUsrMobileNo) == "") {
			alert("담당자 휴대폰 번호를 입력해 주세요.");
			return false;
		} else {
			if (!validator.isLength(this.state.chargeUsrMobileNo,{min:0, max: 20})) {
				alert("담당자 휴대폰 번호는 20자 이내로 입력바랍니다.");
				return false;
			}

			if (!validator.isMobilePhone(this.state.chargeUsrMobileNo,'ko-KR')) {
				alert("휴대폰 번호 형식으로 입력바랍니다.");
				return false;
			}
		}
		
		return true;
	}

	handleChange(e) {
			
		let nextState = {};
		nextState[e.target.name]=e.target.value;
		this.setState(nextState);
	}

	handleCheckAll() {
        
        $("input[name='listCheck']").prop("checked", $("#listChkAll").is(":checked"));
	}
	
	handleDelete() {
		
		let models = this.state.models;

		let removeModels = new Array();
		
		if(!confirm("선택한 항목을 삭제하시겠습니까?")) {
			return;
		}
		$("input[name='listCheck']").each(function() {
			if ( $(this).is(":checked") ) {
				removeModels.push(models[$(this).val()]);
			}
		});
		
		for (var i=0; i<removeModels.length; i++) {
			models.splice($.inArray(removeModels[i], models),1);
		}

		this.setState({
			models: models
		});

		alert("삭제되었습니다.");
	}

	goList() {
		if (confirm("이 페이지에서 나가시겠습니까?\n작성중인 내용이 저장되지 않습니다.")) {
			location.href="/vendor";
		}
	}

	componentDidMount() {
		$("#tab-cont1").show();
	}
	
    render() {

		const mapToModel = (data) => {

            if(data.length > 0) {
                return data.map((item, i) => {//map
                    return(

						<tr key={i}>
							<td className="ui_only_chk">
								<span className="input_ico_box">
									<input type="checkbox" name="listCheck" id={i} value={i} onClick={this.handleCheckBoxClick}/>
									<label htmlFor={i}></label>
								</span>	
							</td>
							<td>{(i + 1)}</td>
							<td>{item.equipClasName}</td>
							<td>{item.equipModelName}</td>
							<td>{item.regDate}</td>
						</tr>
                    );
                });
            } else {
                return (
                    <tr>
						<td className="noresults" colSpan={5}>
							<div className="box_noresults">
								<div className="ver_mid">													
									<i className="ico ico_no_result"></i>
									<span className="lb">{this.props.messages.common_no_data}</span>
								</div>
							</div>
						</td>
					</tr>
                );
            }
        }

        return (
			<section className="body">

				{/* S:wrapper */}
				<div className="wrapper">

					{/* S:page_header */}
					<div className="page_header">
						<h2 className="ptitle">{this.props.messages.vendor_register_vendor}</h2>
						<div className="page_nav">
							{/*<ul>
								<li><a href="/">Home</a></li>
								<li><a href="/assets">{this.props.messages.assets_management}</a></li>
								<li><a href="/vendor">{this.props.messages.vendor_vendor_status}</a></li>
								<li className="here">{this.props.messages.vendor_register_vendor}</li>
							</ul>*/}
						</div>
					</div>
					{/* E:page_header */}

					{/* S:content_wrap */}
					<div className="content_wrap">
						{/* S:content_outbox */}
						<div className="content_outbox">
							{/* S:tab_wrap */}
							<div className="tab_wrap tab-wrap">
								{/* S:tab_header */}
								<div className="box_both tab_header">
									<div className="fl">
										<ul className="tabs">
											<li className="tab_item tab-item">
												<a href="#tab-cont1" className="tab-link" onClick={() => {this.goList()}}><span>{this.props.messages.common_list}</span></a>
											</li>
											<li className="tab_item tab-item on">
												<a href="#tab-cont1" className="tab-link"><span>{this.props.messages.common_detail}</span></a>
											</li>
										</ul>
									</div>
									<div className="fr">
										<div className="btn_group">
											<button type="button" className="btn_pos" onClick={() => {this.handleInitState()}}>{this.props.messages.common_reset}</button>
											{/* <button type="button" className="btn_pos" onClick={() => {this.handleSave('T')}}>임시저장</button> */}
											<button type="button" className="btn_black" onClick={() => {this.handleSave()}}>{this.props.messages.assets_ok}</button>
										</div>
									</div>
								</div>
								{/* E:tab_header */}

								{/* S:tab_content 활성화시 display:block/none  */}
								<div id="tab-cont1" className="tab_content tab-cont" >
									{/* S:content_body */}
									<div className="content_body">
										{/* S:content_inner */}
										<div className="content_inner">

											<div className="box_com">
												<div className="fl">
													<h3 className="ctitle">{this.props.messages.vendor_basic_information}</h3>
												</div>
												<div className="fr">
													<div className="desc">
														<span className="tc_red">*</span> {this.props.messages.assets_required}
													</div>
												</div>
											</div>

											{/* S:Table */}
											<table className="tbl_row">
												<caption>기본 정보 목록</caption>
												<colgroup>
													<col style={{width:'10%'}}/>
													<col style={{width:'40%'}}/>
													<col style={{width:'10%'}}/>
													<col style={{width:'40%'}}/>
												</colgroup>
												<tbody>
												<tr>
													<th scope="row">{this.props.messages.vendor_vendor_name} <span className="tc_red">*</span></th>
													<td className="input">
														<input type="text" className="ui_input" maxLength="100" name="equipVendorName" value={this.state.equipVendorName}  onChange={this.handleChange} />
													</td>
													<th scope="row">{this.props.messages.vendor_business_no} <span className="tc_red">*</span></th>
													<td className="input">
														<input type="text" className="ui_input" maxLength="50" name="bizNo" value={this.state.bizNo}  onChange={this.handleChange}/>
													</td>
												</tr>
												<tr>
													<th scope="row">{this.props.messages.vendor_manager_name} <span className="tc_red">*</span></th>
													<td className="input">
														<input type="text" className="ui_input" maxLength="100" name="chargeUsrName" value={this.state.chargeUsrName}  onChange={this.handleChange}/>
													</td>
													<th scope="row">{this.props.messages.vendor_manager_position}</th>
													<td className="input">
														<input type="text" className="ui_input" maxLength="100" name="chargeUsrPosit" value={this.state.chargeUsrPosit}  onChange={this.handleChange}/>
													</td>
												</tr>
												<tr>
													<th scope="row">{this.props.messages.vendor_manager_email} <span className="tc_red">*</span></th>
													<td className="input" colSpan={3}>
														<input type="text" className="ui_input" maxLength="50" name="chargeUsrEmail" value={this.state.chargeUsrEmail}  onChange={this.handleChange}/>
													</td>
												</tr>
												<tr>
													<th scope="row">{this.props.messages.vendor_phone}</th>
													<td className="input">
														<input type="text" className="ui_input" maxLength="20" name="chargeUsrTel" value={this.state.chargeUsrTel}  onChange={this.handleChange} />
													</td>
													<th scope="row">{this.props.messages.vendor_cellphone} <span className="tc_red">*</span></th>
													<td className="input">
														<input type="text" className="ui_input" maxLength="20" name="chargeUsrMobileNo" value={this.state.chargeUsrMobileNo}  onChange={this.handleChange} />
													</td>
												</tr>
												</tbody>
											</table>
											{/* E:Table */}

											<div className="box_com">

												<div className="fl">
													<h3 className="ctitle">{this.props.messages.vendor_model_information}</h3>
												</div>
												<div className="fr">
													<button type="button" className="btn_pos" onClick={() => {this.handleDelete()}}>{this.props.messages.vendor_model_delete}</button>
													<button type="button" className="btn_black" onClick={() => {this.modelRegist.show();}}>{this.props.messages.vendor_model_registration}</button>
												</div>
											</div>
											
											<table className="tbl_col">
												<caption>모델 정보 목록</caption>
												<colgroup>
													<col style={{width:'3%'}}/>
													<col style={{width:'3%'}}/>
													<col style={{width:'31%'}}/>
													<col style={{width:'31%'}}/>
													<col style={{width:'32%'}}/>
												</colgroup>
												
												<thead>
													<tr>
														<th scope="col" className="ui_only_chk">
															<span className="input_ico_box">
																<input type="checkbox" name="chk_box" id="listChkAll" onClick={() => {this.handleCheckAll()}}/>
																<label htmlFor="listChkAll"></label>
															</span>
														</th>
														<th scope="col">No</th>
														<th scope="col">{this.props.messages.assets_type}</th>
														<th scope="col">{this.props.messages.vendor_model_name}</th>
														<th scope="col">{this.props.messages.vendor_registrantion_date}</th>
													</tr>
												</thead>
												
												<tbody>	
												{mapToModel(this.state.models)}
												</tbody>
											</table>
										</div>
										{/* E:content_inner */}
									</div>
									{/* E:content_body */}
								</div>
							
							{/* E:tab_content  */}
							</div>
						{/* E:tab_wrap */}
						</div>
					</div>
				</div>

				<ModelRegist onRef={ref => (this.modelRegist = ref)} onModelComplete={this.handleModelComplete}/>

			</section>
        );
    }
}

export default connect(mapStateToProps)(VendorCreate);
