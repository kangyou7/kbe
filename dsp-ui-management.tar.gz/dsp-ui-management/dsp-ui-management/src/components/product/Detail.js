import React from 'react';

import ApprovalLineSetting from '../common/ApprovalLineSetting';
import AssetSetting from './AssetSetting';
import ServiceSetting from './ServiceSetting';

import {REST_API_URL} from '../../config/api-config.js';

/*다국어 모듈 시작*/
import { connect } from 'react-redux';
import { changeLangauge, mapStateToProps } from '../../language/Actions';
/*다국어 모듈 종료*/

const initialState = {
	approvalLine : [],
    productName : "",
    productDstnctCode : "",
    productUsePurposeCode : "",
    productVdtStatusCode : "",
    
    trafficUpPrice : "",
	trafficUpExceedPrice : "",
	trafficUpVolume : "",
	trafficDownPrice : "",
	trafficDownExceedPrice : "",
	trafficDownVolume : "",
	saveVolumePrice : "",
	saveVolumeExceedPrice : "",
    saveVolumeVolume : "",

    etcMemoText : "",
    bizDcRate : "",
	prvdrItemChocYn : "N",
	prvdrProftRate : "",
	prvdrProftAmt : "",
	mgmrCommCost : "",
    mgmrDcRate : "",
    
	/*productTotalPrice : "",
	discountPrice : "",
	productPrice : "",
	planDt : "",
    planUserId : "",
    */
    aprvStatusClasCode : "",
   
    assetService:[],
    controlUiService: [],
    functionService: [],
    offlineService: [],

    productDcBefSumAmt : 0,
    dcAmt : 0,
    lastSumAmt : 0,

	assetServiceTotal : 0,
    controlUiServiceTotal : 0,
    functionServiceTotal : 0,
    offlineServiceTotal : 0,

    tcktNo : "",
    approvalNo : "",
    approvalEmail : ""

};

let backupData = {};

class Detail extends React.Component {
    constructor(props) {
        super(props);

        this.state = $.extend(true, {}, initialState);

        this.handleChange = this.handleChange.bind(this);

        /*결재선 지정*/
        this.handleApprovalLineComplete = this.handleApprovalLineComplete.bind(this);

        this.handleServiceChange = this.handleServiceChange.bind(this);
    
    }

    //컴포넌트가 만들어지고 첫 렌더링을 다 마친 후 실행되는 메소드입니다.
	componentDidMount() {

        //if(this.props.location === undefined || this.props.location.query === undefined || this.props.location.query.productNo === undefined) {
        if(this.props.popupDetail === undefined) {
            this.props.onRef(this);
            this.getProduct(this.props.productNo);
        } else {
            //this.getProduct(this.props.location.query.productNo);
            this.getProduct(this.props.popupDetail);
        }
	}

	//컴포넌트가 DOM 에서 사라진 후 실행되는 메소드입니다.
	componentWillUnmount() {
        if(this.props.popupDetail === undefined) {
            this.props.onRef(null);
        }
    }
    
    //props, state가 바뀌면 실행되는 메소드
    shouldComponentUpdate(nextProps, nextState){
        if(
            this.state.trafficUpPrice != nextState.trafficUpPrice
            || this.state.trafficDownPrice != nextState.trafficDownPrice
            || this.state.saveVolumePrice != nextState.saveVolumePrice
            || this.state.assetServiceTotal != nextState.assetServiceTotal
            || this.state.controlUiServiceTotal != nextState.controlUiServiceTotal
            || this.state.functionServiceTotal != nextState.functionServiceTotal
            || this.state.offlineServiceTotal != nextState.offlineServiceTotal
            || this.state.mgmrDcRate != nextState.mgmrDcRate
        ) {
            let productDcBefSumAmt = (nextState.trafficUpPrice === '' ? 0 : Number(nextState.trafficUpPrice)) + 
                                    (nextState.trafficDownPrice === '' ? 0 : Number(nextState.trafficDownPrice)) + 
                                    (nextState.saveVolumePrice === '' ? 0 : Number(nextState.saveVolumePrice)) + 
                                    (nextState.assetServiceTotal === '' ? 0 : Number(nextState.assetServiceTotal)) + 
                                    (nextState.controlUiServiceTotal === '' ? 0 : Number(nextState.controlUiServiceTotal)) + 
                                    (nextState.functionServiceTotal === '' ? 0 : Number(nextState.functionServiceTotal)) + 
                                    (nextState.offlineServiceTotal === '' ? 0 : Number(nextState.offlineServiceTotal)) +
                                    (nextState.mgmrCommCost === '' ? 0 : Number(nextState.mgmrCommCost));

            /*
            *계산식
            *인포섹 : 
                (1 + 이익률 - 영업할인율) * {(트래픽UP요금 + 초과금) + (트래픽Down요금 + 초과금) + (저장요량 + 초과금)  + 장비 설정요금  + 서비스 설정요금 + 공통원가}
            *프로바이더 : 
                (1 + 이익률 + 프로바이더 이익률 - 영업할인율) * {(트래픽UP요금 + 초과금) + (트래픽Down요금 + 초과금) + (저장요량 + 초과금)  + 장비 설정요금  + 서비스 설정요금 + 공통원가} + 이익액
            */
                               
            //let dcAmt = productDcBefSumAmt * (nextState.mgmrDcRate === '' ? 0 : Number(nextState.mgmrDcRate)) / 100;
            let dcAmt = 0;
            let lastSumAmt = 0;
            let rate = 0;

            if(this.props.memberInfo.user_dstnct_code == "03") {
                let bizDcRate = nextState.bizDcRate == '' ? 0 : Number(nextState.bizDcRate); //영업할인률
                let mgmrDcRate = nextState.mgmrDcRate == '' ? 0 : Number(nextState.mgmrDcRate); //Admin 이익률

                //rate = mgmrDcRate - bizDcRate;
                rate = bizDcRate; //이익률을 추가해서계산하면 데이터 가 정확하지 않아 할인율만 계산함.

                dcAmt = rate == 0 ? 0 : productDcBefSumAmt * rate / 100;
            } else {
                let bizDcRate = nextState.bizDcRate == '' ? 0 : Number(nextState.bizDcRate); //영업할인률
                let prvdrProftRate = nextState.prvdrProftRate == '' ? 0 : Number(nextState.prvdrProftRate) //프로바이더 이익율
                let mgmrDcRate = nextState.mgmrDcRate == '' ? 0 : Number(nextState.mgmrDcRate); //Admin 이익률

                //rate = mgmrDcRate + prvdrProftRate - bizDcRate;//이익률을 추가해서계산하면 데이터 가 정확하지 않아 할인율만 계산함.
                rate = bizDcRate;
                productDcBefSumAmt += productDcBefSumAmt + (this.state.prvdrProftAmt == '' ? 0 : Number(nextState.prvdrProftAmt));
                dcAmt = (rate == 0 ? 0 : productDcBefSumAmt * rate / 100)
            }

            
            //프로바이더 이면 프로바이더 이익액 +
            //lastSumAmt = productDcBefSumAmt - dcAmt + (this.props.memberInfo.user_dstnct_code == "03" ? 0 : (this.state.prvdrProftAmt == '' ? 0 : Number(nextState.prvdrProftAmt)));
            lastSumAmt = productDcBefSumAmt - dcAmt;
            
            nextState.productDcBefSumAmt = productDcBefSumAmt;
            nextState.dcAmt = dcAmt;
            nextState.lastSumAmt = lastSumAmt;

            /*lastSumAmt = productDcBefSumAmt + dcAmt;
            if(rate < 0) {
                console.log((dcAmt * 2) + " : "+ dcAmt);
                dcAmt = dcAmt - (dcAmt * 2);
            }
            
            nextState.productDcBefSumAmt = productDcBefSumAmt;
            nextState.dcAmt = dcAmt;
            nextState.lastSumAmt = lastSumAmt;
            */
        }


        if(backupData.trafficUpVolume != undefined || backupData.trafficUpVolume == null) {
            
            let approvalButtonDisabled = true;
            if(backupData.productUsePurposeCode == 'B' && nextState.productUsePurposeCode == 'A') {
                approvalButtonDisabled = false;
            } else if(!(backupData.trafficUpPrice == nextState.trafficUpPrice 
                && backupData.trafficUpExceedPrice == nextState.trafficUpExceedPrice
                && backupData.trafficUpVolume == nextState.trafficUpVolume)) {
                    approvalButtonDisabled = false;
            } else if(!(backupData.trafficDownPrice == nextState.trafficDownPrice 
                && backupData.trafficDownExceedPrice == nextState.trafficDownExceedPrice
                && backupData.trafficDownVolume == nextState.trafficDownVolume)) {
                    approvalButtonDisabled = false;
            } else if(!(backupData.saveVolumePrice == nextState.saveVolumePrice 
                && backupData.saveVolumeExceedPrice == nextState.saveVolumeExceedPrice
                && backupData.saveVolumeVolume == nextState.saveVolumeVolume)) {
                    approvalButtonDisabled = false;
            } else if(!(backupData.bizDcRate == nextState.bizDcRate 
                && backupData.prvdrItemChocYn == nextState.prvdrItemChocYn
                && backupData.prvdrProftRate == nextState.prvdrProftRate
                && backupData.prvdrProftAmt == nextState.prvdrProftAmt
                && backupData.mgmrCommCost == nextState.mgmrCommCost
                && backupData.mgmrDcRate == nextState.mgmrDcRate)) {
                    approvalButtonDisabled = false;
            } else if(JSON.stringify(backupData.assetService).replace(/\"/g,"") !== JSON.stringify(nextState.assetService).replace(/\"/g,"")) {
                approvalButtonDisabled = false;
            } else if(JSON.stringify(backupData.controlUiService).replace(/\"/g,"") !== JSON.stringify(nextState.controlUiService).replace(/\"/g,"")) {
                approvalButtonDisabled = false;
            } else if(JSON.stringify(backupData.functionService).replace(/\"/g,"") !== JSON.stringify(nextState.functionService).replace(/\"/g,"")) {
                approvalButtonDisabled = false;
            } else if(JSON.stringify(backupData.offlineService).replace(/\"/g,"") !== JSON.stringify(nextState.offlineService).replace(/\"/g,"")) {
                approvalButtonDisabled = false;
            }
            
            this.props.onApprovalButtonState(approvalButtonDisabled);
            
        }

        

        return true;
    }

    handleOnlyNumber(smallPoint, e) {

        if(smallPoint > 0 ) {
            //let regexp = /^\d*(\.\d{0,2})?$/;
            let regexp = new RegExp("^\\d*(\\.\\d{0," + smallPoint + "})?$");
            if(e.target.value.search(regexp) == -1) {
                e.target.value=e.target.value.substring(0, e.target.value.length -1);
            } else  {
                e.target.value=e.target.value;
            }
        } else {
            e.target.value = e.target.value.replace(/[^0-9]/g,"")
        }
    }

    handleChange(e) {
        let nextState = {};
        if(e.target.name === 'prvdrItemChocYn') {
            nextState[e.target.name]=this.state.prvdrItemChocYn === 'Y' ? 'N': 'Y';
            if(this.state.prvdrItemChocYn === 'Y') {
                this.setState({
                    prvdrProftRate : "",
                    prvdrProftAmt : ""
                })
            }
        } else {
            nextState[e.target.name]=e.target.value;
        }
        this.setState(nextState);
    }
    /*결재선 지정*/
    handleApprovalLineComplete(approvalLine) {
        this.setState({
            approvalLine : approvalLine
        });
    }

    handleServiceChange(serviceCode, serviceList) {
        if(serviceCode === 'controlUi') {
            this.setState({
                controlUiService : serviceList,
                controlUiServiceTotal : this.serviceSum(serviceCode, serviceList)
            })
        } else if(serviceCode === 'function') {
            this.setState({
                functionService : serviceList,
                functionServiceTotal : this.serviceSum(serviceCode, serviceList)
            })
        } else if(serviceCode === 'offline') {
            this.setState({
                offlineService : serviceList,
                offlineServiceTotal : this.serviceSum(serviceCode, serviceList)
            })
        } else if(serviceCode === 'asset') {
            this.setState({
                assetService : serviceList,
                assetServiceTotal : this.serviceSum(serviceCode, serviceList)
            })
        }
    }

    

    serviceSum(serviceCode, serviceList) {
        let totalSum = 0;
        if(serviceCode === 'asset') {
            $.each(serviceList, (i, el) => {
                totalSum += Number(el.productSubtotAmt);
            });
        } else {
            $.each(serviceList, (i, el) => {
                if(el.checked) {
                    totalSum += Number(el.productSubtotAmt);
                }
            });
        }

        return totalSum;
    }


    handleApproval(flag) {

        if(flag == "R") {
            if(!confirm("반려하시겠습니까?")) {
                return;
            } 
        } else if(flag == "A") {
            if(!confirm("승인하시겠습니까?")) {
                return;
            } 
        } else {
            return;
        }

        if(this.state.hdlOpinText === undefined || this.state.hdlOpinText === '') {
            alert("의견을 등록하세요.");
            return;
        }

        
        let data = {
            tcktNo : this.state.tcktNo,
            aprvLineOrder : this.state.aprvLineOrder,
            hdlOpinText : this.state.hdlOpinText,
            aprvResultCode : flag
        }

        $.ajax({
            url: REST_API_URL + "/product/Approval",
            dataType: 'json',
            type: "post",
            data: data,
            cache: false,
            success: function(result) {
                alert("처리되었습니다.");
                this.props.onDisplaySetting('L');
            }.bind(this),
            error: function(xhr, status, err) {
                alert("오류가 발생하였습니다.");
                console.log(xhr + " : " + status + " : " + err);
            }.bind(this),
			xhrFields: {
			  withCredentials: true
			}
		});
    }
    
    getProduct(productNo) {
        $.ajax({
            url: REST_API_URL + "/product/getProduct",
            dataType: 'json',
            type: "post",
            data: {
                productNo:productNo
            },
            cache: false,
            success: function(result) {
                this.setState(result.response.product);

                this.setState({
                    controlUiServiceTotal : this.serviceSum('controlUi', this.state.controlUiService),
                    functionServiceTotal : this.serviceSum('function', this.state.functionService),
                    offlineServiceTotal : this.serviceSum('offline', this.state.offlineService),
                    assetServiceTotal : this.serviceSum('asset', this.state.assetService)
                });

                backupData = $.extend(true, {}, result.response.product);

                if(this.state.aprvStatusClasCode == 'T') {//임시저장
                    this.props.onDisplaySetting('T');
                } else if(this.state.aprvStatusClasCode == 'W' && this.props.approverYn == 'Y') {//결재대기 이고 현재 단계와 로그인자가 같으면 
                    this.props.onDisplaySetting('A');
                } else if(this.state.aprvStatusClasCode == 'A') {
                    this.props.onDisplaySetting('E');
                }

            }.bind(this),
            error: function(xhr, status, err) {
                console.log(xhr + " : " + status + " : " + err);
            }.bind(this),
			xhrFields: {
			  withCredentials: true
			}
        });
    }

    approvalSaveCheck() {
        if(backupData.productUsePurposeCode == 'B' && this.state.productUsePurposeCode == 'A') {
            return true;
        } else if(!(backupData.trafficUpPrice == this.state.trafficUpPrice 
            && backupData.trafficUpExceedPrice == this.state.trafficUpExceedPrice
            && backupData.trafficUpVolume == this.state.trafficUpVolume)) {
            return true;
        } else if(!(backupData.trafficDownPrice == this.state.trafficDownPrice 
            && backupData.trafficDownExceedPrice == this.state.trafficDownExceedPrice
            && backupData.trafficDownVolume == this.state.trafficDownVolume)) {
            return true;
        } else if(!(backupData.saveVolumePrice == this.state.saveVolumePrice 
            && backupData.saveVolumeExceedPrice == this.state.saveVolumeExceedPrice
            && backupData.saveVolumeVolume == this.state.saveVolumeVolume)) {
            return true;
        } else if(!(backupData.bizDcRate == this.state.bizDcRate 
            && backupData.prvdrItemChocYn == this.state.prvdrItemChocYn
            && backupData.prvdrProftRate == this.state.prvdrProftRate
            && backupData.prvdrProftAmt == this.state.prvdrProftAmt
            && backupData.mgmrCommCost == this.state.mgmrCommCost
            && backupData.mgmrDcRate == this.state.mgmrDcRate)) {
            return true;
        } else if(JSON.stringify(backupData.assetService).replace(/\"/g,"") !== JSON.stringify(this.state.assetService).replace(/\"/g,"")) {
            return true;
        } else if(JSON.stringify(backupData.controlUiService).replace(/\"/g,"") !== JSON.stringify(this.state.controlUiService).replace(/\"/g,"")) {
            return true;
        } else if(JSON.stringify(backupData.functionService).replace(/\"/g,"") !== JSON.stringify(this.state.functionService).replace(/\"/g,"")) {
            return true;
        } else if(JSON.stringify(backupData.offlineService).replace(/\"/g,"") !== JSON.stringify(this.state.offlineService).replace(/\"/g,"")) {
            return true;
        }

        return false;
    }

    validationChecke(flag) {

        if(this.state.productName.trim() == "") {
            alert("상품명을 입력하세요.");
            return false;
        } 

        if((this.state.productUsePurposeCode == 'A' && this.state.approvalLine.length <= 1 && this.state.aprvStatusClasCode == 'T') 
             || flag == 'W' && this.state.approvalLine.length <= 1) {
            alert("결재선을 지정하세요.");
            return false;
        }

        if((this.state.productUsePurposeCode == 'A' && this.state.aprvStatusClasCode == 'T') || flag == 'W' ) {
            let isApprover = false;
            $.each(this.state.approvalLine, function(i, el){
                if(el.aprvStepCode == 'A') {
                    isApprover = true;
                }
            });
            if(!isApprover) {
                alert("결재선에 승인자를 지정하세요.");
                return false;
            }
        }

        if(this.state.productVdtStatusCode != 'A' && this.state.aprvStatusClasCode != 'A') {
            alert("판매 상태는 결재 완료 후 변경 할 수 있습니다.");
            return false;
        }
        if(flag == 'W' && this.state.productUsePurposeCode == 'B') {
            alert("가상견적은 결재품의 할 수 없습니다.");
            return false;
        }

        return true;
    }

    handleSave(flag) {

        let approvalLine = this.state.approvalLine;
        //if(this.props.memberInfo.user_no != approvalLine[0].aprvChargeUsrNo) {
        if(this.props.memberInfo.user_no != this.state.regUsrNo) {
            alert("등록자가 아닙니다.");
            return;
        }

        /*if(flag === 'DELETE') {
            if(!confirm("정말 삭제하시겠습니까?")) {
                return;
            } 
        } else if(flag === 'T' && this.state.aprvStatusClasCode !== 'T') {
            console.log("AAAAAA");
            if(this.approvalSaveCheck()) {
                alert("결재품의해야 합니다.");
                return;
            }
        } else if(flag === 'W') {
            if(!confirm("결재 요청하시겠습니까?")) {
                return;
            }
        }*/
        if(flag === 'DELETE') {
            if(!confirm("정말 삭제하시겠습니까?")) {
                return;
            } 
        } else if(flag === 'W') {
            if(!confirm("결재 요청하시겠습니까?")) {
                return;
            }
        } else {
            if(this.approvalSaveCheck()) {
                alert("결재품의해야 합니다.");
                return;
            }

            if(!confirm("저장하시겠습니까?")) {
                return;
            }
        }

        
		if(!this.validationChecke(flag)) {
			return;
		}

        let aprvStatusClasCode = this.state.aprvStatusClasCode;
        if(flag === 'T') {
            this.state.aprvStatusClasCode = this.state.aprvStatusClasCode == 'A' ? this.state.aprvStatusClasCode : flag;
        } else {
            this.state.aprvStatusClasCode = flag;
        }


        let data = $.extend(true, {}, this.state);
        data.loginUserNo = this.props.memberInfo.user_no;
        delete data.assetServiceTotal;          //장비 합계 금액
        delete data.controlUiServiceTotal;      //관제UI 설정 합계 금액
        delete data.functionServiceTotal;       //서비스 기능 설정 합계 금액
        delete data.offlineServiceTotal;         //Offline 서비스 합계 금액
        delete data.approvalNo;
        delete data.approvalEmail;

		$.ajax({
			url: REST_API_URL + "/product/Edit",
			dataType: 'json',
			type: "post",
			data:  {paramJson : JSON.stringify(data)},
			cache: false,
			success: function(result) {
                if(result.response.complete) {
                    if(flag === 'DELETE') {
                        alert("삭제되었습니다.");
                    } else if(flag === 'T') {
                        alert("수정하신 내용이 저장되었습니다.");
                    } else if(flag === 'W') {
                        alert("결재가 요청 되었습니다.");
                    }
                    
                    //this.props.onDisplaySetting('L');
                    this.props.onListReload();
                } else {
                    alert(result.response.message);
                }
			}.bind(this),
				error: function(xhr, status, err) {
                console.log(xhr + " : " + status + " : " + err);
                this.state.aprvStatusClasCode = aprvStatusClasCode;
			}.bind(this),
			xhrFields: {
			  withCredentials: true
			}
		});

    }

    render() {
        return (

            <div id="tab-cont1" className="tab_content tab-cont" style={{display:'block'}}>
                {/* S:content_body */}
                <div className="content_body">
                    {/* S:content_inner */}
                    <div className="content_inner">
                    
                        <ApprovalLineSetting onRef={ref => (this.approvalLineSetting = ref)}
                                            approvalLine={this.state.approvalLine} 
                                            onApprovalLineComplete={this.handleApprovalLineComplete}
                                            isChange={(this.state.aprvStatusClasCode === 'T' || this.state.aprvStatusClasCode === 'A') ? true : false}
                                            isComment={(this.props.approverYn === 'Y') ? true : false}
                                            isCommentView={(this.state.aprvStatusClasCode === 'A' || this.state.aprvStatusClasCode === 'R' || this.state.aprvStatusClasCode === 'W')  ? true : false}
                                            onCommentChange={this.handleChange}
                                            menuPath={'product'}
                                            />

                        <div className="box_com">
                            <div className="fl">
                                <h3 className="ctitle">{this.props.messages.product_product_information}</h3>
                            </div>
                            <div className="fr">
                                <div className="desc">
                                    <span className="tc_red">*</span> {this.props.messages.contract_reguired}
                                </div>
                                {/*<div className="fr">
                                    <a href="javascript:;" className="btn_pos">상품 불러오기</a>
                                </div>*/}
                            </div>
                        </div>

                        <table className="tbl_row">
                            <caption>상품 정보 테이블</caption>
                            <colgroup>
                                <col style={{width:'10%'}}/>
                                <col style={{width:'40%'}}/>
                                <col style={{width:'10%'}}/>
                                <col style={{width:'40%'}}/>
                            </colgroup>
                            <tbody>
                                <tr>
                                    <th scope="row">{this.props.messages.product_product_name} <span className="tc_red">*</span></th>
                                    <td className="input">
                                        <input type="text" className="ui_input" name="productName" value={this.state.productName}  onChange={this.handleChange} maxLength={100}/>
                                    </td>
                                    <th scope="row">{this.props.messages.product_writer} </th>
                                    <td className="input">
                                        {this.state.regUsrName}
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">{this.props.messages.product_update_time} </th>
                                    <td className="input">
                                        {this.state.regDate}
                                    </td>
                                    <th scope="row">{this.props.messages.product_division} <span className="tc_red">*</span></th>
                                    <td className="input">
                                        <ul className="ip_list">
                                            <li>
                                                <span className="input_ico_box">
                                                    <input type="radio" name="productDstnctCode" id={"productDstnctCode_rdo_1"} value="A" checked={this.state.productDstnctCode === "A"} onChange={this.handleChange}/>
                                                    {<label htmlFor={"productDstnctCode_rdo_1"}>{this.props.messages.product_integrated_control}</label>}
                                                </span>
                                            </li>
                                            <li>
                                                <span className="input_ico_box">
                                                    <input type="radio" name="productDstnctCode" id={"productDstnctCode_rdo_2"}  value="B" checked={this.state.productDstnctCode === "B"} onChange={this.handleChange}/>
                                                    {<label htmlFor={"productDstnctCode_rdo_2"}>{this.props.messages.product_physical_security}</label>}
                                                </span>
                                            </li>
                                            <li>
                                                <span className="input_ico_box">
                                                    <input type="radio" name="productDstnctCode" id={"productDstnctCode_rdo_3"}  value="C" checked={this.state.productDstnctCode === "C"} onChange={this.handleChange}/>
                                                    {<label htmlFor={"productDstnctCode_rdo_3"}>{this.props.messages.product_data_security}</label>}
                                                </span>
                                            </li>
                                        </ul>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">{this.props.messages.product_usage} <span className="tc_red">*</span></th>
                                    <td className="input">
                                        <ul className="ip_list">
                                            <li>
                                                <span className="input_ico_box">
                                                    <input type="radio" name="productUsePurposeCode" id={"productUsePurposeCode_rdo_1"} value="A" 
                                                            checked={this.state.productUsePurposeCode === "A"} 
                                                            onChange={this.handleChange}/>
                                                    {<label htmlFor={"productUsePurposeCode_rdo_1"}>{this.props.messages.product_product_design}</label>}
                                                </span>
                                            </li>
                                            <li>
                                                <span className="input_ico_box">
                                                    <input type="radio" name="productUsePurposeCode" id={"productUsePurposeCode_rdo_2"}  value="B" 
                                                            checked={this.state.productUsePurposeCode === "B"} 
                                                            onChange={this.handleChange} 
                                                            disabled={this.state.aprvStatusClasCode === 'A' ? true : false}/>
                                                    {<label htmlFor={"productUsePurposeCode_rdo_2"}>{this.props.messages.product_estimation}</label>}
                                                </span>
                                            </li>
                                        </ul>
                                    </td>
                                    <th scope="row">{this.props.messages.product_sales_status} <span className="tc_red">*</span></th>
                                    <td className="input">
                                        <ul className="ip_list">
                                            <li>
                                                <span className="input_ico_box">
                                                    <input type="radio" name="productVdtStatusCode" id={"productVdtStatusCode_rdo_1"} value="A" 
                                                            checked={this.state.productVdtStatusCode === "A"} 
                                                            onChange={this.handleChange}
                                                            disabled={!this.state.productVdtStatusCodeChange}/>
                                                    {<label htmlFor={"productVdtStatusCode_rdo_1"}>{this.props.messages.product_waiting}</label>}
                                                </span>
                                            </li>
                                            <li>
                                                <span className="input_ico_box">
                                                    <input type="radio" name="productVdtStatusCode" id={"productVdtStatusCode_rdo_2"}  value="B" 
                                                            checked={this.state.productVdtStatusCode === "B"} 
                                                            onChange={this.handleChange} 
                                                            disabled={!(this.state.aprvStatusClasCode === 'A' && this.state.productUsePurposeCode === "A") ? true : false}/>
                                                    {<label htmlFor={"productVdtStatusCode_rdo_2"}>{this.props.messages.product_on_sale}</label>}
                                                </span>
                                            </li>
                                            <li>
                                                <span className="input_ico_box">
                                                    <input type="radio" name="productVdtStatusCode" id={"productVdtStatusCode_rdo_3"}  value="C" 
                                                            checked={this.state.productVdtStatusCode === "C"} 
                                                            onChange={this.handleChange} 
                                                            disabled={!(this.state.aprvStatusClasCode === 'A' && this.state.productUsePurposeCode === "A")  || !this.state.productVdtStatusCodeChange ? true : false}/>
                                                    {<label htmlFor={"productVdtStatusCode_rdo_3"}>{this.props.messages.product_stop_selling}</label>}
                                                </span>
                                            </li>
                                        </ul>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">{this.props.messages.product_traffic}(Up)</th>
                                    <td className="input" colSpan={3}>
                                        <ul className="ip_list col3">
                                            <li>
                                                <span className="opt_box">
                                                    <span className="lb">{this.props.messages.product_monthly_traffic}(GB)</span>
                                                    <input type="text" className="ui_input" name="trafficUpVolume" value={this.state.trafficUpVolume === null ? '' : this.state.trafficUpVolume}  onChange={this.handleChange} maxLength={10} onInput={this.handleOnlyNumber.bind(this, 0)}/>
                                                    <span className="unit">GB</span>
                                                </span>
                                            </li>
                                            <li>
                                                <span className="opt_box">
                                                    <span className="lb">{this.props.messages.product_basic_rate}({this.props.messages.product_month})</span>
                                                    <input type="text" className="ui_input" name="trafficUpPrice" value={this.state.trafficUpPrice === null ? '' : this.state.trafficUpPrice}  onChange={this.handleChange} maxLength={10} onInput={this.handleOnlyNumber.bind(this, 0)}/>
                                                    <span className="unit">원</span>
                                                </span>
                                            </li>
                                            <li>
                                                <span className="opt_box">
                                                    <span className="lb">{this.props.messages.product_excess_charge}(GB)</span>
                                                    <input type="text" className="ui_input" name="trafficUpExceedPrice" value={this.state.trafficUpExceedPrice === null ? '' : this.state.trafficUpExceedPrice}  onChange={this.handleChange} maxLength={10} onInput={this.handleOnlyNumber.bind(this, 0)}/>
                                                    <span className="unit">원</span>
                                                </span>
                                            </li>
                                        </ul>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">{this.props.messages.product_traffic}(Down)</th>
                                    <td className="input" colSpan={3}>
                                        <ul className="ip_list col3">
                                            <li>
                                                <span className="opt_box">
                                                    <span className="lb">{this.props.messages.product_monthly_traffic}(GB)</span>
                                                    <input type="text" className="ui_input" name="trafficDownVolume" value={this.state.trafficDownVolume === null ? '' : this.state.trafficDownVolume}  onChange={this.handleChange} maxLength={10} onInput={this.handleOnlyNumber.bind(this, 0)}/>
                                                    <span className="unit">GB</span>
                                                </span>
                                            </li>
                                            <li>
                                                <span className="opt_box">
                                                    <span className="lb">{this.props.messages.product_basic_rate}({this.props.messages.product_month})</span>
                                                    <input type="text" className="ui_input" name="trafficDownPrice" value={this.state.trafficDownPrice === null ? '' : this.state.trafficDownPrice}  onChange={this.handleChange} maxLength={10} onInput={this.handleOnlyNumber.bind(this, 0)}/>
                                                    <span className="unit">원</span>
                                                </span>
                                            </li>
                                            <li>
                                                <span className="opt_box">
                                                    <span className="lb">{this.props.messages.product_excess_charge}(GB)</span>
                                                    <input type="text" className="ui_input" name="trafficDownExceedPrice" value={this.state.trafficDownExceedPrice === null ? '' : this.state.trafficDownExceedPrice}  onChange={this.handleChange} maxLength={10} onInput={this.handleOnlyNumber.bind(this, 0)}/>
                                                    <span className="unit">원</span>
                                                </span>
                                            </li>
                                        </ul>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">{this.props.messages.product_storage_capacity}</th>
                                    <td className="input" colSpan={3}>
                                        <ul className="ip_list col3">
                                            <li>
                                                <span className="opt_box">
                                                    <span className="lb">{this.props.messages.product_monthly_capacity}(GB)</span>
                                                    <input type="text" className="ui_input" name="saveVolumeVolume" value={this.state.saveVolumeVolume === null ? '' : this.state.saveVolumeVolume}  onChange={this.handleChange} maxLength={10} onInput={this.handleOnlyNumber.bind(this, 0)}/>
                                                    <span className="unit">GB</span>
                                                </span>
                                            </li>
                                            <li>
                                                <span className="opt_box">
                                                    <span className="lb">{this.props.messages.product_basic_rate}({this.props.messages.product_month})</span>
                                                    <input type="text" className="ui_input" name="saveVolumePrice" value={this.state.saveVolumePrice === null ? '' : this.state.saveVolumePrice}  onChange={this.handleChange} maxLength={10} onInput={this.handleOnlyNumber.bind(this, 0)}/>
                                                    <span className="unit">원</span>
                                                </span>
                                            </li>
                                            <li>
                                                <span className="opt_box">
                                                    <span className="lb">{this.props.messages.product_excess_charge}(GB)</span>
                                                    <input type="text" className="ui_input" name="saveVolumeExceedPrice" value={this.state.saveVolumeExceedPrice === null ? '' : this.state.saveVolumeExceedPrice}  onChange={this.handleChange} maxLength={10} onInput={this.handleOnlyNumber.bind(this, 0)}/>
                                                    <span className="unit">원</span>
                                                </span>
                                            </li>
                                        </ul>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">{this.props.messages.product_promotion_rate} </th>
                                    <td className="input" colSpan={3}>
                                        <ul className="ip_list col3">
                                            <li>
                                                <span className="opt_box">
                                                    <span className="lb">{this.props.messages.product_discount_rate}</span>
                                                    <input type="text" className="ui_input" name="bizDcRate" value={this.state.bizDcRate === null ? '' : this.state.bizDcRate} onChange={this.handleChange} maxLength={5}/>
                                                    <span className="unit">%</span>
                                                </span>
                                            </li>
                                        </ul>
                                    </td>
                                </tr>
                            {
                            this.props.memberInfo.user_dstnct_code == "03"
                            ?
                                <tr>
                                    <th scope="row">{this.props.messages.product_admin_inputs}</th>
                                    <td className="input" colSpan="3">
                                        <ul className="ip_list col3">
                                            <li>
                                                <span className="opt_box">
                                                    <span className="lb">{this.props.messages.product_common_cost}</span>
                                                    <input type="text" className="ui_input" name="mgmrCommCost" value={this.state.mgmrCommCost === null ? '' : this.state.mgmrCommCost}  onChange={this.handleChange} maxLength={10} onInput={this.handleOnlyNumber.bind(this, 0)}/>
                                                    <span className="unit">원</span>
                                                </span>
                                            </li>
                                            <li>
                                                <span className="opt_box">
                                                    <span className="lb">{this.props.messages.product_profit_margin}</span>
                                                    <input type="text" className="ui_input" name="mgmrDcRate" value={this.state.mgmrDcRate === null ? '' : this.state.mgmrDcRate}  onChange={this.handleChange} maxLength={5}/>
                                                    <span className="unit">%</span>
                                                </span>
                                            </li>
                                        </ul>
                                    </td>
                                </tr>
                            :
                                <tr>
                                    <th scope="row">			
                                        <span className="input_ico_box reverse">
                                            <input type="checkbox" name="prvdrItemChocYn" id="prvdrItemChocYn" value="Y" defaultChecked={this.state.prvdrItemChocYn === 'Y' ? true : false} onChange={this.handleChange}/>
                                            <label htmlFor={"prvdrItemChocYn"}>{this.props.messages.product_provider_inputs}</label>
                                        </span>
                                    </th>
                                    <td className="input" colSpan="3">
                                        <ul className="ip_list col3">
                                            <li>
                                                <span className="opt_box">
                                                    <span className="lb">{this.props.messages.product_profit_margin}</span>
                                                    <input type="text" className="ui_input" name="prvdrProftRate" value={this.state.prvdrProftRate === null ? '' : this.state.prvdrProftRate}  onChange={this.handleChange}
                                                           disabled={this.state.prvdrItemChocYn === 'Y' ? "" : "disabled"} maxLength={5}/>
                                                    <span className="unit">%</span>
                                                </span>
                                            </li>
                                            <li>
                                                <span className="opt_box">
                                                    <span className="lb">{this.props.messages.product_profit}</span>
                                                    <input type="text" className="ui_input" name="prvdrProftAmt" value={this.state.prvdrProftAmt === null ? '' : this.state.prvdrProftAmt}  onChange={this.handleChange}
                                                           disabled={this.state.prvdrItemChocYn === 'Y' ? "" : "disabled"} maxLength={10} onInput={this.handleOnlyNumber.bind(this, 0)}/>
                                                    <span className="unit">원</span>
                                                </span>
                                            </li>
                                        </ul>
                                    </td>
                                </tr>
                            }


                                
                            </tbody>
                        </table>

                        <div className="box_com">
                            <div className="fl">
                                <h3 className="ctitle">{this.props.messages.product_device_setup}</h3>
                            </div>
                        </div>
                        <AssetSetting onRef={ref => (this.assetSetting = ref)} 
                                        onServiceChange={this.handleServiceChange}
                                        serviceData={this.state.assetService}/>
                        <div style={{height:'17px'}}></div>
                        <div className="box_com">
                            <div className="fl">
                                <h3 className="ctitle">{this.props.messages.product_control_ui_setup}</h3>
                            </div>
                            <div className="fr">
                                <div className="desc">
                                    <div className="tc_gray">{this.props.messages.product_total} : <span className="tc_blue">{this.state.controlUiServiceTotal}</span> {this.props.messages.product_won}</div>
                                </div>
                            </div>
                        </div>
                        <ServiceSetting onRef={ref => (this.serviceSetting1 = ref)}
                                        serviceCode={['CONTROL_UI_SERVICE']} 
                                        type="radioBox" 
                                        name="controlUi" 
                                        onServiceChange={this.handleServiceChange}
                                        serviceData={this.state.controlUiService}/>

                        <div className="box_com">
                            <div className="fl">
                                <h3 className="ctitle">{this.props.messages.product_function_setup}</h3>
                            </div>
                            <div className="fr">
                                <div className="desc">
                                    <div className="tc_gray">{this.props.messages.product_total} : <span className="tc_blue">{this.state.functionServiceTotal}</span> {this.props.messages.product_won}</div>
                                </div>
                            </div>
                        </div>
                        <ServiceSetting onRef={ref => (this.serviceSetting2 = ref)} 
                                        serviceCode={['BASIC_SERVICE', 'SELECT_SERVICE']} 
                                        type="checkBox" 
                                        name="function" 
                                        onServiceChange={this.handleServiceChange}
                                        serviceData={this.state.functionService}/>
                        
                        <div className="box_com">
                            <div className="fl">
                                <h3 className="ctitle">{this.props.messages.product_offline_service}</h3>
                            </div>
                            <div className="fr">
                                <div className="desc">
                                    <div className="tc_gray">{this.props.messages.product_total} : <span className="tc_blue">{this.state.offlineServiceTotal}</span> {this.props.messages.product_won}</div>
                                </div>
                            </div>
                        </div>
                        <ServiceSetting onRef={ref => (this.serviceSetting4 = ref)} 
                                        serviceCode={['OFFLINE_SERVICE']} 
                                        type="checkBox" 
                                        name="offline" 
                                        onServiceChange={this.handleServiceChange}
                                        serviceData={this.state.offlineService}/>
                            
                        <div className="order_price_wrap">      
                            <div className="box goodsprice">
                                <dl>
                                    <dt>{this.props.messages.product_price}</dt>
                                    <dd className="total">
                                        <strong className="num">{this.state.productDcBefSumAmt}</strong> <span className="unit">{this.props.messages.product_won}</span>
                                    </dd>
                                </dl>
                            </div>
                            <div className="box discount">
                                <i className="ico ico_minus"></i>
                                <dl>
                                    <dt>{this.props.messages.product_discount_price}</dt>
                                    <dd className="total">
                                        <strong className="num">{this.state.dcAmt}</strong> <span className="unit">{this.props.messages.product_won}</span>
                                    </dd>
                                </dl>
                            </div>
                            <div className="box pay_total">
                                <i className="ico ico_equal"></i>
                                <dl>
                                    <dt>{this.props.messages.product_final_price}</dt>
                                    <dd className="total">
                                        <strong className="num">{this.state.lastSumAmt}</strong> <span className="unit">{this.props.messages.product_won}</span>
                                    </dd>
                                </dl>
                            </div>
                        </div>

                        <div className="box_com">
                            <div className="fl">
                                <h3 className="ctitle">{this.props.messages.product_remark}</h3>
                            </div>
                        </div>
                        <table className="tbl_row">
                            <caption>상품 정보 테이블</caption>
                            <colgroup>
                                <col style={{width:'10%'}}/>
                                <col style={{width:'90%'}}/>
                            </colgroup>
                            <tbody>
                                <tr>
                                    <th scope="row">{this.props.messages.product_memo}</th>
                                    <td className="input" colSpan={3}>
                                        <textarea className="ui_textarea" name="etcMemoText" value={this.state.etcMemoText}  onChange={this.handleChange} maxLength={4000}></textarea>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                        
                    </div>
                </div>
            </div>

        );
    }
}

export default connect(mapStateToProps)(Detail);
