/*jshint esversion: 6 */
import React from 'react';
import axios from 'axios';

import Calendar from '../common/Calendar';
import CodeSelect from '../common/CodeSelect';
import AttachFile from '../common/AttachFile';
import BulkUpload from '../common/BulkUpload';


import {TableThead, TableColgroup} from '../common/TableThead';
import {REST_API_URL} from '../../config/api-config.js';
import BnofCreate  from '../customer/BnofCreate';
import { Link, browserHistory } from 'react-router';

/* 유효성 체크 */
import validator from 'validator';

/*다국어 모듈 시작*/
import { connect } from 'react-redux';
import { changeLangauge, mapStateToProps, actionlogin } from '../../language/Actions';
import { isNull } from 'util';
import { parse } from 'query-string';
/*다국어 모듈 종료*/

class CustomerDetail extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            listThead : [
                {name:'checkbox', sort:false, sortColumn:"", view:true, target:false, checkbox:true, width:'4%'},
                {name:props.messages.customer_bnof_name,       sort:false, sortColumn:"", view:true, target:true, width:'12%'},
                {name:props.messages.customer_bnof_addr,       sort:false, sortColumn:"", view:true, target:true, width:'60%'},
                {name:props.messages.customer_bnof_tel,      sort:false, sortColumn:"", view:true, target:true, width:'24%'},
            ],

            loginUserNo :0,
            custmNo : 0,
            custmClasCode : "",
            customerClasCode : "",
            coName : "",
            ceoName : "",
            bizno : "",
            coAddr : "",
            hmpageUrl : "",
            useYn : "",

            chargeUsrSeq : 0,
            chargeUsrName : "",
            chargeUsrDeptName : "",
            chargeUsrPositName : "",
            chargeUsrEmail : "",
            chargeUsrTel : "",
            chargeUsrMobileNo : "",
            chargeUsrClasCode : "",

            chargeUserInfo : {
                custmClsName:"",
                chargeUsrName:"",
                chargeUsrDeptName:"",
                chargeUsrPositName:"",
                chargeUsrMobileNo:"",
                chargeUsrTel:"",
                chargeUsrEmail:"",
            },
            ctrtInfo : {
                ctrtDstnctName :"",
                ctrtUserName :"",
                regDate :"",
                demandDate :"",
            },
            bnofList : [],
            files: [],
            attachFile : [],
            file:[]
        }

        this.handleChange = this.handleChange.bind(this);
        this.handleFileChange = this.handleFileChange.bind(this);
        this.handlecustomerSave = this.handlecustomerSave.bind(this);
        this.handleCreateComplete = this.handleCreateComplete.bind(this);
        this.handleDeleteBnof = this.handleDeleteBnof.bind(this);
        this.handleBulkUploadPopup = this.handleBulkUploadPopup.bind(this);
        this.handleBulkUpload = this.handleBulkUpload.bind(this);
        this.handleBulkUploadSample = this.handleBulkUploadSample.bind(this);
        this.handleBulkFileChange = this.handleBulkFileChange.bind(this);

        this.handleBnofAdd = this.handleBnofAdd.bind(this);

    }

    //  Customer 현황 저장
    handleSave(){
		if(!this.validationChecke()) {
			return;
        }
        
		if(this.state.attachFile.length > 0) {
			this.attachFile.fileUpload();
		} else {
			this.handlecustomerSave(null);
		}
    }
   
    handleChange(e) {
        let nextState = {};
        nextState[e.target.name]=e.target.value;
        this.setState(nextState);
    }

    handleBulkFileChange(file) {
        this.setState({
            file : file
        });
    }

    handleFileRemove(key) {
		let files = this.state.attachFile;

		attachFile.splice(key, 1);

		this.setState({
			attachFile : attachFile
		});
    }
    
	handleFileChange(attachFile) {
		this.setState({
			attachFile : attachFile
		});
    }

    handleBulkUploadPopup() {
        this.bulkUpload.show();
    
        this.setState({
            file : null
        });
    }

    handleBulkUpload() {
        console.log(this.state);
        if(this.state.file == null || this.state.file.length < 1) {
            alert("파일을 선택하세요.");
            return;
        }
        this.bulkUpload.uploadButtonToggle();
        let formData = new FormData();

        formData.append("file", this.state.file);
        
        axios.post(REST_API_URL +"/customer/bulk_upload", formData, { withCredentials : true }, {
            headers: { "X-Requested-With": "XMLHttpRequest" }
        }).then( response => { 
            /*if(response.data.bulkUploadError === undefined) {
                this.bulkUpload.hide();
                this.handleCreateComplete();
            } else {
                console.log(response.data.bulkUploadError);
                this.bulkUpload.uploadButtonToggle();
            }*/

            if(response.data.response.error != undefined && response.data.response.error) {
                alert("등록 도중 오류가 발생하였습니다. 관리자에게 문의바랍니다.");
            } else {
                if(response.data.response.bulkUploadError === undefined) {
                    //alert("파일이 등록되었습니다.");
                    

                    let bnofList = this.state.bnofList;

                    $.each(response.data.response.bnofList, function(i, el) {
                        bnofList.push(el);
                    });

                    this.setState({
                        bnofList : bnofList
                    });

                    this.bulkUpload.hide();

                } else {
                    let msg = "";
                    msg += "첨부하신 파일에서 잘못된 정보가 입력되었습니다.\n";
                    msg += "파일 수정 후 다시 등록 해 주세요.\n\n";
                    msg += "(오류 : ";

                    $.each(response.data.response.bulkUploadError, function(i, el) {
                        msg += (i == 0 ? "": ", ") + el.rowIndex + "행";
                    });
                    msg += ")";

                    alert(msg);

                    console.log(response.data.response.bulkUploadError);
                }

            }

            this.bulkUpload.uploadButtonToggle();
        })
        .catch( response => { 
            console.log(response);
            this.bulkUpload.uploadButtonToggle();
        } );
    }
    
    handleBulkUploadSample() {
        var form = "<form action='" + REST_API_URL + "/customer/sample_download' method='post'>"; 
        form += "<input type='hidden' name='custmNo' value='"+this.state.custmNo+"' />"; 
        form += "</form>"; 
        jQuery(form).appendTo("body").submit().remove();
    }

    componentWillReceivePropsnextProps(){
        if(this.props.locale !== nextProps.locale) {
            let listThead = this.state.listThead;
            listThead[0].name = "";
            listThead[1].name = nextProps.messages.customer_bnof_name;
            listThead[2].name = nextProps.messages.customer_bnof_addr;
            listThead[3].name = nextProps.messages.customer_bnof_tel;
        }
    }
    
    //컴포넌트가 만들어지고 첫 렌더링을 다 마친 후 실행되는 메소드입니다.
    componentDidMount() {

        if(this.props.location === undefined || this.props.location.query === undefined || this.props.location.query.ctrtNo === undefined) {
            this.props.onRef(this);

            this.getcustomer(this.props.custmNo);
        } else {
            this.getcustomer(this.props.location.query.custmNo);
        }
    }

    //컴포넌트가 DOM 에서 사라진 후 실행되는 메소드입니다.
	componentWillUnmount() {
		if(this.props.location === undefined || this.props.location.query === undefined || this.props.location.query.ctrtNo === undefined) {
            this.props.onRef(null);
        }
	}

    getcustomer(value) {
        let memberInfo = JSON.parse(localStorage.getItem("memberInfo"));
        console.log(typeof this.props.custmNo);
        JSON.stringify(this.props.custmNo);

        let parameters = {
            custmNo : this.props.custmNo,
            loginUserNo : memberInfo.user_no
        };

        $.ajax({
            url: REST_API_URL + "/customer/select",
            dataType: 'json',
            type: "post",
            data:  parameters,                  //  this.props.custmNo,
            cache: false,
            processData : true,                 /*querySTring make false*/
            success: function(result) {
                console.log(JSON.stringify(result));
                this.props.onDisplaySetting('R');
                this.setResponseData(result);
                // this.setState(result);
                    
            }.bind(this),
            error: function(xhr, status, err) {
              console.log(xhr + " : " + status + " : " + err);
            }.bind(this),
            xhrFields: {
              withCredentials: true
            }
        });
    }

    //  지점 등록 후 리스트 조회
    handleCreateComplete(){

        $.ajax({
			url: REST_API_URL + "/customer/bnof_select",
			dataType: 'json',
			type: "post",
			data:  {custmNo : this.state.custmNo},
			cache: false,
			processData : true, /*querySTring make false*/
			success: function(result) {
                this.setState({
                    bnofList : result.response
                });
			}.bind(this),
				error: function(xhr, status, err) {
				console.log(xhr + " : " + status + " : " + err);
			}.bind(this),
            xhrFields: {
              withCredentials: true
            }
        });
        
    }

    setResponseData(result){
        this.setState({
            custmNo : result.response.customer.custmNo,
            customerClasCode : result.response.customer.customerClasCode,
            coName : result.response.customer.coName,
            ceoName : result.response.customer.ceoName,
            bizno : result.response.customer.bizno,
            coAddr : result.response.customer.coAddr,
            hmpageUrl : result.response.customer.hmpageUrl,
            coEmail : result.response.customer.coEmail,
            coTel : result.response.customer.coTel,
            coFaxNo : result.response.customer.coFaxNo,
            prvdrNo : result.response.customer.prvdrNo,
            bmModelClasCode : result.response.customer.bmModelClasCode,
            bmModelClasName : result.response.customer.bmModelClasName,
            useYn : result.response.customer.useYn,
            prvdrCtrtEndDate : result.response.customer.prvdrCtrtEndDate,
            prvdrCtrtStrDate : result.response.customer.prvdrCtrtStrDate,
            attachFile : result.response.customer.attachFile,
            chargeUsrSeq : result.response.customer.chargeUsrSeq,
            chargeUsrName : result.response.customer.chargeUsrName,
            chargeUsrDeptName : result.response.customer.chargeUsrDeptName,
            chargeUsrPositName : result.response.customer.chargeUsrPositName,
            chargeUsrEmail : result.response.customer.chargeUsrEmail,
            chargeUsrTel : result.response.customer.chargeUsrTel,
            chargeUsrMobileNo : result.response.customer.chargeUsrMobileNo,
            chargeUsrClasCode : result.response.customer.chargeUsrClasCode,
            chargeUserInfo : this.setChargeUserInfo(result.response.chargeUserInfo),
            ctrtInfo : result.response.ctrtInfo,
            bnofList : result.response.bnofList
        });
    }

    setChargeUserInfo(item) {

        console.log(JSON.stringify(item));
        
        if(!item){

            item = {
                custmClsName:"",
                chargeUsrName:"",
                chargeUsrDeptName:"",
                chargeUsrPositName:"",
                chargeUsrMobileNo:"",
                chargeUsrTel:"",
                chargeUsrEmail:"",
            }
        }

        return item;

    }

	handlecustomerSave(attachFile) {

        if(!this.validationChecke()){
            return false;
        }

        let memberInfo = JSON.parse(localStorage.getItem('memberInfo'));

        let CustmCustomerSaveDto = {
	        custmNo : this.state.custmNo,
            customerClasCode: this.state.customerClasCode,
            custmClasCode: this.state.custmClasCode,
	        coName: this.state.coName,
	        ceoName: this.state.ceoName,
	        bizno: this.state.bizno,
	        coAddr: this.state.coAddr,
	        hmpageUrl: this.state.hmpageUrl,
	        prvdrNo: this.state.prvdrNo,
            chargeUsrSeq: this.state.chargeUsrSeq,
	        chargeUsrName: this.state.chargeUsrName,
	        chargeUsrDeptName: this.state.chargeUsrDeptName,
            chargeUsrPositName: this.state.chargeUsrPositName,
            chargeUsrEmail: this.state.chargeUsrEmail,
            chargeUsrTel: this.state.chargeUsrTel,
            chargeUsrMobileNo: this.state.chargeUsrMobileNo,
            useYn: this.state.useYn,
            rpsntYn: this.state.rpsntYn,
            attachFile: attachFile,
            loginUserNo: memberInfo.user_no,
            dspDefaultTZ : memberInfo.dspDefaultTZ,
            bnofList : this.state.bnofList
        };

        console.log( "Customer 담당자 PK :  "+ this.state.chargeUsrSeq);

		$.ajax({
			url: REST_API_URL + "/customer/update",
			dataType: 'json',
			type: "post",
			data: {paramJson : JSON.stringify(CustmCustomerSaveDto)},
			cache: false,
			processData : true, /*querySTring make false*/
			success: function(result) {

                console.log(JSON.stringify(result));

                alert('수정되었습니다.', this.goCustomer());
                
            }.bind(this),
            error: function(xhr, status, err) {
                alert(JSON.stringify(xhr.responseJSON.message));
                console.log(xhr + " : " + status + " : " + err);
			}.bind(this),
            xhrFields: {
              withCredentials: true
            }
		});
    }
    
    goCustomer(){
        console.log('callback 함수');
        browserHistory.push('/customer');
    }
        
    validationChecke() {

        if(this.state.coName.trim()  == "") {
            alert("고객(사)명을 입력하세요.");
            return false;
        }

        if(this.state.customerClasCode  == "") {
            alert("고객 구분을 선택하세요");
            return false;
        }

        if(this.state.bizno.trim()  == "") {
            alert("사업자번호를 입력 하세요");
            return false;
        }

        if(!validator.isNumeric(this.state.bizno)) {
            alert("사업자번호는 숫자만 입력바랍니다.");
            return false;
        }

        if(this.state.coAddr.trim() == "") {
            alert("주소를 입력하세요.");
            return false;
        }

        if(this.state.chargeUsrName.trim() == "") {
            alert("담당자 이름을 입력하세요.");
            return false;
        }

        if(this.state.chargeUsrEmail.trim() == "") {
            alert("담당자 E-mail을 입력하세요.");
            return false;
        }else {
            if (!validator.isEmail(this.state.chargeUsrEmail)) {
                alert("이메일 형식이 잘못 입력 되었습니다.");
                return false;
            }
        }

        if(this.state.chargeUsrMobileNo.trim() == "") {
            alert("휴대폰 번호를 입력하세요.");
            return false;
        }

		return true;
    }
    
    handleDeleteBnof(){
        let bnofList = this.state.bnofList;
        let deletelist = [];
        console.log(bnofList);
        $('input[name=listCheck]:checked').each(function(){
            deletelist.push($(this).val());
        });

        for(var i = deletelist.length-1; i >= 0; i--) {
            console.log(deletelist[i]);
            console.log(bnofList[deletelist[i]]);
            if(bnofList[deletelist[i]].custmBnofNo > 0) {
                bnofList[deletelist[i]].isDelete='Y';
            } else {
                bnofList.splice(deletelist[i], 1);
            }
        }

        this.setState({
			bnofList : bnofList
        });

        $("input[name='listCheck']").prop("checked", false);

        // console.log(JSON.stringify(deletelist));

        // if(deletelist.list.length>0){
        //     $.ajax({
        //         url: REST_API_URL+"/customer/bnof_Delete",
        //         dataType : "json",
        //         type : "POST",
        //         data : {paramJson : JSON.stringify(deletelist)},
        //         cache: false,
        //         success:function(result){

        //             alert('삭제 되었습니다.');
        //             //  체크박스 해제
        //             $('input[name=listCheck]:checked').each(function(){
        //                 $(this).prop("checked", false);
        //             });

        //             //  지연된 검색
        //             this.handleCreateComplete();
                
        //         }.bind(this),
        //         error:function(xhr, status, err){
        //             console.log(xhr + " : "+ status +" :" + err);
        //         }.bind(this),
        //         xhrFields: {
        //           withCredentials: true
        //         }
        //     });
        // }
        // else{
        //     alert("선택된 지점이 없습니다.");
        // }  
    }

    maxLengthCheck(e){
        e.target.value = e.target.value.replace(/[^0-9]/g,"");
    
        if(e.target.value.length > e.target.maxLength){
          e.target.value = e.target.value.slice(0, e.target.maxLength);
        }
    }

    handleBnofAdd(bnof) {
        
        console.log(JSON.stringify(" 전달 받은 값 ==> "+bnof));

        let bnofList = this.state.bnofList;

        bnofList.push(bnof);

        this.setState({
            bnofList : bnofList
        });
    }

    render() {
        const fncBtnInfo = this.props.memberInfo.dspUserFncBtnInfo;
        const {custmNo} = this.state;
        const enabled = custmNo > 0 ;
        const {bnofList} = this.state;

        const mapToComponent = (data, thead) => {
            if(data.length > 0) {
              return data.map((bnof, i) => {//map
                if(bnof.isDelete != 'Y') {
                    return(
                    <tr key={i}>
                        <td className='ui_only_chk'>
                            <span className='input_ico_box'>
                                <input type='checkbox' 
                                    name='listCheck' 
                                    //id={"ip-chk1-"+provider.chargeUsrSeq} 
                                    id={"ip-chk1-"+i} 
                                    value={i} 
                                    defaultChecked={false}
                                />
                                <label htmlFor={"ip-chk1-"+i}/>
                            </span>
                        </td>
                        <td style={thead[1].view ? {} : {display:'none'}}>{bnof.bnofName}</td>
                        <td style={thead[2].view ? {} : {display:'none'}}>{bnof.bnofAddr}</td>
                        <td style={thead[3].view ? {} : {display:'none'}}>{bnof.bnofTel}</td>
                    </tr>
                    );
                }
              });
            } else {
              let colspan = thead.length;
              for(var i = 0; i<thead.length; i++) {
                  colspan -= thead[i].view ? 0 : 1;
              }
              return (
                <tr>
                  <td className="noresults" colSpan={colspan}>
                    <div className="box_noresults">
                      <div className="ver_mid">
                        <i className="ico ico_no_result"></i>
                        <span className="lb">{this.props.messages.customer_there_are_no_results}</span>
                      </div>
                    </div>
                  </td>
                </tr>
              );
            }
          }
        return (
            <div id="tab-cont3" className="tab_content tab-cont" style={{display:'block'}}>
                {/* S:content_body */}
                <div className="content_body">
                    {/* S:content_inner */}
                    <div className="content_inner">
                        <div className="box_com">
                            <div className="fl">
                                <h3 className="ctitle">
                                    계약정보 {}
                                </h3>
                            </div>
                            <div className="fr">
                                <div className="desc">
                                    <span className="tc_red">*</span> {this.props.messages.contract_reguired}
                                </div>
                            </div>
                        </div>

                        {/* S:Table */}
                        <table className="tbl_row">
                            <caption>{this.props.messages.customer_detail_title}</caption>
                            <colgroup>
                                <col style={{width:'10%'}}/>
                                <col style={{width:'40%'}}/>
                                <col style={{width:'10%'}}/>
                                <col style={{width:'40%'}}/>
                            </colgroup>
                            <tbody>
                                <tr>
                                    <th scope="row">현재상태{} <span className="tc_red">*</span></th>
                                    <td className="input" colSpan={3}>
                                        {this.state.ctrtInfo==null?"":this.state.ctrtInfo.ctrtDstnctName}
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row" >등록자{}<span className="tc_red">*</span></th>
                                    <td className="input">
                                    {this.state.ctrtInfo==null?"":this.state.ctrtInfo.ctrtUserName}
                                    </td>
                                    <th scope="row" >등록일{}<span className="tc_red">*</span></th>
                                    <td className="input">
                                    {this.state.ctrtInfo==null?"":this.state.ctrtInfo.regDate}
                                    </td>
                                </tr>
                                {/*<tr>
                                    <th scope="row" >요청자{}<span className="tc_red">*</span></th>
                                    <td className="input">
                                        {this.props.memberInfo.user_name}
                                    </td>
                                    <th scope="row" >요청일{}<span className="tc_red">*</span></th>
                                    <td className="input">
                                    {this.state.ctrtInfo==null?"":this.state.ctrtInfo.demandDate}
                                    </td>
                                </tr>*/}
                            </tbody>
                        </table>
                        {/* E:Table */}
                        <div className="box_com">
                            <div className="fl">
                                <h3 className="ctitle">
                                    {this.props.messages.customer_detail_title}
                                </h3>
                            </div>
                            <div className="fr">
                                <div className="desc">
                                    <span className="tc_red">*</span> {this.props.messages.contract_reguired}
                                </div>
                            </div>
                        </div>

                        {/* S:Table */}
                        <table className="tbl_row">
                            <caption>{this.props.messages.customer_detail_title}</caption>
                            <colgroup>
                                <col style={{width:'10%'}}/>
                                <col style={{width:'40%'}}/>
                                <col style={{width:'10%'}}/>
                                <col style={{width:'40%'}}/>
                            </colgroup>
                            <tbody>
                                <tr>
                                    <th scope="row">{this.props.messages.customer_name} <span className="tc_red">*</span></th>
                                    <td className="input" colSpan={3}>
                                        <input type="text" className="ui_input" name="coName" value={this.state.coName} onChange={this.handleChange} />
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">{this.props.messages.clas_code_title} <span className="tc_red">*</span></th>
                                    <td  className="input">
                                        <ul className="ip_list">
                                            <li>
                                                <span className="input_ico_box">
                                                    <input type="radio" name="customerClasCode" id={"customer_rdo_1"} value="01" checked={this.state.customerClasCode === "01"} onChange={this.handleChange}/>
                                                    {<label htmlFor={"customer_rdo_1"}>{this.props.messages.clas_code_01}</label>}
                                                </span>
                                            </li>
                                            <li>
                                                <span className="input_ico_box">
                                                    <input type="radio" name="customerClasCode" id={"customer_rdo_2"}  value="02" checked={this.state.customerClasCode === "02"} onChange={this.handleChange}/>
                                                    {<label htmlFor={"customer_rdo_2"}>{this.props.messages.clas_code_02}</label>}
                                                </span>
                                            </li>
                                        </ul>
                                    </td>
                                    <th scope="row">{this.props.messages.customer_ceo_name}</th>
                                    <td className="input">
                                        <input type="text" className="ui_input" name="ceoName" value={this.state.ceoName } onChange={this.handleChange} />
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row" >{this.props.messages.customer_bizno}<span className="tc_red">*</span></th>
                                    <td className="input" colSpan={3}>
                                        <input type="text" className="ui_input" name="bizno" value={this.state.bizno} onChange={this.handleChange} />
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row" >{this.props.messages.customer_addr} <span className="tc_red">*</span></th>
                                    <td className="input" colSpan={3}>
                                        <input type="text" className="ui_input" name="coAddr" value={this.state.coAddr}  onChange={this.handleChange}/>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row" >{this.props.messages.customer_weburl} </th>
                                    <td className="input" colSpan={3}>
                                        <input type="text" className="ui_input" name="hmpageUrl" value={this.state.hmpageUrl}  onChange={this.handleChange}/>
                                    </td>
                                </tr>
                                {/* 담당자 영역 */}
                                <tr>
                                    <th scope="row" >{this.props.messages.customer_charge_usr_name} <span className="tc_red">*</span></th>
                                    <td className="input">
                                        <input type="text" className="ui_input" name="chargeUsrName" value={this.state.chargeUsrName}  onChange={this.handleChange}/>
                                    </td>
                                    <th scope="row" >{this.props.messages.customer_charge_usr_email} <span className="tc_red">*</span></th>
                                    <td className="input">
                                        <input type="text" className="ui_input" name="chargeUsrEmail" value={this.state.chargeUsrEmail}  onChange={this.handleChange}/>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row" >{this.props.messages.customer_charge_usr_dept_name }</th>
                                    <td className="input">
                                        <input type="text" className="ui_input" name="chargeUsrDeptName" value={this.state.chargeUsrDeptName}  onChange={this.handleChange}/>
                                    </td>
                                    <th scope="row" >{this.props.messages.customer_charge_usr_posit_name}</th>
                                    <td className="input">
                                        <input type="text" className="ui_input" name="chargeUsrPositName" value={this.state.chargeUsrPositName}  onChange={this.handleChange}/>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">{this.props.messages.customer_tel}</th>
                                    <td className="input">
                                        <input type="text" className="ui_input" name="chargeUsrTel" value={this.state.chargeUsrTel} onChange={this.handleChange} onInput={this.maxLengthCheck.bind(this)} maxLength={20}/>
                                    </td>

                                    <th scope="row">{this.props.messages.customer_charge_usr_mobile_no}<span className="tc_red">*</span></th>
                                    <td className="input">
                                        <input type="text" className="ui_input" name="chargeUsrMobileNo" value={this.state.chargeUsrMobileNo} onChange={this.handleChange} onInput={this.maxLengthCheck.bind(this)} maxLength={20}/>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">{this.props.messages.contract_attached}</th>
                                    <td className="input" colSpan={3}>
                                        <AttachFile onRef={ref => (this.attachFile = ref)} 
                                            files={this.state.attachFile}  
                                            onChange={this.handleFileChange}
                                            setFileExtension={['.jpg', '.pdf', '.jpeg']} 
                                            setFileMaxSize={20} 
                                            onUploadResult={this.handlecustomerSave}
                                            isFileSearch={true}
                                            setLimitCnt={3}
                                        />
                                        <span style={{color:"red"}}>{this.props.messages.customer_file_desc}</span>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                        {/* E:Table */}
                        <div className="box_com">
                            <div className="fl">
                                <h3 className="ctitle">{this.props.messages.customer_bnof_info}</h3>
                            </div>
                            <div className="fr">
                                <button type="button" className="btn_pos"
                                    onClick={this.handleDeleteBnof} disabled={fncBtnInfo['funcDelYn']=='N'} >{this.props.messages.common_delete}
                                </button>
                                <button type="button" className="btn_pos"  
                                    onClick={this.handleBulkUploadPopup}
                                    disabled={fncBtnInfo['funcFileUploadYn']=='N'} >
                                    {this.props.messages.common_bulk_upload}
                                </button>
                                <button type="button" className="btn_pos" 
                                    disabled={!enabled}
                                    disabled={fncBtnInfo['funcRegYn']=='N'} 
                                    onClick={() => {this.bnofCreate.show()}}>{this.props.messages.customer_bnof_registration}
                                </button>
                            </div>
                        </div>
                        <table className="tbl_col">
                            <caption>{this.props.messages.customer_bnof_info}</caption>
                            <TableColgroup listThead={this.state.listThead} />
                            <TableThead listThead={this.state.listThead} onSort={this.handleSort}/>
                            <tbody id="contractTbody">
                                {mapToComponent(this.state.bnofList, this.state.listThead)}
                            </tbody>
                        </table>
                        <div className="box_com">
                            <div className="fl">
                                <h3 className="ctitle">
                                    계약 담당자 정보 {}
                                </h3>
                            </div>
                            <div className="fr">
                                <div className="desc">
                                    <span className="tc_red">*</span> {this.props.messages.contract_reguired}
                                </div>
                            </div>
                        </div>

                        {/* S:Table */}
                        <table className="tbl_row">
                            <caption>{this.props.messages.customer_detail_title}</caption>
                            <colgroup>
                                <col style={{width:'10%'}}/>
                                <col style={{width:'40%'}}/>
                                <col style={{width:'10%'}}/>
                                <col style={{width:'40%'}}/>
                            </colgroup>
                            <tbody>
                                <tr>
                                    <th scope="row">구분{} <span className="tc_red">*</span></th>
                                    <td className="input" colSpan={3}>
                                        {this.state.chargeUserInfo.custmClsName}
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row" >담당자 이름{}<span className="tc_red">*</span></th>
                                    <td className="input">
                                        {this.state.chargeUserInfo.chargeUsrName}
                                    </td>
                                    <th scope="row" >담당자 E-mail{}<span className="tc_red">*</span></th>
                                    <td className="input">
                                    {this.state.chargeUserInfo.chargeUsrEmail}
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row" >부서{}</th>
                                    <td className="input">
                                    {this.state.chargeUserInfo.chargeUsrDeptName}
                                    </td>
                                    <th scope="row" >직위{}</th>
                                    <td className="input">
                                    {this.state.chargeUserInfo.chargeUsrPositName}
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row" >전화번호{}</th>
                                    <td className="input">
                                    {this.state.chargeUserInfo.chargeUsrTel}
                                    </td>
                                    <th scope="row" >휴대폰번호{}<span className="tc_red">*</span></th>
                                    <td className="input">
                                    {this.state.chargeUserInfo.chargeUsrMobileNo}
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                        {/* E:Table */}
                    </div>
                    {/* E:content_inner */}
                </div>
                {/* E:content_body */}
                <BnofCreate 
                    onRef={ref => (this.bnofCreate = ref)} 
                    onBnofComplete={this.handleCreateComplete}
                    custmNo={this.state.custmNo}
                    onBnofAdd={this.handleBnofAdd}
                />
                <BulkUpload onRef={ref => (this.bulkUpload = ref)} onBulkUpload={this.handleBulkUpload} onBulkUploadSample={this.handleBulkUploadSample} onFileChange={this.handleBulkFileChange}/>
            </div>
        );
    }
}

export default connect(mapStateToProps)(CustomerDetail);