import React from 'react';
import { Link } from 'react-router';
import { browserHistory } from 'react-router';

import axios from 'axios';

import ContractList from './ContractList';
import ContractDetail from './ContractDetail';
import ContractCreate from './ContractCreate';
import BulkUpload from '../common/BulkUpload';

import {REST_API_URL} from '../../config/api-config.js';

/*다국어 모듈 시작*/
import { connect } from 'react-redux';
import { changeLangauge, mapStateToProps, changeToken } from '../../language/Actions';
/*다국어 모듈 종료*/

class Contract extends React.Component {
  constructor(props) {
    super(props);

    this.state ={
      ctrtNo : "",
      file : null,
      displadyState : "L",
      pageInfo : {},
      list : []
    }

    this.handleDetailView = this.handleDetailView.bind(this);
    this.handleExcelDownload = this.handleExcelDownload.bind(this);

    this.handleBulkUploadPopup = this.handleBulkUploadPopup.bind(this);
    this.handleBulkUpload = this.handleBulkUpload.bind(this);
    this.handleBulkUploadSample = this.handleBulkUploadSample.bind(this);
    this.handleBulkFileChange = this.handleBulkFileChange.bind(this);

    this.handleDisplaySetting = this.handleDisplaySetting.bind(this);

    this.handlePageInfoChange = this.handlePageInfoChange.bind(this);

    this.handleListReload = this.handleListReload.bind(this);

  }
  
  handleDetailView(ctrtNo) {
    this.state.ctrtNo = ctrtNo;
    //this.refs.contractDetail.getContract(contractId);
    this.handleDisplaySetting('D');
  }

  handleExcelDownload() {
    this.contractList.getExcelDownload();
  }
  componentWillMount() {
    /*console.log(this.props);
    if(this.props.params.type == 'Create') {
      this.handleDisplaySetting('C');
    }*/
    
    //console.log(new URLSearchParams(this.props.location.search).get('type'));
    const qs = require('query-string');
    const parsed = qs.parse(location.search);
    //console.log(parsed.type);
    if(parsed.type == 'Create') {
      this.handleDisplaySetting('C');
    }
  }

  componentDidMount() {

    if(!this.props.messages){
			this.constructor.fetchData(this.props.dispatch);
    }
    
    
    /*$("#tab-cont1").show();
    $(".fr").show();
    $("#tab-cont2").hide();*/

    if ( $('.ui-sel').length > 0 ){
        $('.ui-sel').each(function(){
            $(this).selectric();//초기화
        });	
    }

    if(this.props.location.pathname == "/contractCreate") {
      this.handleDisplaySetting('C');
    } else {
      this.handleDisplaySetting('L');
    }
  }

  componentWillReceiveProps(nextProps) {
    if(nextProps.location.pathname == "/contractCreate") {
      this.handleDisplaySetting('C');
    } else {
      this.handleDisplaySetting('L');
    }
  }

  handleBulkFileChange(file) {
    this.setState({
      file : file
    });
  }

  handleBulkUploadPopup() {
    this.bulkUpload.show();

    this.setState({
      file : null
    });
  }

  handleBulkUpload() {

    if(this.state.file == null || this.state.file.length < 1) {
      alert("파일을 선택하세요.");
      return;
    }

		let formData = new FormData();

		formData.append("file", this.state.file);
		

		axios.post(REST_API_URL + "/contract/BulkUpload", formData, {
			headers: { "X-Requested-With": "XMLHttpRequest" },
		})
		.then( response => { 
      if(response.data.bulkUploadError === undefined) {
        alert("완료");
        this.bulkUpload.hide();
        this.contractList.getList();
      } else {
        console.log(response.data.bulkUploadError);
      }
		})
		.catch( response => { console.log(response) } );
  }

  handleBulkUploadSample() {
    var form = "<form action='" + REST_API_URL + "/contract/BulkUploadSampleDownload' method='post'>"; 
    form += "</form>"; 
    jQuery(form).appendTo("body").submit().remove();
  }

  handleDisplaySetting(state) {

    //.console.log(state);
    /*if(state === 'T') {
      $("#groupList").hide();
      $("#groupCreate").show();
    }*/

    if(this.state.displadyState == 'C' || this.state.displadyState == 'T' || this.state.displadyState == 'R') {
      if (!confirm("이 페이지에서 나가시겠습니까?\n작성중인 내용이 저장되지 않습니다.")) {
        return;
      }
    } 
    this.setState({displadyState : state});
    

  }

  handlePageInfoChange(pageInfo, reload) {
    this.setState({
        pageInfo : pageInfo
    });

    if(reload) {
      this.contractList.getList();
    }

    
  }

  handleListReload() {
    //this.handleDisplaySetting('L');
    this.setState({
      displadyState : 'L'
    })
    this.contractList.getList();
  }

  

  

  render() {
    const fncBtnInfo = this.props.memberInfo.dspUserFncBtnInfo;
        return (
          <section className="body">

            <div className="wrapper">

              <div className="page_header">
                <h2 className="ptitle">{this.state.displadyState == 'C' ? this.props.messages.contract_contract_registration : this.props.messages.contract_contract_status}</h2>
                <div className="page_nav">
                  {/*<ul>
                    <li><Link to="/">Home</Link></li>
                    <li><a href="javascript:;" onClick={() => this.setState({displadyState:'L'})}>{this.props.messages.contract_contract_management}</a></li>
                    <li className="here">{this.state.displadyState == 'C' ? this.props.messages.contract_contract_registration : this.props.messages.contract_contract_status}</li>
                  </ul>*/}
                </div>
              </div>
              <div className="content_wrap">

                <div className="content_outbox">

                  <div className="tab_wrap tab-wrap">

                    <div className="box_both tab_header">
                      <div className="fl">
                        <ul className="tabs">
                          <li  className={this.state.displadyState == 'L' ? "tab_item tab-item on" : "tab_item tab-item"}>
                            {/*<a href="javascript:;" onClick={() => {this.handleTabsChange('List')}} className="tab-link"><span>{this.props.messages.common_list}</span></a>*/}
                            <a href="javascript:;" onClick={() => this.handleDisplaySetting('L')} className="tab-link"><span>{this.props.messages.common_list}</span></a>
                          </li>
                          <li className={this.state.displadyState != 'L' ? "tab_item tab-item on" : "tab_item tab-item"}>
                            <a href="javascript:;" className={this.state.displadyState == 'L' ? "tab-link disabled" : "tab-link"}><span>{this.props.messages.common_detail}</span></a>
                          </li>
                        </ul>
                      </div>
                      <div className="fr">
                        <div className="btn_group" style={this.state.displadyState === 'L' ? {} : {display:'none'}}>
                          <button disabled={fncBtnInfo['funcXlxDwldYn']=='N'} type="button" className="ibtn_pos" onClick={this.handleExcelDownload}><i className="ico_btn_xls"></i>{this.props.messages.contract_excel_download}</button>
                          {/*<button type="button" className="ibtn_pos" onClick={this.handleBulkUploadPopup}><i className="ico_btn_write"></i>{this.props.messages.contract_batch_registration}</button>*/}
                        </div>
                        <div className="btn_group" style={this.state.displadyState === 'C' ? {} : {display:'none'}}>
                          <button type="button" className="btn_pos" onClick={() => {this.contractCreate.handleInitState()}}>{this.props.messages.contract_reset}</button>
                          <button disabled={fncBtnInfo['funcRegYn']=='N'} type="button" className="btn_pos" onClick={() => {this.contractCreate.handleSave('T')}}>{this.props.messages.contract_temporary_save}</button>
                          <button disabled={fncBtnInfo['funcRegYn']=='N'} type="button" className="btn_black" onClick={() => {this.contractCreate.handleSave('')}}>{this.props.messages.product_approval_request}</button>
                        </div>
                        <div className="btn_group" style={this.state.displadyState === 'T' ? {} : {display:'none'}}>
                          <button disabled={fncBtnInfo['funcModYn']=='N'} type="button" className="btn_pos" onClick={() => {this.contractDetail.handleSave('T')}}>{this.props.messages.contract_temporary_save}</button>
                          <button disabled={fncBtnInfo['funcModYn']=='N'} type="button" className="btn_black" onClick={() => {this.contractDetail.handleSave('')}}>{this.props.messages.product_approval_request}</button>
                        </div>
                        <div className="btn_group" style={this.state.displadyState === 'R' ? {} : {display:'none'}}>
                          <button disabled={fncBtnInfo['funcRegYn']=='N'} type="button" className="btn_black" onClick={() => {this.contractDetail.handleSave('R')}}>{this.props.messages.product_approval_request}</button>
                        </div>
                      </div>
                    </div>
{/*
                    <ContractList ref="contractList" onDisplaySetting={this.handleDisplaySetting} onDetailView={this.handleDetailView} />
                    <ContractDetail ref="contractDetail" onDisplaySetting={this.handleDisplaySetting}/>
                    <ContractCreate ref="contractCreate" onDisplaySetting={this.handleDisplaySetting}/>

                    <ContractList ref="contractList" 
                                                    onDisplaySetting={this.handleDisplaySetting} 
                                                    onDetailView={this.handleDetailView} 
                                                    pageInfo={this.state.pageInfo} 
                                                    onPageInfoChange={this.handlePageInfoChange} 
                                                    list={this.state.list} 
                                                    getList={this.getList}/> 
*/}

                    {this.state.displadyState == 'L' 
                                    ? <ContractList onRef={ref => (this.contractList = ref)}
                                                    onDisplaySetting={this.handleDisplaySetting} 
                                                    onDetailView={this.handleDetailView} 
                                                    pageInfo={this.state.pageInfo} 
                                                    onPageInfoChange={this.handlePageInfoChange} 
                                                    /> 
                                    : this.state.displadyState == 'C' 
                                        ? <ContractCreate onRef={ref => (this.contractCreate = ref)} onDisplaySetting={this.handleDisplaySetting} onListReload={this.handleListReload}/>
                                        : <ContractDetail onRef={ref => (this.contractDetail = ref)} onDisplaySetting={this.handleDisplaySetting} ctrtNo={this.state.ctrtNo} onListReload={this.handleListReload}/>
                    }

                  </div>

                </div>

              </div>

            </div>

            <BulkUpload onRef={ref => (this.bulkUpload = ref)} onBulkUpload={this.handleBulkUpload} onBulkUploadSample={this.handleBulkUploadSample} onFileChange={this.handleBulkFileChange}/>
          </section>
        );
    }
}

export default connect(mapStateToProps)(Contract);
