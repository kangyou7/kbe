/*jshint esversion: 6 */
import React, { Component } from 'react';
import { Link, browserHistory } from 'react-router';
import PropTypes from 'prop-types';

import { REST_API_URL } from '../../config/api-config.js';

import { Map, List } from 'immutable';
import { locales } from 'moment';

/*다국어 모듈 시작*/
import { connect } from 'react-redux';
import { changeLangauge, mapStateToProps, actionlogin } from '../../language/Actions';
/*다국어 모듈 종료*/


class UserList extends Component {
    constructor(props) {
        super(props);
        this.state = {
            data : Map({
                searchInfo : Map({
                    searchKeyCode: '',
                    searchKeyWord: '',
                    userDstnctCode : '',
                }),
                response : Map({
                    totalCount : 0,
                    currentPage : 1,
                    endPage : 0,
                    rowCount : 30,
                    list : List([
                    ]),
                })
            })
        };
        this.handlerOnChange = this.handlerOnChange.bind(this);
        this.handlerOnSearch = this.handlerOnSearch.bind(this);
        this.handlerOnDelete = this.handlerOnDelete.bind(this);
        this.handlerOnChangeSearch = this.handlerOnChangeSearch.bind(this);
        this.handlerSetPage = this.handlerSetPage.bind(this);
        this.handlerCheckAll = this.handlerCheckAll.bind(this);
        this.fncEnterSearch = this.fncEnterSearch.bind(this);
        this.handlerClickCreate = this.handlerClickCreate.bind(this);
        this.handlerPerPageChange = this.handlerPerPageChange.bind(this);
        this.handleChange = this.handleChange.bind(this);
    }

    handleChange(e){
        const { data } = this.state;

        this.setState({
            data:data.setIn(["response","currentPage"] ,e.target.value)
        });

        this.fncSearch();
    }
    //  전체 선택
    handlerCheckAll(e){
        $("input[type='checkbox']").prop("checked", $(e.target).is(":checked"));
    }

    //  하단 footer 영역 처음, 이전, 다음, 마지막 페이지 변경 버튼
    handlerSetPage(page){
        const { data } = this.state;

        this.setState({
            data:data.setIn(["response","currentPage"] ,page)
        });

        this.fncSearch();
    }

    //  Footer 영역의 한페이지별 검색rows 설정 시 바로 변경된 rows보기
    handlerOnChangeSearch(e){
        const { data } = this.state;
        this.setState({
            data:data.setIn(["response",e.target.name] ,e.target.value)
        });

        this.fncSearch();
    }

    fncSearch(){
        //  state에 반영되기 되도록 검색 함수 호출을 지연시킨다.
        setTimeout(() => {
            this.handlerOnSearch();    
        }, 100);
    }

    fncEnterSearch(e){
        if(e.keyCode === 13)
            this.handlerOnSearch();    
    }

    //  검색 함수
    handlerOnSearch(){
        const { data } = this.state;
        const memberInfo = storage.get('memberInfo');

        let param = {
            searchKeyCode : data.getIn(["searchInfo", "searchKeyCode"]),
            searchKeyWord : data.getIn(["searchInfo", "searchKeyWord"]),
            userDstnctCode : memberInfo.user_dstnct_code,
            page : data.getIn(["response", "currentPage"]),
            perPageNum : data.getIn(["response", "rowCount"]),
            totalCount : data.getIn(["response", "totalCount"]),
            startNum : 0,
            loginUserNo : memberInfo.user_no,
        };

        const _flag = sessionStorage.getItem('_reset');
        if(!_flag){
            sessionStorage.setItem("_param", JSON.stringify(param));
            sessionStorage.setItem("_reset", false);
        }else if(_flag==='false'){
            sessionStorage.setItem("_param", JSON.stringify(param));
            sessionStorage.setItem("_reset", false);
        }
        else{
            param = JSON.parse(sessionStorage.getItem("_param"));

            // this.setState({
            //     data : data.setIn(["searchInfo", "searchKeyCode"], param.searchKeyCode)
            //             .setIn(["searchInfo", "searchKeyWord"], param.searchKeyWord)
            //             .setIn(["response","currentPage"], param.page)
            // });

            // this.forceUpdate();
            sessionStorage.setItem("_reset", false);
        }

        $.ajax({
            url: REST_API_URL+"/user/list",
            dataType : "json",
            type : "POST",
            data : param,
            cache: false,
            success:function(result){
                console.log('조회 결과 : '+JSON.stringify(result));
                this.setState({
                    data:data.setIn(["response","list"] , result.response.list)                    
                             .setIn(["response","totalCount"] , result.response.pageInfo.totalCount)
                             .setIn(["response","currentPage"] , result.response.pageInfo.page)
                             .setIn(["response","endPage"] , Math.ceil(result.response.pageInfo.totalCount/result.response.pageInfo.perPageNum))
                             .setIn(["searchInfo", "searchKeyCode"], param.searchKeyCode)
                             .setIn(["searchInfo", "searchKeyWord"], param.searchKeyWord)
                });
            }.bind(this),
            error:function(xhr, status, err){
                console.log(xhr + " : "+ status +" :" + err);
            }.bind(this),
            xhrFields: {
              withCredentials: true
            }
        });
    }

    //  검색 영역 변경 이벤트 함수
    handlerOnChange(e){
        const { data } = this.state;

        this.setState({
            data : data.setIn(['searchInfo', e.target.name], e.target.value)
        });

    }

    //  페이지 하단 변경 이벤트
    handlerPerPageChange(e){
        const { data } = this.state;

        this.setState({
            data : data.setIn(['response', e.target.name], e.target.value)
        });

    }

    handlerOnDelete(){

        let deleteList = {list:[]};
        let deleteItem = {};
        let memberInfo = JSON.parse(localStorage.getItem("memberInfo"));
        let _self_delete = false;

        if(!confirm('선택한 항목을 삭제하시겠습니까?’')){
            return false;
        }

        $('input[name=chk_box]:checked').each(function(){
            console.log($(this).val());
            if($(this).val()==memberInfo.user_no){
                _self_delete = true ;
            }

            deleteItem  = {
               userNo : parseFloat( $(this).val() ),
               loginUserNo : memberInfo.user_no,
            };

            if(!deleteItem.user_no){
                console.log(deleteItem);
               deleteList.list.push(deleteItem);
            }
        });

        if(_self_delete){
            alert('사용자 본인의 사용자 데이터는 삭제할 수 없습니다.');

            $('input[name=chk_box]:checked').each(function(){
                $(this).prop('checked',false);
            });
            return false;
        }

        if(deleteList.list.length < 1){

            alert("선택된 사용자가 없습니다.");
            return false;
        }

        console.log(JSON.stringify(deleteList));

        $.ajax({
            url: REST_API_URL+"/user/delete",
            dataType : "json",
            type : "POST",
            data : {paramJson :JSON.stringify(deleteList)},
            cache: false,
            xhrFields: { withCredentials: true },
            success:function(result){

                alert('삭제 되었습니다.');
                //  체크박스 해제
                $('input[name=chk_box]:checked').each(function(){
                    $(this).prop("checked", false);
                });

                //  지연된 검색
                this.fncSearch();
            
            }.bind(this),
            error:function(xhr, status, err){
                console.log(xhr + " : "+ status +" :" + err);
            }.bind(this),
        });
    }

    componentDidMount(){
        const { data } =this.state;
        let self = this;

        $("select[name=searchKeyCode]").on("change",function(obj){
            self.handlerOnChange(obj);
        });

        $("#rowCount").on("change",function(obj){
            self.handlerPerPageChange(obj);
            self.handlerOnSearch();
        });
        

        this.fncSearch();

        $('.ui-sel').each(function(){
            $(this).selectric();	//초기화
        });	

    }

    componentDidUpdate(prevProps, prevState){
        if ( $('.ui-sel').length > 0 ){
            $('.ui-sel').each(function(){
                $(this).selectric();//초기화
            });	
        }
    }
    

    handlerClickCreate()
    {location.href = "/usercreate";}

    render(){
        const fncBtnInfo = this.props.memberInfo.dspUserFncBtnInfo;
        const { data } = this.state;
        const { handlerOnChange } = this;
        const { handlerOnSearch } = this;
        const { handlerOnDelete } = this;
        const { handlerOnChangeSearch } = this;
        const { handlerSetPage } = this;
        const { handlerCheckAll } = this;
        const { fncEnterSearch } = this;
        const { handlerClickCreate } = this;
        
        const mapToList = (records) => {
            if(records.length > 0) {
                return records.map((item, i) => {
                    return(
                        <tr key={i+1}>
                            <td className='ui_only_chk'>
                                <span className='input_ico_box'>
                                    <input type='checkbox' name='chk_box' id={"ip-chk1-"+item.userNo} value={item.userNo} />
                                    <label htmlFor={"ip-chk1-"+item.userNo}/>
                                </span>
                            </td>
                            <td>{item.rownum}</td>
                            <td>{item.userClasName}</td>
                            <td>{item.userStatusName}</td>
                            <td title={item.roleName}>{item.roleName}</td>
                            <td><Link to={{ pathname: "/userdetail", state: { userNo : item.userNo } }}>{item.userName}</Link></td>
                            <td title={item.userId}>{item.userId}</td>
                            <td>{item.coName}</td>
                            <td>{item.mobileNo}</td>
                            <td>{item.regDate}</td>
                            <td>{item.cntrctEndDate}</td>
                        </tr>
                    );
                });
            }else {
                return (
                    <tr>
                        <td className="noresults" colSpan={11}>
                            <div className="box_noresults">
                                <div className="ver_mid">													
                                    <i className="ico ico_no_result"></i>
                                    <span className="lb">{this.props.messages.user_there_are_no_results}</span>
                                </div>
                            </div>
                        </td>
                    </tr>
                );
            }
        }
        const selectStyle ={
            display: 'inline-block',
            border: '1px solid #dadada',
            height: '28px',
            padding: '0 9px',
            fontSize: '12px',
            color: '#444',
            boxSizing: 'border-box',
            verticalAlign: 'top'
        };
        return(
            <section className='body'>
                { /* S:wrapper */ }
                <div className='wrapper'>

                    { /* S:page_header */ }
                    <div className='page_header'>
                        <h2 className='ptitle'>{this.props.messages.user_user_status}</h2>
                        <div className='page_nav'>
                            {/*<ul>
                                <li><Link to="/">Home</Link></li>
                                <li><Link to="/userlist">{this.props.messages.user_management}</Link></li>
                                <li className='here'>{this.props.messages.user_user_status}</li>
                            </ul>*/}
                        </div>
                    </div>
                    { /* E:page_header */ }

                    { /* S:content_wrap */ }
                    <div className='content_wrap'>
                        { /* S:content_outbox */ }
                        <div className='content_outbox'>
                            { /* S:tab_wrap */ }
                            <div className='tab_wrap tab-wrap'>
                                { /* S:tab_header */ }
                                <div className='box_both tab_header'>
                                    <div className='fl'>
                                        <ul className='tabs'>
                                            <li className='tab_item tab-item on'>
                                                <Link> <span>{this.props.messages.user_list}</span> </Link>
                                            </li>
                                            <li className='tab_item tab-item disabled'>
                                                <Link className="tab-link disabled"> <span>{this.props.messages.user_detail}</span></Link>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                { /* E:tab_header */ }
                                { /* S:tab_content 활성화시 display:block/none  */ }
                                <div id='tab-cont1' className='tab_content tab-cont' style={{display:'block'}}>
                                    { /* S:content_body */ }
                                    <div className='content_body'>
                                        { /* S:content_inner */ }
                                        <div className='content_inner'>
                                            <div className='box_com term_wrap'>
                                                <div className="fl">
                                                    <select className="ui-sel" name="searchKeyCode" id='searchKeyCode' value={data.getIn(["searchInfo","searchKeyCode"])} >
                                                        <option value="" >{this.props.messages.user_select}</option>
                                                        <option value="01">{this.props.messages.user_name1}</option>
                                                        <option value="02">{this.props.messages.user_group_name}</option>
                                                        <option value="03">{this.props.messages.user_company_name}</option>
                                                    </select>
                                                    <span className="input_search_box">
                                                        <input type="text" className="ui_input" name ="searchKeyWord" 
                                                            value={data.getIn(["searchInfo","searchKeyWord"])} 
                                                            onChange = { handlerOnChange }
                                                            onKeyDown = { fncEnterSearch }
                                                        />
                                                        <a className="btn_search" onClick={handlerOnSearch}><span className="offscreen">검색</span></a>
                                                    </span>
                                                </div>
                                                <div className='fr'>
                                                        <button className='ibtn_pos' name='user-list-delete'
                                                        onClick={handlerClickCreate}
                                                        disabled={fncBtnInfo['funcRegYn']=='N'}
                                                    >
                                                        {this.props.messages.user_registration1}
                                                    </button>
                                                    <button className='ibtn_pos' name='user-list-delete'
                                                        onClick={handlerOnDelete}
                                                        disabled={fncBtnInfo['funcDelYn']=='N'}
                                                    >
                                                        {this.props.messages.user_delete}
                                                    </button>
                                                </div>
                                            </div>


                                            <table className='tbl_col'>
                                                <caption>사용자 현황 목록</caption>
                                                <colgroup>
                                                    <col style={{width:'2%'}} />
                                                    <col style={{width:'3%'}} />
                                                    <col style={{width:'9%'}} />
                                                    <col style={{width:'10%'}} />
                                                    <col style={{width:'11%'}} />
                                                    <col style={{width:'11%'}} />
                                                    <col style={{width:'11%'}} />
                                                    <col style={{width:'11%'}} />
                                                    <col style={{width:'10%'}} />
                                                    <col style={{width:'11%'}} />
                                                    <col style={{width:'11%'}} />
                                                </colgroup>

                                                <thead>
                                                    <tr>
                                                        { /* Com : checobkx 만 있을때 ui_only_chk class 추가 */ }
                                                        <th scope='col' className='ui_only_chk'>
                                                            <span className='input_ico_box'>
                                                                <input type='checkbox' name='chk_box_all' id='ip-chk1-all' value='' defaultChecked={false} onChange={handlerCheckAll} />
                                                                <label htmlFor='ip-chk1-all'></label>
                                                            </span>
                                                        </th>
                                                        <th scope='col'>No</th>
                                                        <th scope='col'>{this.props.messages.user_division3}</th>
                                                        <th scope='col'>{this.props.messages.user_state}</th>
                                                        <th scope='col'>ROLE</th>
                                                        <th scope='col'>{this.props.messages.user_name}</th>
                                                        <th scope='col'>ID</th>
                                                        <th scope='col'>{this.props.messages.user_company_name}</th>
                                                        <th scope='col'>{this.props.messages.user_cell_phone}</th>
                                                        <th scope='col'>{this.props.messages.user_registration_date}</th>
                                                        <th scope='col'>{this.props.messages.user_access_termination_date}</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    { mapToList(data.getIn(["response","list"])) }
                                                    { /* Com : tab_content 영역에 className='no_results' 추가 필요 */ }
                                                </tbody>
                                            </table>
                                        </div>
                                        { /* E:content_inner */ }
                                    </div>
                                    { /* E:content_body */ }
                                    { /* S:content_bottom */ }
                                    <div className='content_bottom'>
                                        <div className='bottom_inner'>
                                            <select className='ui-sel sel_white' name="rowCount" style={selectStyle} id="rowCount">
                                                <option value='30'>30 rows per page</option>
                                                <option value='50'>50 rows per page</option>
                                                <option value='100'>100 rows per page</option>
                                            </select>
                                            <span className='gap'></span>
                                            <div className='page_wrap'>
                                                { /* Com : 버튼 비활성화시 스타일 disabled 클래스 속성 추가 */ }
                                                <button className='first' 
                                                    disabled={data.getIn(['response','currentPage']) <=1 ? 'disabled':'' }
                                                    onClick={()=>{this.handlerSetPage(1)}}
                                                >
                                                    <span className='offscreen'>첫페이지</span>
                                                </button>
                                                <button className='prev' 
                                                    disabled={data.getIn(['response','currentPage']) <=1 ? 'disabled':''}
                                                    onClick={()=>{this.handlerSetPage(data.getIn(['response','endPage'])-1)}}
                                                >
                                                    <span className='offscreen'>이전페이지</span>
                                                </button>
                                                <input type="text" className="ui_input" style={{width:"50px"}} name="currentPage" value={data.getIn(['response','currentPage'])}  onKeyPress={this.handleKeyPress} onChange={this.handleChange}/>
                                                <span className='num_wrap'>
                                                    &nbsp;of&nbsp;
                                                    <span>{data.getIn(['response','endPage'])}</span>
                                                </span>
                                                <button className='next' 
                                                    disabled={data.getIn(['response','currentPage']) >= data.getIn(['response','endPage'])?'disabled':''}
                                                    onClick={()=>{this.handlerSetPage(data.getIn(['response','currentPage'])+1)}}
                                                >
                                                    <span className='offscreen'>다음페이지</span>
                                                </button>
                                                <button className='last' 
                                                    disabled={data.getIn(['response','currentPage']) >= data.getIn(['response','endPage'])?'disabled':''}
                                                    onClick={()=>{this.handlerSetPage(data.getIn(['response','endPage']))}}
                                                >
                                                    <span className='offscreen' >마지막페이지</span>
                                                </button>
                                            </div>

                                            <strong className='total_val'>{this.props.messages.sales_total}&nbsp;{ data.getIn(["response", "totalCount"])}</strong>
                                        </div>
                                    </div>
                                    { /* E:content_bottom */ }
                                </div>
                                { /* E:tab_content  */ }
                            </div>
                            { /* E:tab_wrap */ }
                        </div>
                        { /* E:content_outbox */ }
                    </div>
                    { /* E:content_wrap */ }
                </div>
                { /* E:wrapper */ }
            </section>
        );
    }
}
export default connect(mapStateToProps)(UserList);