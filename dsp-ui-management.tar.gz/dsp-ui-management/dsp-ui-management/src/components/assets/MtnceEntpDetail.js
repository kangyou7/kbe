import React from 'react';

import { browserHistory } from 'react-router';

import ApprovalLineSetting from '../common/ApprovalLineSetting';

import MtnceEntpChargeRegist from './MtnceEntpChargeRegist';

import Calendar from '../common/Calendar';
import CodeSelect from '../common/CodeSelect';
import AttachFile from '../common/AttachFile';

import {REST_API_URL} from '../../config/api-config.js';

import axios from 'axios';

/*다국어 모듈 시작*/
import { connect } from 'react-redux';
import { changeLangauge, mapStateToProps } from '../../language/Actions';
/*다국어 모듈 종료*/




class MtnceEntpDetail extends React.Component {

	constructor(props) {
		super(props);

		this.state = {
			maintCoName : "",
			equipVendorNo : "",
			chargeArea1Name : "",
			chargeArea2Name : "",
			chargeArea3Name : "",
			refMemo : "",
			vendorList : [],
			charges : [],
			removeCharges : [],
			addCharges : []
		}

		this.handleChange = this.handleChange.bind(this);

		this.handleMtnceEntpSave = this.handleMtnceEntpSave.bind(this);

		/*담당자 등록*/
		this.handleChargeComplete = this.handleChargeComplete.bind(this);

		this.handleDelete = this.handleDelete.bind(this);

		this.handleInitState = this.handleInitState.bind(this);
		
	}

	handleInitState() {
		
		this.setState({
			maintCoName : "",
			equipVendorNo : "",
			chargeArea1Name : "",
			chargeArea2Name : "",
			chargeArea3Name : "",
			refMemo : "",
			charges : [],
			removeCharges : [],
			addCharges : []
		});
	}

	handleChargeComplete(charge) {

		
		let chargeArray = this.state.charges;
		chargeArray.push(charge);

		this.setState({
			charges: chargeArray
		});

		let addChargeArray = this.state.addCharges;
		addChargeArray.push(charge);

		this.setState({
			addCharges: addChargeArray
		});

	}

	handleMtnceEntpSave() {

		if (this.validationCheck()) {
			let data = this.state;

			if (confirm("변경하시겠습니까?")) {

				let memberInfo = JSON.parse(localStorage.getItem("memberInfo"));
				data.loginUserNo = memberInfo.user_no;
		
				$.ajax({
					url: REST_API_URL+"/assets/MtnceEntpUpdate",
					dataType: 'json',
					type: "post",
					data: {paramJson : JSON.stringify(data)},
					xhrFields : {
						withCredentials : true
					},
		
					success: function(result) {
						
						if (result.response == "SUCCESS") {
							alert("변경되었습니다.");
							location.href="/mtnceEntp";
						} else {
							alert("변경 도중 오류가 발생하였습니다. 관리자에게 문의바랍니다.");
							return;
						}
		
					}.bind(this),
						error: function(xhr, status, err) {
						console.log(xhr + " : " + status + " : " + err);
					}.bind(this)
				});
			}		
		}
	}

	handleSave() {

		this.handleMtnceEntpSave();
		
	}

	validationCheck() {

		if(validator.trim(this.state.maintCoName) == "") {
			alert("업체명을 입력해 주세요.");
			return false;
		} else {
			if (!validator.isLength(this.state.maintCoName,{min:0, max: 100})) {
				alert("업체명은 100자 이내로 입력바랍니다.");
				return false;
			}
		}

		if(validator.trim(this.state.equipVendorNo) == "") {
			alert("담당 장비벤더를 선택해 주세요.");
			return false;
		}

		if(validator.trim(this.state.chargeArea1Name) == "") {
			alert("담당지역을 입력해 주세요.");
			return false;
		} else {
			if (!validator.isLength(this.state.chargeArea1Name,{min:0, max: 100})) {
				alert("담당지역은 100자 이내로 입력바랍니다.");
				return false;
			}
		}
		return true;
	}

	handleChange(e) {
			
		let nextState = {};
		nextState[e.target.name]=e.target.value;
		this.setState(nextState);
	}

	getMtnceEntp(maintCoNo) {

		this.getVendorNoList();


        $.ajax({
            url: REST_API_URL+"/assets/MtnceEntpDetail",
            dataType: 'json',
            type: "post",
            data: {
                maintCoNo:maintCoNo
			},
			xhrFields : {
				withCredentials : true
			},
            cache: false,
            success: function(result) {
				this.handleInitState();
				var vendorList = this.state.vendorList;

				this.setState(result.response);
				
				let nextState = {};
				nextState["vendorList"]=vendorList;
				this.setState(nextState);
            }.bind(this),
                error: function(xhr, status, err) {
                console.log(xhr + " : " + status + " : " + err);
            }.bind(this)
        });
    }

	handleCheckAll() {
        
        $("input[name='chargesListCheck']").prop("checked", $("#chargesListChkAll").is(":checked"));
	}
	
	handleDelete() {
		
		let charges = this.state.charges;

		let removeCharges = new Array();
		
		$("input[name='chargesListCheck']").each(function() {
			if ( $(this).is(":checked") ) {
				removeCharges.push(charges[$(this).val()]);
			}
		});

		this.setState({
			removeCharges: removeCharges
		});
		
		for (var i=0; i<removeCharges.length; i++) {
			charges.splice($.inArray(removeCharges[i], charges),1);
		}

		this.setState({
			charges: charges
		});
	}

	getVendorNoList() {
		$.ajax({
            url: REST_API_URL+"/assets/getVendorNoList",
            dataType: 'json',
            type: "post",
            xhrFields : {
				withCredentials : true
			},
            success: function(result) {
				this.setState({
					vendorList :result.response
				});
            }.bind(this),
                error: function(xhr, status, err) {
                console.log(xhr + " : " + status + " : " + err);
            }.bind(this)
        });
	}

	componentDidMount() {
		//this.getVendorNoList();
		this.props.onRef(this)
		$("#tab-cont1").show();
		
	}

	componentWillUnmount() {
		this.props.onRef(null)
	}
	
    render() {
		const fncBtnInfo = this.props.memberInfo.dspUserFncBtnInfo;
		const mapToVendorNoList = (data) => {
            if(data != null) {
                return data.map((item, i) => {//map
                    //console.log(item.files);
                    return(
                        <option value={item.equipVendorNo} key={i}>{item.equipVendorName}</option>
                    );
                });
            }
        }

		const mapToCharge = (data) => {
            if(data.length > 0) {
				return data.map((item, i) => {//map
					let id = "chk"+i;
                    return(

						<tr key={i}>
							<td className="ui_only_chk">
								<span className="input_ico_box">
									<input type="checkbox" name="chargesListCheck" id={id} value={i} onClick={this.handleCheckBoxClick}/>
									<label htmlFor={id}></label>
								</span>	
							</td>
							<td>{item.chargeUsrName}</td>
							<td>{item.chargeUsrPosit}</td>
							<td>{item.chargeUsrTel}</td>
							<td>{item.chargeUsrMobileNo}</td>
							<td>{item.chargeUsrEmail}</td>
							<td>{item.chargeTaskMemo}</td>
						</tr>
                    );
                });
            } else {
                return (
                    <tr>
						<td className="noresults" colSpan={7}>
							<div className="box_noresults">
								<div className="ver_mid">													
									<i className="ico ico_no_result"></i>
									<span className="lb">{this.props.messages.common_no_data}</span>
								</div>
							</div>
						</td>
					</tr>
                );
            }
        }

        return (
							
				<div id="tab-cont2" className="tab_content tab-cont no_paging">
					{/* S:content_body */}
					<div className="content_body">
						{/* S:content_inner */}
						<div className="content_inner">

							<div className="box_com">
								<div className="fl">
									<h3 className="ctitle">{this.props.messages.mtnce_basic_information}</h3>
								</div>
								<div className="fr">
									<div className="desc">
										<span className="tc_red">*</span> {this.props.messages.assets_required}
									</div>
								</div>
							</div>

							{/* S:Table */}
							<table className="tbl_row">
								<caption>기본 정보 목록</caption>
								<colgroup>
									<col style={{width:'10%'}}/>
									<col style={{width:'40%'}}/>
									<col style={{width:'10%'}}/>
									<col style={{width:'40%'}}/>
								</colgroup>
								<tbody>
									<tr>
										<th scope="row">{this.props.messages.mtnce_company_name} <span className="tc_red">*</span></th>
										<td className="input" colSpan={3}>
											<input type="text" className="ui_input" maxLength="100" name="maintCoName" value={this.state.maintCoName}  onChange={this.handleChange} />
										</td>
									</tr>
									<tr>
										<th scope="row">{this.props.messages.mtnce_manage_vendor}<span className="tc_red">*</span></th>
										<td className="input">
											<select className="ui_sel" name="equipVendorNo" onChange={this.handleChange} value={this.state.equipVendorNo}>
												<option value="">선택</option>
												{mapToVendorNoList(this.state.vendorList)}
											</select>
										</td>
										<th scope="row">{this.props.messages.mtnce_area1}<span className="tc_red">*</span></th>
										<td className="input">
											<input type="text" className="ui_input" maxLength="100" name="chargeArea1Name" value={this.state.chargeArea1Name}  onChange={this.handleChange}/>
										</td>
									</tr>
									<tr>
										<th scope="row">{this.props.messages.mtnce_area2}</th>
										<td className="input">
											<input type="text" className="ui_input" maxLength="100" name="chargeArea2Name" value={this.state.chargeArea2Name}  onChange={this.handleChange}/>
										</td>
										<th scope="row">{this.props.messages.mtnce_area3}</th>
										<td className="input">
											<input type="text" className="ui_input" maxLength="100" name="chargeArea3Name" value={this.state.chargeArea3Name}  onChange={this.handleChange}/>
										</td>
									</tr>
									<tr>
										<th scope="row">{this.props.messages.mtnce_remark}</th>
										<td className="input" colSpan={3}>
											<textarea className="ui_textarea" maxLength="1000" name="refMemo" value={this.state.refMemo} onChange={this.handleChange}></textarea>
										</td>
									</tr>
								</tbody>
							</table>
							{/* E:Table */}

							<div className="box_com">
								<div className="fl">
									<h3 className="ctitle">{this.props.messages.mtnce_manager_information}</h3>
								</div>
								<div className="fr">
									<button disabled={fncBtnInfo['funcDelYn']=='N'} type="button" className="btn_pos" onClick={() => {this.handleDelete()}}>{this.props.messages.assets_delete}</button>
									<button disabled={fncBtnInfo['funcRegYn']=='N'} type="button" className="btn_black" onClick={() => {this.mtnceEntpChargeRegist.show();}}>{this.props.messages.mtnce_manager_registration}</button>
								</div>
							</div>
							
							<table className="tbl_col">
								<caption>담당자 정보 목록</caption>
								<colgroup>
									<col style={{width:'4%'}}/>
									<col style={{width:'16%'}}/>
									<col style={{width:'16%'}}/>
									<col style={{width:'16%'}}/>
									<col style={{width:'16%'}}/>
									<col style={{width:'16%'}}/>
									<col style={{width:'16%'}}/>
								</colgroup>
								
								<thead>
									<tr>
										<th scope="col" className="ui_only_chk">
											<span className="input_ico_box">
												<input type="checkbox" name="chk_box" id="chargesListChkAll" onClick={() => {this.handleCheckAll()}}/>
												<label htmlFor="chargesListChkAll"></label>
											</span>
										</th>
										<th scope="col">{this.props.messages.mtnce_manager_name}</th>
										<th scope="col">{this.props.messages.mtnce_manager_position}</th>
										<th scope="col">{this.props.messages.mtnce_manager_phone}</th>
										<th scope="col">{this.props.messages.mtnce_manager_cellphone}</th>
										<th scope="col">{this.props.messages.mtnce_email}</th>
										<th scope="col">{this.props.messages.mtnce_manager_work}</th>
									</tr>
								</thead>
								
								<tbody>	
									{mapToCharge(this.state.charges)}
								</tbody>
							</table>
						</div>
						{/* E:content_inner */}
					</div>
					{/* E:content_body */}
					<MtnceEntpChargeRegist onRef={ref => (this.mtnceEntpChargeRegist = ref)} onChargeComplete={this.handleChargeComplete}/>
				</div>
        );
    }
}

export default connect(mapStateToProps)(MtnceEntpDetail);
