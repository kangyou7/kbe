import React from 'react';

import { Link } from 'react-router';
import { browserHistory } from 'react-router';

import Search from '../common/Search';
import PagingView from '../common/PagingView';
import ColumnChange from '../common/ColumnChange';

import {TableThead, TableColgroup} from '../common/TableThead';


import {REST_API_URL} from '../../config/api-config.js';

/*다국어 모듈 시작*/
import { connect } from 'react-redux';
import { changeLangauge, mapStateToProps } from '../../language/Actions';
/*다국어 모듈 종료*/

class ContractList extends React.Component {

  constructor(props) {
    super(props);

    this.state = {
      listThead : [
        {name:props.messages.contract_no,                  sort:false, sortColumn:"", view:true, target:false, width:'4%'},
        {name:props.messages.contract_provider,            sort:true, sortColumn:"sply_usr_name", view:true, target:true, width:'12%'},
        {name:props.messages.contract_customer_name,       sort:true, sortColumn:"demnd_usr_name", view:true, target:true, width:'12%'},
        {name:props.messages.contract_customer_division,   sort:true, sortColumn:"customer_clas_code_name", view:true, target:true, width:'12%'},
        {name:props.messages.contract_contract_division,   sort:true, sortColumn:"ctrt_dstnct_code_name", view:true, target:true, width:'12%'},
        {name:props.messages.contract_writer,              sort:true, sortColumn:"reg_usr_name", view:true, target:true, width:'12%'},
        {name:props.messages.contract_update_time,         sort:true, sortColumn:"reg_date", view:true, target:true, width:'12%'},
        {name:props.messages.contract_approval_status,     sort:true, sortColumn:"aprv_status_code", view:true, target:true, width:'12%'},
        {name:props.messages.contract_approver,            sort:true, sortColumn:"approver_name", view:true, target:true, width:'12%'}
      ],
      searchSelectOption : [
        {value:"", text: props.messages.contract_select},
        {value:"provider", text : props.messages.contract_provider},
        {value:"custom", text : props.messages.contract_customer_name},
        {value:"writer", text : props.messages.contract_writer}
      ],
      list : [],
      pageInfo:{
        //totalCount : 0,
        //perPageNum : 0,
        //page : 0
      }
    }

    this.handleSearch = this.handleSearch.bind(this);
    this.handlePageChange = this.handlePageChange.bind(this);

    this.handleColumnChange = this.handleColumnChange.bind(this);
    this.handleDetailView = this.handleDetailView.bind(this);
    this.handleSort = this.handleSort.bind(this);
  }

  

  getExcelDownload() {
    var form = "<form action='" + REST_API_URL + "/contract/ExcelDownload' method='post'>"; 
    form += "<input type='hidden' name='sortColumn' value='"+this.props.pageInfo.sortColumn+"' />"; 
    form += "<input type='hidden' name='sortType' value='"+this.props.pageInfo.sortType+"' />"; 
    form += "<input type='hidden' name='searchKeyCode' value='"+this.props.pageInfo.searchKeyCode+"' />"; 
    form += "<input type='hidden' name='searchKeyWord' value='"+this.props.pageInfo.searchKeyWord+"' />"; 

    form += "<input type='hidden' name='loginUserNo' value='"+this.props.memberInfo.user_no+"' />"; 
    form += "<input type='hidden' name='loginUserDstnctCode' value='"+this.props.memberInfo.user_dstnct_code+"' />"; 

    form += "</form>"; 
    jQuery(form).appendTo("body").submit().remove(); 
  }

  handleSearch(searchInfo) {
    let pageInfo = this.props.pageInfo;
    pageInfo.searchKeyCode = searchInfo.searchKeyCode;
    pageInfo.searchKeyWord = searchInfo.searchKeyWord;

    this.props.onPageInfoChange(pageInfo, true);
  }



  //페이지 변경 및 페이지 출력 갯수 변경
  handlePageChange(perPageNum, page) {

    let changePage = this.props.pageInfo;
    changePage.perPageNum = perPageNum;
    changePage.page = page;

    this.props.onPageInfoChange(changePage, true);
  }

  handleSort(sort) {
    let sortPage = this.props.pageInfo;
    sortPage.sortColumn = sort.sortColumn;
    sortPage.sortType = sort.sortType;
    
    this.props.onPageInfoChange(sortPage, true);
}




 //항목변경 팝업에서 항목 변경 후 state 정보 변경
 handleColumnChange(changeThead) {
   this.setState({
     listThead : changeThead
   });

 }

 handleDetailView(index) {
   this.props.onDetailView(this.state.list[index].ctrtNo);
 }

  //컴포넌트가 만들어지고 첫 렌더링을 다 마친 후 실행되는 메소드입니다.
  componentDidMount() {
    this.props.onRef(this)
    //this.getList();
    this.props.onPageInfoChange(this.props.pageInfo, true);
  }

  //컴포넌트가 DOM 에서 사라진 후 실행되는 메소드입니다.
  componentWillUnmount() {
    this.props.onRef(null)
  }

  //컴포넌트가 prop 을 새로 받았을 때 실행됩니다.
  componentWillReceiveProps(nextProps) {
    if(this.props.locale !== nextProps.locale) {
      let listThead = this.state.listThead;
      
      listThead[0].name = nextProps.messages.contract_no;
      listThead[1].name = nextProps.messages.contract_provider;
      listThead[2].name = nextProps.messages.contract_customer_name;
      listThead[3].name = nextProps.messages.contract_customer_division;
      listThead[4].name = nextProps.messages.contract_contract_division;
      listThead[5].name = nextProps.messages.contract_writer;
      listThead[6].name = nextProps.messages.contract_update_time;
      listThead[7].name = nextProps.messages.contract_approval_status;
      listThead[8].name = nextProps.messages.contract_approver;


      let searchSelectOption = this.state.searchSelectOption;
      
      searchSelectOption[0].text = nextProps.messages.contract_select;
      searchSelectOption[1].text = nextProps.messages.contract_provider;
      searchSelectOption[2].text = nextProps.messages.contract_customer_name;
      searchSelectOption[3].text = nextProps.messages.contract_writer;
    }
  }

  getList() {
    let data = this.props.pageInfo;

    data.loginUserNo = this.props.memberInfo.user_no;
    data.loginUserDstnctCode = this.props.memberInfo.user_dstnct_code;

    $.ajax({
    url: REST_API_URL + "/contract/List",
    dataType: 'json',
    type: "post",
    data: data,
    cache: false,
    success: function(result) {
      this.props.onPageInfoChange(result.response.pageInfo, false);
      this.setState({
        list: result.response.list//,
        //pageInfo : result.pageInfo
      });
    }.bind(this),
    error: function(xhr, status, err) {
      alert(JSON.stringify(xhr.responseJSON.message));
      console.log(xhr + " : " + status + " : " + err);
    }.bind(this),
    xhrFields: {
      withCredentials: true
    }
    });

  }

  render() {
    const fncBtnInfo = this.props.memberInfo.dspUserFncBtnInfo;
      const mapToComponent = (data, thead) => {
        if(data.length > 0) {
          return data.map((contract, i) => {//map
            return(<tr key={i}>
              <td style={thead[0].view ? {} : {display:'none'}}>{contract.rownum}</td>
              <td style={thead[1].view ? {} : {display:'none'}}>{contract.splyUsrName}</td>
              <td style={thead[2].view ? {} : {display:'none'}}><a href="javascript:;" onClick={() => {this.handleDetailView(i);}}>{contract.demndUsrName}</a></td>
              <td style={thead[3].view ? {} : {display:'none'}}>{contract.customerClasCodeName}</td>
              <td style={thead[4].view ? {} : {display:'none'}}>{contract.ctrtDstnctCodeName}</td>
              <td style={thead[5].view ? {} : {display:'none'}}>{contract.regUsrName}</td>
              <td style={thead[6].view ? {} : {display:'none'}}>{contract.regDate}</td>
              <td style={thead[7].view ? {} : {display:'none'}}>{contract.aprvStatusCode}</td>
              <td style={thead[8].view ? {} : {display:'none'}}>{contract.approverName}</td>
            </tr>);
          });
        } else {
          let colspan = thead.length;
          for(var i = 0; i<thead.length; i++) {
              colspan -= thead[i].view ? 0 : 1;
          }
          return (
            <tr>
              <td className="noresults" colSpan={colspan}>
                <div className="box_noresults">
                  <div className="ver_mid">
                    <i className="ico ico_no_result"></i>
                    <span className="lb">{this.props.messages.contract_there_are_no_results}</span>
                  </div>
                </div>
              </td>
            </tr>
          );
        }
      }

      return (
          <div id="tab-cont1" className="tab_content tab-cont" style={{display:'block'}}>
            <div className="content_body">
              <div className="content_inner">
                <div className="box_com term_wrap">
                    <Search onSearch={this.handleSearch} searchSelectOption={this.state.searchSelectOption} searchInfo={{"searchKeyCode":this.props.pageInfo.searchKeyCode, "searchKeyWord":this.props.pageInfo.searchKeyWord}}/>
                    <div className="fr">
                    {/*<Link to="/contractCreate" className="gnb_link"><button type="button" className="btn_black">계약등록</button></Link>*/}
                    {/*<a href="javascript:;" onClick={() => this.props.onDisplaySetting('C')} className="btn_black">{this.props.messages.contract_contract_registration}</a>*/}
                    <Link disabled={fncBtnInfo['funcRegYn']=='N'}  
                      style={fncBtnInfo['funcRegYn']=='N' ? { 'pointer-events':'none'}:{}}
                      to="/contractCreate" className="btn_black">{this.props.messages.contract_contract_registration}</Link>
                    <span className="gap"></span>
                    <button type="button" className="btn_pos" onClick={() => this.columnChange.show()}>{this.props.messages.contract_change_item}</button>
                    {/*<ul className="sort_wrap">
                        <li className="active"><button type="button">List</button></li>
                        <li><button type="button">Tree</button></li>
                    </ul>*/}
                    </div>
                </div>
                <table className="tbl_col">
                  <caption>계약 현황 목록</caption>
                  <TableColgroup listThead={this.state.listThead} />
                  <TableThead listThead={this.state.listThead} onSort={this.handleSort}/>
                  <tbody id="contractTbody">
                    {mapToComponent(this.state.list, this.state.listThead)}
                  </tbody>
                </table>
              </div>
            </div>
            <PagingView pageInfo={this.props.pageInfo} onPageChange={this.handlePageChange}/>
            <ColumnChange onRef={ref => (this.columnChange = ref)} listThead={this.state.listThead} onColumnChange={this.handleColumnChange} />
          </div>

      );
    }
}

export default connect(mapStateToProps)(ContractList);