import React from 'react';
import axios from 'axios';

import {REST_API_URL} from '../../config/api-config.js';

/*다국어 모듈 시작*/
import { connect } from 'react-redux';
import { changeLangauge, mapStateToProps } from '../../language/Actions';
/*다국어 모듈 종료*/

class NoticePopup extends React.Component{

    constructor(props) {
        super(props);

        this.state = {
            noticeList : [],
            pageInfo:{
                searchCode : "02",
                //totalCount : 0,
                perPageNum : 0
                //page : 0
              }
        }
    }

    componentDidMount(){
	    this.getNotice();
    }

    openNoticeDetailPopup(key, e) {
        this.props.setNoticeDetailInfo(this.state.noticeList[key]);
        //layer_open('.pop-layer-notice-detail');
    }

    getNotice() {
        this.state.pageInfo.perPageNum = "10";

        $.ajax({
          url: REST_API_URL+"/main/getNoticeList",
          dataType: 'json',
          type: "post",
          data: this.state.pageInfo,
          xhrFields : {
            withCredentials : true
          },
          success: function(result) {
            
            this.setState({
              noticeList : result.response.list
            });
          }.bind(this),
          error: function(xhr, status, err) {
            console.log(xhr + " : " + status + " : " + err);
          }.bind(this)
        });
    }

    render(){

        const mapToNoticeList = (data) => {
            if(data.length > 0) {
              
                return data.map((noticeData, i) => {
                  
                 
                    return(
                            <li key={i}><a className="link" onClick={this.openNoticeDetailPopup.bind(this, i)} href="javascript:;">{noticeData.noticeTitle}</a></li>
                    );
                });
            }
        }
        
        return(
            <div className="util_drop_box util_notice_drop_box util-drop-box" style={{zIndex:9999}}>
                <span className="arrow"></span>
                <div className="title">Notice</div>
                <ul className="notice_list">
                    {mapToNoticeList(this.state.noticeList)}
                </ul>
            </div>
        );
    }

}


export default connect(mapStateToProps)(NoticePopup);

