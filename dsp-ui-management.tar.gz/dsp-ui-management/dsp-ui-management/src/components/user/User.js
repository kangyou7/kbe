import React, { Component } from 'react';

import List from './UserList';
import Detail from './UserDetail';
import Create from './UserCreate';

class User extends Component {
    constructor(props) {
        super(props);
    
        this.state ={
            userNo : "",
            displadyState : "L",
            pageInfo : {}
        }
    
        this.handleDisplaySetting = this.handleDisplaySetting.bind(this);
        this.handleDetailView = this.handleDetailView.bind(this);
        this.handleListReload = this.handleListReload.bind(this);
        this.handleApproval = this.handleApproval.bind(this);
        this.handlePageInfoChange = this.handlePageInfoChange.bind(this);
    }

    handleDisplaySetting(state) {
        this.setState({displadyState : state});
    }

    componentDidMount() {
        if ( $('.ui-sel').length > 0 ){
            $('.ui-sel').each(function(){
                $(this).selectric();//초기화
            });	
        }
    }

    handleDetailView(ticketId, isApproval) {
        //A이면 Complete상태라 승인 할 수있는 승인 버튼 출력하기 위함.
        this.handleDisplaySetting(isApproval ? 'A' : 'D');
        this.setState({
            ticketId : ticketId
        });
    }

    handleListReload() {
        this.handleDisplaySetting('L');
        this.refs.list.getList();
    }

    handlePageInfoChange(pageInfo, reload) {
        this.setState({
            pageInfo : pageInfo
        });

        if(reload) {
            this.refs.list.getList();
        }
    }

    handleApproval(type) {
        if(type == "Approval") {
            if(!confirm("승인하시겠습니까?")) {
                return;
            } 
        } else {
            return;
        }

        this.refs.detail.approval(this.state);
        
        
    }

    render() {
        return (
            <section className="body">
                
                {/*S:wrapper */}
                <div className="wrapper">
                    
                    {/*S:page_header */}
                    <div className="page_header">
                        <h2 className="ptitle">{this.state.displadyState == 'C' ? "티켓 생성" : "티켓 현황"}</h2>
                        <div className="page_nav">
                            {/*<ul>
                                <li><a href="javascript:;">Home</a></li>
                                <li><a href="javascript:;">티켓 관리</a></li>
                                <li className="here">{this.state.displadyState == 'C' ? '티켓생성' : '티켓현황'}</li>
                            </ul>*/}
                        </div>
                    </div>
                    {/*E:page_header */}
                    
                    {/*S:content_wrap */}
                    <div className="content_wrap">
                        {/*S:content_outbox */}
                        <div className="content_outbox">
                            {/*S:tab_wrap */}
                            <div className="tab_wrap tab-wrap">
                                {/*S:tab_header */}
                                <div className="box_both tab_header">		
                                    <div className="fl">
                                        <ul className="tabs">
                                            <li className={this.state.displadyState == 'L' ? "tab_item tab-item on" : "tab_item tab-item"}>
                                                <a href="javascript:;" onClick={() => this.setState({displadyState:'L'})} className="tab-link"><span>목록</span></a>
                                            </li>
                                            <li className={this.state.displadyState != 'L' ? "tab_item tab-item on" : "tab_item tab-item"}>
                                                {/*Com : tab disabled 처리시 스타일 > a영역 disabled 클래스 추가 */}
                                                <a href="javascript:;" className={this.state.displadyState == 'L' ? "tab-link disabled" : "tab-link"}><span>상세</span></a>
                                            </li>
                                        </ul>
                                    </div>
                                    <div className="fr">
                                        <div className="btn_group" style={this.state.displadyState === 'C' ? {} : {display:'none'}}>
                                            <a href="javascript:;" className="btn_pos" onClick={() => this.refs.create.handleMainEvent('RESET')}>초기화</a>
                                            <a href="javascript:;" className="btn_black" onClick={() => this.refs.create.handleMainEvent('SAVE')}>확인</a>
                                        </div>
                                        <div className="btn_group" style={this.state.displadyState === 'A' ? {} : {display:'none'}}>
                                            <a href="javascript:;" className="btn_pos" onClick={() => this.setState({displadyState:'L'})}>취소</a>
                                            <a href="javascript:;" className="btn_black" onClick={() => {this.handleApproval('Approval')}}>승인</a>
                                        </div>
                                    </div>
                                </div>
                                {/*E:tab_header */}
                                
                                {/*S:tab_content 활성화시 display:block/none  */}
                                {this.state.displadyState == 'L' 
                                    ? <UserList ref="list" onDisplaySetting={this.handleDisplaySetting} onDetailView={this.handleDetailView} pageInfo={this.state.pageInfo} onPageInfoChange={this.handlePageInfoChange}/> 
                                    : this.state.displadyState == 'C' 
                                        ? <Create ref="create" onDisplaySetting={this.handleDisplaySetting}/>
                                        : <Detail ref="detail" onDisplaySetting={this.handleDisplaySetting} ticketId={this.state.ticketId} onListReload={this.handleListReload}/>}
                                {/*E:tab_content  */}	
                                
                                {/*S:tab_content 활성화시 display:block/none  */}
                                
                                {/*E:tab_content  */}	
                            </div>
                            {/*E:tab_wrap */}
                        </div>
                        {/*E:content_outbox */}
                    </div>
                    {/*E:content_wrap */}
                </div>
                {/*E:wrapper */}
            </section>
        );
    }
}

export default User;
