import React from 'react';

import axios from 'axios';

import {REST_API_URL} from '../../config/api-config.js';

/*다국어 모듈 시작*/
import { connect } from 'react-redux';
import { changeLangauge, mapStateToProps } from '../../language/Actions';
/*다국어 모듈 종료*/

class CustomSelect extends React.Component {

    constructor(props) {
        super(props);

        this.state = {
            prvdrNo : "",
            customList : []
        }
    }
    componentDidMount() {
        if ( $('.ui-sel').length > 0 ){
            $('.ui-sel').each(function(){
                $(this).selectric();//초기화
            });	
        }


        if(this.props.prvdrNo === undefined) {
            let searchCode = {
                custmClasCode : this.props.custmClasCode
            }
            this.getCode(searchCode, true);
        }

        let self = this;
        $("#" + this.props.name).on("change", function(obj){
            self.props.onChange(obj);
        })
    }

    componentWillReceiveProps(nextProps){

        //if(nextProps.prvdrNo != undefined && nextProps.prvdrNo != "") {
            if(this.state.prvdrNo != nextProps.prvdrNo) {
                let searchCode = {
                    custmClasCode : nextProps.custmClasCode,
                    prvdrNo : nextProps.prvdrNo
                }
                this.setState({
                    prvdrNo : nextProps.prvdrNo
                });
                this.getCode(searchCode, false);
            }
        //}
    }
    getCode(searchCode, type) {
        let url = "/provider/getCustomer";
        
		$.ajax({
			url: REST_API_URL + url,
			dataType: 'json',
			type: "post",
            data: searchCode,
			cache: false,
			success: function(result) {
				this.setState({
                    customList:result.response.customer
                });

                if ( $('.ui-sel').length > 0 ){
                    $('.ui-sel').each(function(){
                        $(this).selectric();//초기화
                    });	
                }
			}.bind(this),
				error: function(xhr, status, err) {
				console.log(xhr + " : " + status + " : " + err);
			}.bind(this),
            xhrFields: {
              withCredentials: true
            }
        });
	}

    

    
    render() {
		const mapToCustomList = (data) => {

            if(data != null) {
                return data.map((item, i) => {//map
                    //console.log(item.files);
                    return(
                        <option value={item.custmNo} key={i}>{item.coName}</option>
                    );
                });
            }
		}
        return(
            <select className={this.props.className} id={this.props.name} name={this.props.name} value={this.props.value == null ? "" : this.props.value}>
                {/*<select className={this.props.className} name={this.props.name} onChange={this.props.onChange} value={this.props.value}>*/}
                {/* DESC : option 비활성화시 disabled="disabled" 속성 추가 */}
                <option value="">{this.props.messages.contract_select}</option>
                {mapToCustomList(this.state.customList)}
            </select>
        );
    }
}

export default connect(mapStateToProps)(CustomSelect);