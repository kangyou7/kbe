import React from 'react';

import {REST_API_URL} from '../../config/api-config.js';

/*다국어 모듈 시작*/
import { connect } from 'react-redux';
import { changeLangauge, mapStateToProps } from '../../language/Actions';
/*다국어 모듈 종료*/

class NoticeTargetSearch extends React.Component {

    constructor(props) {
        super(props);

        this.state = {
            searchName:"",
            selectKey:-1,
            customers : []
        }

        this.handleChange = this.handleChange.bind(this);
        this.handleSearch = this.handleSearch.bind(this); 
    }

    handleChange(e) {
        let nextState = {};
        nextState[e.target.name]=e.target.value;
        this.setState(nextState);
    }

   
    handleSearch() {
        this.getNoticeTarget();
    }
    
    getNoticeTarget() {
        $.ajax({
            url: REST_API_URL+"/notice/getNoticeTarget",
            dataType: 'json',
            type: "post",
            data: {
                searchKeyWord:this.state.searchName,
                loginUserNo : this.props.memberInfo.user_no,
            },
            xhrFields : {
                withCredentials : true
            },
            success: function(result) {
                this.setState({
                    selectKey : -1,
                    customers: result.response
                });
                //this.treemapEvent();
            }.bind(this),
                error: function(xhr, status, err) {
                console.log(xhr + " : " + status + " : " + err);
            }.bind(this)
        });
    }

    complete() {
        //console.log($("input[name='custmNo']:checked").length);
        //console.log(this.state.customers);

        let checkedCustm = [];
        let selectCustomer = [];

        $("input[name='custmNo']:checked").each(function () {

            checkedCustm.push($(this).val());
            
        });

        //console.log(checkedCustm);

        if (checkedCustm.length > 0) {
            for ( var i=0; i<checkedCustm.length; i++ ) {
                for (var j=0; j<this.state.customers.length; j++) {
                    if ( this.state.customers[j].custmNo == checkedCustm[i]) {
                        selectCustomer.push(this.state.customers[j]);
                    }
                }
            }
        }
        
        //console.log(selectCustomer);
        this.props.onTargetComplete(selectCustomer);
        this.hide();
    }

    hide() {
        layer_close(".pop-notice-search");
    }

    show() {
        this.setState({
            searchName:"",
            selectKey:-1
        })
        layer_open(".pop-notice-search");
    }

    treemapEvent() {
        console.log('이벤트 처리');
        
        if ( $(".treemap-list").length > 0 ){
            $(".treemap-list li").each(function(n){
                if($(this).find("> .row > a.btn-more").length > 0) {
                    $(this).find("> .row > a.btn-more").unbind("click");
                }
            });

            $(".treemap-list li").each(function(n){
                $(this).find("> .row > a.btn-more").on("click",function(e){
                    var tg = $(this).closest('li'); //li
                    var bico = $(this).find("> i"); // icon
                    
                    if( tg.hasClass('hide') == true ){ //트리맵 아이콘 - 열어라
                        tg.removeClass('hide');
                        bico.find('.offscreen').text('더보기');
                        
                    }else{// -- 닫아라
                        tg.addClass('hide');
                        bico.find('.offscreen').text('닫기'); 
                    }
                });
            });
        }
    }

  
    componentDidMount() {
        this.props.onRef(this)
        //this.treemapEvent();

        this.handleSearch();
    }
    
    componentDidUpdate() {
		this.treemapEvent();
    }
    
    componentWillUnmount() {
        this.props.onRef(null)
    }

    

    render() {
        const {treemapEvent} = this;

        const addBtn = (data,prdvrNo) => {
            let childCnt = 0;
             data.map((item, i) => {//map
                
                if (item.custmClasCode == "02" && item.prvdrNo == prdvrNo)  {
                    childCnt++;
                }
            });

            if (childCnt > 0) {
                return(
                    <a href="javascript:;" className="btn-more btn_more off"><i className="ico_more"><span className="offscreen">더보기</span></i></a>
                );
            }
        }

        const addItem = (data,prdvrNo) => {
            return data.map((item, i) => {//map
                if (item.custmClasCode == "02" && item.prvdrNo == prdvrNo)  {
                    return(
                        <li key={i} className="hide">
                            <div className="row">
                                <span className="input_ico_box">
                                    <input type="checkbox" name="custmNo" id={item.custmNo} value={item.custmNo}/>
                                    <label htmlFor={item.custmNo}>{item.coName}</label>
                                </span>
                            </div>
                        </li>
                    );
                }
            });

            //treemapEvent();
        }

        

        const mapToCustomer = (data) => {
            
            if(data.length > 0) {
                return data.map((item, i) => {//map

                    if (item.custmClasCode == "01")  {
                        return(
                            <li key={i} className="hide">
                                <div className="row">
                                    {addBtn(data,item.custmNo)}
                                    <span className="input_ico_box">
                                        <input type="checkbox" name="custmNo" id={item.custmNo} value={item.custmNo}/>
                                        <label htmlFor={item.custmNo}>{item.coName}</label>
                                    </span>
                                </div>
                                <ul className="sub">
                                    {addItem(data,item.custmNo)}
                                </ul>                               
                            </li>
                        );
                    }
                });
            }
        }

        

        return(

            <div className="lpopup">
                <div className="dimmed"></div>
                <div className="popup_layer pop_notice_search pop-notice-search mid" style={{top:'100px', left:'100px'}}>
                    <div className="pop_container">
                        <div className="pop_header">
                            <h1>{this.props.messages.notice_target_search}</h1>
                        </div>
                       
                        <div className="pop_contents">
                            <div className="pop_inner">
                                <div className="psearch_form">
                                    <input type="text" className="ui_input" name="searchName" onChange={this.handleChange}/>
                                    <a href="javascript:;" onClick={this.handleSearch} className="btn_pos">{this.props.messages.notice_target_searching}</a>
                                </div>
                                
                                <div className="treemap_wrap scroll_wrap">
                                   
                                    <div className="treemap_list treemap-list">
                                        <ul className="treemap_ul treemap-ul">
                                            <li className="hide">	
                                                <div className="row" style={this.state.customers.length == 0 ?{display:'none'}:{}}>
                                                    <a href="javascript:;" className="btn-more btn_more off"><i className="ico_more"><span className="offscreen">더보기</span></i></a>
                                                    <span className="input_ico_box">
                                                        {/* <input type="checkbox" name="treemap-ip-chk" id="treemap-chk-all" value=""/> */}
                                                        <label htmlFor="treemap-chk-all">전체</label>
                                                    </span>
                                                </div>
                                                <ul className="sub">
                                                {mapToCustomer(this.state.customers)}
                                                </ul>
                                            </li>
                                        </ul>
                                    </div> 
                  
                                    {/* <!-- S : 검색결과 없는 경우 -->
                                    <!--
                                    <div class="box_noresults">
                                        <div class="ver_mid">													
                                            <i class="ico ico_no_result"></i>
                                            <span class="lb">검색 결과가 없습니다.</span>
                                        </div>
                                    </div>
                                    -->
                                    <!-- E : 검색결과 없는 경우 -->  */}
                                </div>
                            </div>
                        </div>	
                        
                        <div className="pop_bottom">
                            <button type="button" className="pbtn_black" onClick={() => {this.complete();}}>{this.props.messages.notice_ok}</button>
                        </div>
                    </div>
                    <a href="javascript:;" onClick={() => {this.hide();}} className="btn_pop_close"><span className="offscreen">닫기</span></a>
                </div>
            </div>
        );
    }
}


export default connect(mapStateToProps)(NoticeTargetSearch);