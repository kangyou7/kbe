import React from 'react';

import CustomerSearch from '../common/CustomerSearch';

import ManagerSearch from '../common/ManagerSearch';

import Calendar from '../common/Calendar';
import CodeSelect from '../common/CodeSelect';

import { MultiRowInputOne } from '../common/MultiRowInput';
import { ApprovalSearch } from '../common/ApprovalSearch';

import {REST_API_URL} from '../../config/api-config.js';

/*다국어 모듈 시작*/
import { connect } from 'react-redux';
import { changeLangauge, mapStateToProps } from '../../language/Actions';
/*다국어 모듈 종료*/

const initialState = {
    custmNo : "",
    custmName : "",
    tcktCaseMenuCode : "",
    tcktCaseTaskCode : "",
    priorCode : "",
    tcktName : "",
    tcktEnddate : "",
    //ticketEndTm : "",
    emailAlarm : "Yes",
    email : [],
    smsAlarm : "Yes",
    sms : [],
    approvalLine : [],
    approverUserNo : "",
    approverNm : "",
    approverDept : "",
    approverCblePhonNo : "",
    approverMoblPhonNo : "",
    approverEmail : "",
    approverEmailNotify : "N",
    approverSmsNotify : "N"
};

class Create extends React.Component {
    constructor(props) {
        super(props);

        this.state = $.extend(true, {}, initialState);

        this.handleChange = this.handleChange.bind(this);
        /*고객 찾기*/
        this.handleCustomerComplete = this.handleCustomerComplete.bind(this);

        /*담당자 찾기*/
        this.handleManagerComplete = this.handleManagerComplete.bind(this);

        /*승인자 찾기*/
        this.handleApprovalComplete = this.handleApprovalComplete.bind(this);

        /*담당자 정보 삭제*/
        this.handleManagerRemove = this.handleManagerRemove.bind(this);

        /*상위 콤포넌트에서 버튼 클릭*/
        this.handleMainEvent = this.handleMainEvent.bind(this);
    }

    //컴포넌트가 만들어지고 첫 렌더링을 다 마친 후 실행되는 메소드입니다.
	componentDidMount() {
		this.props.onRef(this)
	}

	//컴포넌트가 DOM 에서 사라진 후 실행되는 메소드입니다.
	componentWillUnmount() {
		this.props.onRef(null)
	}

    handleMainEvent(type) {

        if(type === 'RESET') {
            this.setState($.extend(true, {}, initialState));
        } else if( type === 'SAVE') {
            if(!this.validationChecke()) {
                return;
            }

            let data = $.extend(true, {}, this.state);
            
            /*담당자 결재 구분 담당으로 추가*/
            $.each(data.approvalLine, function(idx, item) {
                item.aprvStepCode = 'M';
                item.aprvChargeUsrNo = item.userNo;
            })
            /*담당자 결재 구분 담당으로 추가*/

            /*승인자 결재라인에 추가*/
            let tmp = {
                aprvStepCode: 'A',
                aprvChargeUsrNo : this.state.approverUserNo,
                userName : this.state.approverNm,
                deptName : this.state.approverDept,
                positName : "",
                coTel : this.state.approverCblePhonNo,
                mobileNo : this.state.approverMoblPhonNo,
                emailNotify : this.state.approverEmailNotify,
                smsNotify : this.state.approverSmsNotify
            };
            data.loginUserNo = this.props.memberInfo.user_no;
            data.approvalLine.push(tmp);
            /*승인자 결재라인에 추가*/

            $.ajax({
                url: REST_API_URL + "/ticket/Create",
                dataType: 'json',
                type: "post",
                data:  {paramJson : JSON.stringify(data)},
                cache: false,
                success: function(result) {
                    this.props.onListReload();
                }.bind(this),
                    error: function(xhr, status, err) {
                    console.log(xhr + " : " + status + " : " + err);
                }.bind(this),
                xhrFields: {
                  withCredentials: true
                }
            });
        }
    }

    validationChecke(temp) {
        
        if(this.state.custmNo == "") {
            alert("고객명을 등록하세요.");
            return false;
        }
        if(this.state.tcktCaseMenuCode == "") {
            alert("티켓Case 메뉴를 선택하세요.");
            return false;
        }
        if(this.state.tcktCaseTaskCode == "") {
            alert("티켓Case 업무를 선택하세요.");
            return false;
        }
        if(this.state.priorCode == "") {
            alert("우선순위를 선택하세요.");
            return false;
        }
        if(this.state.tcktName.trim() == "") {
            alert("티켓명을 입력하세요.");
            return false;
        }

        if(this.state.tcktEnddate == "") {
            alert("티켓 만기일을 선택하세요.");
            return false;
        }
        /*if(this.state.ticketEndTm == "") {
            alert("티켓 만기시간을 선택하세요.");
            return false;
        }*/
        /*if(this.state.emailAlarm == "Yes" && this.state.email.length < 1) {
            alert("이메일 알림 받을 메일을 등록하세요.");
            return false;
        }
        if(this.state.smsAlarm == "Yes" && this.state.sms.length < 1) {
            alert("SMS 알림 받을 전화번호를 등록하세요.");
            return false;
        }*/
        if(this.state.approvalLine.length < 1) {
            alert("담당자 정보를 등록하세요.");
            return false;
        }
        
        if(this.state.approverUserNo == "") {
            alert("승인자 정보를 등록하세요.");
            return false;
        }

        return true;
    
    }

	handleChange(e) {
        let nextState = {};
        if(e.target.name === 'approverEmailNotify') {
            nextState[e.target.name]= this.state.approverEmailNotify === 'Y' ? 'N' : 'Y';
        } else if(e.target.name === 'approverSmsNotify') {
            nextState[e.target.name]= this.state.approverSmsNotify === 'Y' ? 'N' : 'Y';
        } else {
            nextState[e.target.name]=e.target.value;
        }
        this.setState(nextState);
    }
    
    handleCustomerComplete(customer) {
		this.setState({
			custmNo : customer.custmNo,
			custmName : customer.coName
		})
    }

    handleApprovalComplete(approver) {
        
        this.setState({
            approverUserNo : approver.userNo,
            approverNm : approver.userName,
            approverDept : approver.deptName,
            approverCblePhonNo : approver.coTel,
            approverMoblPhonNo : approver.mobileNo,
            approverEmail : approver.userEmail,
            approverEmailNotify : "N",
            approverSmsNotify : "N"
        })
    }

    handleManagerComplete(manager) {

        let approvalLine = this.state.approvalLine;
        
        //배열 합치기
        approvalLine = approvalLine.concat(manager);

        let unique = [];
        //중복 제거
        let hashTable = {};
        unique = approvalLine.filter((el) => {
            let key = JSON.stringify(el);
            let alreadyExist = !!hashTable[key];
            return (alreadyExist ? false : hashTable[key] = true);
        });

        this.setState({
			approvalLine : unique
		});
    }

    handleNotifyChange(index, event) {

        let approvalLine = this.state.approvalLine.slice();

        if(event.target.name === 'emailNotify') {
            approvalLine[index].emailNotify = approvalLine[index].emailNotify  === 'Y' ? 'N' : 'Y';
        } else if(event.target.name === 'smsNotify') {
            approvalLine[index].smsNotify = approvalLine[index].smsNotify  === 'Y' ? 'N' : 'Y';
        }
        

        this.setState({
            approvalLine : approvalLine
        });
    }

    allChecked(obj) {
        $("input[name='columnCheck']").prop("checked", $(obj.target).is(":checked"));
    }
    
    handleManagerRemove() {
        let approvalLine = this.state.approvalLine;
        let removeManager = [];
        $("input[name='columnCheck']:checked").each(function(i) {
            removeManager.push($(this).val());
        });
        
        for(var i = removeManager.length-1; i >= 0; i--) {
            approvalLine.splice(removeManager[i], 1);
        }

        this.setState({
			approvalLine : approvalLine
        });
        
        $("input[name='columnCheck']").prop("checked", false);
    }

    render() {
        const mapToManager = (data) => {
            if(data != null && data.length > 0) {
                return data.map((item, i) => {//map
                    return(
                        <tr key={i}>
                            <td className="ui_only_chk">
                                <span className="input_ico_box">
                                    <input type="checkbox" name="columnCheck" id={"manager_" + i} value={i} defaultChecked={false} />
                                    <label htmlFor={"manager_" + i}></label>
                                </span>
                            </td>
                            <td>{item.userName}</td>
                            <td>{item.userDept}</td>
                            <td>{item.positName}</td>
                            <td>{item.coTel}</td>
                            <td>{item.mobileNo}</td>
                            <td>{item.userEmail}</td>
                            <td className="ui_only_chk">
                                <span className="input_ico_box">
                                    <input type="checkbox" name='emailNotify' id={'emailNotify_' + i} value="Y" checked={item.emailNotify === 'Y' ? true : false} onChange={this.handleNotifyChange.bind(this, i)}/>
                                    <label htmlFor={"emailNotify_" + i}></label>
                                </span>
                            </td>
                            <td className="ui_only_chk">
                                <span className="input_ico_box">
                                    <input type="checkbox" name='smsNotify' id={'smsNotify_' + i} value="Y" checked={item.smsNotify === 'Y' ? true : false} onChange={this.handleNotifyChange.bind(this, i)}/>
                                    <label htmlFor={"smsNotify_" + i}></label>
                                </span>
                            </td>
                        </tr>
                    );
                });
            } else {
                return (
                    <tr>
                        <td className="noresults" colSpan={10}>
                            <div className="box_noresults">
                                <div className="ver_mid">													
                                    <i className="ico ico_no_result"></i>
                                    <span className="lb">등록된 담당자가 없습니다.</span>
                                </div>
                            </div>
                        </td>
                    </tr>
                );
            }
        }

        return(
            <div id="tab-cont2" className="tab_content tab-cont no_paging" style={{display:'block'}}>
                {/*S:content_body */}
                <div className="content_body">
                    {/*S:content_inner */}
                    <div className="content_inner">
                        
                        <div className="box_com">
                            <div className="fl">
                                <h3 className="ctitle">{this.props.messages.ticket_ticket_information}</h3>
                            </div>
                            <div className="fr">
                                <div className="desc">
                                    <span className="tc_red">*</span> {this.props.messages.ticket_required}
                                </div>
                            </div>
                        </div>
                            
                        {/*S:Table */}
                        <table className="tbl_row">
                            <caption>티켓 정보 목록</caption>
                            <colgroup>
                                <col style={{width:'10%'}}/>
                                <col style={{width:'40%'}}/>
                                <col style={{width:'10%'}}/>
                                <col style={{width:'40%'}}/>
                            </colgroup>
                            <tbody>
                                <tr>
                                    <th scope="row">{this.props.messages.ticket_ticket_id}</th>
                                    <td></td>
                                    <th scope="row">{this.props.messages.ticket_ticket_status_2}</th>
                                    <td><span className="tc_gray tw_bold">Open</span></td>
                                </tr>
                                <tr>
                                    <th scope="row">{this.props.messages.ticket_registrant}</th>
                                    <td>{this.props.memberInfo.user_name}</td>
                                    <th scope="row">{this.props.messages.ticket_registration_date}</th>
                                    <td></td>
                                </tr>
                                <tr>
                                    <th scope="row">{this.props.messages.ticket_customer_name} <span className="tc_red">*</span></th>
                                    <td className="input">
                                        <span className="input_btn_box">
											<input type="text" className="ui_input" name="custmName" value={this.state.custmName} onChange={this.handleChange} readOnly/>
                                            <a href="javascript:;" className="tbtn_pos" onClick={() => this.customerSearch.show()}>{this.props.messages.ticket_search_1}</a>
                                        </span>
                                    </td>
                                    <th scope="row">{this.props.messages.ticket_ticket_case} <span className="tc_red">*</span></th>
                                    <td className="input">
                                        <div className="input_half_box">
                                            <CodeSelect className="ui-sel sel_white" 
                                                            name="tcktCaseMenuCode" 
                                                            value={this.state.tcktCaseMenuCode} 
                                                            onChange={this.handleChange} 
                                                            groupCode="CL005"/>
                                            &nbsp;
                                            <CodeSelect className="ui-sel sel_white" 
                                                            name="tcktCaseTaskCode" 
                                                            value={this.state.tcktCaseTaskCode} 
                                                            onChange={this.handleChange} 
                                                            groupCode="CL006"
                                                            upperCode={{upprCommCodeListId:"CL005", upprCommCode:this.state.tcktCaseMenuCode}}/>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">{this.props.messages.ticket_priority} <span className="tc_red">*</span></th>
                                    <td className="input">
                                        <ul className="ip_list">
                                            <li>
                                                <span className="input_ico_box">
                                                    <input type="radio" name="priorCode" id={"rdobox-rdo-1"} value="High" checked={this.state.priorCode === "High"} onChange={this.handleChange}/>
                                                    <label htmlFor={"rdobox-rdo-1"}>{this.props.messages.ticket_high}</label>
                                                </span>
                                            </li>
                                            <li>
                                                <span className="input_ico_box">
                                                    <input type="radio" name="priorCode" id={"rdobox-rdo-2"} value="Medium" checked={this.state.priorCode === "Medium"} onChange={this.handleChange}/>
                                                    <label htmlFor={"rdobox-rdo-2"}>{this.props.messages.ticket_mid}</label>
                                                </span>
                                            </li>
                                            <li>
                                                <span className="input_ico_box">
                                                    <input type="radio" name="priorCode" id={"rdobox-rdo-3"} value="Low" checked={this.state.priorCode === "Low"} onChange={this.handleChange}/>
                                                    <label htmlFor={"rdobox-rdo-3"}>{this.props.messages.ticket_low}</label>
                                                </span>
                                            </li>
                                        </ul>
                                    </td>
                                    <th scope="row">{this.props.messages.ticket_ticket_name} <span className="tc_red">*</span></th>
                                    <td className="input">
                                        <input type="text" className="ui_input" name="tcktName" value={this.state.tcktName} onChange={this.handleChange} maxLength={100}/>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">{this.props.messages.ticket_ticket_termination_date} <span className="tc_red">*</span></th>
                                    <td className="input" colSpan={3}>
                                        <div className="input_half_box">
                                            {/*s: 캘린더폼 */}
                                            <div className="date_box">
                                                {/*Com : default value값 오늘날짜로 표기 */}
                                                <Calendar className="ui_cal" 
                                                        dateFormat="YYYY-MM-DD"
                                                        selected={this.state.tcktEnddate}
                                                        onChange={(data) => this.setState({tcktEnddate: data})}
                                                        name="tcktEnddate"/>
                                            </div>
                                            {/*e: 캘린더폼 */}
                                            {/*<select className="ui-sel sel_white">
                                                <option value="">오후 05:30</option>
                                            </select>*/}
                                            {/*<CodeSelect className="ui-sel sel_white" 
                                                        name="ticketEndTm" 
                                                        value={this.state.ticketEndTm} 
                                                        onChange={this.handleChange} 
                                                        groupCode="CL007"/>*/}
                                        </div>
                                    </td>
                                </tr>
                                {/*<tr>
                                    <th scope="row">{this.props.messages.ticket_e_mail}</th>
                                    <td className="input" colSpan={3}>
                                        <ul className="ip_list">
                                            <li>
                                                <span className="input_ico_box">
                                                    <input type="radio" name="emailAlarm" id={"rdobox-rdo-2-1"} value="Yes" checked={this.state.emailAlarm === "Yes"} onChange={this.handleChange} />
                                                    <label htmlFor={"rdobox-rdo-2-1"}>{this.props.messages.ticket_completion_e_mail}</label>
                                                </span>
                                            </li>
                                            <li>
                                                <span className="input_ico_box">
                                                    <input type="radio" name="emailAlarm" id={"rdobox-rdo-2-2"} value="No" checked={this.state.emailAlarm === "No"} onChange={this.handleChange}/>
                                                    <label htmlFor={"rdobox-rdo-2-2"}>{this.props.messages.ticket_unnecessary}</label>
                                                </span>
                                            </li>
                                        </ul>
                                        
                                        <MultiRowInputOne inData={this.state.email} isDisabled={this.state.emailAlarm != 'Yes' ? true : false}/>
                                        
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">{this.props.messages.ticket_sms}</th>
                                    <td className="input" colSpan={3}>
                                        <ul className="ip_list">
                                            <li>
                                                <span className="input_ico_box">
                                                    <input type="radio" name="smsAlarm" id={"rdobox-rdo-3-1"} value="Yes" checked={this.state.smsAlarm === "Yes"} onChange={this.handleChange}/>
                                                    <label htmlFor={"rdobox-rdo-3-1"}>{this.props.messages.ticket_completion_sms}</label>
                                                </span>
                                            </li>
                                            <li>
                                                <span className="input_ico_box">
                                                    <input type="radio" name="smsAlarm" id={"rdobox-rdo-3-2"} value="No"  checked={this.state.smsAlarm === "No"} onChange={this.handleChange}/>
                                                    <label htmlFor={"rdobox-rdo-3-2"}>{this.props.messages.ticket_unnecessary}</label>
                                                </span>
                                            </li>
                                        </ul>

                                        <MultiRowInputOne inData={this.state.sms} isDisabled={this.state.smsAlarm != 'Yes' ? true : false}/>
                                    </td>
                                </tr>*/}
                            </tbody>
                        </table>
                        {/*E:Table */}
                        

                        <div className="box_com">
                            <div className="fl">
                                <h3 className="ctitle">{this.props.messages.ticket_manager_2}</h3>
                            </div>
                            <div className="fr">
                                <a href="javascript:;" className="btn_pos" onClick={this.handleManagerRemove}>{this.props.messages.ticket_delete}</a>
                                <a href="javascript:;" className="btn_black" onClick={() => this.managerSearch.show()}>{this.props.messages.ticket_manager_searching}</a>
                            </div>
                        </div>

                        <table className="tbl_col">
                            <caption>담당자 정보 목록</caption>
                            <colgroup>
                                <col style={{width:'2%'}}/>
                                <col style={{width:'14%'}}/>
                                <col style={{width:'14%'}}/>
                                <col style={{width:'14%'}}/>
                                <col style={{width:'14%'}}/>
                                <col style={{width:'14%'}}/>
                                <col style={{width:'18%'}}/>
                                <col style={{width:'5%'}}/>
                                <col style={{width:'5%'}}/>
                            </colgroup>
                            
                            <thead>
                                <tr>
                                    {/*Com : checkbox 만 있을때 ui_only_chk class 추가 */}
                                    <th scope="col" className="ui_only_chk">
                                        <span className="input_ico_box">
                                            <input type="checkbox" name="chk_box" id={"ip-chk1-all"} value="ALL" onClick={this.allChecked}/>
                                            <label htmlFor={"ip-chk1-all"}></label>
                                        </span>
                                    </th>
                                    <th scope="col">{this.props.messages.ticket_name}</th>
                                    <th scope="col">{this.props.messages.ticket_manager_department}</th>
                                    <th scope="col">{this.props.messages.ticket_position}</th>
                                    <th scope="col">{this.props.messages.ticket_phone}</th>
                                    <th scope="col">{this.props.messages.ticket_cell_phone}</th>
                                    <th scope="col">{this.props.messages.contract_e_mail}</th>
                                    <th scope="col">{this.props.messages.ticket_e_mail}</th>
                                    <th scope="col">{this.props.messages.ticket_sms}</th>
                                   
                                </tr>
                            </thead>
                            
                            <tbody>
                                {mapToManager(this.state.approvalLine)}
                            </tbody>
                        </table>
                        
                        <div className="box_com">
                            <div className="fl">
                                <h3 className="ctitle">{this.props.messages.ticket_approver_information}</h3>
                            </div>
                            <div className="fr">
                                <a href="javascript:;" className="btn_black" onClick={()=>this.approvalSearch.show()}>{this.props.messages.ticket_searching_approver}</a>
                            </div>
                        </div>
                        
                        {/*S : 승인자 정보 목록이 있는 경우 */}
                        {/*S:Table */}
                        <table className="tbl_row">
                            <caption>승인자 정보 목록</caption>
                            <colgroup>
                                <col style={{width:'10%'}}/>
                                <col style={{width:'40%'}}/>
                                <col style={{width:'10%'}}/>
                                <col style={{width:'40%'}}/>
                            </colgroup>
                            <tbody>
                                <tr>
                                    <th scope="row">{this.props.messages.ticket_name}</th>
                                    <td>{this.state.approverNm}<input type="hidden" name="approverUserNo" value={this.state.approverUserNo}  onChange={this.handleChange}/></td>
                                    <th scope="row">{this.props.messages.ticket_manager_department}</th>
                                    <td>{this.state.approverDept}</td>
                                </tr>
                                <tr>
                                    <th scope="row">{this.props.messages.ticket_phone}</th>
                                    <td>{this.state.approverCblePhonNo}</td>
                                    <th scope="row">{this.props.messages.ticket_cell_phone}</th>
                                    <td>{this.state.approverMoblPhonNo}</td>
                                </tr>
                                <tr>
                                    <th scope="row">{this.props.messages.contract_e_mail}</th>
                                    <td colSpan={3}>{this.state.approverEmail}</td>
                                </tr>

                                {/*<tr>
                                    <th scope="row">{this.props.messages.ticket_e_mail}</th>
                                    <td colSpan={3}>
                                        <input type="checkbox" name='approverEmailNotify' id={'approverEmailNotify'} value="Y" checked={this.state.approverEmailNotify === 'Y' ? true : false} onChange={this.handleChange}/>
                                        <label htmlFor={'approverEmailNotify'}></label>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">{this.props.messages.ticket_sms}</th>
                                    <td colSpan={3}>
                                        <input type="checkbox" name='approverSmsNotify' id={'approverSmsNotify'} value="Y" checked={this.state.approverSmsNotify === 'Y' ? true : false} onChange={this.handleChange}/>
                                        <label htmlFor={'approverSmsNotify'}></label>
                                    </td>
                                </tr>*/}




                            </tbody>
                        </table>
                        {/*E:Table */}
                        
                    </div>
                    {/*E:content_inner */}
                </div>
                {/*E:content_body */}
                <CustomerSearch onRef={ref => (this.customerSearch = ref)} onCustomerComplete={this.handleCustomerComplete}/>
                <ManagerSearch onRef={ref => (this.managerSearch = ref)} onManagerComplete={this.handleManagerComplete}/>
                <ApprovalSearch onRef={ref => (this.approvalSearch = ref)} onComplete={this.handleApprovalComplete} menuPath={'ticket'}/>
            </div>
        )
    }
}

export default connect(mapStateToProps)(Create);
