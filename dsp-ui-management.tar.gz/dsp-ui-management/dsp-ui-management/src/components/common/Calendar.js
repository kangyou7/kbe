import React from 'react';

import DatePicker from 'react-datepicker';
import moment from 'moment';

import 'react-datepicker/dist/react-datepicker.css';




class CustomInput extends React.Component {

    render () {
        return (
            <div>
                <input type="text" className="ui_cal" name={this.props.name} value={this.props.value} onClick={this.props.onClick}/>
                <button className="ui-datepicker-trigger" name={"b_" + this.props.name} style={{backgroundPosition: '0px 0px'}} type="button" onClick={this.props.onClick}><img title="..." alt="..." src="/images/ui/ico_btn_cal.png"/></button>
            </div>
        )
    }
}

export default class Calendar extends React.Component {

    constructor(props) {
        super(props);

        this.state = {
            outDate : ""//null
        }
        this.handleChange = this.handleChange.bind(this);
    }

    handleChange(e) {
        this.setState({
            outDate : e
        });
        this.props.onChange(e.format(this.props.dateFormat));
    }

    componentWillReceiveProps(nextProps){

        if(nextProps.selected != undefined && nextProps.selected != "") {
            //this.state.outDate = moment(nextProps.selected);
            this.state.outDate = nextProps.selected;
        } else {
            if ( nextProps.selected == "" ) {
                this.state.outDate = "";//null;
            }
        }
    }

    componentDidMount() {
        //달력 아이콘 출력안되는 부분이 있어 추가함.
        //달력 아이콘 출력하지 않으면 init 값을 false로 넘기면 출력됨
        if(this.props.init == undefined || this.props.init) {
            if ( $("[data-role=datepicker]").length > 0 ){
                $("[data-role=datepicker]").datepicker();
            }  
        }

        let self = this;
        $("#" + this.props.name).on("change", function(obj){
            self.props.onChange($(this).val());
        })
    }

    render() {
        // return(<DatePicker
        //         className={this.props.className} 
        //         dateFormat={this.props.dateFormat} 
        //         selected={this.state.outDate}
        //         disabled={this.props.disabled}
        //         onChange={this.handleChange} readOnly={true}
        //         name={this.props.name}
        //     customInput={<CustomInput />}
        //     />
        // );
        return(
            <input type="text" data-role="datepicker" className={this.props.className} id={this.props.name} name={this.props.name} value={this.state.outDate} readOnly={true}/>
        );
    }
}

