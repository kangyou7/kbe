import React from 'react';


/*다국어 모듈 시작*/
import { connect } from 'react-redux';
import { changeLangauge, mapStateToProps } from '../../language/Actions';
/*다국어 모듈 종료*/

class Test2 extends React.Component {
    constructor(props) {
        super(props);
    
        this.state = {
           
        }
    }


    

    render() {
        return (

            <section className="body">
                
                <form method="post" action="http://localhost:8080/paymentOk">
                    

                    <input type="text" name="CASH_GB" value="CN"/> /* 결제수단(CN)*/<br/>
                    <input type="text" name="Svcid" value="170622040674"/> /* 서비스아이디 */<br/>
                    <input type="text" name="Mobilid" value="180508000243159"/> /* 모빌리언스 거래번호 */<br/>
                    <input type="text" name="Signdate" value="20180508152844"/> /* 결제일자 */<br/>
                    <input type="text" name="Tradeid" value="skinfosec_168"/> /* 상점거래번호 */<br/>
                    <input type="text" name="Prdtnm" value="aaaaaaaa"/> /* 상품명 */<br/>
                    <input type="text" name="Prdtprice" value="1000"/> /* 상품가격 */<br/>
                    <input type="text" name="Userid" value="1"/> /* 사용자아이디*/<br/>
                    <input type="text" name="Resultcd" value="0000"/> /* 결과코드 */<br/>
                    <input type="text" name="Resultmsg" value="����ó���Ǿ����ϴ�."/> /* 결과메세지 */<br/>
                    <input type="text" name="Payeremail" value="test@test.com"/> /* 결제자 이메일 */<br/>
                    <input type="text" name="MSTR" value="{|salesSeq|:2,|raSvcid|:|170622040674|,|prdtnm|:|aaaaaaaa|,|prdtprice|:1000,|tradeid|:|skinfosec_168|,|siteurl|:|http://secuiot|,|notiurl|:|http://di.portal.lb-1486659-seo01.lb.bluemix.net:8700/paymentNoti|,|okurl|:|http://di.portal.lb-1486659-seo01.lb.bluemix.net:8700/paymentOk|,|closeurl|:||,|failurl|:||,|userid|:1,|payeremail|:|operator@secudiumiot.com|,|cashGb|:|RA|,|payMode|:|00|,|callType|:|P|,|iframeName|:||,|cryptyn|:|N|,|cryptstring|:||,|prdtcd|:||,|notiemail|:||,|infoareaYn|:|N|,|footerYn|:|N|,|height|:||,|prdtHidden|:|N|,|emailHidden|:|N|,|contractHidden|:|N|,|logoYn|:|N|,|item|:||,|setleMethodName|:|01|,|saleUsrProviderAgreYn|:|N|,|collectUtilAgreYn|:|N|,|setleSeq|:|168|}"/> /* 가맹점 전달 콜백변수 */<br/>

                    
                    <input type="text" name="Install" value="0"/> /* 할부개월수 */<br/>

                    <input type="submit" value="확인"/>

                </form>
            </section>



        );
    }
}

export default connect(mapStateToProps)(Test2);
