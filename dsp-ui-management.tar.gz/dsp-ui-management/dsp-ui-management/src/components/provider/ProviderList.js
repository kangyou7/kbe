/*jshint esversion: 6 */
import React from 'react';

import { Link } from 'react-router';
import { browserHistory } from 'react-router';

import Search from '../common/Search';
import PagingView from '../common/PagingView';
import ColumnChange from '../common/ColumnChange';

import {TableThead, TableColgroup} from '../common/TableThead';

import {REST_API_URL} from '../../config/api-config.js';

/*다국어 모듈 시작*/
import { connect } from 'react-redux';
import { changeLangauge, mapStateToProps, actionlogin } from '../../language/Actions';
/*다국어 모듈 종료*/

class ProviderList extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      list : [],
      pageInfo:{
        sortColumn:"",
        sortType:"",
        searchKeyCode:"",
        searchKeyWord:"",
        loginUserNo:-1,
      },
    };

    this.handleColumnChange = this.handleColumnChange.bind(this);
    this.handleSearch = this.handleSearch.bind(this);
    this.handleDetailView = this.handleDetailView.bind(this);
    this.handlePageChange = this.handlePageChange.bind(this);
    this.handleSort = this.handleSort.bind(this);
  }

  //컴포넌트가 만들어지고 첫 렌더링을 다 마친 후 실행되는 메소드입니다.
  componentDidMount() {
    this.props.onRef(this);
    this.props.onPageInfoChange(this.props.pageInfo, true);
  }

  //컴포넌트가 DOM 에서 사라진 후 실행되는 메소드입니다.
	componentWillUnmount() {
		this.props.onRef(null);
  }
  
  //항목변경 팝업에서 항목 변경 후 state 정보 변경
  handleColumnChange(changeThead) {
    this.setState({
        listThead : changeThead
    });
  }

  handleSearch(searchInfo) {

    let pageInfo = this.props.pageInfo;
    
    pageInfo.searchKeyCode = searchInfo.searchKeyCode;
    pageInfo.searchKeyWord = searchInfo.searchKeyWord;
    pageInfo.loginUserNo = this.props.memberInfo.user_no;

    this.props.onPageInfoChange(pageInfo, true);
  }

  //페이지 변경 및 페이지 출력 갯수 변경
  handlePageChange(perPageNum, page) {

    let changePage = this.props.pageInfo;
    changePage.perPageNum = perPageNum;
    changePage.page = page;
    changePage.loginUserNo = this.props.memberInfo.user_no;

    this.props.onPageInfoChange(changePage, true);
  }

  handleSort(sort) {
    let sortPage = this.props.pageInfo;
    sortPage.sortColumn = sort.sortColumn;
    sortPage.sortType = sort.sortType;
    sortPage.loginUserNo = this.props.memberInfo.user_no;
    
    this.props.onPageInfoChange(sortPage, true);
  }

  handleDetailView(custmNo) {
    this.props.onDetailView(custmNo);
  }

  getList() {
    console.log("조회 파라미터 : "+JSON.stringify(this.props.pageInfo));
    $.ajax({
      url: REST_API_URL + "/provider/list",
      dataType: 'json',
      type: "post",
      data: this.props.pageInfo,
      cache: false,
      xhrFields: { withCredentials: true },
      success: function(result) {
        console.log("조회시 리턴되는 결과값" + JSON.stringify(result.response.pageInfo));
        this.props.onPageInfoChange(result.response.pageInfo, false);
        this.setState({
          list: result.response.list
        });
      }.bind(this),
      error: function(xhr, status, err) {
        console.log(xhr + " : " + status + " : " + err);
      }.bind(this)
    });
  }

  getExcelDownload() {
    console.log('엑셀 다운로드'+JSON.stringify(this.props.pageInfo));
    var form = "<form action='" + REST_API_URL + "/provider/excel_download' method='post'>"; 
    form += "<input type='hidden' name='sortColumn' value='"+this.props.pageInfo.sortColumn+"' />"; 
    form += "<input type='hidden' name='sortType' value='"+this.props.pageInfo.sortType+"' />"; 
    form += "<input type='hidden' name='searchKeyCode' value='"+this.props.pageInfo.searchKeyCode+"' />"; 
    form += "<input type='hidden' name='searchKeyWord' value='"+this.props.pageInfo.searchKeyWord+"' />"; 
    form += "</form>"; 
    jQuery(form).appendTo("body").submit().remove(); 
  }
  render() {
    const fncBtnInfo = this.props.memberInfo.dspUserFncBtnInfo;
      const mapToList = (record, thead) => {
        if(record.length > 0) {
          return record.map((provider, i) => {//map
            return(
              <tr key={i}>
                <td style={thead[0].view ? {} : {display:'none'}}>{provider.rownum}</td>
                <td style={thead[1].view ? {} : {display:'none'}}>{provider.custmNo}</td>
                <td style={thead[2].view ? {} : {display:'none'}}>
                  <a onClick={() => {this.handleDetailView(provider.custmNo);}}>{provider.coName}</a>
                </td>
                <td style={thead[3].view ? {} : {display:'none'}}>{provider.bizno}</td>
                <td style={thead[4].view ? {} : {display:'none'}}>{provider.chargeUsrName}</td>
                <td style={thead[5].view ? {} : {display:'none'}}>{provider.chargeUsrMobileNo}</td>
                <td style={thead[6].view ? {} : {display:'none'}}>{provider.chargeUsrEmail}</td>
                <td style={thead[7].view ? {} : {display:'none'}}>{provider.regUserName}</td>
                <td style={thead[8].view ? {} : {display:'none'}}>{provider.regDate}</td>
              </tr>
            );
          });
        } else {
          let colspan = thead.length;
          for(var i = 0; i<thead.length; i++) {
              colspan -= thead[i].view ? 0 : 1;
          }
          return (
            <tr>
              <td className="noresults" colSpan={colspan}>
                <div className="box_noresults">
                  <div className="ver_mid">
                    <i className="ico ico_no_result"></i>
                    <span className="lb">{this.props.messages.provider_there_are_no_results}</span>
                  </div>
                </div>
              </td>
            </tr>
          );
        }
      }

      return (
          <div id="tab-cont1" className="tab_content tab-cont" style={{display:'block'}}>
            <div className="content_body">
              <div className="content_inner">
                <div className="box_com term_wrap">
                    <Search onSearch={this.handleSearch} 
                      searchSelectOption={this.props.searchSelectOption}
                      searchInfo={{"searchKeyCode":this.props.pageInfo.searchKeyCode, "searchKeyWord":this.props.pageInfo.searchKeyWord}}
                    />
                    <div className="fr">
                      <button onClick={() => this.props.onDisplaySetting('C')} 
                        className="btn_black"
                        disabled={fncBtnInfo['funcRegYn']=='N'} 
                      >
                      {this.props.messages.provider_registration}
                      </button>
                      <span className="gap"></span>
                      <button type="button" 
                              className="btn_pos" 
                              onClick={() => this.columnChange.show()}
                      >
                      {this.props.messages.provider_change_item}
                      </button>
                    </div>
                </div>

                <table className="tbl_col">
                  <caption>{this.props.messages.provider_list}</caption>
                  <TableColgroup listThead={this.props.listThead} />
                  <TableThead listThead={this.props.listThead} onSort={this.handleSort}/>
                  <tbody>
                    {mapToList(this.state.list, this.props.listThead)}
                  </tbody>
                </table>
              </div>
            </div>
            <PagingView pageInfo={this.props.pageInfo} onPageChange={this.handlePageChange}/>
            <ColumnChange onRef={ref => (this.columnChange = ref)} listThead={this.props.listThead} onColumnChange={this.handleColumnChange} />
          </div>
    );
  }
}
export default connect(mapStateToProps)(ProviderList);