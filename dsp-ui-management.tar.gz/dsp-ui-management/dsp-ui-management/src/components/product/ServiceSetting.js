import React from 'react';

import {REST_API_URL} from '../../config/api-config.js';

/*다국어 모듈 시작*/
import { connect } from 'react-redux';
import { changeLangauge, mapStateToProps } from '../../language/Actions';
/*다국어 모듈 종료*/


class ServiceSetting extends React.Component {
    constructor(props) {
        super(props);
        
        this.state = {
            serviceList : [],
            radioName : "",
            radioPrice : ''
        }

        this.handleChange = this.handleChange.bind(this);
    }

    handleOnlyNumber(smallPoint, e) {

        if(smallPoint > 0 ) {
            //let regexp = /^\d*(\.\d{0,2})?$/;
            let regexp = new RegExp("^\\d*(\\.\\d{0," + smallPoint + "})?$");
            if(e.target.value.search(regexp) == -1) {
                e.target.value=e.target.value.substring(0, e.target.value.length -1);
            } else  {
                e.target.value=e.target.value;
            }
        } else {
            e.target.value = e.target.value.replace(/[^0-9]/g,"")
        }
    }

    handleChange(event) {
        
        this.state.radioPrice = event.target.value;
        
        this.radioPriceChange();
    }

    handlePriceChange(index, event) {

        let serviceList = this.state.serviceList.slice();
        if(event.target.name === 'price') {
            serviceList[index].productSubtotAmt = event.target.value;
        } else {
            if(this.props.type === 'checkBox') {
                serviceList[index].checked = serviceList[index].checked ? false : true;
            } else {
                $.each(serviceList, (i) => {
                    serviceList[i].checked = i === index ? true : false;
                });

                let nextState = {};
                nextState['radioName'] = event.target.value;
                this.setState(nextState);

                this.radioPriceChange();
            }
        }
        
        this.setState({
            serviceList : serviceList
        });
        
        this.props.onServiceChange(this.props.name, this.state.serviceList);
    }

    radioPriceChange() {
        let serviceList = this.state.serviceList.slice();

        $.each(serviceList, (i) => {
            //if(serviceList[i].categoriCode === categoriCode ) {
                
                if(serviceList[i].checked) {
                    serviceList[i].productSubtotAmt = this.state.radioPrice;
                } else {
                    serviceList[i].productSubtotAmt = 0;
                }
            //}
        });

        this.setState({
            serviceList : serviceList
        });

        this.props.onServiceChange(this.props.name, this.state.serviceList);
    }

    //컴포넌트가 만들어지고 첫 렌더링을 다 마친 후 실행되는 메소드입니다.
	componentDidMount() {
        this.props.onRef(this);
        this.getInitData();
	}

	//컴포넌트가 DOM 에서 사라진 후 실행되는 메소드입니다.
	componentWillUnmount() {
		this.props.onRef(null);
	}
	

    componentWillReceiveProps(nextProps){
        if(nextProps.serviceData !== undefined) {
            this.setState({
                serviceList : nextProps.serviceData
            });
            
            this.radioSet();
            
        }
    }

    getInitData() {
        $.ajax({
			url: REST_API_URL + "/product/getService",
			dataType: 'json',
            type: "post",
            data: {paramJson : JSON.stringify(this.props.serviceCode)},
            //data: {serviceCode:this.props.serviceCode},
            cache: false,
			success: function(result) {
				this.setState({
                    serviceList : result.response.serviceList
                });

                //this.radioSet();

                this.props.onServiceChange(this.props.name, this.state.serviceList);
			}.bind(this),
				error: function(xhr, status, err) {
				console.log(xhr + " : " + status + " : " + err);
			}.bind(this),
			xhrFields: {
			  withCredentials: true
			}
        });
    }

    radioSet() {
        let radioName = "";
        let radioPrice = "";

        if(this.props.type === "radioBox") {
            let serviceList = this.state.serviceList.slice();

            $.each(serviceList, (i, el) => {
                //if(serviceList[i].categoriCode === categoriCode ) {
                    if(el.checked) {
                        radioName = el.commCode;
                        radioPrice = el.productSubtotAmt;
                    } 
                //}
            });

            this.state.radioName = radioName
            this.state.radioPrice = radioPrice;
            
        }
    }

    handleInitState() {
        this.getInitData();
    }

    render() {
        const mapToServiceItem = (data, topCommCode) => {
            return data.map((item, i) => {
                if(item.topCommCode === topCommCode) {


                    if(this.props.type === 'radioBox' && item.checked) {
                        this.state.radioName = item.commCode;
                        this.state.radioPrice = item.productSubtotAmt;
                    }

                    return (
                        <li key={i} className={(i > 0 && i % 3 === 0) ? 'f_clear' : ''}>
                            {
                            this.props.type === "checkBox" 
                            ?
                                <span className="opt_box">
                                    <span className="lb">
                                        <span className="input_ico_box">
                                            <input type="checkbox" name={item.topCommCode} id={item.topCommCode + '_' + i} value={item.commCode} 
                                                    checked={item.checked} onChange={this.handlePriceChange.bind(this, i)}/>
                                            <label htmlFor={item.topCommCode + '_' + i}>{item.commCodeName}</label>
                                        </span>
                                    </span>

                                    <input type="text" className="ui_input" placeholder="단가" 
                                            name="price" 
                                            disabled={!item.checked} value={item.productSubtotAmt == null ? '' : item.productSubtotAmt} 
                                            onChange={this.handlePriceChange.bind(this, i)}
                                            maxLength={10} onInput={this.handleOnlyNumber.bind(this, 0)}/>
                                    <span className="unit">원</span>
                                </span>
                            :
                                <span className="input_ico_box">
                                    <input type="radio" name={item.topCommCode} id={item.topCommCode + '_' + i} value={item.commCode} 
                                           checked={this.state.radioName === item.commCode || item.checked} onChange={this.handlePriceChange.bind(this, i)}/>
                                    <label htmlFor={item.topCommCode + '_' + i}>{item.commCodeName}</label>
                                </span>
                            }
                        </li>
                    );
                }
            });
        }

        const mapToService = (data) => {
            if(data != null) {
                let topCommCode = "";
                
                return data.map((item, i) => {
                    if(topCommCode != item.topCommCode) {
                        topCommCode = item.topCommCode;

                        
                        return (
                            <tr key={i}>
                                <th scope="row">{item.commCodeName} </th>
                                <td className="input">
                                    <ul className={this.props.type === "checkBox" ? "ip_list col3" : "ip_list"} >
                                        {mapToServiceItem(data, topCommCode)}

                                        {
                                        this.props.type === "checkBox" 
                                        ? 
                                            ""
                                        :
                                            <li className="f_clear">
                                                <span className="opt_box">
                                                    <input type="text" className="ui_input"
                                                            name="radioPrice" 
                                                            value={this.state.radioPrice}
                                                            onChange={this.handleChange}
                                                            disabled={this.state.radioName === ''} maxLength={10} onInput={this.handleOnlyNumber.bind(this, 0)}/>
                                                    <span className="unit">원</span>
                                                </span>
                                            </li>
                                        }
                                    </ul>
                                </td>
                            </tr>
                        );
                    }
                    

                    
                });
            }
        }

        return (
                    


            <table className="tbl_row">
                <caption>서비스 세팅</caption>
                <colgroup>
                    <col style={{width:'10%'}}/>
                    <col style={{width:'90%'}}/>
                </colgroup>
                <tbody>
                    {mapToService(this.state.serviceList)}
                    
                </tbody>
            </table>

        );
    }
}

export default connect(mapStateToProps)(ServiceSetting);
