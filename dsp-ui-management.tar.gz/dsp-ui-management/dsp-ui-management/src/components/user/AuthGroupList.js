/*jshint esversion: 6 */
import React from 'react';

import { Link } from 'react-router';
import { browserHistory } from 'react-router';

import Search from '../common/Search';
import PagingView from '../common/PagingView';
import ColumnChange from '../common/ColumnChange';

import {TableThead, TableColgroup} from '../common/TableThead';

import {REST_API_URL} from '../../config/api-config.js';
import AuthGroupCreate from './AuthGroupCreate';

/*다국어 모듈 시작*/
import { connect } from 'react-redux';
import { changeLangauge, mapStateToProps, actionlogin } from '../../language/Actions';
/*다국어 모듈 종료*/

class AuthGroupList extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      listThead : [
        {name:'',                                      sort:false, sortColumn:"", view:true, target:false, width:'4%'},
        {name:props.messages.auth_group_no,            sort:false, sortColumn:"", view:true, target:false, width:'4%'},
        {name:props.messages.auth_group_group_name,    sort:true, sortColumn:"group_name", view:true, target:true, width:'12%'},
        {name:props.messages.auth_group_user_cnt,      sort:false, sortColumn:"", view:true, target:true, width:'12%'},
        {name:props.messages.auth_group_reg_name,      sort:true, sortColumn:"user_name", view:true, target:true, width:'12%'},
        {name:props.messages.auth_group_reg_date,      sort:true, sortColumn:"reg_date", view:true, target:true, width:'12%'},
      ],
      searchSelectOption : [
        {value:'', text: props.messages.auth_group_search_select},
        {value:'1', text : props.messages.auth_group_search_type1},
        {value:'2', text : props.messages.auth_group_search_type2},
      ],
      list : [],
      pageInfo:{
      },
    }

    this.handleSearch = this.handleSearch.bind(this);
    this.handlePageChange = this.handlePageChange.bind(this);
    this.handleColumnChange = this.handleColumnChange.bind(this);
    this.handleDetailView = this.handleDetailView.bind(this);
    this.handleSort = this.handleSort.bind(this);
    this.handleCreateComplete = this.handleCreateComplete.bind(this);
    this.handlerOnDelete = this.handlerOnDelete.bind(this);
  }

  

  

  handleSearch(searchInfo) {

    let memberInfo = storage.get("memberInfo");

    let pageInfo = this.props.pageInfo;
    
    pageInfo.searchKeyCode = searchInfo.searchKeyCode;
    pageInfo.searchKeyWord = searchInfo.searchKeyWord;
    pageInfo.userDstnctCode = memberInfo.user_dstnct_code;
    pageInfo.loginUserNo = memberInfo.user_no;
   // pageInfo.page = 1;

    console.log(JSON.stringify(pageInfo));

    this.props.onPageInfoChange(pageInfo, true);
  }



  //페이지 변경 및 페이지 출력 갯수 변경
  handlePageChange(perPageNum, page) {

    let changePage = this.props.pageInfo;
    changePage.perPageNum = perPageNum;
    changePage.page = page;

    this.props.onPageInfoChange(changePage, true);
  }

  handleSort(sort) {
    let sortPage = this.props.pageInfo;
    sortPage.sortColumn = sort.sortColumn;
    sortPage.sortType = sort.sortType;
    
    this.props.onPageInfoChange(sortPage, true);
}

 //항목변경 팝업에서 항목 변경 후 state 정보 변경
 handleColumnChange(changeThead) {
   this.setState({
     listThead : changeThead
   });
 }

 handleDetailView(groupSeq) {
   this.props.onDetailView(groupSeq);
 }

  //컴포넌트가 만들어지고 첫 렌더링을 다 마친 후 실행되는 메소드입니다.
  componentDidMount() {
    this.props.onRef(this);
    this.props.onPageInfoChange(this.props.pageInfo, true);
  }

  //컴포넌트가 DOM 에서 사라진 후 실행되는 메소드입니다.
  componentWillUnmount() {
    this.props.onRef(null);
  }

  //컴포넌트가 prop 을 새로 받았을 때 실행됩니다.
  componentWillReceiveProps(nextProps) {
    if(this.props.locale !== nextProps.locale) {
      let listThead = this.state.listThead;
      listThead[0].name = "";
      listThead[1].name = nextProps.messages.auth_group_no;
      listThead[2].name = nextProps.messages.auth_group_group_name;
      listThead[3].name = nextProps.messages.auth_group_user_cnt;
      listThead[4].name = nextProps.messages.auth_group_reg_name;
      listThead[5].name = nextProps.messages.auth_group_reg_date;

      let searchSelectOption = this.state.searchSelectOption;
      
      searchSelectOption[0].text = nextProps.messages.auth_group_search_select;
      searchSelectOption[1].text = nextProps.messages.auth_group_search_type1;
      searchSelectOption[2].text = nextProps.messages.auth_group_search_type2;
    }
  }

  handleCreateComplete(){
    this.getList();
  }

  isEmpty(obj){
    return Object.keys(obj).length ===0;
  }
  
  getList() {
    const memberInfo = storage.get('memberInfo');
    let _param = {};
    
    if(this.isEmpty(this.props.pageInfo)){
      _param = {
        loginUserNo : memberInfo.user_no,
        userDstnctCode : memberInfo.user_dstnct_code,
      }
    }else{
      _param = this.props.pageInfo;
    }

    console.log("조회 출력 : "+JSON.stringify(_param));

    $.ajax({
    url: REST_API_URL + "/user/group/list",
    dataType: 'json',
    type: "post",
    data: _param,
    cache: false,
    success: function(result) {
      this.props.onPageInfoChange(result.response.pageInfo, false);
      this.setState({
        list: result.response.list
      });
    }.bind(this),
    error: function(xhr, status, err) { 
      console.log(JSON.stringify(xhr) + " : "+ JSON.stringify(status) +" :" + JSON.stringify(err));
    }.bind(this),
    xhrFields: {
      withCredentials: true
    }
    });
  }

  handlerOnDelete(){

    if(!confirm('선택한 항목을 삭제하시겠습니까?’')){
      return false;
    }

    let deleteList = [];
    let deleteItem = 0;
    let _index = 0;

    let {list} = this.state;
    let list_delete_item = {list : []};


    $('input[name=chk_box]:checked').each(function(){
      _index = parseFloat($(this).val());
      list_delete_item.list.push(list[_index]);
    });

    console.log(JSON.stringify(list_delete_item));

    if(list_delete_item.list.length>0){
        $.ajax({
            url: REST_API_URL+"/user/group/delete",
            dataType : "json",
            type : "POST",
            data : {paramJson : JSON.stringify(list_delete_item)},
            cache: false,
            success:function(result){

                alert('삭제 되었습니다.');
                //  체크박스 해제
                $('input[type=checkbox]:checked').each(function(){
                    $(this).prop("checked", false);
                });

                this.getList();
            
            }.bind(this),
            error:function(xhr, status, err){
                console.log(JSON.stringify(xhr) + " : "+ JSON.stringify(status) +" :" + JSON.stringify(err));
            }.bind(this),
            xhrFields: {
              withCredentials: true
            }
        });
    }
    else{
        alert("선택된 그룹이 없습니다.");
    }    
        
}
  render() {
    const fncBtnInfo = this.props.memberInfo.dspUserFncBtnInfo;
      const mapToComponent = (data, thead) => {
        console.log(JSON.stringify(data));
        if(data.length > 0) {
          return data.map((item, i) => {//map
            return(
              <tr key={i}>
                <td className='ui_only_chk'>
                    <span className='input_ico_box'>
                        <input type='checkbox' 
                            name='chk_box' 
                            id={"ip-chk1-"+item.groupSeq} 
                            value={i} 
                        />
                        <label htmlFor={"ip-chk1-"+item.groupSeq}/>
                    </span>
                </td>
                <td style={thead[0].view ? {} : {display:'none'}}>{item.rownum}</td>
                <td style={thead[1].view ? {} : {display:'none'}}>
                  <a onClick={() => {this.handleDetailView(item.groupSeq);}}>{item.groupName}</a>
                </td>
                <td style={thead[2].view ? {} : {display:'none'}}>{item.userCnt}</td>
                <td style={thead[3].view ? {} : {display:'none'}}>{item.userName}</td>
                <td style={thead[4].view ? {} : {display:'none'}}>{item.regDate}</td>
              </tr>
            );
          });
        } else {
          let colspan = thead.length;
          for(var i = 0; i<thead.length; i++) {
              colspan -= thead[i].view ? 0 : 1;
          }
          return (
            <tr>
              <td className="noresults" colSpan={colspan}>
                <div className="box_noresults">
                  <div className="ver_mid">
                    <i className="ico ico_no_result"></i>
                    <span className="lb">{this.props.messages.auth_group_there_are_no_results}</span>
                  </div>
                </div>
              </td>
            </tr>
          );
        }
      }

      return (
          <div id="tab-cont1" className="tab_content tab-cont" style={{display:'block'}}>
            <div className="content_body">
              <div className="content_inner">
                <div className="box_com term_wrap">
                    <Search onSearch={this.handleSearch} 
                      searchSelectOption={this.state.searchSelectOption} 
                      searchInfo={{"searchKeyCode":this.state.pageInfo.searchKeyCode, "searchKeyWord":this.state.pageInfo.searchKeyWord}}
                    />
                    <div className="fr">
                      <button 
                        onClick={() => {this.authGroupCreate.show()}}
                        className="btn_black"
                        disabled={fncBtnInfo['funcRegYn']=='N'} 
                      >
                      {this.props.messages.auth_group_registration}
                      </button>
                      <span className="gap"></span>
                      <button type="button" 
                              className="btn_pos" 
                              onClick={this.handlerOnDelete}
                              disabled={fncBtnInfo['funcDelYn']=='N'} 
                      >
                      {this.props.messages.auth_group_delete}
                      </button>
                    </div>
                </div>

                <table className="tbl_col">
                  <caption>{this.props.messages.auth_group_list}</caption>
                  <TableColgroup listThead={this.state.listThead} />
                  <TableThead listThead={this.state.listThead} onSort={this.handleSort}/>
                  <tbody id="contractTbody">
                    {mapToComponent(this.state.list, this.state.listThead)}
                  </tbody>
                </table>
              </div>
            </div>
            <PagingView pageInfo={this.props.pageInfo} onPageChange={this.handlePageChange}/>
            <ColumnChange onRef={ref => (this.columnChange = ref)} listThead={this.state.listThead} onColumnChange={this.handleColumnChange} />
            <AuthGroupCreate 
              onRef={ref => (this.authGroupCreate = ref)} 
              onAuthGroupComplete={this.handleCreateComplete}
            />
          </div>
          
    );
  }
}
export default connect(mapStateToProps)(AuthGroupList);