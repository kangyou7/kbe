import React from 'react';

class Search extends React.Component {

    constructor(props) {
        super(props);

        this.state = {
        searchKeyCode : "",
        searchKeyWord: ""
        }

        this.handleChange = this.handleChange.bind(this);
        this.handleSearch = this.handleSearch.bind(this);
    }

    handleChange(e) {
        let nextState = {};
        nextState[e.target.name]=e.target.value;
        
        this.setState(nextState);
    }

    handleSearch() {
        if(this.state.searchKeyCode === "" && this.state.searchKeyWord !== "") {
            alert("검색 항목을 선택하세요.");
        } else {
            this.props.onSearch(this.state);
        }
    }

    componentWillReceiveProps(nextProps) {
        if(nextProps.searchInfo != undefined) {
            if(nextProps.searchInfo.searchKeyCode != null && nextProps.searchInfo.searchKeyWord != null) {
                this.setState({
                    searchKeyCode : nextProps.searchInfo.searchKeyCode,
                    searchKeyWord: nextProps.searchInfo.searchKeyWord
                })
            }
        }
    }

    componentDidUpdate(prevProps, prevState){
        if ( $('.ui-sel').length > 0 ){
            $('.ui-sel').each(function(){
                $(this).selectric();//초기화
            });	
        }
    }

    componentDidMount() {
        if ( $('.ui-sel').length > 0 ){
            $('.ui-sel').each(function(){
                $(this).selectric();//초기화
            });	
        }

        let self = this;
        $("#searchKeyCode").on("change", function(obj){
            self.handleChange(obj);
        })
    }

    render() {

        const mapToOption = (data, thead) => {
           
            if(data.length > 0) {
                
                return data.map((item, i) => {//map
                    
                    return(
                        <option key={i} value={item.value}>{item.text}</option>
                    );
                });
            }
        };

        return(

            <div className="fl">
                {/*<select className="ui-sel sel_white" name="searchKeyCode" value={this.state.searchKeyCode} onChange={this.handleChange} >*/}
                <select className="ui-sel sel_white" id="searchKeyCode" name="searchKeyCode" value={this.state.searchKeyCode}  >
                    {mapToOption(this.props.searchSelectOption)}
                </select>&nbsp;
                <span className="input_search_box">
                    <input type="text" className="ui_input" name="searchKeyWord" value={this.state.searchKeyWord} onChange={this.handleChange}/>
                    <a id="searchContract" className="btn_search" href="javascript:void(0);"
                    onClick={this.handleSearch}><span className="offscreen">검색</span></a>
                </span>
            </div>
        );
    }
}

export default Search;
