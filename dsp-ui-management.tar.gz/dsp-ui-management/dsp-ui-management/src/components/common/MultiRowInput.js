import React from 'react';

/*다국어 모듈 시작*/
import { connect } from 'react-redux';
import { changeLangauge, mapStateToProps } from '../../language/Actions';
/*다국어 모듈 종료*/

class MultiRowInputOne extends React.Component {

    constructor(props) {
        super(props);
    
        this.state = {
            inString : "",
            temp : ""
        }
    
        this.handleChange = this.handleChange.bind(this);
        this.handleAdd = this.handleAdd.bind(this);
    }

    handleChange(e) {
        let nextState = {};
        nextState[e.target.name]=e.target.value;
        this.setState(nextState);
    }

    handleAdd() {
        let data = this.props.inData;
        let inString = this.state.inString;

        if(inString == "") {
            alert("정보를 입력하세요.");
            return;
        }
        let check = false;
        $.each(data, function(i, el){
            if(el == inString) {
                check = true;
            }
        });

        if(!check) {
            data.push(inString);

            this.setState({inString : ""});
        }
    }

    handleRemove(key) {
        let data = this.props.inData;
        data.splice(key, 1);

        this.setState({temp : ""});
    }

    render() {
        const mapToInput = (data, readonly) => {
            return data.map((item, i) => {//map
                if (readonly) {
                    return(
                        <div className="ip_con" key={i}>
                            <span className="input_btn_box">
                                <input type="text" className="ui_input" value={item} readOnly/>
                            </span>
                        </div>
                    );
                } else {
                    return(
                        <div className="ip_con" key={i}>
                            <span className="input_btn_box">
                                <input type="text" className="ui_input" value={item} readOnly/>
                                <a href="javascript:;" className="tbtn_pos" onClick={() => this.handleRemove(i)}>{this.props.messages.product_delete}</a>
                            </span>
                        </div>
                    );
                }
			});
        }
        const inputDiv = (
                <div className="ip_con">
                    <span className="input_btn_box">
                        {/*Com : input disabled 처리시, disabled="disabled" 추가 */}
                        <input type="text" className="ui_input" name="inString" value={this.state.inString} onChange={this.handleChange} 
                            disabled={this.props.isDisabled ? true : false}
                            />
                        <a href="javascript:;" className={this.props.isDisabled ? "tbtn_pos disabled" : "tbtn_pos"} onClick={this.handleAdd}>{this.props.messages.product_add}</a>
                    </span>
                </div>
        )

        return(
            <div>
                {this.props.readonly ? "" : inputDiv}
                

                {mapToInput(this.props.inData, this.props.readonly)}

            </div>
        );
    }
}



class MultiRowInputTwo extends React.Component {
    render() {
        return(
            <div>
                <div className="ip_con">
                    <span className="input_btn_box">
                        {/*Com : input disabled 처리시, disabled="disabled" 추가 */}
                        <input type="text" className="ui_input"/> <input type="text" className="ui_input"/> 
                        <a href="javascript:;" className="tbtn_pos">{this.props.messages.product_add}</a>
                    </span>
                </div>

                <div className="ip_con">
                    <span className="input_btn_box">
                        <input type="text" className="ui_input"/> <input type="text" className="ui_input"/>
                        <a href="javascript:;" className="tbtn_pos">{this.props.messages.product_delete}</a>
                    </span>
                </div>
            </div>
        );
    }
}

module.exports = {
    MultiRowInputOne : connect(mapStateToProps)(MultiRowInputOne),
    MultiRowInputTwo : connect(mapStateToProps)(MultiRowInputTwo)
};