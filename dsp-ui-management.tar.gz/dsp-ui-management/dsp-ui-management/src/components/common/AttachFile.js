/*jshint esversion: 6 */
import React from 'react';

import axios from 'axios';

import {REST_API_URL} from '../../config/api-config.js';

/*다국어 모듈 시작*/
import { connect } from 'react-redux';
import { changeLangauge, mapStateToProps } from '../../language/Actions';
/*다국어 모듈 종료*/

/*
첨부파일 Component
files : Component 호출시 파일정보 json 형식
onChange : 파일 선택시 Componet 호출 Function
onUploadResult : Component 호출한 곳에서 파일 업로드하지 않고 Component 에서 업로드 수행 후 attachFileId를 받을 Function
isFileSearch : 파일 선택, 삭제 여부
*/
class AttachFile extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            viewFileName : "",
            attachFileId : "",
            files : []
        }

        this.handleChange = this.handleChange.bind(this);
        //this.handleFileUpload = this.handleFileUpload.bind(this);
    }

    //컴포넌트가 만들어지고 첫 렌더링을 다 마친 후 실행되는 메소드입니다.
    componentDidMount() {
        this.props.onRef(this)
        this.setState({
            attachFileId : this.props.attachFileId ==  undefined ? "" : this.props.attachFileId,
            files : this.props.files == null ? [] : this.props.files
        })
    }

    //컴포넌트가 DOM 에서 사라진 후 실행되는 메소드입니다.
    componentWillUnmount() {
        this.props.onRef(null)
    }

	handleChange(e) {

        let files = this.state.files;

        //  파일 사이즈 체크
        if(this.props.setFileMaxSize !== undefined){
            let filesize = e.target.files[0].size;
            if(filesize > this.props.setFileMaxSize * 1024 * 1000){
                alert(this.props.setFileMaxSize + 'MB 이하만 등록 가능합니다.');
                return false;
            }
        }

        //  파일 확장자 체크
        if(this.props.setFileExtension !== undefined){
            let fileUploadAry = new Array();
            fileUploadAry = this.props.setFileExtension;
            
            let filename = e.target.files[0].name;
            let _fileLen = filename.length; 
            /** 
             * lastIndexOf('.') * 뒤에서부터 '.'의 위치를 찾기위한 함수 
             * 검색 문자의 위치를 반환한다. * 파일 이름에 '.'이 포함되는 경우가 있기 때문에 lastIndexOf() 사용 
             */ 
            let _lastDot = filename.lastIndexOf('.'); 
            // 확장자 명만 추출한 후 소문자로 변경 
            let _fileExt = filename.substring(_lastDot, _fileLen).toLowerCase();

            console.log("file 확장자 확인 ["+_fileExt+ "]  : ["+fileUploadAry+"]" +fileUploadAry.findIndex(_extension => _extension == _fileExt));

            if(fileUploadAry.findIndex(_extension => _extension == _fileExt)==-1) {
                // Returns an index value of -1.
                alert('JPEG, PDF만 등록 가능합니다.');
                return false;
            }
        }
        //  파일 업로드 갯수 체크
        if(this.props.setLimitCnt !== undefined){
            let maxCnt = 0;
            maxCnt = this.props.setLimitCnt;
            let cnt = 0;

            files.map((record, i)=>{
                if(record.state != 'D'){
                    cnt += 1;
                }
            });

            if( cnt == maxCnt ){
                alert('파일 첨부는 최대 '+this.props.setLimitCnt+'개 까지 가능합니다.');
                return false;
            }
        }

        files.push(
            {  
                state : 'I',
                attachFileId : this.state.attachFileId,
                fileSeq : 0,
                fileName : e.target.files[0].name,
                saveFileName : "",
                file : e.target.files[0]
            }
        );

        this.setState({
            files : files
        })

        this.props.onChange(files);
    }
    
    handleFileRemove(key) {
		let files = this.state.files;


        if(files[key].fileSeq <= 0) {
            $("#fileUpload").val("")
            files.splice(key, 1);
        } else  {        
            files[key].state = 'D';
        }

		this.setState({
			files : files
        })
        
        this.props.onChange(files);
    }

    handleFileDownload(key) {
        
        /*$.ajax({
			url: REST_API_URL + "/attachFile/fileDownload",
			dataType: 'json',
            type: "post",
            data: this.state.files[key],
            cache: false,
            success: function(result) {
                console.log("다운로드 완료");
            }.bind(this),
            error: function(xhr, status, err) {
                console.log(xhr + " : " + status + " : " + err);
            }.bind(this)
        });*/
        
        var form = "<form action='" + REST_API_URL + "/attachFile/fileDownload' method='post'>"; 
        //form += "<input type='hidden' name='attachFileId' value='" + this.state.files[key].attachFileId + "'>";
        form += "<input type='hidden' name='fileSeq' value='" + this.state.files[key].fileSeq + "'>";
        form += "</form>"; 
        jQuery(form).appendTo("body").submit().remove();
    }

    fileUpload() {
		let formData = new FormData();

        //formData.append("attachFileId", this.state.attachFileId);
        
        formData.append("userNo", 3);//로그인아이디로 변경
        this.state.files.map(file => {
            if(file.state == "I" || file.state == "D") {
                formData.append("fileSeq", file.fileSeq);
                formData.append("file", file.file, encodeURI(file.fileName));
            }
        });


        $('#loading').show();
		axios.post(REST_API_URL + "/attachFile/fileUpload", formData, {withCredentials : true}, {
            headers: { 
                headers: { "X-Requested-With": "XMLHttpRequest" },
            },
		})
		.then( response => { 
            $('#loading').hide();
            this.props.onUploadResult(response.data.response.attachFile);
		})
        .catch( response => {  $('#loading').hide(); console.log(response) } );
        
    }
    

    fileCopyUpload() {
        let formData = new FormData();

        //formData.append("attachFileId", this.state.attachFileId);
        formData.append("userNo", 3);//로그인아이디로 변경
		this.state.files.map(file => {
            if(file.state == "I" || file.state != "D") {
                formData.append("fileSeq", file.fileSeq);
                formData.append("file", file.file, encodeURI(file.fileName));
            }
        });
        $('#loading').show();
		axios.post(REST_API_URL + "/attachFile/fileCopyUpload", formData, {withCredentials : true}, {
			headers: { "X-Requested-With": "XMLHttpRequest" },
		})
		.then( response => { 
            $('#loading').hide();
            this.props.onUploadResult(response.data.response.attachFile);

		})
		.catch( response => { 
            $('#loading').hide();
            console.log(response) 
        });
    }

    
    
    
    //컴포넌트가 prop 을 새로 받았을 때 실행됩니다.
    componentWillReceiveProps(nextProps){
        this.setState({
            attachFileId : nextProps.attachFileId ==  undefined ? "" : nextProps.attachFileId,
            files : nextProps.files == null ? [] : nextProps.files
        })
    }
    
    render() {
		const mapToFiles = (data) => {
            if(data != null && data.length > 0) {
                return data.map((item, i) => {//map
                    const fileDelete = (
                        <a href="javascript:;" className="ibtn_del" onClick={() => {this.handleFileRemove(i)}}><i className="ico_del"><span className="offscreen">삭제</span></i></a>
                    );

                    //console.log(item.files);
                    if(item.state != 'D') {
                        if(item.state == 'I') {
                            return(
                                <span className="file_item" key={i}>
                                    <span>{item.fileName}</span>
                                    {this.props.isFileSearch ? fileDelete : ""}
                                </span>
                            );
                        } else {
                            return(
                                <span className="file_item" key={i}>
                                    <span><a href="javascript:;" onClick={() => {this.handleFileDownload(i)}}>{item.fileName}</a></span>
                                    {this.props.isFileSearch ? fileDelete : ""}
                                </span>
                            );
                        }
                    }
                });
            }
        }

        const fileSearch = (
                <span className="file-upload file_wrap">
            
                    <input className="file-name file_ip_name" disabled="disabled" name="viewFileName" value={this.state.viewFileName} />
                    <label htmlFor={"fileUpload"} className="tbtn_pos">{this.props.messages.contract_browser}</label> 
                    <input type="file" id="fileUpload" className="file-hidden ui_hidden" name="fileUpload" onChange={this.handleChange}/> 

                </span>
        )
        
        return (
            <div>
                    {this.props.isFileSearch ? fileSearch : ""}
                    {/* S:filelist */}
                    <span className="file_group">
                    {/* s:repeat file */}
                    {mapToFiles(this.state.files)}
                    {/* e:repeat file */}
                    </span>
                    {/* E:filelist */}
            </div>
        );
    }
}

export default connect(mapStateToProps)(AttachFile);
