import React from 'react';
import CodeSelect from '../common/CodeSelect';

import {REST_API_URL} from '../../config/api-config.js';
/*다국어 모듈 시작*/
import { connect } from 'react-redux';
import { changeLangauge, mapStateToProps } from '../../language/Actions';
/*다국어 모듈 종료*/

import validator from 'validator';

class ModelRegist extends React.Component {

    constructor(props) {
        super(props);

        this.state = {
            equipClasCode:"",
            equipClasName:"",
            equipModelName:"",
            equipLevelCode:"",
            equipTypeCode:"",
            equipLevelCodeList : [],
            equipTypeCodeList : [],
            equipClasCodeList : []
        }

        this.handleChange = this.handleChange.bind(this);
        this.handleInitState = this.handleInitState.bind(this);
    }

    handleInitState(type) {
		if(type == "ALL") {
            this.setState({
                equipClasCode:"",
                equipClasName:"",
                equipModelName:"",
                equipLevelCode:"",
                equipTypeCode:"",
                equipLevelCodeList : [],
                equipTypeCodeList : [],
                equipClasCodeList : []
            });
        } else {
            this.setState({
                // equipClasCode:"",
                // equipClasName:"",
                equipModelName:""
                // equipLevelCode:"",
                // equipTypeCode:"",
                // equipLevelCodeList : [],
                // equipTypeCodeList : [],
                // equipClasCodeList : []
            });
        }
	}

    handleChange(e) {
        let nextState = {};
        nextState[e.target.name]=e.target.value;
        this.setState(nextState);

        if (e.target.name == "equipLevelCode") {
            this.setState({
                equipTypeCodeList : [],
                equipTypeCode : "",
                equipClasCodeList : [],
                equipClasCode : ""
            })

            this.getTypeCodeList(e.target.value);
            
        } 

        if (e.target.name == "equipTypeCode") {
            this.setState({
                equipClasCodeList : [],
                equipClasCode : ""
            })
            this.getClasCodeList(e.target.value);
            
        } 

        if (e.target.name == "equipClasCode") {
            console.log(e.target.options[e.target.selectedIndex].text);
            nextState["equipClasName"]=e.target.options[e.target.selectedIndex].text;
        } 

        
        // console.log(e.target.name);
        // console.log(e.target.value);
        //console.log(this.state.equipLevelCode);
    }

    complete() {
        if(this.state.equipClasCode == "") {
            alert("장비유형을 선택하시기 바랍니다.");
            return
        }

        if(validator.trim(this.state.equipModelName) == "") {
            alert("모델명을 입력하시기 바랍니다.");
            return
        }

        let model = this.state;
        var today = new Date();
        var dd = today.getDate();
        var mm = today.getMonth()+1; //January is 0!
        if (mm.toString().length == 1) {
            mm = "0"+mm;
        }
        var yyyy = today.getFullYear();
        var td = yyyy + "-" + mm + "-" + dd;

        model.regDate = td;
        this.props.onModelComplete(model);
        this.hide();
    }

    hide() {
        layer_close(".pop_model_upload");
        this.handleInitState("");
    }

    show() {
        layer_open(".pop_model_upload");
        this.getLevelCodeList();
    }

    getLevelCodeList() {
        $.ajax({
            url: REST_API_URL+"/assets/getEquipClasList",
            dataType: 'json',
            type: "post",
            xhrFields : {
                withCredentials : true
            },
            success: function(result) {
				this.setState({
					equipLevelCodeList :result.response
				});
            }.bind(this),
                error: function(xhr, status, err) {
                console.log(xhr + " : " + status + " : " + err);
            }.bind(this)
        });
    }

    getTypeCodeList(levelCode) {
        //console.log("?? : " + levelCode);
        $.ajax({
            url: REST_API_URL+"/assets/getEquipClasList",
            dataType: 'json',
            type: "post",
            xhrFields : {
                withCredentials : true
            },
            data: {
                commCode:levelCode
            },
            success: function(result) {
				this.setState({
					equipTypeCodeList :result.response
				});
            }.bind(this),
                error: function(xhr, status, err) {
                console.log(xhr + " : " + status + " : " + err);
            }.bind(this)
        });
    }

    getClasCodeList(typeCode) {
        $.ajax({
            url: REST_API_URL+"/assets/getEquipClasList",
            dataType: 'json',
            type: "post",
            xhrFields : {
                withCredentials : true
            },
            data: {
                commCode:typeCode
            },
            success: function(result) {
				this.setState({
					equipClasCodeList :result.response
				});
            }.bind(this),
                error: function(xhr, status, err) {
                console.log(xhr + " : " + status + " : " + err);
            }.bind(this)
        });
    }

    //컴포넌트가 만들어지고 첫 렌더링을 다 마친 후 실행되는 메소드입니다.
	componentDidMount() {
        this.props.onRef(this)
        this.getLevelCodeList();
	}

	//컴포넌트가 DOM 에서 사라진 후 실행되는 메소드입니다.
	componentWillUnmount() {
		this.props.onRef(null)
	}

    

    render() {

        const mapToCodeList = (data) => {
            if(data != null) {
                return data.map((item, i) => {//map
                    return(
                        <option value={item.commCode} key={i}>{item.commCodeName}</option>
                    );
                });
            }
        }

        return(
            <div className="lpopup">
                <div className="dimmed"></div>
                <div className="popup_layer pop_model_upload pop-model-upload mid">
                    <div className="pop_container">
                        <div className="pop_header">
                            <h1>{this.props.messages.vendor_model_registration}</h1>
                        </div>
                        <div className="pop_contents">
                            <div className="pop_inner">
                                <table className="tbl_row">
                                    <caption>모델 등록 목록</caption>
                                    <colgroup>
                                        <col style={{width:'130px'}} />
                                        <col style={{width:'auto'}} />
                                    </colgroup>
                                    <tbody>
                                        <tr>
                                            <th scope="row">{this.props.messages.vendor_equip_level} <span className="tc_red">*</span></th> 
                                            <td className="input">
                                                <div className="ip_con">
                                                    <select className="ui_sel" name="equipLevelCode" onChange={this.handleChange}>
                                                        <option value="">선택</option>
                                                        {mapToCodeList(this.state.equipLevelCodeList)}
                                                    </select>
                                                </div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th scope="row">{this.props.messages.vendor_equip_type} <span className="tc_red">*</span></th>
                                            <td className="input">
                                                <div className="ip_con">
                                                    <select className="ui_sel" name="equipTypeCode" onChange={this.handleChange}>
                                                        <option value="">선택</option>
                                                        {mapToCodeList(this.state.equipTypeCodeList)}
                                                    </select>
                                                </div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th scope="row">{this.props.messages.vendor_equip_clas} <span className="tc_red">*</span></th>
                                            <td className="input">
                                                <div className="ip_con">
                                                    <select className="ui_sel" name="equipClasCode" onChange={this.handleChange}>
                                                        <option value="">선택</option>
                                                        {mapToCodeList(this.state.equipClasCodeList)}
                                                    </select>
                                                </div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th scope="row">{this.props.messages.vendor_model_name} <span className="tc_red">*</span></th>
                                            <td className="input">
                                                <input type="text" className="ui_input" maxLength="100"  name="equipModelName" value={this.state.equipModelName} onChange={this.handleChange}/>								
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>	
                        <div className="pop_bottom">
                            <button type="button" className="pbtn_pos" onClick={() => {this.hide();}}>{this.props.messages.vendor_model_cancel}</button>
                            <button type="button" className="pbtn_black" onClick={() => {this.complete();}}>{this.props.messages.assets_ok}</button>
                        </div>
                    </div>
                    <a href="javascript:;" onClick={() => {this.hide();}} className="btn_pop_close"><span className="offscreen">{this.props.messages.assets_close}</span></a>
                </div>
            </div>
        );
    }
}


export default connect(mapStateToProps)(ModelRegist);