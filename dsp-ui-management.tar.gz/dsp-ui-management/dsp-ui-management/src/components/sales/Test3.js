import React from 'react';


/*다국어 모듈 시작*/
import { connect } from 'react-redux';
import { changeLangauge, mapStateToProps } from '../../language/Actions';
/*다국어 모듈 종료*/

class Test3 extends React.Component {
    constructor(props) {
        super(props);
    
        this.state = {
            CASH_GB : "CN",                  //필수
            CN_SVCID : "170622040674",       //필수    CN_SVCID
            PAY_MODE : "10",                 //필수    10 : 실거래결제. 고정
            Prdtprice: 100,                 //필수    결제요청금액
            Prdtnm  : "테스트상품",          //필수    상품명
            Siteurl : "http://localhost",   //필수    가맹점도메인
            Tradeid : "170622040674_1",     //필수    가맹점거래번호 결제 요청 시 마다 unique한 값을 세팅해야 함.
            Notiurl : "http://localhost",   //필수    결제 완료 후 가맹점 측 결제 처리 URL
            Okurl : "http://localhost",     //필수    결제 완료 후 가맹점 측 결제 처리를 담당하는 페이지
            Failurl : "",       			//결제 실패 시 사용자에게 보여질 가맹점 측 실패 페이지
            MSTR : "",			    		//가맹점콜백변수 //가맹점에서 추가적으로 파라미터가 필요한 경우 사용하며 &,%,?,^ 는 사용불가 ( 예 : MSTR="a=1|b=2|c=3" )
            Payeremail : "",		        //결제자email
            Userid : "",				    //가맹점결제자ID
            CN_Install : "",        		//최대 할부개월수
            CALL_TYPE : "I",	            	//결제창 호출방식
            IFRAME_NAME : "iframePayment",
            Closeurl : "",			        //닫기버튼 클릭 시 호출되는 가맹점 측 페이지. CALL_TYPE = ‘I’ 또는 ‘SELF’ 셋팅 시 필수
            billType : "",      			//매출전표 출력 시 과세/비과세 구분
            tax : "",			    		//부과세 // 전체금액의 10%이하로 설정
            taxFree : "",			        //비과세
            Cryptyn	: "N",	                //Y: 암호화 사용, N: 암호화 미사용
            Cryptstring	: ""	            //암호화 사용 시 암호화된 스트링
        }

        this.handleChange = this.handleChange.bind(this);
    }


    handleChange(e) {
        let nextState = {};
        nextState[e.target.name]=e.target.value;
        this.setState(nextState);
	}

    test() {
        MCASH_PAYMENT(document.payForm);		
    }
   

    render() {
        return (

            <section className="body">
                
                <form name="payForm" accept-charset="euc-kr">
                    <table border="1" width="100%">
                        <tbody>
                            <tr>
                                <td align="center" colspan="6"><font size="15pt"><b>실시간 계좌이체 SAMPLE PAGE</b></font></td>
                            </tr>
                            <tr>
                                <td colspan="3"><font color="red">&nbsp;빨간색 항목은 필수 값!!!</font></td>
                                <td colspan="3"><font color="blue">&nbsp;파란색 항목은 결제창 UI 관련 파라미터</font></td>
                            </tr>
                            <tr>
                                <td align="center"><font color="red">결제수단 구분</font></td>
                                <td align="center"><font color="red">*CASH_GB</font></td>
                                <td><input type="text" name="CASH_GB" id="CASH_GB" size="30" value="RA"/></td>
                                <td align="center"><font color="red">성공URL</font></td>
                                <td align="center"><font color="red">*Okurl</font></td>
                                <td><input type="text" name="Okurl" id="Okurl" size="50" value="http://localhost"/></td>
                            </tr>
                            <tr>
                                <td align="center"><font color="red">서비스아이디</font></td>
                                <td align="center"><font color="red">*RA_SVCID</font></td>
                                <td><input type="text" name="RA_SVCID" id="RA_SVCID" size="30" value="170622040674"/></td>
                                <td align="center"><font color="red">상품명</font></td>
                                <td align="center"><font color="red">*Prdtnm</font></td>
                                <td><input type="text" name="Prdtnm" id="Prdtnm" size="30" value="상품명"/></td>
                            </tr>
                            <tr>
                                <td align="center"><font color="red">결제요청금액</font></td>
                                <td align="center"><font color="red">*Prdtprice</font></td>
                                <td><input type="text" name="Prdtprice" id="Prdtprice" size="30" value="100"/></td>
                                <td align="center"><font color="red">가맹점도메인</font></td>
                                <td align="center"><font color="red">*Siteurl</font></td>
                                <td><input type="text" name="Siteurl" id="Siteurl" size="30" value="http://localhost"/></td>
                            </tr>
                            <tr>
                                <td align="center"><font color="red">거래종류</font></td>
                                <td align="center"><font color="red">*PAY_MODE</font></td>
                                <td><input type="text" name="PAY_MODE" id="PAY_MODE" size="30" value="00"/></td>
                                <td align="center"><font color="red">가맹점거래번호</font></td>
                                <td align="center"><font color="red">*Tradeid</font></td>
                                <td><input type="text" name="Tradeid" id="Tradeid" size="50" value="170622040674_1"/></td>
                            </tr>
                            <tr>
                                <td align="center"><font color="red">가맹점 로고 사용여부</font></td>
                                <td align="center"><font color="red">*LOGO_YN</font></td>
                                <td><input type="text" name="LOGO_YN" id="LOGO_YN" size="30" value="N"/></td>
                                <td align="center"><font color="red">결제창 호출방식</font></td>
                                <td align="center"><font color="red">*CALL_TYPE</font></td>
                                <td><input type="text" name="CALL_TYPE" id="CALL_TYPE" size="30" value="P"/></td>
                            </tr>
                            <tr>
                                <td align="center">결과통보 처리 url</td>
                                <td align="center">Notiurl</td>
                                <td><input type="text" name="Notiurl" id="Notiurl" size="50" value="http://localhost"/></td>
                                <td align="center">취소/닫기 시 이동 url</td>
                                <td align="center">Closeurl</td>
                                <td><input type="text" name="Closeurl" id="Closeurl" size="50" value=""/></td>
                            </tr>
                            <tr>
                                <td align="center">실패 시 이동 url</td>
                                <td align="center">Failurl</td>
                                <td><input type="text" name="Failurl" id="Failurl" size="50" value=""/></td>
                                <td align="center">사용자 ID</td>
                                <td align="center">Userid</td>
                                <td><input type="text" name="Userid" id="Userid" size="30" value="userId"/></td>
                            </tr>
                            <tr>
                                <td align="center">아이템</td>
                                <td align="center">Item</td>
                                <td><input type="text" name="Item" id="Item" size="30" value=""/></td>
                                <td align="center">상품코드</td>
                                <td align="center">Prdtcd</td>
                                <td><input type="text" name="Prdtcd" id="Prdtcd" size="30" value=""/></td>
                            </tr>
                            <tr>
                                <td align="center">결제자 이메일</td>
                                <td align="center">Payeremail</td>
                                <td><input type="text" name="Payeremail" id="Payeremail" size="30" value=""/></td>
                                <td align="center">가맹점 콜백 변수</td>
                                <td align="center">MSTR</td>
                                <td><input type="text" name="MSTR" id="MSTR" size="50" value=""/></td>
                            </tr>
                            <tr>
                                <td align="center">Noti 알림E-mail</td>
                                <td align="center">Notiemail</td>
                                <td><input type="text" name="Notiemail" id="Notiemail" size="30" value=""/></td>
                                <td align="center"><font color="blue">iframe 명칭</font></td>
                                <td align="center"><font color="blue">IFRAME_NAME</font></td>
                                <td><input type="text" name="IFRAME_NAME" id="IFRAME_NAME" size="30" value=""/></td>
                            </tr>
                            <tr>
                                <td align="center"><font color="blue">결제창 안내문 표시 여부</font></td>
                                <td align="center"><font color="blue">INFOAREA_YN</font></td>
                                <td><input type="text" name="INFOAREA_YN" id="INFOAREA_YN" size="30" value="N"/></td>
                                <td align="center"><font color="blue">결제창 하단 안내 표시 여부</font></td>
                                <td align="center"><font color="blue">FOOTER_YN</font></td>
                                <td><input type="text" name="FOOTER_YN" id="FOOTER_YN" size="30" value="N"/></td>
                            </tr>
                            <tr>
                                <td align="center"><font color="blue">결제창 높이</font></td>
                                <td align="center"><font color="blue">HEIGHT</font></td>
                                <td><input type="text" name="HEIGHT" id="HEIGHT" size="30" value=""/></td>
                                <td align="center"><font color="blue">상품명 숨김 여부</font></td>
                                <td align="center"><font color="blue">PRDT_HIDDEN</font></td>
                                <td><input type="text" name="PRDT_HIDDEN" id="PRDT_HIDDEN" size="30" value="N"/></td>
                            </tr>
                            <tr>
                                <td align="center"><font color="blue">결제자 이메일 숨김 여부</font></td>
                                <td align="center"><font color="blue">EMAIL_HIDDEN</font></td>
                                <td><input type="text" name="EMAIL_HIDDEN" id="EMAIL_HIDDEN" size="30" value="N"/></td>
                                <td align="center"><font color="blue">이용약관 숨김 여부</font></td>
                                <td align="center"><font color="blue">CONTRACT_HIDDEN</font></td>
                                <td><input type="text" name="CONTRACT_HIDDEN" id="CONTRACT_HIDDEN" size="30" value="N"/></td>
                            </tr>
                            <tr>
                                <td align="center">암호화 사용 여부</td>
                                <td align="center">Cryptyn</td>
                                <td><input type="text" name="Cryptyn" id="Cryptyn" size="30" value="N"/></td>
                                <td align="center">암호화 검증 값</td>
                                <td align="center">Cryptstring</td>
                                <td><input type="text" name="Cryptstring" id="Cryptstring" size="50" value=""/></td>
                            </tr>
                            <tr>
                                <td align="center" colspan="6">&nbsp;</td>
                            </tr>
                            <tr>
                                <td colSpan={"6"}><input type="button" value="결제하기" onClick={()=>this.test()}/></td>
                            </tr> 	
                        </tbody>
                    </table>
                    
                </form>


            </section>



        );
    }
}

export default connect(mapStateToProps)(Test3);
