import React from 'react';

import Calendar from '../common/Calendar';
import CodeSelect from '../common/CodeSelect';

import { MultiRowInputOne } from '../common/MultiRowInput';

import {REST_API_URL} from '../../config/api-config.js';

import {ManagerComment} from '../common/ApprovalComment';

/*다국어 모듈 시작*/
import { connect } from 'react-redux';
import { changeLangauge, mapStateToProps } from '../../language/Actions';
/*다국어 모듈 종료*/

const initialState = {
    custmNo : "",
    custmName : "",
    tcktCaseMenuCode : "",
    tcktCaseTaskCode : "",
    priorCode : "",
    tcktName : "",
    tcktEnddate : "",
    //ticketEndTm : "",
    emailAlarm : "",
    email : [],
    smsAlarm : "",
    sms : [],
    approvalLine : [],
    approverUserNo : "",
    approverNm : "",
    approverDept : "",
    approverCblePhonNo : "",
    approverMoblPhonNo : "",
    approverEmail : "",
    approverEmailNotify : "N",
    approverSmsNotify : "N",
    approvalInfo : {}
};

class Detail extends React.Component {
    constructor(props) {
        super(props);

        this.state = $.extend(true, {}, initialState);

        this.handleChange = this.handleChange.bind(this);
        this.handleCommandView = this.handleCommandView.bind(this);
    }

    //컴포넌트가 만들어지고 첫 렌더링을 다 마친 후 실행되는 메소드입니다.
	componentDidMount() {
        this.props.onRef(this);
        this.getTicket(this.props.tcktNo);
	}

	//컴포넌트가 DOM 에서 사라진 후 실행되는 메소드입니다.
	componentWillUnmount() {
		this.props.onRef(null);
	}

    handleChange(e) {
        let nextState = {};
        nextState[e.target.name]=e.target.value;
        this.setState(nextState);
    }
    

    getTicket(tcktNo) {
        $.ajax({
            url: REST_API_URL + "/ticket/getTicket",
            dataType: 'json',
            type: "post",
            data: {
                tcktNo:tcktNo
            },
            cache: false,
            success: function(result) {
                this.setState(result.response.ticket);
            }.bind(this),
            error: function(xhr, status, err) {
                console.log(xhr + " : " + status + " : " + err);
            }.bind(this),
			xhrFields: {
			  withCredentials: true
			}
        });
    }
    
    handleCommandView(key) {
        this.managerComment.show();
        this.setState({
            approvalInfo:this.state.approvalLine[key]
        });
    }

    approval(data) {
        $.ajax({
            url: REST_API_URL + "/ticket/Approval",
            dataType: 'json',
            type: "post",
            data: data,
            cache: false,
            success: function(result) {
                alert("처리되었습니다.");
                this.props.onListReload();
            }.bind(this),
            error: function(xhr, status, err) {
                alert("오류가 발생하였습니다.");
                console.log(xhr + " : " + status + " : " + err);
            }.bind(this),
			xhrFields: {
			  withCredentials: true
			}
		});
    }



    render() {
        const mapToManager = (data) => {
            if(data != null && data.length > 0) {
                return data.map((item, i) => {//map
                    return(
                        <tr key={i}>
                            <td>{item.userName}</td>
                            <td>{item.deptName}</td>
                            <td>{item.positName}</td>
                            <td>{item.coTel}</td>
                            <td>{item.mobileNo}</td>
                            <td>{item.userEmail}</td>
                            <td className="ui_only_chk">
                                <span className="input_ico_box">
                                    <input type="checkbox" name='emailNotify' id={'emailNotify_' + i} value="Y" checked={item.emailNotify === 'Y' ? true : false} readOnly/>
                                    <label htmlFor={"emailNotify_" + i}></label>
                                </span>
                            </td>
                            <td className="ui_only_chk">
                                <span className="input_ico_box">
                                    <input type="checkbox" name='smsNotify' id={'smsNotify_' + i} value="Y" checked={item.smsNotify === 'Y' ? true : false} readOnly/>
                                    <label htmlFor={"smsNotify_" + i}></label>
                                </span>
                            </td>
                            <td>{(item.hdlDt == null || item.hdlDt == "") && (this.props.memberInfo.user_no == item.aprvChargeUsrNo)
                                ? 
                                    <a href="javascript:;" className="tbtn_pos" onClick={() => this.handleCommandView(i)}>{this.props.messages.ticket_registration}</a>
                                :
                                    (item.hdlDt == null || item.hdlDt == "")
                                    ?
                                        ''
                                    :    <a href="javascript:;" onClick={() => this.handleCommandView(i)}>{this.props.messages.ticket_view}</a>
                                }</td>
                        </tr>
                    );
                });
            } else {
                return (
                    <tr>
                        <td className="noresults" colSpan={9}>
                            <div className="box_noresults">
                                <div className="ver_mid">													
                                    <i className="ico ico_no_result"></i>
                                    <span className="lb">{this.props.messages.ticket_there_are_no_registered_contacts}</span>
                                </div>
                            </div>
                        </td>
                    </tr>
                );
            }
        }

        return(
            <div id="tab-cont2" className="tab_content tab-cont no_paging" style={{display:'block'}}>
                {/*S:content_body */}
                <div className="content_body">
                    {/*S:content_inner */}
                    <div className="content_inner">
                        
                        <div className="box_com">
                            <div className="fl">
                                <h3 className="ctitle">{this.props.messages.ticket_ticket_information}</h3>
                            </div>
                            <div className="fr">
                                <div className="desc">
                                    <span className="tc_red">*</span> {this.props.messages.ticket_required}
                                </div>
                            </div>
                        </div>
                            
                        {/*S:Table */}
                        <table className="tbl_row">
                            <caption>티켓 정보 목록</caption>
                            <colgroup>
                                <col style={{width:'10%'}}/>
                                <col style={{width:'40%'}}/>
                                <col style={{width:'10%'}}/>
                                <col style={{width:'40%'}}/>
                            </colgroup>
                            <tbody>
                                <tr>
                                    <th scope="row">{this.props.messages.ticket_ticket_id}</th>
                                    <td>{this.state.tcktNo}</td>
                                    <th scope="row">{this.props.messages.ticket_ticket_status_2}</th>
                                    <td><span className="tc_gray tw_bold">{this.state.tcktStatusCodeName}</span></td>
                                </tr>
                                <tr>
                                    <th scope="row">{this.props.messages.ticket_registrant}</th>
                                    <td>{this.state.regUsrName}</td>
                                    <th scope="row">{this.props.messages.ticket_registration_date}</th>
                                    <td>{this.state.regDate}</td>
                                </tr>
                                <tr>
                                    <th scope="row">{this.props.messages.ticket_customer_name} <span className="tc_red">*</span></th>
                                    <td>{this.state.custmName}</td>
                                    <th scope="row">{this.props.messages.ticket_ticket_case} <span className="tc_red">*</span></th>
                                    <td>{this.state.tcktCaseMenuCodeName} > {this.state.tcktCaseTaskCodeName}
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">{this.props.messages.ticket_priority} <span className="tc_red">*</span></th>
                                    <td className="input">
                                        <ul className="ip_list">
                                            <li>
                                                <span className="input_ico_box">
                                                    <input type="radio" name="priorCode" id={"rdobox-rdo-1"} value="High" checked={this.state.priorCode === "High"} onChange={this.handleChange} disabled="disabled"/>
                                                    <label htmlFor={"rdobox-rdo-1"}>{this.props.messages.ticket_high}</label>
                                                </span>
                                            </li>
                                            <li>
                                                <span className="input_ico_box">
                                                    <input type="radio" name="priorCode" id={"rdobox-rdo-2"} value="Medium" checked={this.state.priorCode === "Medium"} onChange={this.handleChange} disabled="disabled"/>
                                                    <label htmlFor={"rdobox-rdo-2"}>{this.props.messages.ticket_mid}</label>
                                                </span>
                                            </li>
                                            <li>
                                                <span className="input_ico_box">
                                                    <input type="radio" name="priorCode" id={"rdobox-rdo-3"} value="Low" checked={this.state.priorCode === "Low"} onChange={this.handleChange} disabled="disabled"/>
                                                    <label htmlFor={"rdobox-rdo-3"}>{this.props.messages.ticket_low}</label>
                                                </span>
                                            </li>
                                        </ul>
                                    </td>
                                    <th scope="row">{this.props.messages.ticket_ticket_name} <span className="tc_red">*</span></th>
                                    <td>{this.state.tcktName}</td>
                                </tr>
                                <tr>
                                    <th scope="row">{this.props.messages.ticket_ticket_termination_date} <span className="tc_red">*</span></th>
                                    <td colSpan={3}>{this.state.tcktEnddate} </td>
                                </tr>
                                {/*<tr>
                                    <th scope="row">{this.props.messages.ticket_e_mail}</th>
                                    <td className="input" colSpan={3}>
                                        <ul className="ip_list">
                                            <li>
                                                <span className="input_ico_box">
                                                    <input type="radio" name="emailAlarm" id={"rdobox-rdo-2-1"} value="Yes" checked={this.state.emailAlarm === "Yes"} onChange={this.handleChange} disabled="disabled"/>
                                                    <label htmlFor={"rdobox-rdo-2-1"}>{this.props.messages.ticket_completion_e_mail}</label>
                                                </span>
                                            </li>
                                            <li>
                                                <span className="input_ico_box">
                                                    <input type="radio" name="emailAlarm" id={"rdobox-rdo-2-2"} value="No" checked={this.state.emailAlarm === "No"} onChange={this.handleChange} disabled="disabled"/>
                                                    <label htmlFor={"rdobox-rdo-2-2"}>{this.props.messages.ticket_unnecessary}</label>
                                                </span>
                                            </li>
                                        </ul>
                                        
                                        <MultiRowInputOne inData={this.state.email} isDisabled={this.state.emailAlarm != 'Yes' ? true : false} readonly={true}/>
                                        
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">SMS 알림</th>
                                    <td className="input" colSpan={3}>
                                        <ul className="ip_list">
                                            <li>
                                                <span className="input_ico_box">
                                                    <input type="radio" name="smsAlarm" id={"rdobox-rdo-3-1"} value="Yes" checked={this.state.smsAlarm === "Yes"} onChange={this.handleChange} disabled="disabled"/>
                                                    <label htmlFor={"rdobox-rdo-3-1"}>{this.props.messages.ticket_completion_sms}</label>
                                                </span>
                                            </li>
                                            <li>
                                                <span className="input_ico_box">
                                                    <input type="radio" name="smsAlarm" id={"rdobox-rdo-3-2"} value="No" checked={this.state.smsAlarm === "No"} onChange={this.handleChange} disabled="disabled"/>
                                                    <label htmlFor={"rdobox-rdo-3-2"}>{this.props.messages.ticket_unnecessary}</label>
                                                </span>
                                            </li>
                                        </ul>

                                        <MultiRowInputOne inData={this.state.sms} isDisabled={this.state.smsAlarm != 'Yes' ? true : false} readonly={true}/>
                                    </td>
                                </tr>*/}
                            </tbody>
                        </table>
                        {/*E:Table */}
                        

                        <div className="box_com">
                            <div className="fl">
                                <h3 className="ctitle">{this.props.messages.ticket_manager_2}</h3>
                            </div>
                            {/*<div className="fr">
                                <a href="javascript:;" className="btn_pos" onClick={this.handleManagerRemove}>삭제</a>
                                <a href="javascript:;" className="btn_black" onClick={() => this.refs.managerSearch.show()}>담당자 검색</a>
                            </div>*/}
                        </div>

                        <table className="tbl_col">
                            <caption>담당자 정보 목록</caption>
                            <colgroup>
                                <col style={{width:'13%'}}/>
                                <col style={{width:'13%'}}/>
                                <col style={{width:'13%'}}/>
                                <col style={{width:'13%'}}/>
                                <col style={{width:'13%'}}/>
                                <col style={{width:'13%'}}/>
                                <col style={{width:'5%'}}/>
                                <col style={{width:'5%'}}/>
                                <col style={{width:'12%'}}/>
                                
                            </colgroup>
                            
                            <thead>
                                <tr>
                                    {/*Com : checkbox 만 있을때 ui_only_chk class 추가 */}
                                    <th scope="col">{this.props.messages.ticket_name}</th>
                                    <th scope="col">{this.props.messages.ticket_manager_department}</th>
                                    <th scope="col">{this.props.messages.ticket_position}</th>
                                    <th scope="col">{this.props.messages.ticket_phone}</th>
                                    <th scope="col">{this.props.messages.ticket_cell_phone}</th>
                                    <th scope="col">{this.props.messages.contract_e_mail}</th>
                                    <th scope="col">{this.props.messages.ticket_e_mail}</th>
                                    <th scope="col">{this.props.messages.ticket_sms}</th>
                                    <th scope="col">{this.props.messages.ticket_comment_1}</th>
                                    
                                </tr>
                            </thead>
                            
                            <tbody>
                                {mapToManager(this.state.approvalLine)}
                            </tbody>
                        </table>
                        
                        <div className="box_com">
                            <div className="fl">
                                <h3 className="ctitle">{this.props.messages.ticket_approver_information}</h3>
                            </div>
                            {/*<div className="fr">
                                <a href="javascript:;" className="btn_black" onClick={()=>this.refs.approvalSearch.show()}>승인자 검색</a>
                            </div>*/}
                        </div>
                        
                        {/*S : 승인자 정보 목록이 있는 경우 */}
                        {/*S:Table */}
                        <table className="tbl_row">
                            <caption>승인자 정보 목록</caption>
                            <colgroup>
                                <col style={{width:'10%'}}/>
                                <col style={{width:'40%'}}/>
                                <col style={{width:'10%'}}/>
                                <col style={{width:'40%'}}/>
                            </colgroup>
                            <tbody>
                                <tr>
                                    <th scope="row">{this.props.messages.ticket_name}</th>
                                    <td>{this.state.approverNm}<input type="hidden" name="approverId" value={this.state.approverId}  onChange={this.handleChange}/></td>
                                    <th scope="row">{this.props.messages.ticket_manager_department}</th>
                                    <td>{this.state.approverDept}</td>
                                </tr>
                                <tr>
                                    <th scope="row">{this.props.messages.ticket_phone}</th>
                                    <td>{this.state.approverCblePhonNo}</td>
                                    <th scope="row">{this.props.messages.ticket_cell_phone}</th>
                                    <td>{this.state.approverMoblPhonNo}</td>
                                </tr>
                                <tr>
                                    <th scope="row">{this.props.messages.contract_e_mail}</th>
                                    <td colSpan={3}>{this.state.approverEmail}</td>
                                </tr>
                                {/*<tr>
                                    <th scope="row">{this.props.messages.ticket_e_mail}</th>
                                    <td colSpan={3}>
                                        <input type="checkbox" name='approverEmailNotify' id={'approverEmailNotify'} value="Y" checked={this.state.approverEmailNotify === 'Y' ? true : false} readOnly/>
                                        <label htmlFor={'approverEmailNotify'}></label>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">{this.props.messages.ticket_sms}</th>
                                    <td colSpan={3}>
                                        <input type="checkbox" name='approverSmsNotify' id={'approverSmsNotify'} value="Y" checked={this.state.approverSmsNotify === 'Y' ? true : false} readOnly/>
                                        <label htmlFor={'approverSmsNotify'}></label>
                                    </td>
                                </tr>*/}
                            </tbody>
                        </table>
                        {/*E:Table */}
                        
                    </div>
                    {/*E:content_inner */}
                    <ManagerComment onRef={ref => (this.managerComment = ref)} approvalInfo={this.state.approvalInfo} onCommentResult={this.props.onListReload}/>
                </div>
                {/*E:content_body */}

            </div>
        )
    }
}

export default connect(mapStateToProps)(Detail);