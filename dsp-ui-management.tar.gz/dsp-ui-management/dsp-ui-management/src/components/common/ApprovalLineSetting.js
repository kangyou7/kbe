import React from 'react';

import {ApprovalLineSearch} from './ApprovalSearch';
import {ApprovalComment} from './ApprovalComment';

/*다국어 모듈 시작*/
import { connect } from 'react-redux';
import { changeLangauge, mapStateToProps } from '../../language/Actions';
/*다국어 모듈 종료*/

class ApprovalLineSetting extends React.Component {

    constructor(props) {
        super(props);

        this.state = {
            approvalInfo:{},
            hdlOpinText : ""
        }

        this.handleApprovalLineComplete = this.handleApprovalLineComplete.bind(this);
        this.handleCommandView = this.handleCommandView.bind(this);
        this.handleChange = this.handleChange.bind(this);
    }

    handleApprovalLineComplete(approvalLine) {
        this.props.onApprovalLineComplete(approvalLine);
    }

    handleCommandView(key) {
        this.approvalComment.show();
        this.setState({
            approvalInfo:this.props.approvalLine[key]
        });
    }

    handleChange(e) {
        let nextState = {};
        nextState[e.target.name]=e.target.value;
        this.setState(nextState);

        this.props.onCommentChange(e);
	}

    componentWillReceiveProps(nextProps){
        this.state.hdlOpinText = "";
    }
    //컴포넌트가 만들어지고 첫 렌더링을 다 마친 후 실행되는 메소드입니다.
    componentDidMount() {
        this.props.onRef(this)
    }

    //컴포넌트가 DOM 에서 사라진 후 실행되는 메소드입니다.
    componentWillUnmount() {
        this.props.onRef(null)
    }

    render() {
        const mapToApprovalLine = (data, isChange) => {
            if(data != null && data.length > 0) {
                return data.map((item, i) => {//map

                    let aprvStepCodeName = '';
                    if(item.aprvStepCode === 'D') {
                        aprvStepCodeName = this.props.messages.contract_draft;
                    } else if(item.aprvStepCode === 'R') {
                        aprvStepCodeName = this.props.messages.contract_review;
                    } else if(item.aprvStepCode === 'C') {
                        aprvStepCodeName = this.props.messages.contract_cooperation;
                    } else if(item.aprvStepCode === 'A') {
                        aprvStepCodeName = this.props.messages.contract_approval;
                    }

                    if(!this.props.isCommentView) {
                        return(
                            <tr className={item.type === "D" ? "tc_gray" : ""} key={i}>
                                <td>{aprvStepCodeName}</td>
                                <td>{item.userName}</td>
                                <td>{item.deptName}</td>
                                <td>{item.positName}</td>
                            </tr>
                        );
                    } else {
                        return(
                            <tr className={item.aprvStepCode === "D" ? "tc_gray" : ""} key={i}>
                                <td>{aprvStepCodeName}</td>
                                <td>{item.userName}</td>
                                <td>{item.deptName}</td>
                                <td>{item.positName}</td>
                                <td>{item.hdlDt}</td>
                                <td>{!(item.hdlDt == null || item.hdlDt == "") && item.aprvStepCode != 'D' ? <a href="javascript:;" onClick={() => {this.handleCommandView(i)}}>{this.props.messages.contract_view}</a> : ""}</td>
                            </tr>
                        );
                    }
                });
            } else {
                return (
                    <tr>
                        <td className="noresults" colSpan={this.props.isCommentView ? 6 : 4}>
                            <div className="box_noresults">
                                <div className="ver_mid">
                                    <i className="ico ico_no_result"></i>
                                    <span className="lb">결재 정보가 없습니다.</span>
                                </div>
                            </div>
                        </td>
                    </tr>
                );
            }
        }


        const lineSettingDiv = (
            <div className="fr">
                <button type="button" className="btn_pos" onClick={() => {this.approvalLineSearch.show();}}>{this.props.messages.contract_approval_line}</button>
            </div>
        );

        const tableCaption4 = (
            <colgroup>
                <col style={{width:'25%'}}/>
                <col style={{width:'25%'}}/>
                <col style={{width:'25%'}}/>
                <col style={{width:'25%'}}/>
                
            </colgroup>
        );

        const tableCaption6 = (
            <colgroup>
                <col style={{width:'16%'}}/>
                <col style={{width:'16%'}}/>
                <col style={{width:'16%'}}/>
                <col style={{width:'16%'}}/>
                <col style={{width:'17%'}}/>
                <col style={{width:'16%'}}/>
            </colgroup>
        )

        const tablethead4 = (
            <thead>
                <tr>
                    <th scope="col">{this.props.messages.contract_method}</th>
                    <th scope="col">{this.props.messages.contract_name}</th>
                    <th scope="col">{this.props.messages.contract_manager_department}</th>
                    <th scope="col">{this.props.messages.contract_position}</th>
                </tr>
            </thead>
        );

        const tablethead6 = (
            <thead>
                <tr>
                    <th scope="col">{this.props.messages.contract_method}</th>
                    <th scope="col">{this.props.messages.contract_name}</th>
                    <th scope="col">{this.props.messages.contract_manager_department}</th>
                    <th scope="col">{this.props.messages.contract_position}</th>
                    <th scope="col">{this.props.messages.contract_approved_date}</th>
                    <th scope="col">{this.props.messages.contract_comment}</th>
                </tr>
            </thead>
        )


        const commandDiv = (
            <table className="tbl_row">
                <caption>결재 정보 목록</caption>
                <colgroup>
                    <col style={{width:'10%'}}/>
                    <col style={{width:'90%'}}/>
                </colgroup>
                <tbody>
                    <tr>
                        <th scope="row">{this.props.messages.contract_comment}</th>
                        <td className="input">
                            <textarea className="ui_textarea" name="hdlOpinText" value={this.state.hdlOpinText} onChange={this.handleChange} maxLength={1000}></textarea>
                        </td>
                    </tr>
                </tbody>
            </table>
        )

        return(
            <div>
                <div className="box_com">
                    <div className="fl">
                        <h3 className="ctitle">{this.props.messages.contract_approval_information}</h3>
                    </div>
                    {this.props.isChange ? lineSettingDiv : ""}
                </div>
                

                {/* DESC : 결재정보 목록 5줄 이상 스크롤 처리 */}
                {/*<div className={this.props.isCommentView ? "scroll_wrap confirm" : ""}>*/}
                <div>
                    {/* S:Table*/}
                    <table className="tbl_col">
                        <caption>결재 정보 목록</caption>
                        {this.props.isCommentView ? tableCaption6 : tableCaption4}
                        
                        {this.props.isCommentView ? tablethead6 : tablethead4}
                        
                        <tbody>
                            
                            {/* 결재선 */}
                            {mapToApprovalLine(this.props.approvalLine, this.props.isChange)}
                            
                        </tbody>
                    </table>
                    
                    {/* 의견 */}
                    {this.props.isComment ? commandDiv : ""}
                    
                </div>

                <ApprovalLineSearch onRef={ref => (this.approvalLineSearch = ref)} onComplete={this.handleApprovalLineComplete} approvalLine={this.props.approvalLine} menuPath={this.props.menuPath}/>
                <ApprovalComment onRef={ref => (this.approvalComment = ref)} approvalInfo={this.state.approvalInfo}/>
                <div style={{height:'17px'}}></div>
            </div>
        );
    }
}


export default connect(mapStateToProps)(ApprovalLineSetting);