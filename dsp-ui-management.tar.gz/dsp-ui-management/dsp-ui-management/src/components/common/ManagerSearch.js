import React from 'react';

import {REST_API_URL} from '../../config/api-config.js';

/*다국어 모듈 시작*/
import { connect } from 'react-redux';
import { changeLangauge, mapStateToProps } from '../../language/Actions';
/*다국어 모듈 종료*/

class ManagerSearch extends React.Component {

    constructor(props) {
        super(props);

        this.state = {
            searchName:"",
            users : []
        }

        this.handleChange = this.handleChange.bind(this);
        this.handleSearch = this.handleSearch.bind(this);
    }

    //컴포넌트가 만들어지고 첫 렌더링을 다 마친 후 실행되는 메소드입니다.
	componentDidMount() {
		this.props.onRef(this)
	}

	//컴포넌트가 DOM 에서 사라진 후 실행되는 메소드입니다.
	componentWillUnmount() {
		this.props.onRef(null)
	}

    show() {
        this.setState({
            searchName:"",
            users : []
        });

        layer_open(".pop-search-manager");
    }

    hide() {
        layer_close(".pop-search-manager");
    }

    handleChange(e) {
        let nextState = {};
        nextState[e.target.name]=e.target.value;
        this.setState(nextState);
    }

    handleSearch() {
        const memberInfo = this.props.memberInfo;

        let _param = {
            searchName:this.state.searchName,
                loginUserNo : memberInfo.user_no,
        };
        console.log(JSON.stringify(_param));

        $.ajax({
            url: REST_API_URL + "/approval/getManagerUsersSearch",
            dataType: 'json',
            type: "post",
            data: _param,
            cache: false,
            success: function(result) {
                this.setState({
                    users: result.response.users
                });
            }.bind(this),
            error: function(xhr, status, err) {
                console.log(xhr + " : " + status + " : " + err);
            }.bind(this),
            xhrFields: {
              withCredentials: true
            }
        });
    }
    
    complete() {

        let stateUsers = this.state.users;
        let users = [];

        $("input[name='searchColumnCheck']:checked").each(function(i) {
            users.push(stateUsers[$(this).val()]);
        });
        
        this.props.onManagerComplete(users);
        this.hide();
    }

    allChecked(obj) {
        $("input[name='searchColumnCheck']").prop("checked", $(obj.target).is(":checked"));
    }

    render() {
        const mapToUser = (data) => {
            if(data.length > 0) {
                return data.map((item, i) => {//map
                    return(
                        <tr key={i}>
                            <td className="ui_only_chk">
                                <span className="input_ico_box">
                                    <input type="checkbox" name="searchColumnCheck" id={"searchColumnCheck_" + i} value={i} defaultChecked={false} />
                                    <label htmlFor={"searchColumnCheck_" + i}></label>
                                </span>
                            </td>
                            <td>{item.userName}</td>
                            <td>{item.deptName}</td>
                            <td>{item.positName}</td>
                            <td>{item.coTel}</td>
                            <td>{item.mobileNo}</td>
                            <td>{item.userEmail}</td>
                        </tr>
                    );
                });
            } else {
                return (
                    <tr>
                        <td className="noresults" colSpan={7}>
                            <div className="box_noresults">
                                <div className="ver_mid">													
                                    <i className="ico ico_no_result"></i>
                                    <span className="lb">{this.props.messages.contract_there_are_no_results}</span>
                                </div>
                            </div>
                        </td>
                    </tr>
                );
            }
        }

        return(
            <div className="lpopup">
                <div className="dimmed"></div>
                <div className="popup_layer pop_search_manager pop-search-manager lg">
                    <div className="pop_container">
                        <div className="pop_header">
                            <h1>{this.props.messages.ticket_manager_list}</h1>
                        </div>
                        {/* pop_contents */}
                        <div className="pop_contents scroll_wrap search_form">
                            {/* pop_inner */}
                            <div className="pop_inner">
                                <div className="psearch_form">
                                    <input type="text" className="ui_input" placeholder={this.props.messages.ticket_name} name="searchName" value={this.state.searchName} onChange={this.handleChange} />
                                    <a href="javascript:;" className="btn_pos" onClick={this.handleSearch}>{this.props.messages.ticket_search_2}</a>
                                </div>
                                
                                <table className="tbl_col">
                                    <caption>담당자 목록</caption>
                                    <colgroup>
                                        <col style={{width:'6%'}}/>
                                        <col style={{width:'14%'}}/>
                                        <col style={{width:'15%'}}/>
                                        <col style={{width:'8%'}}/>
                                        <col style={{width:'17%'}}/>
                                        <col style={{width:'17%'}}/>
                                        <col style={{width:'23%'}}/>
                                    </colgroup>
                                    
                                    <thead>
                                        <tr>
                                            {/* Com : checobkx 만 있을때 ui_only_chk class 추가 */}
                                            <th scope="col" className="ui_only_chk">
                                                <span className="input_ico_box">
                                                    <input type="checkbox" name="allCheck" id={"allCheck"} defaultChecked={false} onClick={this.allChecked}/>
                                                    <label htmlFor={"allCheck"}></label>
                                                </span>
                                            </th>
                                            <th scope="col">{this.props.messages.ticket_name}</th>
                                            <th scope="col">{this.props.messages.ticket_manager_department}</th>
                                            <th scope="col">{this.props.messages.ticket_position}</th>
                                            <th scope="col">{this.props.messages.ticket_phone}</th>
                                            <th scope="col">{this.props.messages.ticket_cell_phone}</th>
                                            <th scope="col">{this.props.messages.contract_e_mail}</th>
                                        </tr>
                                    </thead>
                                    
                                    <tbody>
                                        {/* S : 리스트 있는 경우 */}
                                        {mapToUser(this.state.users)}
                                        {/* E : 리스트 없는 경우 */}
                                    </tbody>
                                </table>
                            </div>
                            {/* // pop_inner */}
                        </div>	
                        {/*// pop_contents*/}
                        <div className="pop_bottom">
                            <a href="javascript:;" className="pbtn_black" onClick={() => {this.complete()}}>{this.props.messages.ticket_ok}</a>
                        </div>
                    </div>{/*// pop_container */}
                    <a href="javascript:;" onClick={() => {this.hide()}} className="btn_pop_close"><span className="offscreen">{this.props.messages.ticket_close}</span></a>
                </div>{/*// popup_layer */}
            </div>
        )
    }
}

export default connect(mapStateToProps)(ManagerSearch);
