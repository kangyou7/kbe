import React from 'react';
import { connect } from 'react-redux';
import { actionlogin } from '../../language/Actions';
import { bindActionCreators } from 'redux';

import { Link, browserHistory } from 'react-router';
import PropTypes from 'prop-types';
import { REST_AUTH_URL, SITE_DOMAIN, ACTIVE } from '../../config/api-config.js';


let memberInfo = {
  memberInfo: {
    user_no :-1,
    user_name : "",
    user_id : "",
    login_time : "",
    user_dstnct_code : "", //  01:Provider, 02:Customer, 03:SK Infosec
    menus:[],
  }
};


class DspLogin extends React.PureComponent {

  constructor(props, context) {
    super(props, context);
    this.state = {
        userId : "",
        pwd : "",
        memberInfo:{
          user_no :-1,
          user_name : "",
          user_id : "",
          login_time : "",
          user_dstnct_code : "",
          dspDefaultTZ :"",
          dept_name : "",
          posit_name : "",
          duti_name : "",
          dspUserFncBtnInfo : "",
          menus : [],
        }
    }

    this.handleChange = this.handleChange.bind(this);
    this.fncEnterLogin = this.fncEnterLogin.bind(this);
  }

  static fetchData(dispatch){
		let cl = bindActionCreators(actionlogin, dispatch);
		return Promise.all([ cl.loginAction ]);
  }

  componentDidMount (){
    $('#loading').hide();
    //  localStorage.clear();
  }

  handleChange(e){
    let nextState = {};
    nextState[e.target.name] = e.target.value;
    this.setState(nextState);
  }

  fncSetCookie(cname , cValue, cDay=1){
    let setDay = new Date();
    setDay.setDate(setDay.getDate()+cDay);  //1일 유지 시간
    let expires = "; expires="+setDay.toGMTString()+';';
    let domain = 'domain='+SITE_DOMAIN+';HttpOnly';
    let path = "/";

    document.cookie = cname+"="+escape(cValue)+expires+domain+path;
  }

  moveToUri(goUri){
    //browserHistory.push(goUri);
    location.href=goUri;
  }

  loginProcess(){
    if(!this.state.userId.trim()){
      alert('아이디를 입력해주세요.');
      return false;
    }

    if(!this.state.pwd.trim()){
      alert('비밀번호를 입력해주세요.');
      return false;
    }

    let data = {
      userId : this.state.userId,
      pwd : this.state.pwd,
      dspDefaultTZ : getTimezoneName()
    }

    $.ajax({
       url: REST_AUTH_URL+"/log_in",
      dataType : "json",
      type : "post",
      data : data,
      cache: false,
      success:function(result){

        memberInfo = this.state.memberInfo;

        if(ACTIVE=="local"){
          this.fncSetCookie("user_no", result.response.member_info.userNo);
          this.fncSetCookie("user_id", result.response.member_info.userId);
          this.fncSetCookie("user_name", result.response.member_info.userName);
          this.fncSetCookie("access_token", result.response.member_info.accessToken);
          this.fncSetCookie("refresh_token", result.response.member_info.refreshToken);
          this.fncSetCookie("user_dstnct_code", result.response.member_info.userDstnctCode);
          this.fncSetCookie("expiration_timestamp", "dsp_test_token");
        }
        
        this.fncSetCookie("dspDefaultTZ", getTimezoneName());


        memberInfo.user_no = result.response.member_info.userNo;
        memberInfo.user_id = result.response.member_info.userId;
        memberInfo.user_name = result.response.member_info.userName;
        memberInfo.user_dstnct_code = result.response.member_info.userDstnctCode;
        memberInfo.dept_name = result.response.member_info.deptName;
        memberInfo.posit_name = result.response.member_info.positName;
        memberInfo.duti_name = result.response.member_info.dutiName;
        memberInfo.login_time = result.response.loginDt;
        memberInfo.menus = this.setMunuInfo(result.response.menu_info);
        memberInfo.dspDefaultTZ = getTimezoneName();
        memberInfo.dspUserFncBtnInfo = result.response.fncBtnInfo;

        console.log(JSON.stringify(result));

        this.setState({ memberInfo: memberInfo });
        
        this.props.actionlogin('LOG_IN');
        
        console.log("memberInfo ==> "+JSON.stringify(memberInfo));
        localStorage.setItem('memberInfo', JSON.stringify(memberInfo));
        this.moveToUri('/'); //  로그인 후 메인 페이지로 이동
        //  location.href='/';

      }.bind(this),
      error:function(xhr, status, err){
        alert(JSON.stringify(xhr.responseJSON.message));
        console.log(JSON.stringify( xhr ) + " : "+ status +" :" + JSON.stringify(err));
      }.bind(this),
      xhrFields: {
        withCredentials: true
      }
    });
  }

  setMunuInfo(menus){
    let setMenus = [];
    let setMenuItem = {
      name :'',
      uri:'',
      subMenu:[]
    };

    menus.forEach(menu => {
      switch(menu.authotPath){
        case 'contract':
          setMenuItem ={
            name : menu.authotName,
            uri : '/'+menu.authotPath,
            subMenu:[
              {name:'계약 현황',uri:'/contract'},
              //{name:'계약등록',uri:'/contract?type=Create'},
              {name:'계약등록',uri:'/contractCreate'},
              {name:'결제 미처리 현황',uri:'/ContractTodo'}
            ]
          };
          setMenus.push(setMenuItem);
          break;
          case 'assets':
          setMenuItem ={
            name : menu.authotName,
            uri : '/'+menu.authotPath,
            subMenu:[
              {name:'자산 현황',uri:'/assets'},
              {name:'자산 등록',uri:'/assetsCreate'},
              {name:'장비 이관 현황',uri:'/assetsTransfer'},
              {name:'장비 벤더 관리',uri:'/vendor'},
              {name:'유지보수 업체 관리',uri:'/mtnceEntp'},
              {name:'벤더 별 장비 보유 현황',uri:'/assetsGroupByVendor'}
            ]
          };
          setMenus.push(setMenuItem);
          break;
          case 'provider':
          setMenuItem ={
            name : menu.authotName,
            uri : '/'+menu.authotPath,
            subMenu:[
              {name:'Provider 현황',uri:'/provider'},
              {name:'Customer 현황',uri:'/customer'}
            ]
          };
          setMenus.push(setMenuItem);
          break;
          case 'cntrlSchedule':
          setMenuItem ={
            name : menu.authotName,
            uri : '/'+menu.authotPath,
            subMenu:[
              {name:'관제 스케줄 관리',uri:'/cntrlSchedule'}
            ]
          };
          setMenus.push(setMenuItem);
          break;
          case 'product':
          setMenuItem ={
            name : menu.authotName,
            uri : '/'+menu.authotPath,
            subMenu:[
              {name:'상품 현황',uri:'/product'},
              {name:'상품 등록',uri:'/productCreate'}
            ]
          };
          setMenus.push(setMenuItem);
          break;
          case 'sales':
          setMenuItem ={
            name : menu.authotName,
            uri : '/'+menu.authotPath,
            subMenu:[
              {name:'매출 현황',uri:'/sales'},
              {name:'대사',uri:'/paymentList'}
            ]
          };
          setMenus.push(setMenuItem);
          break;
          case 'ticket':
          setMenuItem ={
            name : menu.authotName,
            uri : '/'+menu.authotPath,
            subMenu:[
              {name:'Ticket 현황',uri:'/ticket'},
              {name:'Ticket 등록',uri:'/ticketCreate'}
            ]
          };
          setMenus.push(setMenuItem);
          break;
          case 'userlist':
          setMenuItem ={
            name : menu.authotName,
            uri : '/'+menu.authotPath,
            subMenu:[
              {name: '사용자 관리',uri:'/userlist'},	
              {name: '사용자 그룹',uri:'/group'},	
            ]
          };
          setMenus.push(setMenuItem);
          break;
          case 'monitoringNotice':
          setMenuItem ={
            name : menu.authotName,
            uri : '/'+menu.authotPath,
            subMenu:[
              {name: '관제 공지',uri:'/monitoringNotice'},						
              {name: 'Provider 공지',uri:'/providerNotice'},
              {name: '프로세스 변경 안내',uri:'/processNotice'}
            ]
          };
          
          setMenus.push(setMenuItem);
          break;
      }


    });

    return setMenus;
  }

  fncEnterLogin(e){
    if(e.keyCode === 13)
        this.loginProcess();
  }

  render(){
	    return(
        <section className="member">
          <div className="memer_wrap">
            <div className="login_group">
              <div className="login_box">
                <h1 className="login_logo"><img src="./images/common/login_logo.png" alt="secudium digital security platform"></img></h1>
                <div className="lg_body">
                  <div className="input_form">
                    <label className="input_box">
                      <input type="text" placeholder="User ID" value={this.state.userId} onChange={this.handleChange} name="userId" />
                    </label>
                    <label className="input_box">
                      <input type="password" placeholder="Password" value={this.state.pwd} 
                        onChange={this.handleChange} name="pwd" 
                        onKeyDown = { this.fncEnterLogin }
                        />
                    </label>
                  </div>
                  <div className="btn_group">
                    <a href="javascript:;" className="btn_dsp_login" onClick={()=>this.loginProcess()}>LOG IN</a>
                  </div>
                  
                  <div className="guide_pw">
                    <a href="javascript:;"  onClick={() => {alert('Please contact the administrator.');}}>Notice</a>
                  </div>				
                </div>
              </div>
              <p className="copyright">Copyright ⓒ 2018 SK infosec. All rights reserved.</p>
            </div>
          </div>
        </section>
      );
    }
  }
  let mapDispatchToProps = (dispatch) => {
    return {
      actionlogin: (event) => dispatch(actionlogin(memberInfo))
    };
  }
export default connect(undefined, mapDispatchToProps)(DspLogin);