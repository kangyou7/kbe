/*jshint esversion: 6 */
import React from 'react';

import Calendar from '../common/Calendar';
import CodeSelect from '../common/CodeSelect';
import AttachFile from '../common/AttachFile';

import {TableThead, TableColgroup} from '../common/TableThead';

import {REST_API_URL} from '../../config/api-config.js';

import ChargeUsrCreate  from '../provider/ChargeUsrCreate';

import { Link, browserHistory } from 'react-router';

/*다국어 모듈 시작*/
import { connect } from 'react-redux';
import { changeLangauge, mapStateToProps, actionlogin } from '../../language/Actions';
import { isNull } from 'util';
import { parse } from 'query-string';
/*다국어 모듈 종료*/

/* 유효성 체크 */
import validator from 'validator';

class ProviderDetail extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            listThead : [
                {name:'checkbox', sort:false, sortColumn:"", view:true, target:false, checkbox:true, width:'4%'},
                {name:props.messages.charge_usr_name,       sort:false, sortColumn:"", view:true, target:true, width:'12%'},
                {name:props.messages.charge_usr_dept_name,       sort:false, sortColumn:"", view:true, target:true, width:'12%'},
                {name:props.messages.charge_usr_posit_name,      sort:false, sortColumn:"", view:true, target:true, width:'12%'},
                {name:props.messages.charge_usr_tel,        sort:false, sortColumn:"", view:true, target:true, width:'12%'},
                {name:props.messages.charge_usr_mobile_no,  sort:false, sortColumn:"", view:true, target:true, width:'12%'},
                {name:props.messages.charge_usr_email,      sort:false, sortColumn:"", view:true, target:true, width:'12%'},
                {name:props.messages.charge_usr_clas_name,  sort:false, sortColumn:"", view:true, target:true, width:'12%'},
            ],
            custmNo : 0,
            custmClasCode : "",
            customerClasCode : "",
            coName : "",
            ceoName : "",
            bizno : "",
            coAddr : "",
            hmpageUrl : "",
            coEmail : "",
            coTel : "",
            coFaxNo : "",
            prvdrNo : "",
            bmModelClasCode : "",
            bmModelClasName : "",
            useYn : "",
            regUserNo : "",
            prvdrCtrtStrDate : "",
            prvdrCtrtEndDate : "",
            setleSvcId:"",
            attachFile : [],
            chageUsrList : [],
            acctSetleSvcId : "",
            cardSetleSvcId : ""
        }

        this.handleChange = this.handleChange.bind(this);
        this.handleFileChange = this.handleFileChange.bind(this);
        this.handleProviderSave = this.handleProviderSave.bind(this);
        this.handleCreateComplete = this.handleCreateComplete.bind(this);
        this.handleDeleteUsr = this.handleDeleteUsr.bind(this);
        this.handleUpdateUsr = this.handleUpdateUsr.bind(this);
        this.handleChargeUsrAdd = this.handleChargeUsrAdd.bind(this);

    }

    handleSave(){
		if(!this.validationCheck()) {
			return;
		}

        $('#loading').show();
		if(this.state.attachFile.length > 0) {
			this.attachFile.fileUpload();
		} else {
			this.handleProviderSave(null);
		}
    }
   
    handleChange(e) {
        let nextState = {};
        nextState[e.target.name]=e.target.value;
        this.setState(nextState);
	}

    handleFileRemove(key) {
		let files = this.state.attachFile;

		attachFile.splice(key, 1);

		this.setState({
			attachFile : attachFile
		});
    }
    
	handleFileChange(attachFile) {
		this.setState({
			attachFile : attachFile
		});
    }
    
    componentWillReceivePropsnextProps(){
        if(this.props.locale !== nextProps.locale) {
            let listThead = this.state.listThead;
            listThead[0].name = "";
            listThead[1].name = nextProps.messages.charge_usr_name;
            listThead[2].name = nextProps.messages.charge_usr_dept_name;
            listThead[3].name = nextProps.messages.charge_usr_posit_name;
            listThead[4].name = nextProps.messages.charge_usr_tel;
            listThead[5].name = nextProps.messages.charge_usr_mobile_no;
            listThead[6].name = nextProps.messages.charge_usr_email;
            listThead[7].name = nextProps.messages.charge_usr_clas_name;
        }
    }
    
    //컴포넌트가 만들어지고 첫 렌더링을 다 마친 후 실행되는 메소드입니다.
    componentDidMount() {

        if(this.props.location === undefined || this.props.location.query === undefined || this.props.location.query.ctrtNo === undefined) {
            this.props.onRef(this);

            this.getProvider(this.props.custmNo);
        } else {
            this.getProvider(this.props.location.query.custmNo);
        }
    }

    //컴포넌트가 DOM 에서 사라진 후 실행되는 메소드입니다.
	componentWillUnmount() {
		if(this.props.location === undefined || this.props.location.query === undefined || this.props.location.query.ctrtNo === undefined) {
            this.props.onRef(null);
        }
	}

    getProvider(value) {
        $.ajax({
            url: REST_API_URL + "/provider/select",
            dataType: 'json',
            type: "post",
            data: {'custmNo':parseInt(this.props.custmNo)},
            cache: false,
            processData : true, /*querySTring make false*/
            success: function(result) {
                console.log(JSON.stringify(result));
                this.props.onDisplaySetting('R');
                this.setResponseData(result);
                
            }.bind(this),
            error: function(xhr, status, err) {
            console.log(xhr + " : " + status + " : " + err);
            }.bind(this),
            xhrFields: {
            withCredentials: true
            }
        });
    }

    setResponseData(result){
        console.log("출력 : "+ JSON.stringify(result.response.provider.custmNo));
        this.setState({
            custmNo : result.response.provider.custmNo,
            custmClasCode : result.response.provider.custmClasCode,
            customerClasCode : result.response.provider.customerClasCode,
            coName : result.response.provider.coName,
            ceoName : result.response.provider.ceoName,
            bizno : result.response.provider.bizno,
            coAddr : result.response.provider.coAddr,
            hmpageUrl : result.response.provider.hmpageUrl,
            coEmail : result.response.provider.coEmail,
            coTel : result.response.provider.coTel,
            coFaxNo : result.response.provider.coFaxNo,
            prvdrNo : result.response.provider.prvdrNo,
            bmModelClasCode : result.response.provider.bmModelClasCode,
            bmModelClasName : result.response.provider.bmModelClasName,
            useYn : result.response.provider.useYn,
            prvdrCtrtEndDate : result.response.provider.prvdrCtrtEndDate,
            prvdrCtrtStrDate : result.response.provider.prvdrCtrtStrDate,
            chageUsrList : result.response.chageUsrList,
            acctSetleSvcId : result.response.provider.acctSetleSvcId,
            cardSetleSvcId : result.response.provider.cardSetleSvcId,
            attachFile : result.response.provider.attachFile
        });
    }

	handleProviderSave(attachFile) {
        
        //this.setState({
        //    attachFile : attachFile
        //});

        let memberInfo = JSON.parse(localStorage.getItem("memberInfo"));
        let data ={
            custmNo : this.state.custmNo,
            ceoName : this.state.ceoName,
            coAddr : this.state.coAddr,
            coEmail : this.state.coEmail,
            coTel : this.state.coTel,
            coFaxNo : this.state.coFaxNo,
            prvdrCtrtStrDate : this.state.prvdrCtrtStrDate,
            prvdrCtrtEndDate : this.state.prvdrCtrtEndDate,
            loginUserNo : memberInfo.user_no,
            acctSetleSvcId : this.state.acctSetleSvcId,
            cardSetleSvcId : this.state.cardSetleSvcId,
            attachFile :  attachFile,
            chageUsrList : this.state.chageUsrList
        }; 

        console.log(JSON.stringify(data));

		$.ajax({
			url: REST_API_URL + "/provider/update",
			dataType: 'json',
			type: "post",
			data:  {paramJson : JSON.stringify(data)},
			cache: false,
            processData : true, /*querySTring make false*/
            complete:function(){
                $('#loading').hide();
            },
			success: function(result) {
                console.log(JSON.stringify(result));
                alert('수정 되었습니다.', this.goProvider());
			}.bind(this),
				error: function(xhr, status, err) {
                console.log(xhr + " : " + status + " : " + err);
                this.setState({
                    files : filesTmp
                })
            }.bind(this),
            xhrFields: {
              withCredentials: true
            }
		});
    }
    
    goProvider(){
        location.href="/provider";
    }
        
    validationCheck(temp) {

        if(!this.state.acctSetleSvcId.trim()) {
            alert("결제ID를 입력하세요.");
            return false;
        }

        if(!this.state.cardSetleSvcId.trim()) {
            alert("서비스결제ID를 입력하세요.");
            return false;
        }
        
        if(!this.state.coAddr.trim()) {
            alert("주소를 입력하세요.");
            return false;
        }
        
        if(!this.state.coEmail.trim()) {
            alert("Email을 입력하세요.");
            return false;
        }else {
            if (!validator.isEmail(this.state.coEmail)) {
                alert("이메일 형식이 잘못 입력 되었습니다.");
                return false;
            }
        }
        console.log("계약 기간 체크 "+this.state.prvdrCtrtStrDate);
        if(!this.state.prvdrCtrtStrDate) {
            alert("계약기간을 입력하세요.");
            return false;
        }

        if(!this.state.prvdrCtrtEndDate) {
            alert("계약기간을 입력하세요.");
            return false;
        }

        if(this.state.prvdrCtrtStrDate > this.state.prvdrCtrtEndDate ){
            alert("계약기간이 잘못 입력 되었습니다.");
            return false;
        }

        let { chageUsrList } = this.state;

        if(chageUsrList.length < 1){
            alert('담당자 정보를 입력하세요.');
            return false;
        }

        if(chageUsrList.length < 1){
            alert('담당자 정보를 입력하세요.');
            return false;
        }else{
            if(!this.chargeUsrRpsntYn()){
                alert('대표 담당자 1명을 선택해 주세요.');
                return false;
            }
        }
		return true;
    }

    maxLengthCheck(e){
        e.target.value = e.target.value.replace(/[^0-9]/g,"");
    
        if(e.target.value.length > e.target.maxLength){
          e.target.value = e.target.value.slice(0, e.target.maxLength);
        }
    }

    //  담당자 등록 후 리스트 조회
    handleCreateComplete(response){
        this.setState(response);
    }

    handleDeleteUsr(){

        let chageUsrList = this.state.chageUsrList;
        let removeChageUsrList = [];
        $("input[name='listCheck']:checked").each(function(i) {
            removeChageUsrList.push($(this).val());
        });
        
        for(var i = removeChageUsrList.length-1; i >= 0; i--) {
            if(chageUsrList[removeChageUsrList[i]].chargeUsrSeq > 0) {
                chageUsrList[removeChageUsrList[i]].isDelete='Y';
            } else {
                chageUsrList.splice(removeChageUsrList[i], 1);
            }
        }

        this.setState({
			chageUsrList : chageUsrList
        });

        $("input[name='listCheck']").prop("checked", false);
    }

    handleUpdateUsr(){

        if(!confirm('선택하신 담당자를 대표 담당자로 지정하시겠습니까?')){
            return false;
        }

        if( $('input[name=listCheck]:checked').length > 1) {
            alert("대표 담당자는 1명만 선택할 수 있습니다.");
            return false;
        }

        let index = $("input[name=listCheck]").index($("input[name=listCheck]:checked"));

        if(index < 0) {
            alert("대표 담당자를 선택하세요.");
            return false;
        }

        let chageUsrList = this.state.chageUsrList;

        $.each(chageUsrList, function(i, el){
            if(i == index) {
                el.rpsntYn = "Y";
            } else {
                el.rpsntYn = "N";
            }
        });
        this.setState({
            chageUsrList : chageUsrList
        });

        $("input[name=listCheck]").each(function(){
            $(this).prop('checked',false);
        });
    }

    handleChargeUsrAdd(chargeUsr) {

        console.log(JSON.stringify(" 전달 받은 값 ==> "+chargeUsr));

        let chageUsrList = this.state.chageUsrList;

        if(chargeUsr.rpsntYn == "Y") {
            $.each(chageUsrList, function(i, el){
                if(el.rpsntYn == "Y") {
                    el.rpsntYn = "N";
                }
            });
        }

        chageUsrList.push(chargeUsr);

        this.setState({
            chageUsrList : chageUsrList
        });
        
    }

    //  대표자 지정 여부
    chargeUsrRpsntYn(){
        let {chageUsrList} = this.state;
        let return_boolean = false;
        chageUsrList.map((item, i) => {
            if(item.rpsntYn == 'Y'){
                return_boolean = true;
            }
        });

        return return_boolean;
    }

    render() {

        const {custmNo} = this.state;
        const enabled = custmNo > 0 ;
        const {chageUsrList} = this.state;
        const chargeUsrListEnabled = chageUsrList.length > 0;

        const mapToComponent = (data, thead) => {
            if(data.length > 0) {
              return data.map((provider, i) => {//map
                if(provider.isDelete != 'Y') {
                    return(
                    <tr key={i} className={provider.rpsntYn == "Y" ? 'tc_blue' : ''}>
                        <td className='ui_only_chk'>
                            <span className='input_ico_box'>
                                <input type='checkbox' 
                                    name='listCheck' 
                                    //id={"ip-chk1-"+provider.chargeUsrSeq} 
                                    id={"ip-chk1-"+i} 
                                    value={i} 
                                    defaultChecked={false}
                                />
                                <label htmlFor={"ip-chk1-"+i}/>
                            </span>
                        </td>
                        <td style={thead[1].view ? {} : {display:'none'}}>{provider.chargeUsrName}</td>
                        <td style={thead[2].view ? {} : {display:'none'}}>{provider.chargeUsrDeptName}</td>
                        <td style={thead[3].view ? {} : {display:'none'}}>{provider.chargeUsrPositName}</td>
                        <td style={thead[4].view ? {} : {display:'none'}}>{provider.chargeUsrTel}</td>
                        <td style={thead[5].view ? {} : {display:'none'}}>{provider.chargeUsrMobileNo}</td>
                        <td style={thead[6].view ? {} : {display:'none'}}>{provider.chargeUsrEmail}</td>
                        <td style={thead[7].view ? {} : {display:'none'}}>{provider.chargeUsrClasName}</td>
                    </tr>
                    );
                }
              });
            } else {
              let colspan = thead.length;
              for(var i = 0; i<thead.length; i++) {
                  colspan -= thead[i].view ? 0 : 1;
              }
              return (
                <tr>
                  <td className="noresults" colSpan={colspan}>
                    <div className="box_noresults">
                      <div className="ver_mid">
                        <i className="ico ico_no_result"></i>
                        <span className="lb">{this.props.messages.provider_there_are_no_results}</span>
                      </div>
                    </div>
                  </td>
                </tr>
              );
            }
          }
        return (
            <div id="tab-cont3" className="tab_content tab-cont" style={{display:'block'}}>
                {/* S:content_body */}
                <div className="content_body">
                    {/* S:content_inner */}
                    <div className="content_inner">
                    
                        <div className="box_com">
                            <div className="fl">
                                <h3 className="ctitle">
                                    {this.props.messages.provider_detail_title}
                                </h3>
                            </div>
                            <div className="fr">
                                <div className="desc">
                                    <span className="tc_red">*</span> {this.props.messages.contract_reguired}
                                </div>
                            </div>
                        </div>

                        {/* S:Table */}
                        <table className="tbl_row">
                            <caption>{this.props.messages.provider_detail_title}</caption>
                            <colgroup>
                                <col style={{width:'10%'}}/>
                                <col style={{width:'40%'}}/>
                                <col style={{width:'10%'}}/>
                                <col style={{width:'40%'}}/>
                            </colgroup>
                            <tbody>
                                <tr>
                                    <th scope="row">{this.props.messages.provider_bm} <span className="tc_red">*</span></th>
                                    <td  className="input" colSpan={3}>
                                        {this.state.bmModelClasName}
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">{this.props.messages.provider_name} <span className="tc_red">*</span></th>
                                    <td className="input">
                                        {this.state.coName}
                                    </td>

                                    <th scope="row">{this.props.messages.provider_ceo_name}</th>
                                    <td className="input">
                                        <input type="text" className="ui_input" name="ceoName" value={this.state.ceoName} onChange={this.handleChange} maxLength={100}/>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row" >{this.props.messages.provider_bizno} <span className="tc_red">*</span></th>
                                    <td className="input" colSpan={3}>
                                        {this.state.bizno}
                                    </td>
                                </tr>

                                <tr>
                                    <th scope="row">{this.props.messages.provider_acct_setle_svc_id} <span className="tc_red">*</span></th>
                                    <td className="input">
                                        <input type="text" className="ui_input" name="acctSetleSvcId" value={this.state.acctSetleSvcId }  onChange={this.handleChange} maxLength={50}/>
                                    </td>

                                    <th scope="row">{this.props.messages.provider_card_setle_svc_id} <span className="tc_red">*</span></th>
                                    <td className="input">
                                        <input type="text" className="ui_input" name="cardSetleSvcId" value={this.state.cardSetleSvcId } onChange={this.handleChange} maxLength={50}/>
                                    </td>
                                </tr>
                                
                                <tr>
                                    <th scope="row" >{this.props.messages.provider_addr} <span className="tc_red">*</span></th>
                                    <td className="input" colSpan={3}>
                                        <input type="text" className="ui_input" name="coAddr" value={this.state.coAddr}  onChange={this.handleChange} maxLength={500}/>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row" >{this.props.messages.provider_weburl}</th>
                                    <td className="input" colSpan={3}>
                                        {this.state.hmpageUrl}
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row" >{this.props.messages.provider_email} <span className="tc_red">*</span></th>
                                    <td className="input" colSpan={3}>
                                        <input type="text" className="ui_input" name="coEmail" value={this.state.coEmail}  onChange={this.handleChange} maxLength={50}/>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">{this.props.messages.provider_tel}</th>
                                    <td className="input">
                                        <input type="text" className="ui_input" name="coTel" value={this.state.coTel}  onChange={this.handleChange} onInput={this.maxLengthCheck.bind(this)}
                                        maxLength={20}/>
                                    </td>

                                    <th scope="row">{this.props.messages.provider_fax}</th>
                                    <td className="input">
                                        <input type="text" className="ui_input" name="coFaxNo" value={this.state.coFaxNo} onChange={this.handleChange} onInput={this.maxLengthCheck.bind(this)}
                                        maxLength={20}/>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">{this.props.messages.provider_contract_date} <span className="tc_red">*</span></th>
                                    <td className="input">
                                        {/* s: 캘린더폼 */}
                                        <div className="date_box">
                                            <Calendar 
                                                name="prvdrCtrtStrDate"
                                                className="ui_cal" 
                                                selected={this.state.prvdrCtrtStrDate}
                                                onChange={(data) => this.setState({prvdrCtrtStrDate : data})}
                                            />
                                        </div>
                                        {/* e: 캘린더폼 */}
                                         ~
                                        {/* s: 캘린더폼 */}
                                        <div className="date_box">
                                            <Calendar className="ui_cal" 
                                                name="prvdrCtrtEndDate"
                                                selected={this.state.prvdrCtrtEndDate}
                                                onChange={(data) => this.setState({prvdrCtrtEndDate : data})}
                                            />
                                        </div>
                                        {/* e: 캘린더폼 */}
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">{this.props.messages.contract_attached}</th>
                                    <td className="input" colSpan={3}>
                                        <AttachFile onRef={ref => (this.attachFile = ref)} 
                                            files={this.state.attachFile} 
                                            onChange={this.handleFileChange}
                                            setFileExtension={['.jpg', '.pdf', '.jpeg']} 
                                            setFileMaxSize={20} 
                                            onUploadResult={this.handleProviderSave}
                                            isFileSearch={true}
                                            setLimitCnt={3}
                                        />
                                        <span style={{color:"red"}}>{this.props.messages.provider_file_desc}</span>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                        {/* E:Table */}

                        <div className="box_com">
                            <div className="fl">
                                <h3 className="ctitle">{this.props.messages.provider_charge_usr_info}</h3>
                            </div>
                            <div className="fr">
                                <button type="button" className="btn_pos"
                                    onClick={this.handleUpdateUsr}
                                    disabled={!chargeUsrListEnabled} >{this.props.messages.provider_charge_usr_rpsnt_yn}
                                </button>
                                <button type="button" className="btn_pos" 
                                    disabled={!chargeUsrListEnabled} 
                                    onClick={this.handleDeleteUsr}>{this.props.messages.provider_charge_usr_delete}
                                </button>
                                <button type="button" className="btn_pos" 
                                    disabled={!enabled}
                                    onClick={() => {this.chargeUsrCreate.show()}}>{this.props.messages.provider_charge_usr_save}
                                </button>
                            </div>
                        </div>
                        <table className="tbl_col">
                            <caption>{this.props.messages.customer_bnof_info}</caption>
                            <TableColgroup listThead={this.state.listThead} />
                            <TableThead listThead={this.state.listThead}/>
                            <tbody id="contractTbody">
                                {mapToComponent(this.state.chageUsrList, this.state.listThead)}
                            </tbody>
                        </table>
                    </div>
                    {/* E:content_inner */}
                    
                </div>
                {/* E:content_body */}
                <ChargeUsrCreate 
                    onRef={ref => (this.chargeUsrCreate = ref)} 
                    onProviderUsrComplete={this.handleCreateComplete}
                    custmNo={this.state.custmNo}
                    onChargeUsrAdd={this.handleChargeUsrAdd}
                    rpsntYn ={this.state.chageUsrList.length > 0? false:true}
                    
                />
            </div>
        );
    }
}

export default connect(mapStateToProps)(ProviderDetail);