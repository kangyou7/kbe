import React from 'react';

import { Link } from 'react-router';
import { browserHistory } from 'react-router';

import PagingView from '../common/PagingView';
import ColumnChange from '../common/ColumnChange';
import {TableThead, TableColgroup} from '../common/TableThead';
//import TableThead from '../common/TableThead';

import {REST_API_URL} from '../../config/api-config.js';

/*다국어 모듈 시작*/
import { connect } from 'react-redux';
import { changeLangauge, mapStateToProps } from '../../language/Actions';
/*다국어 모듈 종료*/


class MtnceEntpList extends React.Component {

  constructor(props) {
    super(props);

    this.state = {
      searchKeyCode : "",
      searchKeyWord : "",
      checkedIndex : "",
      checkedAssetsSeq : "",
      checkedAssetsStatus : "",
      listThead : [
        
        {name:"checkbox",  sort:false, view:true, target:false, checkbox:true, width:'2%'},
        {name:"NO",        sort:false, sortColumn:"rownum", view:true, target:false, width:'3%'},
        {name:"업체명",  sort:false, sortColumn:"maintCoName", view:true, target:true, width:'15%'},
        {name:"담당 장비벤더",     sort:false, sortColumn:"equipVendorName", view:true, target:true, width:'15%'},
        {name:"담당자",   sort:true, sortColumn:"chargeUsrName", view:true, target:true, width:'15%'},
        {name:"휴대폰 번호",     sort:true, sortColumn:"chargeUsrMobileNo", view:true, target:true, width:'15%'},
        {name:"이메일",     sort:true, sortColumn:"chargeUsrEmail", view:true, target:true, width:'15%'},
        {name:"등록일",   sort:true, sortColumn:"regDate", view:true, target:true, width:'16%'}
      ],
      list : [],
      pageInfo:{
        //totalCount : 0,
        //perPageNum : 0,
        //page : 0
      }

    }

    this.handleChange = this.handleChange.bind(this);
    this.handleSearch = this.handleSearch.bind(this);
    this.handlePageChange = this.handlePageChange.bind(this);

    this.handleColumnChangeView = this.handleColumnChangeView.bind(this);
    this.handleColumnChange = this.handleColumnChange.bind(this);
    this.handleDetailView = this.handleDetailView.bind(this);
    this.handleSort = this.handleSort.bind(this);
    this.handleDelete = this.handleDelete.bind(this);
    this.handleCheckBoxClick = this.handleCheckBoxClick.bind(this);
  }

  handleChange(e) {
    let nextState = {};
    nextState[e.target.name]=e.target.value;
    this.setState(nextState);
  }

  getList() {
    
    $.ajax({
      url: REST_API_URL+"/assets/MtnceEntpList",
      dataType: 'json',
      type: "post",
      data: this.state.pageInfo,
      xhrFields : {
        withCredentials : true
      },
      success: function(result) {

        this.setState({
          list: result.response.list,
          pageInfo : result.response.pageInfo
        });

        $("#listChkAll").prop("checked",false);
        $("input[name='listCheck']").prop("checked",false);
        
      }.bind(this),
      error: function(xhr, status, err) {
        console.log(xhr + " : " + status + " : " + err);
      }.bind(this)
    });
  }

  getExcelDownload() {
    var form = "<form action='" + REST_API_URL + "/assets/MtnceEntpExcelDownload' method='post'>"; 
    form += "<input type='hidden' name='sortColumn' value='"+this.state.pageInfo.sortColumn+"' />"; 
    form += "<input type='hidden' name='sortType' value='"+this.state.pageInfo.sortType+"' />"; 
    form += "<input type='hidden' name='searchKeyCode' value='"+this.state.pageInfo.searchKeyCode+"' />"; 
    form += "<input type='hidden' name='searchKeyWord' value='"+this.state.pageInfo.searchKeyWord+"' />"; 
    form += "</form>"; 
    jQuery(form).appendTo("body").submit().remove(); 
  }

  handleSearch() {
    let pageInfo = this.state.pageInfo;
    pageInfo.searchKeyCode = this.state.searchKeyCode;
    pageInfo.searchKeyWord = this.state.searchKeyWord;
    this.setState({
      pageInfo : pageInfo
    })
    this.getList();
  }



  //페이지 변경 및 페이지 출력 갯수 변경
  handlePageChange(perPageNum, page) {

    let changePage = this.state.pageInfo;
    changePage.perPageNum = perPageNum;
    changePage.page = page;
    this.setState({
      pageInfo:changePage
    })


    this.getList();

  }

  handleSort(sort) {
    let sortPage = this.state.pageInfo;
    sortPage.sortColumn = sort.sortColumn;
    sortPage.sortType = sort.sortType;
    this.setState({
        pageInfo:sortPage
    })

    this.getList();
}


  //항목변경 팝업 호출
  handleColumnChangeView(e) {
    this.columnChange.show();
 }

 //항목변경 팝업에서 항목 변경 후 state 정보 변경
 handleColumnChange(changeThead) {
   this.setState({
     listThead : changeThead
   });
 }

 handleDetailView(index) {
   this.props.onDetailView(this.state.list[index].maintCoNo);
 }
 
 //선택항목 삭제
 handleDelete() {
   var reqParam;
   var checkedEntps = "";

   $("input[name='listCheck']").each(function() {
     if ( $(this).is(":checked") ) {

      if (checkedEntps != "") {
        checkedEntps += "|" + $(this).val();
      } else {
        checkedEntps = $(this).val();
      }
     }
   });

   if (checkedEntps == "") {
     alert("삭제할 대상을 선택하시기 바랍니다.");
   } else {
     if (confirm("삭제하시겠습니까?")) {
      reqParam = new Object();
      reqParam.maintCoNo = checkedEntps;
      $.ajax({
        url: REST_API_URL+"/assets/MtnceEntpDelete",
        dataType: 'json',
        type: "post",
        data: reqParam,
        xhrFields : {
          withCredentials : true
        },
        success: function(result) {
          if ( result.response == "SUCCESS" ) {
            alert("삭제 되었습니다.");
            this.getList();
            return;
          } else {
            alert("ERROR..! 관리자에게 문의 바랍니다.");
            return;
          }
          
        }.bind(this),
        error: function(xhr, status, err) {
          console.log(xhr + " : " + status + " : " + err);
        }.bind(this)
        });
     }
   }
 }

 handleCheckBoxClick(e) {
  this.setState({
    checkedAssetsSeq : $(e.target).val(),
    checkedIndex : $(e.target).attr("id")
  });
}

  //페이지 로딩 시 목록 조회
  componentDidMount() {
    this.props.onRef(this)
    this.getList();
  }

	componentWillUnmount() {
		this.props.onRef(null)
	}

  render() {
    const fncBtnInfo = this.props.memberInfo.dspUserFncBtnInfo;
      const mapToComponent = (data, thead) => {
        if(data.length > 0) {
          return data.map((enterprise, i) => {//map
            return(<tr key={i}>
              
              <td className="ui_only_chk">
                  <span className="input_ico_box">
                    <input type="checkbox" name="listCheck" id={i} value={enterprise.maintCoNo} onClick={this.handleCheckBoxClick}/>
                    <label htmlFor={i}></label>
                  </span>
							</td>

              <td style={thead[1].view ? {} : {display:'none'}}>{enterprise.rownum}</td>
              <td style={thead[2].view ? {} : {display:'none'}}><a href="javascript:;" onClick={() => {this.handleDetailView(i);}}>{enterprise.maintCoName}</a></td>
              <td style={thead[3].view ? {} : {display:'none'}}>{enterprise.equipVendorName}</td>
              <td style={thead[4].view ? {} : {display:'none'}}>{enterprise.chargeUsrName}</td>
              <td style={thead[5].view ? {} : {display:'none'}}>{enterprise.chargeUsrMobileNo}</td>
              <td style={thead[6].view ? {} : {display:'none'}}>{enterprise.chargeUsrEmail}</td>
              <td style={thead[7].view ? {} : {display:'none'}}>{enterprise.regDate}</td>
            </tr>);
          });
        } else {
          return (
            <tr>
              <td className="noresults" colSpan={8}>
                <div className="box_noresults">
                  <div className="ver_mid">
                    <i className="ico ico_no_result"></i>
                    <span className="lb">{this.props.messages.common_no_data}</span>
                  </div>
                </div>
              </td>
            </tr>
          );
        }
      }

      return (
          <div id="tab-cont1" className="tab_content tab-cont" >

            <div className="content_body">

              <div className="content_inner">


                <div className="box_com term_wrap">
                  
                    <span className="input_search_box">
                    <input type="text" className="ui_input" name="searchKeyWord" value={this.state.searchKeyWord} onChange={this.handleChange}/>
                    <a id="searchAssets" className="btn_search" href="javascript:void(0);"
                    onClick={this.handleSearch}><span className="offscreen">검색</span></a>
                    </span>

                    <div className="fr">
                    <button disabled={fncBtnInfo['funcDelYn']=='N'} type="button" className="btn_pos" id="btnDelete" onClick={this.handleDelete}>{this.props.messages.assets_delete}</button>
                    <Link to="/mtnceEntpCreate" className="gnb_link"><button disabled={fncBtnInfo['funcRegYn']=='N'} type="button" className="btn_black">{this.props.messages.mtnce_register_maintenance_company}</button></Link>
                    </div>
                </div>


                <table className="tbl_col">
                  <caption>유지보수 업체 현황 목록</caption>
                  <TableColgroup listThead={this.props.listThead} />
                  <TableThead listThead={this.props.listThead} onSort={this.handleSort}/>

                  <tbody id="contractTbody">

                    {mapToComponent(this.state.list, this.props.listThead)}


                  </tbody>
                </table>

              </div>

            </div>

            <PagingView pageInfo={this.state.pageInfo} onPageChange={this.handlePageChange}/>

            <ColumnChange onRef={ref => (this.columnChange = ref)} listThead={this.props.listThead} onColumnChange={this.handleColumnChange} />
            
          </div>

      );
    }
}

export default connect(mapStateToProps)(MtnceEntpList);
