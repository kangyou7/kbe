import React, { Component } from 'react';

class Paging extends Component {
  constructor(props) {
    super(props);

    this.state = {
      pageInfo : {
        perPageNum : 30,
        page : 1,
        totalCount : 0,
        startNum : 0,
        searchKeyCode : 0,
        searchKeyWord : "",
      },
    };


    this.handlePageChange = this.handlePageChange.bind(this);
    this.handleChange = this.handleChange.bind(this);
    this.handleKeyPress = this.handleKeyPress.bind(this);
  }

  setPage(page) {
    if(page < 1) {
      return;
    }

    if(this.state.pageInfo.totalCount === 0 || page > ( Math.ceil(this.state.pageInfo.perPageNum / this.state.pageInfo.totalCount) ) ) {
      return;
    }


    this.getPage(page);
    this.props.onPageChange(this.props.pageInfo.perPageNum, page);
  }

  getPage(page) {
    let currentPage = Number(page || 1);
    const perPageNum = this.props.pageInfo.perPageNum;

    const totalPages = Math.ceil(this.props.pageInfo.totalCount / perPageNum);
    if(totalPages === 0) {
      currentPage = 0;
    }

    this.setState({
      pageInfo :{
        perPageNum : perPageNum,
        page:currentPage
      }
    });
  }

  handlePageChange(e) {
    this.setState({
      pageInfo :{
        perPageNum : Number(e.target.value),
      }
    });

    this.props.onPageChange(e.target.value, 1);
  }

  handleChange(e) {
    if(e.target.name == "page") {
      e.target.value = e.target.value.replace(/[^0-9]/g,"");
    }

    this.setState({
      pageInfo : {
        page : Number(e.target.value),
      }
    });
  }

  handleKeyPress(e) {
    const totalPages = Math.ceil(this.props.totalCount / perPageNum);
    const page =this.state.pageInfo.page;
    if(e.charCode===13) {
      if(totalPages >= Number(e.target.value)) {
        this.getPage(page);
        this.setPage(page);
      }
    }
  }

  componentDidUpdate(prevProps, prevState) {

    if (this.props.pageInfo.totalCount !== prevProps.pageInfo.totalCount ||
        this.props.pageInfo.perPageNum !== prevProps.pageInfo.perPageNum) {
        this.getPage(this.props.pageInfo.page);
    }
  }

  componentWillReceiveProps(nextProps) {
    this.getPage(nextProps.pageInfo.page);
  }


  render() {

    const totalPages = Math.ceil(this.state.pageInfo.totalCount / this.state.pageInfo.perPageNum);
    const page = this.state.pageInfo.page;
    const totalCount = this.state.pageInfo.perPageNum;

    return(
      <div className="content_bottom">
        <div className="bottom_inner">
          {/*<select className="ui-sel sel_white" name="perPage" onChange={this.handlePerPageChange}>*/}
          <select className="ui_sel" name="perPageNum" onChange={this.handlePageChange}>
            <option value="30">30 rows per page</option>
            <option value="50">50 rows per page</option>
            <option value="100">100 rows per page</option>
          </select>
          <span className="gap"></span>
          <div className="page_wrap">
            <button 
              type="button" 
              className="first" 
              disabled={page <= 1 ? 'disabled' : ''} 
              onClick={() => this.setPage(1)}
            >
              <span className="offscreen">첫페이지</span>
            </button>
            <button type="button" className="prev" disabled={page <= 1 ? 'disabled' : ''} onClick={() => this.setPage(page - 1)}>
              <span className="offscreen">이전페이지</span>
            </button>
            <input type="text" className="ui_input" style={{width:"50px"}} name="page" value={page} ref="page" onKeyPress={this.handleKeyPress} onChange={this.handleChange}/>
            <span className="num_wrap">
              of&nbsp;&nbsp;
              <span>{ isNaN(totalPages) ? 0 : totalPages}</span>
            </span>
            <button type="button" className="next" disabled={page >= totalPages? 'disabled' : ''} onClick={() => this.setPage(page + 1)}><span className="offscreen">다음페이지</span></button>
            <button type="button" className="last" disabled={page >= totalPages ? 'disabled' : ''} onClick={() => this.setPage(totalPages)}><span className="offscreen">마지막페이지</span></button>
          </div>

          <strong className="total_val">전체 
          &nbsp;&nbsp;
          {this.props.pageInfo === 'undefined' ? " 0" : (totalCount+"").replace(/\B(?=(\d{3})+(?!\d))/g, ",")}

          </strong>
        </div>
      </div>

    );
  }
}

export default Paging;
