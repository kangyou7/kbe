/*
    global actions
*/
const CHANGE_LANG = 'CHANGE_LANG';
const LOG_IN = 'LOG_IN';

export function changeLangauge(lang) {
    return {
        type : CHANGE_LANG,
        lang
    };
}

export function actionlogin(memberInfo) {
    return {
        type : LOG_IN,
        memberInfo,
    };
}

export let mapStateToProps = (state) => {
    return {
		messages : state.changeLang.messages,
        locale : state.changeLang.language,
        memberInfo : state.loginAction.memberInfo,
    };
}
