import React from 'react';

import {REST_API_URL} from '../../config/api-config.js';

/*다국어 모듈 시작*/
import { connect } from 'react-redux';
import { changeLangauge, mapStateToProps } from '../../language/Actions';
/*다국어 모듈 종료*/

const initialState = {
    searchName:"",
    assetTypeList:[],
    assetTypeSelect:[],
    assetTypeModelList:[],
    asset:[],
    totalSum : 0
};

class AssetSetting extends React.Component {
    constructor(props) {
        super(props);

        this.state = $.extend(true, {}, initialState);

        this.handleChange = this.handleChange.bind(this);
        this.assetAdd = this.assetAdd.bind(this);
        this.assetRemove = this.assetRemove.bind(this);
    }

    handleOnlyNumber(smallPoint, e) {

        if(smallPoint > 0 ) {
            //let regexp = /^\d*(\.\d{0,2})?$/;
            let regexp = new RegExp("^\\d*(\\.\\d{0," + smallPoint + "})?$");
            if(e.target.value.search(regexp) == -1) {
                e.target.value=e.target.value.substring(0, e.target.value.length -1);
            } else  {
                e.target.value=e.target.value;
            }
        } else {
            e.target.value = e.target.value.replace(/[^0-9]/g,"")
        }
    }

    handleChange(e) {
        let nextState = {};
        nextState[e.target.name]=e.target.value;
        this.setState(nextState);
    }

    //컴포넌트가 만들어지고 첫 렌더링을 다 마친 후 실행되는 메소드입니다.
	componentDidMount() {
        this.props.onRef(this);
        this.getInitData();
	}

	//컴포넌트가 DOM 에서 사라진 후 실행되는 메소드입니다.
	componentWillUnmount() {	
        this.props.onRef(null);
	}
	

    componentWillReceiveProps(nextProps){
        if(nextProps.serviceData !== undefined) {
            this.setState({
                asset : nextProps.serviceData
            });

            this.assetSumPrice();
        }
    }

    assetTypeClick(idx) {
        let assetTypeSelect = this.state.assetTypeSelect;
        

        if(idx < 0) {
            let allAssetTypeSelect = [];
            if(assetTypeSelect.length === this.state.assetTypeList.length) {
                $("#assetTypeAllRow").removeClass();
                $("#assetTypeAll").prop("checked", false);

                this.setState({
                    assetTypeSelect : allAssetTypeSelect,
                    assetTypeModelList : []
                });
                return;
            } else {
                $("#assetTypeAllRow").addClass('selected');
                $("#assetTypeAll").prop("checked", true);

                $.each(this.state.assetTypeList, function(i, el){
                    allAssetTypeSelect.push(el.commCode);
                });
            }
            this.state.assetTypeSelect = allAssetTypeSelect;
            
        } else {
            $("#assetTypeAllRow").removeClass();
            $("#assetTypeAll").prop("checked", false);
            let searchIndex = assetTypeSelect.indexOf(this.state.assetTypeList[idx].commCode)
            if( searchIndex === -1) {
                assetTypeSelect.push(this.state.assetTypeList[idx].commCode);
            } else {
                assetTypeSelect.splice(searchIndex, 1);
            }
        }
        this.getAssetTypeModel();
    }

    getAssetTypeModel() {
        
        $.ajax({
			url: REST_API_URL + "/product/getAssetTypeModel",
			dataType: 'json',
            type: "post",
            data: {paramJson : JSON.stringify(this.state.assetTypeSelect)},
            cache: false,
			success: function(result) {
				this.setState({
                    assetTypeModelList:result.response.assetTypeModelList
                });
			}.bind(this),
				error: function(xhr, status, err) {
				console.log(xhr + " : " + status + " : " + err);
			}.bind(this),
			xhrFields: {
			  withCredentials: true
			}
        });
    }

    modelSearch() {
        $.ajax({
			url: REST_API_URL + "/product/getModelSearch",
			dataType: 'json',
            type: "post",
            data: {modelName : this.state.searchName},
            cache: false,
			success: function(result) {
                let assetTypeModelList = result.response.assetTypeModelList;
                let assetTypeSelect = [];
                $.each(assetTypeModelList, (i, el) => {
                    if(assetTypeSelect.indexOf(el.commCode) === -1) {
                        assetTypeSelect.push(el.commCode)
                    }
                });

                this.setState({
                    assetTypeSelect : assetTypeSelect,
                    assetTypeModelList:assetTypeModelList
                });
			}.bind(this),
				error: function(xhr, status, err) {
				console.log(xhr + " : " + status + " : " + err);
			}.bind(this),
			xhrFields: {
			  withCredentials: true
			}
        });
    }

    assetTypeModelAllChecked(obj) {
        $("input[name='assetTypeModel']").prop("checked", $(obj.target).is(":checked"));
    }

    assetAllChecked(obj) {
        $("input[name='asset']").prop("checked", $(obj.target).is(":checked"));
    }

    assetAdd() {
        let asset = this.state.asset;
        let assetTypeModelList = this.state.assetTypeModelList;
        $("input[name='assetTypeModel']:checked").each(function(i) {

            let check = false;
            let selectAsset = assetTypeModelList[$(this).val()];
            $.each(asset, function(i, el){
                if(el.equipModelNo === selectAsset.equipModelNo) {
                    check = true;
                }
            });

            if(!check) {
                asset.push(selectAsset);
            }
        });

        this.setState({
            asset : asset
        });

        this.props.onServiceChange('asset', this.state.asset);
    }

    assetRemove() {
        let asset = this.state.asset;
        let assetRemove = [];
        
        $("input[name='asset']:checked").each(function(i) {
            assetRemove.push(Number($(this).val()));
        });

        assetRemove.sort(function(a, b) {// 내림차순
            return b - a;
        });

        $.each(assetRemove, (i, el) => {
            asset.splice(el, 1);
        });
        
        this.setState({
            asset : asset
        });

        this.props.onServiceChange('asset', this.state.asset);
    }


    handleAsetPriceChange(index, event) {
        if(event.target.name === 'asset.productBasFee' || event.target.name === 'asset.productQty') {
            let asset = this.state.asset.slice();
            if(event.target.name === 'asset.productBasFee') {
                asset[index].productBasFee = event.target.value;
            } else if(event.target.name === 'asset.productQty') {
                asset[index].productQty = event.target.value;
            }
            this.setState({
                asset : asset
            });

            this.assetSumPrice();
            
            this.props.onServiceChange('asset', this.state.asset);
        }
    }

    quantityChange(type, index) {
        let asset = this.state.asset.slice();
        if(type === 'add') {
            if(((Number(asset[index].productQty) + 1) + "").length > 4) { 
                return;
            }
            asset[index].productQty = Number(asset[index].productQty) + 1;
        } else {
            asset[index].productQty = (Number(asset[index].productQty) - 1) < 0 ? 0 : Number(asset[index].productQty) - 1 ;
        }

        this.setState({
            asset : asset
        });

        this.assetSumPrice();

        this.props.onServiceChange('asset', this.state.asset);
    }

    assetSumPrice() {
        let asset = this.state.asset.slice();
        //let totalSum = this.state.totalSum;
        let totalSum = 0;

        $.each(asset, (i, el) => {
            el.productSubtotAmt = el.productBasFee * el.productQty;
            totalSum += el.productSubtotAmt;
        });

        this.setState({
            //asset : asset,
            totalSum : totalSum
        });

        
    }

    getInitData() {
        $.ajax({
			url: REST_API_URL + "/code/getAssetType",
			dataType: 'json',
			type: "post",
			cache: false,
			success: function(result) {
				this.setState({
                    assetTypeList:result.response.assetTypeList
                });
			}.bind(this),
				error: function(xhr, status, err) {
				console.log(xhr + " : " + status + " : " + err);
			}.bind(this),
			xhrFields: {
			  withCredentials: true
			}
        });
    }

    handleInitState() {
        this.setState($.extend(true, {}, initialState));
		this.getInitData();
    }

    render() {

        const mapToAssetTypeList = (data, assetTypeSelect) => {
            if(data != null) {
                return data.map((item, i) => {
                    return(
                        <tr key={i} className={assetTypeSelect.indexOf(item.commCode) === -1 ? '' : 'selected'} onClick={() => this.assetTypeClick(i)}>
                            <td className="ui_only_chk">
                                <span className="input_ico_box white">
                                    <input type="checkbox" name="chk_box4" id={'assetType_' + i} value="" checked={assetTypeSelect.indexOf(item.commCode) === -1 ? '' : 'checked'}/>
                                    <label htmlFor={'assetType_' + i}></label>
                                </span>
                            </td>
                            <td>{item.commCodeName}</td>
                        </tr>
                    );
                });
            }
        }

        const mapToAssetTypeModelList = (data) => {
            if(data != null) {
                return data.map((item, i) => {
                    return(
                        <tr key={i}>
                            <td className="ui_only_chk">
                                <span className="input_ico_box white">
                                    <input type="checkbox" name="assetTypeModel" id={'assetTypeModel_' + i} value={i} defaultChecked={false}/>
                                    <label htmlFor={'assetTypeModel_' + i}></label>
                                </span>
                            </td>
                            <td>{item.commCodeName}</td>
                            <td>{item.equipVendorName}</td>
                            <td>{item.equipModelName}</td>
                            <td>{item.stockCount}</td>
                        </tr>
                    );
                });
            }
        }

        const mapToAssetList = (data) => {
            
            if(data != null) {
                return data.map((item, i) => {
                    return(
                        <tr key={i}>
                            <td className="ui_only_chk">
                                <span className="input_ico_box white">
                                <input type="checkbox" name="asset" id={'asset_' + i} value={i} defaultChecked={false}/>
                                    <label htmlFor={'asset_' + i}></label>
                                </span>
                            </td>
                            <td>{item.commCodeName}</td>
                            <td>{item.equipVendorName}</td>
                            <td>{item.equipModelName}</td>
                            <td className="input">
                                <input type="text" className="ui_input w_100" name="asset.productBasFee" value={item.productBasFee == null ? '' : item.productBasFee} onChange={this.handleAsetPriceChange.bind(this, i)} maxLength={10} onInput={this.handleOnlyNumber.bind(this, 0)}/>
                            </td>
                            <td className="input">
                                <div className="number_counter number-counter">
                                <span className="ui-spinner ui-widget ui-widget-content ui-corner-all ui-spinner-horizontal">
                                    <a className="decrease ui-spinner-button ui-spinner-down ui-corner-left ui-button ui-widget" onClick={() => this.quantityChange('del', i)}></a>
                                    <input type="text" className="ip_spinner ip-spinner ui-spinner-input" name="asset.productQty" style={{width:'40px'}} value={item.productQty == null ? 0 : item.productQty} onChange={this.handleAsetPriceChange.bind(this, i)} maxLength={4} onInput={this.handleOnlyNumber.bind(this, 0)}/>
                                    <a className="increase ui-spinner-button ui-spinner-up ui-corner-right ui-button ui-widget" onClick={() => this.quantityChange('add', i)}></a>
                                </span>
                                </div>
                                {/*
                                <button onClick={() => this.quantityChange('add', i)}>+</button>
                                <input type="text" className="ui_input" name="asset.quantity" value={item.quantity} onChange={this.handleAsetPriceChange.bind(this, i)} />
                                <button onClick={() => this.quantityChange('del', i)}>-</button>
                                */}
                            </td>
                            <td>{item.stockCount}</td>
                            <td className="ar">{item.productSubtotAmt} {this.props.messages.product_won}</td>
                        </tr>
                    );
                });
            }
        }
        
        

        return (

            <div>
                <div className="box_com">
                    <div className="fl">
                        <input type="text" className="ui_input w_lg" placeholder={this.props.messages.product_model_name} name="searchName" value={this.state.searchName} onChange={this.handleChange}/>
                        <a href="javascript:;" className="btn_pos" onClick={() => this.modelSearch()}>{this.props.messages.contract_search_2}</a>
                    </div>
                    <div className="fr">
                        <div className="desc fl_ipcon">
                            <div className="tc_gray">{this.props.messages.product_total} : <span className="tc_blue">{this.state.totalSum}</span> {this.props.messages.product_won}</div>
                        </div>
                    </div>
                </div>
                
                <div className="insert_cont_wrap device_setting">
                    <div className="left_wrap box_cont">
                        <div className="filter_list scroll_wrap">
                            <table className="tbl_col">
                                <caption>장비 목록</caption>
                                <colgroup>
                                    <col style={{width:'15%'}}/>
                                    <col style={{width:'85%'}}/>
                                </colgroup>
                                
                                <thead>
                                    <tr>
                                        {/*<th scope="col" className="ui_only_chk">
                                            <span className="input_ico_box white">
                                                <input type="checkbox" name="chk_box4" id="ip-chk4-all" />
                                                <label htmlFor="ip-chk4-all"></label>
                                            </span>
                                        </th>*/}
                                        <th scope="col" colSpan={2}>{this.props.messages.product_asset_type}</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr id="assetTypeAllRow">
                                        <td className="ui_only_chk">
                                            <span className="input_ico_box white">
                                                <input type="checkbox" name="chk_box4" id="assetTypeAll" />
                                                <label htmlFor="assetTypeAll"></label>
                                            </span>
                                        </td>
                                        <td onClick={() => this.assetTypeClick(-1)}>All</td>
                                    </tr>
                                    {mapToAssetTypeList(this.state.assetTypeList, this.state.assetTypeSelect)}
                                </tbody>

                            </table>
                        </div>
                        <div className="filter_result_list scroll_wrap">
                            <table className="tbl_col">
                                <caption>장비상세 목록</caption>
                                <colgroup>
                                    <col style={{width:'10%'}}/>
                                    <col style={{width:'22.5%'}}/>
                                    <col style={{width:'22.5%'}}/>
                                    <col style={{width:'22.5%'}}/>
                                    <col style={{width:'22.5%'}}/>
                                </colgroup>
                                
                                <thead>
                                    <th scope="col" className="ui_only_chk">
                                        <span className="input_ico_box white">
                                        <input type="checkbox" name="all" id="assetTypeModelAll" defaultChecked={false} onClick={this.assetTypeModelAllChecked}/>
                                        <label htmlFor="assetTypeModelAll">ALL</label>
                                        </span>
                                    </th>
                                    <th scope="col">{this.props.messages.product_asset_type}</th>
                                    <th scope="col">{this.props.messages.product_manufacturer}</th>
                                    <th scope="col">{this.props.messages.product_model_name}</th>
                                    <th scope="col">{this.props.messages.product_inventory}</th>
                                </thead>
                                <tbody>
                                    {mapToAssetTypeModelList(this.state.assetTypeModelList)}
                                </tbody>
                            </table>
                        </div>
                    </div>


                    <div className="btn_wrap">
                        <ul>
                            <li><a href="javascript:;" className="btn_black" onClick={this.assetAdd}>{this.props.messages.product_add}<i className="ico_btn_rright"></i></a></li>
                            <li><a href="javascript:;" className="btn_pos" onClick={this.assetRemove}>{this.props.messages.product_delete}<i className="ico_btn_del"></i></a></li>
                        </ul>
                    </div>

                    <div className="right_wrap box_cont">
                        <div className="insert_result_list scroll_wrap">
                            <table className="tbl_col">
                                <caption>장비단가 목록</caption>
                                <colgroup>
                                    <col style={{width:'8%'}}/>
                                    <col style={{width:'13%'}}/>
                                    <col style={{width:'13%'}}/>
                                    <col style={{width:'13%'}}/>
                                    <col style={{width:'119px'}}/>
                                    <col style={{width:'119px'}}/>
                                    <col style={{width:'auto'}}/>
                                    <col style={{width:'13%'}}/>
                                </colgroup>
                                
                                <thead>
                                    <tr>
                                        <th scope="col" className="ui_only_chk">
                                            <span className="input_ico_box white">
                                                <input type="checkbox" name="all" id="assetAll" defaultChecked={false} onClick={this.assetAllChecked}/>
                                                <label htmlFor="assetAll">ALL</label>
                                            </span>
                                        </th>
                                        <th scope="col">{this.props.messages.product_asset_type}</th>
                                        <th scope="col">{this.props.messages.product_manufacturer}</th>
                                        <th scope="col">{this.props.messages.product_model_name}</th>
                                        <th scope="col">{this.props.messages.product_unit_price} <span className="tc_red">*</span></th>
                                        <th scope="col">{this.props.messages.product_quantity}</th>
                                        <th scope="col">{this.props.messages.product_inventory}</th>
                                        <th scope="col">{this.props.messages.product_sub_total}</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {mapToAssetList(this.state.asset)}
                                </tbody>
                            </table>
                        </div>
                    </div>

                </div>


                
            </div>

        );
    }
}

export default connect(mapStateToProps)(AssetSetting);