import React from 'react';

import { browserHistory } from 'react-router';

import ApprovalLineSetting from '../common/ApprovalLineSetting';

import Calendar from '../common/Calendar';
import CodeSelect from '../common/CodeSelect';
import AttachFile from '../common/AttachFile';

import {REST_API_URL} from '../../config/api-config.js';

import axios from 'axios';

/*다국어 모듈 시작*/
import { connect } from 'react-redux';
import { changeLangauge, mapStateToProps } from '../../language/Actions';
/*다국어 모듈 종료*/


class MonitoringNoticeDetail extends React.Component {

	constructor(props) {
		super(props);

		this.state = {
			noticeNo : "",
			noticeTitle : "",
			noticeRegUsrName : "",
			noticeRegUsrDept : "",
			noticeStrDate : "",
			attachFileId : "",
			files: []
		}

		this.handleInitState = this.handleInitState.bind(this);
		
	}

	handleInitState() {
		
		this.setState({
			noticeNo : "",
			noticeTitle : "",
			noticeRegUsrName : "",
			noticeRegUsrDept : "",
			noticeStrDate : "",
			attachFileId : "",
			files: []
		});
	}


	handleSave() {

		location.href="/monitoringNotice";
		
	}

	getNotice(noticeNo) {
        $.ajax({
            url: REST_API_URL+"/notice/Detail",
            dataType: 'json',
            type: "post",
            data: {
                noticeNo:noticeNo
			},
			xhrFields : {
				withCredentials : true
			},
            success: function(result) {
				this.handleInitState();
                this.setState(result.response);
            }.bind(this),
                error: function(xhr, status, err) {
                console.log(xhr + " : " + status + " : " + err);
            }.bind(this)
        });
    }

	componentDidMount() {
		this.props.onRef(this)
		$("#tab-cont1").show();
	}
	componentWillUnmount() {
		this.props.onRef(null)
	}
	
    render() {

        return (
							
				<div id="tab-cont2" className="tab_content tab-cont no_paging">
					{/* S:content_body */}
					<div className="content_body">
						{/* S:content_inner */}
						<div className="content_inner">

							<div className="box_com">
								<div className="fl">
									<h3 className="ctitle">{this.props.messages.notice_information}</h3>
								</div>
							</div>

							{/* S:Table */}
							<table className="tbl_row">
								<caption>공지 정보 목록</caption>
								<colgroup>
									<col style={{width:'10%'}}/>
									<col style={{width:'40%'}}/>
									<col style={{width:'10%'}}/>
									<col style={{width:'40%'}}/>
								</colgroup>
								<tbody>
								<tr>
									<th scope="row">{this.props.messages.notice_registrant}</th>
									<td>{this.state.noticeRegUsrName}</td>
									{/*<th scope="row">{this.props.messages.notice_registration_date}</th>
									<td>{this.state.noticeStrDate}</td>*/}
									<th scope="row">{this.props.messages.notice_post_date}</th>
									<td>{this.state.noticeStrDate}</td>
								</tr>
								<tr>
									<th scope="row">{this.props.messages.notice_dept_name}</th>
									<td className="input">
										{this.state.noticeRegUsrDept}
									</td>
									<th scope="row">{this.props.messages.notice_attached}</th>
									<td className="input">
										<AttachFile onRef={ref => (this.attachFile = ref)}
										attachFileId={this.state.attachFileId}
										files={this.state.attachFile} 
										onChange={this.handleFileChange} 
										onUploadResult={this.handleScheduleSave}/>
									</td>
								</tr>
								<tr>
									<th scope="row">{this.props.messages.notice_title}</th>
									<td className="input" colSpan={3}>
										{this.state.noticeTitle}
									</td>
								</tr>
								<tr>
									<th scope="row">{this.props.messages.notice_content}</th>
									<td className="input" colSpan={3} dangerouslySetInnerHTML={{ __html: this.state.noticeContent }}>
									</td>
								</tr>
								</tbody>
							</table>
							{/* E:Table */}
						</div>
						{/* E:content_inner */}
					</div>
					{/* E:content_body */}
				</div>
			

				

	
        );
    }
}

export default connect(mapStateToProps)(MonitoringNoticeDetail);
