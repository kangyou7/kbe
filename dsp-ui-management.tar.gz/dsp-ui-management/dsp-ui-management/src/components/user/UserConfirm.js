import React, { Component  } from 'react';
import { Link, browserHistory } from 'react-router';

class UserConfirm extends Component {
    render(){
        return(
            <section className="body">
                <div className="wrapper">
                    <div className="page_header">
                        <h2 className="ptitle">사용자 등록</h2>
                        <div className="page_nav">
                            {/*<ul>
                                <li><a href="javascript:;">Home</a></li>
                                <li className="here">사용자 등록</li>
                            </ul>*/}
                        </div>
                    </div>
                    <div className="content_wrap">
                        <div className="content_outbox">
                            <div className="tab_wrap tab-wrap">
                                <div className="box_both tab_header">
                                    <div className="fl">
                                        <ul className="tabs">
                                            <li className="tab_item tab-item on">
                                                <a href="#tab-cont2" onclick={()=>{tabsOnOff($(this), $(this).parents('.tab-wrap')); return false;}} className="tab-link"><span>상세</span></a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>

                                <div id="tab-cont1" className="tab_content tab-cont complete" style={{display:'block'}}>
                                    <div className="content_inner">
                                        <div className="box_complete">
                                            <div className="ver_mid">
                                                <i className="ico ico_check"></i>
                                                <strong className="tit">사용자 등록이 완료되었습니다.</strong>
                                                <span className="lb">사용자 승인이 완료되면 작성하신 이메일로 <br /> 승인완료 메일이 전송됩니다.</span>
                                                <div className="btn_group">
                                                    <Link to="/" className="btn_black main_link">메인화면으로 이동</Link>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        )
    }
}
export default UserConfirm;