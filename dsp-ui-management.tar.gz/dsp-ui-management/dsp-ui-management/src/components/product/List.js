import React from 'react';

import Search from '../common/Search';
import PagingView from '../common/PagingView';
import ColumnChange from '../common/ColumnChange';

import {TableThead, TableColgroup} from '../common/TableThead';

import {REST_API_URL} from '../../config/api-config.js';

/*다국어 모듈 시작*/
import { connect } from 'react-redux';
import { changeLangauge, mapStateToProps } from '../../language/Actions';
/*다국어 모듈 종료*/

import validator from 'validator';

class List extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            list : [],
            pageInfo:{

            }
        }

        this.handleColumnChange = this.handleColumnChange.bind(this);

        this.handleDetailView = this.handleDetailView.bind(this);

        this.handleSearch = this.handleSearch.bind(this);
        this.handlePageChange = this.handlePageChange.bind(this);
        this.handleSort = this.handleSort.bind(this);
    }

    //컴포넌트가 만들어지고 첫 렌더링을 다 마친 후 실행되는 메소드입니다.
	componentDidMount() {
        this.props.onRef(this);
        this.getList();
	}

	//컴포넌트가 DOM 에서 사라진 후 실행되는 메소드입니다.
	componentWillUnmount() {
		this.props.onRef(null);
	}

    //항목변경 팝업에서 항목 변경 후 state 정보 변경
    handleColumnChange(changeThead) {
        this.setState({
            listThead : changeThead
        });
    }

    handleSearch(searchInfo) {
        let pageInfo = this.props.pageInfo;
        pageInfo.searchKeyCode = searchInfo.searchKeyCode;
        pageInfo.searchKeyWord = searchInfo.searchKeyWord;
        
        this.props.onPageInfoChange(pageInfo, true);
    }
    //페이지 변경 및 페이지 출력 갯수 변경
    handlePageChange(perPageNum, page) {
        let changePage = this.props.pageInfo;
        changePage.perPageNum = perPageNum;
        changePage.page = page;
   
        this.props.onPageInfoChange(changePage, true);
    }
    handleSort(sort) {
        let sortPage = this.props.pageInfo;
        sortPage.sortColumn = sort.sortColumn;
        sortPage.sortType = sort.sortType;

        this.props.onPageInfoChange(sortPage, true);
    }

    handleDetailView(index) {
        this.props.onDetailView(this.state.list[index].productNo, this.state.list[index].approverYn);
    }

    getList() {
        if(this.props.pageInfo.searchKeyCode != undefined && this.props.pageInfo.searchKeyCode == 'product_id') {
            if(!(this.props.pageInfo.searchKeyWord == '' || validator.isNumeric(this.props.pageInfo.searchKeyWord))) {
                alert("상품ID는 숫자로만 입력하세요.");
                return;
            }
        }

        let data = this.props.pageInfo;

        data.loginUserNo = this.props.memberInfo.user_no;
        data.loginUserDstnctCode = this.props.memberInfo.user_dstnct_code;

        $.ajax({
            url: REST_API_URL + "/product/List",
            dataType: 'json',
            type: "post",
            data: data,
            cache: false,
            success: function(result) {
                this.props.onPageInfoChange(result.response.pageInfo, false);
                this.setState({
                    list: result.response.list//,
                    //pageInfo : result.pageInfo
                });
            }.bind(this),
            error: function(xhr, status, err) {
                console.log(xhr + " : " + status + " : " + err);
            }.bind(this),
			xhrFields: {
			  withCredentials: true
			}
        });
    }



    render() {
        const fncBtnInfo = this.props.memberInfo.dspUserFncBtnInfo;
        const mapToList = (data, thead) => {
            if(data.length > 0) {
                return data.map((item, i) => {//map
                    return(
                        <tr key={i}>
                            <td style={thead[0].view ? {} : {display:'none'}}>{item.rownum}</td>
                            <td style={thead[1].view ? {} : {display:'none'}}>{item.productNo}</td>
                            <td style={thead[2].view ? {} : {display:'none'}}>{item.productDstnctCodeName}</td>
                            <td style={thead[3].view ? {} : {display:'none'}}>{item.productUsePurposeCodeName}</td>
                            <td style={thead[4].view ? {} : {display:'none'}}><a href="javascript:;" onClick={() => {this.handleDetailView(i);}}>{item.productName}</a></td>
                            <td style={thead[5].view ? {} : {display:'none'}}>{item.productVdtStatusCodeName}</td>
                            <td style={thead[6].view ? {} : {display:'none'}}>{item.regUsrName}</td>
                            <td style={thead[7].view ? {} : {display:'none'}}>{item.regDate}</td>
                            <td style={thead[8].view ? {} : {display:'none'}}>{item.aprvStatusCode}</td>
                            <td style={thead[9].view ? {} : {display:'none'}}>{item.approverName}</td>
                        </tr>
                    );
                });
            } else {
                let colspan = thead.length;
                for(var i = 0; i<thead.length; i++) {
                    colspan -= thead[i].view ? 0 : 1;
                }
                return (
                    <tr>
                        <td className="noresults" colSpan={colspan}>
                            <div className="box_noresults">
                                <div className="ver_mid">
                                    <i className="ico ico_no_result"></i>
                                    <span className="lb">{this.props.messages.product_search}</span>
                                </div>
                            </div>
                        </td>
                    </tr>
                );
            }
        }

        return (

            <div id="tab-cont2" className="tab_content tab-cont" style={{display:'block'}}>
                {/*S:content_body */}
                <div className="content_body">
                    {/*S:content_inner */}
                    <div className="content_inner">
                        <div className="box_com term_wrap">
                            
                        <Search onSearch={this.handleSearch} 
                                searchSelectOption={this.props.searchSelectOption} 
                                searchInfo={{"searchKeyCode":this.props.pageInfo.searchKeyCode, "searchKeyWord":this.props.pageInfo.searchKeyWord}}
                                />

                            <div className="fr">
                                <button disabled={fncBtnInfo['funcXlxDwldYn']=='N'} onClick={() => this.props.onDisplaySetting('C')} className="btn_black">{this.props.messages.product_product_registration}</button>
                                <span className="gap"></span>
                                <a href="javascript:;" className="btn_pos" onClick={() => this.columnChange.show()}>{this.props.messages.contract_change_item}</a>
                                {/*<ul className="sort_wrap">
                                    <li className="active"><a href="javascript:;">List</a></li>
                                    <li><a href="javascript:;">Tree</a></li>
                                </ul>*/}
                            </div>
                        </div>			
                        
                        
                        <table className="tbl_col">
                            <caption>티켓 현황 목록</caption>

                            <TableColgroup listThead={this.props.listThead} />
                            <TableThead listThead={this.props.listThead} onSort={this.handleSort}/>
                            
                            <tbody>

                                {mapToList(this.state.list, this.props.listThead)}
                               
                            </tbody>
                        </table>
                    </div>
                    {/*E:content_inner */}
                </div>

                <PagingView pageInfo={this.props.pageInfo} onPageChange={this.handlePageChange}/>

                <ColumnChange onRef={ref => (this.columnChange = ref)} listThead={this.props.listThead} onColumnChange={this.handleColumnChange} />
                
            </div>

        );
    }
}

export default connect(mapStateToProps)(List);
