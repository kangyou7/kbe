/*jshint esversion: 6 */
import React from 'react';

import {REST_API_URL} from '../../config/api-config.js';

/*다국어 모듈 시작*/
import { connect } from 'react-redux';
import { changeLangauge, mapStateToProps, actionlogin } from '../../language/Actions';
/*다국어 모듈 종료*/

class PopupCustm extends React.Component {

    constructor(props) {
        super(props);

        this.state = {
            custmClasCode:"",
            keyWord:"",
            selectKey:-1,
            response : []
        }

        this.handleChange = this.handleChange.bind(this);
        this.handleSearch = this.handleSearch.bind(this);
    }

    handleChange(e) {
        let nextState = {};
        nextState[e.target.name]=e.target.value;
        this.setState(nextState);
    }

    handleCustmSelect(key) {
        $("#custmBody tr").removeClass();
        $("#custmBody tr").eq(key).addClass('selected');
    }

    handleSearch() {
        this.getCustm();
    }

    
    getCustm() {
        const _memberInfo = this.props.memberInfo;

        let _param =  {
            loginUserNo :  _memberInfo.user_no,
            custmClasCode : this.props.setUserClasCode,
            keyWord : this.props.coName
        };

        console.log(JSON.stringify(_param));

        $.ajax({
            url: REST_API_URL + "/custm/popup/search",
            dataType: 'json',
            type: "post",
            data: _param,
            cache: false,
            success: function(result) {
                this.setState({
                    selectKey : -1,
                    response: result.response
                });
            }.bind(this),
                error: function(xhr, status, err) {
                console.log(xhr + " : " + status + " : " + err);
            }.bind(this),
            xhrFields: {
              withCredentials: true
            }
        });
    }

    complete() {
        if(this.state.selectKey < 0) {
            alert("선택하세요");
            return;
        }
        let response = this.state.response[this.state.selectKey];
        this.props.onCustmComplete(response);
        this.hide();
    }

    hide() {
        layer_close(".pop-search-Custm");
    }

    show() {

        let _keyWork = this.props.coName;
        let _custmClasCode = this.props.setUserClasCode;


        let nextState = ({
            custmClasCode :_custmClasCode,
            keyWord:_keyWork,
            selectKey:-1,
            response : []
        });

        this.setState(nextState);
        
        layer_open(".pop-search-Custm");
    }
    //컴포넌트가 만들어지고 첫 렌더링을 다 마친 후 실행되는 메소드입니다.
    componentDidMount() {
        this.props.onRef(this);
    }

    //컴포넌트가 DOM 에서 사라진 후 실행되는 메소드입니다.
    componentWillUnmount() {
        this.props.onRef(null);
    }
    

    render() {

        const mapToCustm = (data) => {
            if(data.length > 0) {
                return data.map((item, i) => {//map
                    return(
                        <tr key={i} onClick={() => {this.setState ({selectKey : i}); this.handleCustmSelect(i)}}
                            onDoubleClick={()=>{this.setState ({selectKey : i}); this.handleCustmSelect(i); this.complete()}} >
                            <td>{item.custmClasName}</td>
                            <td>{item.coName}</td>
                            <td>{item.bizno}</td>
                            <td>{item.ceoName}</td>
                        </tr>
                    );
                });
            } else {
                return (
                    <tr>
                        <td className="noresults" colSpan={4}>
                            <div className="box_noresults">
                                <div className="ver_mid">													
                                    <i className="ico ico_no_result"></i>
                                    <span className="lb">검색 결과가 없습니다.</span>
                                </div>
                            </div>
                        </td>
                    </tr>
                );
            }
        }

        return(
            <div className="lpopup">
                <div className="dimmed"></div>
                <div className="popup_layer pop_search_Custm pop-search-Custm mid">
                    <div className="pop_container">
                        <div className="pop_header">
                            <h1>회사 검색</h1>
                        </div>
                        {/*pop_contents */}
                        <div className="pop_contents scroll_wrap search_form">
                            {/*pop_inner */}
                            <div className="pop_inner">
                                <div className="psearch_form">
                                    <input type="hidden" />
                                    <input type="text" className="ui_input" name="keyWord" value={this.state.keyWord} onChange={this.handleChange}/>
                                    <a href="javascript:;" className="btn_pos" onClick={this.handleSearch}>검색</a>
                                </div>
                                
                                <table className="tbl_col">
                                    <caption>회사 검색</caption>
                                    <colgroup>
                                        <col style={{width:'25%'}} />
                                        <col style={{width:'25%'}} />
                                        <col style={{width:'25%'}} />
                                        <col style={{width:'25%'}} />
                                    </colgroup>
                                    
                                    <thead>
                                        <tr>
                                            <th scope="col">구분</th>
                                            <th scope="col">업체명</th>
                                            <th scope="col">사업자번호</th>
                                            <th scope="col">대표자명</th>
                                        </tr>
                                    </thead>
                                    
                                    <tbody id="custmBody">
                                        {/*S : 리스트 */}
                                        {mapToCustm(this.state.response)}
                                        {/*E : 리스트 */}
                                        
                                    </tbody>
                                </table>
                            </div>
                            {/*// pop_inner */}
                        </div>	
                        {/*// pop_contents*/}
                        <div className="pop_bottom">
                            <button type="button" className="pbtn_black" onClick={() => {this.complete();}}>확인</button>
                        </div>
                    </div>{/*// pop_container */}
                    <a href="javascript:;" onClick={() => {this.hide();}} className="btn_pop_close"><span className="offscreen">닫기</span></a>
                </div>{/*// popup_layer */}
            </div>
        );
    }
}
export default connect(mapStateToProps)(PopupCustm);


