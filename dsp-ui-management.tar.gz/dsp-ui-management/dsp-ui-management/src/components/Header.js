import React from 'react'
import { Link } from 'react-router';
import { browserHistory } from 'react-router';

import NoticePopup from './common/NoticePopup';
import NoticeDetailPopup from './common/NoticeDetailPopup';
import UserInfoPopup from './common/UserInfoPopup';

/*다국어 모듈 시작*/
import { connect } from 'react-redux';
import { changeLangauge, mapStateToProps, loginAction } from '../language/Actions';
import { bindActionCreators } from 'redux';
/*다국어 모듈 종료*/

import {REST_API_URL} from '../config/api-config.js';

import SelectLang from './SelectLang';

class Header extends React.Component{

	static fetchData(dispatch){
		var cl = bindActionCreators(changeLangauge, dispatch);
		return Promise.all([
			cl.changeLang()
		]);
	}

	constructor(props) {
		super(props);

		this.state = {
			curTime : new Date().toLocaleString(),
			menus: [],
			noticeDetailInfo : {},
			releaseVersion:""
		};

		this.noticeDetail = this.noticeDetail.bind(this);
	}

	componentDidUpdate() {
		$(".gnb_item").on("click",function(obj){
			$(".gnb_item").removeClass("active");
			$(obj.currentTarget).addClass("active");
		});

		//새로고침시 타이틀 메뉴 class 지정
		let menuGroup = "";
		switch(browserHistory.getCurrentLocation().pathname) {
			case '/contract' : 
			case '/contractCreate' :
			case '/ContractTodo' :
				menuGroup = '/contract'; break;
			case '/assets' : 
			case '/assetsCreate' : 
			case '/assetsTransfer' : 
			case '/vendor' : 
			case '/vendorCreate' : 
			case '/mtnceEntp' : 
			case '/mtnceEntpCreate' : 
			case '/assetsGroupByVendor' : 
				menuGroup = '/assets'; break;
			case '/product' : 
			case '/productCreate' :
				menuGroup = '/product'; break;
			case '/ticket' : 
			case '/ticketCreate' :
				menuGroup = '/ticket'; break;
			case '/provider' : 
			case '/customer' :
				menuGroup = '/provider'; break;
			case '/cntrlSchedule' : 
			case '/cntrlScheduleCreate' :
				menuGroup = '/cntrlSchedule'; break;
			case '/monitoringNotice' : 
			case '/monitoringNoticeCreate' :
			case '/providerNotice' : 
			case '/providerNoticeCreate' :
			case '/processNotice' : 
			case '/processNoticeCreate' :
				menuGroup = '/monitoringNotice'; break;
			case '/userlist' : 
			case '/usercreate' :
			case '/userdetail' : 
			case '/group' :
				menuGroup = '/userlist'; break;
			case '/sales' : 
			case '/paymentList' :
				menuGroup = '/sales'; break;
		}
		$(".gnb_item").each(function(idx, obj){
			//if($(this).find("a").attr("href") == browserHistory.getCurrentLocation().pathname) {
			if($(this).find("a").attr("href") == menuGroup) {
				$(this).addClass("active");
			}
		});
	}
			
	componentDidMount(){
		if(!this.props.messages){
			this.constructor.fetchData(this.props.dispatch);
		}

		/*setInterval( () => {
			this.setState({
				curTime : new Date().toLocaleString()
			});
		},1000);*/

		$(".logo").on("click", function(obj) {
			$(".gnb_item").removeClass("active");
		});



		const memberInfo = JSON.parse(localStorage.getItem('memberInfo'));
		this.setState({
			menus: memberInfo.menus
			// [
			// 	{
			// 		name: '계약관리', 
			// 		uri:'/contract',
			// 		subMenu:[
			// 			{name:'계약 현황',uri:'/contract'},
			// 			{name:'계약등록',uri:'/contract?type=Create'},
			// 			{name:'결제 미처리 현황',uri:'/ContractTodo'}
			// 			//{name:'계약등록',uri:'/contract/Create'}
			// 		]
			// 	},
			// 	{
			// 		name: '자산관리' , 
			// 		uri:'/assets',
			// 		subMenu:[
			// 			{name:'자산 현황',uri:'/assets'},
			// 			{name:'자산 등록',uri:'/assetsCreate'},
			// 			{name:'장비 이관 현황',uri:'/assetsTransfer'},
			// 			{name:'장비 벤더 관리',uri:'/vendor'},
			// 			{name:'유지보수 업체 관리',uri:'/mtnceEntp'},
			// 			{name:'벤더 별 장비 보유 현황',uri:'/assetsGroupByVendor'}
			// 		]
			// 	},
			// 	{
			// 		name: '프로바이더관리', 
			// 		uri:'/provider',
			// 		subMenu:[
			// 			{name:'Provider 관리',uri:'/provider'},
			// 			{name:'Customer 관리',uri:''}
			// 		]
			// 	},
			// 	{
			// 		name: '관제/서비스관리', 
			// 		uri:'/',
			// 		subMenu:[
			// 			{name:'관제 스케줄 관리',uri:'/cntrlSchedule'}
			// 			//{name:'관제 현황',uri:''},
			// 			//{name:'장비 유지 관리',uri:''},
			// 			//{name:'관제 요원 관리',uri:''}
			// 		]
			// 	},
			// 	{
			// 		name: '상품관리', 
			// 		uri:'/product',
			// 		subMenu:[
			// 			{name:'상품 목록',uri:'/product'},
			// 			{name:'상품 등록',uri:''}
			// 		]
			// 	},
			// 	{
			// 		name: '매출관리', 
			// 		uri:'/sales',
			// 		subMenu:[
			// 			{name:'매출 현황',uri:'/sales'},
			// 			{name:'대사',uri:''}
			// 		]
			// 	},
			// 	{
			// 		name: '티켓관리', 
			// 		uri:'/ticket',
			// 		subMenu:[
			// 			{name:'티켓 현황',uri:'/ticket'},
			// 			{name:'티켓 등록',uri:''}
			// 		]
			// 	},
			// 	{
			// 		name: '사용자 관리', 
			// 		uri:'/userlist',
			// 		subMenu:[
			// 			{name: '사용자 현황',uri:'/userlist'},						
			// 			{name: '사용자 등록',uri:'/usercreate'},
			// 			{name: '사용자그룹 현황',uri:'/usercreate'}
			// 			// {name: '사용자 현황 상세',uri:'/user/detail'},
			// 			//	{name: '사용자 그룹',uri:'/usergrouplist'},
			// 			// {name: '사용자 그룹 상세',uri:'/user/group/detail'}
			// 		]
			// 	},
			// 	{
			// 		name: '공지사항관리', 
			// 		uri:'/',
			// 		subMenu:[
			// 			{name: '관제 공지',uri:'/monitoringNotice'},						
			// 			{name: 'Provider 공지',uri:'/providerNotice'},
			// 			{name: '프로세스 변경 안내',uri:'/processNotice'}
			// 		]
			// 	}
			// ]
		});

		this.getVersion();

	}



	onOpenNoticePopup(e) {
		funcUtilDropBox($(e.currentTarget), '.util-item');
	}

	getVersion() {
        
		$.ajax({
			url: REST_API_URL + "/code/CommCodeList",
			dataType: 'json',
			type: "post",
            data: {commCodeListId : 'SYS_VERSION_GROUP'},
			cache: false,
			success: function(result) {

				let releaseVersion = "";
				$.each(result.response.list, function(i, ei) {
					if(ei.commCode == '040002') {
						releaseVersion = ei.commCodeName;
					}

					console.log(releaseVersion);
				});
				this.setState({
                    releaseVersion : releaseVersion
                });
			}.bind(this),
				error: function(xhr, status, err) {
				console.log(xhr + " : " + status + " : " + err);
			}.bind(this),
            xhrFields: {
              withCredentials: true
            }
        });
	}


	noticeDetail(noticeDetailInfo) {
		this.setState({
			noticeDetailInfo : noticeDetailInfo
		})

		layer_open('.pop-layer-notice-detail');
	}

	manualDownload() {
		$.ajax({
			url: '/sample/manual.pdf',
			success: function(data) {
				var blob=new Blob([data]);
				var link=document.createElement('a');
				link.href=window.URL.createObjectURL(blob);
				link.download="manual.pdf";
				link.click();
			}
		});
	}

	render(){

		const subMenu = (data) => {
			if(data != null && data.length > 0) {
				return (
					<ul className="gnb_sub">
							{data.map((subItem, j) => (
								<li key={j}><Link to={subItem.uri} className="gnb_link">{menuPrint(subItem.uri, 'sub')}</Link></li>
							))}
					</ul>
				)
			} else {
				return ("");
			}
		}

		const menuPrint = (url, level) => {
			return (this.props.messages["gnb_" + level + "_menu_" + url.substring(1)]);
		}

		return (
				<header className="header">
				<div className="wrapper">
					<h1 className="logo">
						<Link to="/"><img src="images/common/logo.png" alt="SECUDIUM IoT" /></Link>
					</h1>
					<ul className="gnb" style={{zIndex:10000}}>
						{/*mapToMenu(this.state.menus)*/}
						{this.state.menus.map((item, i) => (
							<li className="gnb_item" key={i}><Link to={item.uri} className="gnb_link">{menuPrint(item.uri, 'top')}</Link>
								{subMenu(item.subMenu)}
							</li>
						))}
					</ul>



					<div className="util_menu">
						<span className="system_time" id="curTime">{/*this.state.curTime*/}</span>
						<span className="util_item alarm util-item">
							<a href="#" onClick={this.onOpenNoticePopup.bind(this)} className="btn-util-item"><i className="ico ico_alarm"><span className="offscreen">alarm</span></i>{/*<span className="num">2</span>*/}</a>
							<NoticePopup setNoticeDetailInfo={this.noticeDetail}/>
						</span>
						<span className="util_item user_name util-item">
							<a href="#" onClick={this.onOpenNoticePopup.bind(this)} className="btn-util-item"><i className="ico ico_user"><span className="offscreen">관리자</span></i></a>
							<UserInfoPopup/>
						</span>
						<span className="util_item help util-item">
							<a href="#" onClick={this.onOpenNoticePopup.bind(this)} className="btn-util-item"><i className="ico ico_help"><span className="offscreen">공지사항</span></i></a>
							<div className="util_drop_box util_help_drop_box util-drop-box">
								<span className="arrow"></span>
								<div className="title">Version</div>
								<p className="desc">{this.state.releaseVersion}</p>
								<div className="title">Contact</div>
								<p className="desc">secudium@sk.com</p>
								<div className="title tit_manual">Manual</div>
								<a className="link" href="javascript:;" onClick={this.manualDownload.bind(this)}>Download</a>
							</div>
						</span>
						{/*<span className="util_lan">
						<select className="ui-sel sel_lang">
							<option value="KO">Korean</option>
							<option value="EN">English</option>
						</select>
						</span>*/}
						<SelectLang />
					</div>

				</div>

				<NoticeDetailPopup notice={this.state.noticeDetailInfo}/>
			</header>
		);
	}

};

//export default Header;
export default connect(mapStateToProps)(Header);