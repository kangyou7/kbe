import React from 'react';
import CodeSelect from '../common/CodeSelect';

/*다국어 모듈 시작*/
import { connect } from 'react-redux';
import { changeLangauge, mapStateToProps } from '../../language/Actions';
/*다국어 모듈 종료*/

import validator from 'validator';

class MtnceEntpChargeRegist extends React.Component {

    constructor(props) {
        super(props);

        this.state = {
            chargeUsrName:"",
            chargeUsrPosit:"",
            chargeUsrEmail:"",
            chargeUsrTel:"",
            chargeUsrMobileNo:"",
            chargeTaskMemo:""
        }

        this.handleChange = this.handleChange.bind(this);
    }

    handleChange(e) {
        let nextState = {};
        nextState[e.target.name]=e.target.value;
        this.setState(nextState);
    }

    complete() {
        if(validator.trim(this.state.chargeUsrName) == "") {
            alert("담당자 이름을 입력하시기 바랍니다.");
            return
        } else {
			if (!validator.isLength(this.state.chargeUsrName,{min:0, max: 100})) {
				alert("담당자 이름은 100자 이내로 입력바랍니다.");
				return false;
			}
		}

        if(validator.trim(this.state.chargeUsrEmail) == "") {
            alert("담당자 이메일을 입력하시기 바랍니다.");
            return
        } else {
			if (!validator.isEmail(this.state.chargeUsrEmail)) {
				alert("이메일 형식으로 입력 바랍니다.");
				return false;
            }
            var emailRegExp = /[0-9a-zA-Z][_0-9a-zA-Z-]*@[_0-9a-zA-Z-]+(\.[_0-9a-zA-Z-]+){1,2}$/;
            if(!emailRegExp.test(this.state.chargeUsrEmail)) {
                alert("이메일 형식으로 입력 바랍니다.");
                return false;
            }
            
			if (!validator.isLength(this.state.chargeUsrEmail,{min:0, max: 50})) {
				alert("담당자 이메일은 50자 이내로 입력바랍니다.");
				return false;
			}
		}

        if(validator.trim(this.state.chargeUsrTel) == "") {
            alert("전화번호를 입력하시기 바랍니다.");
            return
        } else {
			if (!validator.isLength(this.state.chargeUsrTel,{min:0, max: 20})) {
				alert("전화번호는 20자 이내로 입력바랍니다.");
				return false;
            }

            var regExp = /^\d{2,3}-\d{3,4}-\d{4}$/;

            if (!regExp.test(this.state.chargeUsrTel)) {
                alert("전화번호 형식으로 입력바랍니다.");
                return false;
            }
		}

        if(validator.trim(this.state.chargeUsrMobileNo) == "") {
            alert("휴대폰번호를 입력하시기 바랍니다.");
            return
        } else {
			if (!validator.isLength(this.state.chargeUsrMobileNo,{min:0, max: 20})) {
				alert("휴대폰번호는 20자 이내로 입력바랍니다.");
				return false;
            }
            
            if (!validator.isMobilePhone(this.state.chargeUsrMobileNo,'ko-KR')) {
				alert("휴대폰 번호 형식으로 입력바랍니다.");
				return false;
			}
		}

        let charge = this.state;
        this.props.onChargeComplete(charge);
        this.hide();
    }

    hide() {
        layer_close(".pop_manager_register");
    }

    show() {
        this.setState({
            chargeUsrName:"",
            chargeUsrPosit:"",
            chargeUsrEmail:"",
            chargeUsrTel:"",
            chargeUsrMobileNo:"",
            chargeTaskMemo:""
        })
        layer_open(".pop_manager_register");
    }

    componentDidMount() {
		this.props.onRef(this)
	}

	componentWillUnmount() {
		this.props.onRef(null)
	}

    

    render() {

        return(
            <div className="lpopup">
                <div className="dimmed"></div>
                <div className="popup_layer pop_manager_register pop-manager-register mid">
                    <div className="pop_container">
                        <div className="pop_header">
                            <h1>{this.props.messages.mtnce_manager_registration}</h1>
                        </div>
                        <div className="pop_contents">
                            <div className="pop_inner">
                                <table className="tbl_row">
                                    <caption>담당자 정보</caption>
                                    <colgroup>
                                        <col style={{width:'130px'}} />
                                        <col style={{width:'auto'}} />
                                    </colgroup>
                                    <tbody>
                                        <tr>
                                            <th scope="row">{this.props.messages.mtnce_manager_name} <span className="tc_red">*</span></th>
                                            <td className="input">
                                                <input type="text" className="ui_input" maxLength="100" name="chargeUsrName" value={this.state.chargeUsrName} onChange={this.handleChange}/>								
                                            </td>
                                        </tr>
                                        <tr>
                                            <th scope="row">{this.props.messages.mtnce_manager_position} </th>
                                            <td className="input">
                                                <input type="text" className="ui_input" maxLength="100"  name="chargeUsrPosit" value={this.state.chargeUsrPosit} onChange={this.handleChange}/>								
                                            </td>
                                        </tr>
                                        <tr>
                                            <th scope="row">{this.props.messages.mtnce_email} <span className="tc_red">*</span></th>
                                            <td className="input">
                                                <input type="text" className="ui_input"  maxLength="50" name="chargeUsrEmail" value={this.state.chargeUsrEmail} onChange={this.handleChange}/>								
                                            </td>
                                        </tr>
                                        <tr>
                                            <th scope="row">{this.props.messages.mtnce_manager_phone} <span className="tc_red">*</span></th>
                                            <td className="input">
                                                <input type="text" className="ui_input" maxLength="20"  name="chargeUsrTel" value={this.state.chargeUsrTel} onChange={this.handleChange}/>								
                                            </td>
                                        </tr>
                                        <tr>
                                            <th scope="row">{this.props.messages.mtnce_manager_cellphone}<span className="tc_red">*</span></th>
                                            <td className="input">
                                                <input type="text" className="ui_input" maxLength="20" name="chargeUsrMobileNo" value={this.state.chargeUsrMobileNo} onChange={this.handleChange}/>								
                                            </td>
                                        </tr>
                                        <tr>
                                            <th scope="row">{this.props.messages.mtnce_manager_work}</th>
                                            <td className="input">
                                                <input type="text" className="ui_input" maxLength="100" name="chargeTaskMemo" value={this.state.chargeTaskMemo} onChange={this.handleChange}/>								
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>	
                        <div className="pop_bottom">
                            <button type="button" className="pbtn_pos" onClick={() => {this.hide();}}>{this.props.messages.mtnce_cancel}</button>
                            <button type="button" className="pbtn_black" onClick={() => {this.complete();}}>{this.props.messages.assets_ok}</button>
                        </div>
                    </div>
                    <a href="javascript:;" onClick={() => {this.hide();}} className="btn_pop_close"><span className="offscreen">{this.props.messages.assets_close}</span></a>
                </div>
            </div>
        );
    }
}

export default connect(mapStateToProps)(MtnceEntpChargeRegist);
