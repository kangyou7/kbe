import React from 'react';

import { Link } from 'react-router';
import { browserHistory } from 'react-router';

import ApprovalLineSetting from '../common/ApprovalLineSetting';
import ProviderSearch from '../common/ProviderSearch';
import CustomerSearch from '../common/CustomerSearch';

import Calendar from '../common/Calendar';
import CodeSelect from '../common/CodeSelect';
import AttachFile from '../common/AttachFile';

import axios from 'axios';

import {REST_API_URL} from '../../config/api-config.js';

import { ApprovalSearch } from '../common/ApprovalSearch';
import ProductSearch from '../product/ProductSearch';

/*다국어 모듈 시작*/
import { connect } from 'react-redux';
import { changeLangauge, mapStateToProps } from '../../language/Actions';
/*다국어 모듈 종료*/


const initialState = {
	approvalLine : [],

	svcAplcDate : "", //serviceApplicationDt : "",
	splyUsrNo : "", //providerId : "",
	splyUsrName : "",//providerNm
	customerManager : "",
	ctrtStrDate : "", //contractStartDt : "",
	ctrtEndDate : "", //contractEndDt : "",
	svcStrDate : "", //serviceStartDt : "",
	svcEndDate : "", //serviceEndDt : "",
	billingSetleDayCode : "", //chargeType : "",
	billingMethodCode : "", //chargeApproveDt : "",
	billingStrDate : "", //chargeStartDt : "",
	billingEndDate : "", //chargeEndDt : "",
	bizFetuMemoText : "", //salesNothing : "",
	ctrtIssueMemoText : "", //contractIssue : "",
	demndUsrNo : "123", //cstmrId : "",
	demndUsrName : "", ///cstmrNm : "",
	customerClasCode : "",
	ceoName : "",
	bizno : "",
	coAddr : "",
	hmpageUrl : "",
	coName : "",
	chargeUsrName : "",
	chargeUsrEmail : "",
	chargeUsrDept : "",
	chargeUsrTel : "",
	chargeUsrMobileNo : "",


    tcktChargeUsrNo : "",
    ticketNextNm : "",
    ticketNextDept : "",
    ticketNextCblePhonNo : "",
    ticketNextMoblPhonNo : "",
    ticketNextEmail : "",
    ticketNextPositionNm : "",

    productNo : "", //productId : "",
    productName : "", //productNm : "",
    lastSumAmt : "",
    totalSumAmt : "",

    aprvStatusCode : "",
    useYn : "Y",
	attachFile : [],
    ctrtDstnctCode : "NC",

	files: []
};

class ContractCreate extends React.Component {

	constructor(props) {
		super(props);

		this.state = $.extend(true, {}, initialState);
		this.handleChange = this.handleChange.bind(this);
		/*결재선 지정*/
		this.handleApprovalLineComplete = this.handleApprovalLineComplete.bind(this);
		/*프로바이더 찾기*/
		this.handleProviderComplete = this.handleProviderComplete.bind(this);
		/*고객 찾기*/
		this.handleCustomerComplete = this.handleCustomerComplete.bind(this);

		this.handleFileChange = this.handleFileChange.bind(this);
        this.handleContractSave = this.handleContractSave.bind(this);
        
        /*승인자 찾기*/
        this.handleApprovalComplete = this.handleApprovalComplete.bind(this);
        this.handleGetProduct = this.handleGetProduct.bind(this);
	}

	handleInitState() {
		this.setState($.extend(true, {}, initialState));
	}

	handleContractSave(attachFile) {

		this.setState({
			attachFile : attachFile
        });
        
		//let data = this.state;
        //data.files = [];

        let data = $.extend(true, {}, this.state);
        if(this.props.memberInfo.user_no == null ) {
            alert("로그인이 필요합니다.");
            return;
        }
        data.loginUserNo = this.props.memberInfo.user_no;
        delete data.files;
        delete data.customerManager;
        delete data.lastSumAmt;
        delete data.totalSumAmt;


		$.ajax({
			url: REST_API_URL + "/contract/Create",
			dataType: 'json',
            type: "post",
            cache: false,
            data: {paramJson : JSON.stringify(data)},
			success: function(result) {
                //location.href = "/contract";
                if(this.state.aprvStatusCode == "W") {
                    alert("결재가 요청 되었습니다.");
                } else {
                    alert("임시저장 되었습니다.");
                }
                this.props.onListReload();
			}.bind(this),
				error: function(xhr, status, err) {
				console.log(xhr + " : " + status + " : " + err);
			}.bind(this),
            xhrFields: {
              withCredentials: true
            }
        });
        
	}

	handleSave(temp) {
        

        if(temp == 'T') {
            this.state.aprvStatusCode = 'T';
        } else {
            
            this.state.aprvStatusCode = 'W';
        }
        
        
		if(!this.validationChecke(temp)) {
			return;
		}

        if(this.state.aprvStatusCode == 'W' && !confirm("결재 요청을 하시겠습니까?")) {
            return;
        }

        //고객의 계약정보 조회
        $.ajax({
            url: REST_API_URL + "/contract/ContractDuplicationCheck",
            dataType: 'json',
            type: "post",
            data: {
                demndUsrNo:this.state.demndUsrNo
            },
            cache: false,
            success: function(result) {
                
                if(result.response.contract) {
                    if(result.response.contract.aprvStatusCode == 'A') {
                        alert("계약된 고객입니다.");
                    } else if(result.response.contract.aprvStatusCode == 'W') {
                        alert("결제진행 중인 고객입니다.");
                    } else if(result.response.contract.aprvStatusCode == 'T') {
                        alert("임시저장 중인 고객입니다.");
                    }
                    
                } else {
                    if(this.state.files.length > 0) {
                        this.attachFile.fileUpload();
                    } else {
                        this.handleContractSave(null);
                    }
                }

            }.bind(this),
            error: function(xhr, status, err) {
                console.log(xhr + " : " + status + " : " + err);
            }.bind(this),
            xhrFields: {
              withCredentials: true
            }
        });

		
		
	}

	validationChecke(temp) {

		if(temp != 'T') {
			if(this.state.approvalLine.length < 2) {
				alert("결재선을 지정하세요.");
				return false;
            }
            let isApprover = false;
            $.each(this.state.approvalLine, function(i, el){
                if(el.aprvStepCode == 'A') {
                    isApprover = true;
                }
            });
            if(!isApprover) {
                alert("결재선에 승인자를 지정하세요.");
                return false;
            }
			if(this.state.svcAplcDate == "") {
				alert("서비스 신청일을 지정하세요.");
				return false;
			}

			if(this.state.splyUsrNo == "") {
				alert("Provider를 지정하세요.");
				return false;
			}

			if(this.state.ctrtStrDate == "") {
				alert("계약 시작일 지정하세요.");
				return false;
			}

			if(this.state.ctrtEndDate == "") {
				alert("계약 종료일 지정하세요.");
				return false;
			}

			if(this.state.svcStrDate == "") {
				alert("서비스 시작일 지정하세요.");
				return false;
			}

			if(this.state.svcEndDate == "") {
				alert("서비스 만료일 지정하세요.");
				return false;
			}

			if(this.state.billingMethodCode == "") {
				alert("과금 방법 지정하세요.");
				return false;
			}

			if(this.state.billingSetleDayCode == "") {
				alert("과금 결제일 (매월) 지정하세요.");
				return false;
			}

			if(this.state.billingStrDate == "") {
				alert("과금 개시일 지정하세요.");
				return false;
			}

			if(this.state.billingEndDate == "") {
				alert("과금 만료일 지정하세요.");
				return false;
			}

			if(this.state.demndUsrNo == "") {
				alert("고객명 지정하세요.");
				return false;
			}

			if(this.state.customerClasCode == "") {
				alert("고객 구분 지정하세요.");
				return false;
			}

			if(this.state.coAddr == "") {
				alert("주소 지정하세요.");
				return false;
			}

			if(this.state.coAddr == "") {
				alert("담당자 이름 지정하세요.");
				return false;
			}

			if(this.state.chargeUsrEmail == "") {
				alert("이메일 지정하세요.");
				return false;
			}

			if(this.state.chargeUsrMobileNo == "") {
				alert("휴대폰번호 지정하세요.");
				return false;
            }
            if(this.state.productNo == "") {
				alert("상품을 지정하세요.");
				return false;
			}
		} else {
			if(this.state.demndUsrNo == "") {
				alert("고객명을 지정하세요.");
				return false;
			}
		}
		
		return true;

	}

	handleChange(e) {

		if(e.target.name === "fileUpload") {
			let files = this.state.files;

			files.push(e.target.files[0]);
			this.setState({
				files : files
			})
			
		} else {
			let nextState = {};
			nextState[e.target.name]=e.target.value;
			this.setState(nextState);
		}
	}

	handleFileChange(files) {
		this.setState({
			files : files
		})
	}
	
	handleFileRemove(key) {
		let files = this.state.files;

		files.splice(key, 1);

		this.state.files = files
	}

	/*결재선 지정*/
	handleApprovalLineComplete(approvalLine) {
		this.setState({
			approvalLine : approvalLine
        });
	}

	/*프로바이더 찾기*/
	handleProviderComplete(provider) {
		this.setState({
			splyUsrNo : provider.custmNo,
            splyUsrName : provider.coName,
            customerManager : provider.customerManager
		})
	}

	handleCustomerComplete(customer) {
		this.setState({
			demndUsrNo : customer.custmNo,
			demndUsrName : customer.coName,
			customerClasCode : customer.customerClasCode,
			ceoName : customer.ceoName,
			bizno : customer.bizno,
			coAddr : customer.coAddr,
			hmpageUrl : customer.hmpageUrl,
			coName : customer.coName,
			chargeUsrName : customer.chargeUsrName,
			chargeUsrEmail : customer.chargeUsrEmail,
			chargeUsrDept : customer.chargeUsrDeptName,
			chargeUsrTel : customer.chargeUsrTel,
            chargeUsrMobileNo : customer.chargeUsrMobileNo
		})
    }
    
    handleApprovalComplete(approver) {
        this.setState({
            tcktChargeUsrNo : approver.userNo,
            ticketNextNm : approver.userName,
            ticketNextDept : approver.deptName,
            ticketNextCblePhonNo : approver.coTel,
            ticketNextMoblPhonNo : approver.mobileNo,
            ticketNextEmail : approver.userEmail,
            ticketNextPositionNm : approver.positName
        })
    }
	
    //컴포넌트가 만들어지고 첫 렌더링을 다 마친 후 실행되는 메소드입니다.
	componentDidMount() {
        this.props.onRef(this)

        if(this.state.approvalLine.length == 0){

            let approvalLineDraft = [{
                aprvChargeUsrNo : this.props.memberInfo.user_no,
                aprvStepCode : 'D',
                userName : this.props.memberInfo.user_name,
                userEmail : '',
                deptName : this.props.memberInfo.dept_name,
                positName : this.props.memberInfo.posit_name
            }];


            this.setState({
                approvalLine : approvalLineDraft
            });
        }


        $("#tab-cont1").show();
        

    }
    
    //컴포넌트가 DOM 에서 사라진 후 실행되는 메소드입니다.
	componentWillUnmount() {
		this.props.onRef(null);
    }
    
    handleGetProduct(product) {
        this.setState({
            productNo : product.productNo,
            productName : product.productName,
            lastSumAmt : product.lastSumAmt,
            totalSumAmt : product.totalSumAmt
        })
    }
	
    render() {
        const fncBtnInfo = this.props.memberInfo.dspUserFncBtnInfo;
		/*const mapToFiles = (data) => {
			return data.map((item, i) => {//map
				//console.log(item.files);
				return(
					<span className="file_item" key={i}>
						<span>{item.name}</span>
						<a href="javascript:;" className="ibtn_del" onClick={() => {this.handleFileRemove(i)}}><i className="ico_del"><span className="offscreen">삭제</span></i></a>
					</span>
				);
			});
		}*/

        return (


            <div id="tab-cont3" className="tab_content tab-cont" style={{display:'block'}}>
                {/* S:content_body */}
                <div className="content_body">
                    {/* S:content_inner */}
                    <div className="content_inner">
                        <ApprovalLineSetting onRef={ref => (this.approvalLineSetting = ref)} approvalLine={this.state.approvalLine} onApprovalLineComplete={this.handleApprovalLineComplete} isChange={true} menuPath={'contract'}/>
                        <div className="box_com">
                            <div className="fl">
                                <h3 className="ctitle">{this.props.messages.contract_ticket_manager_information}</h3>
                            </div>
                            <div className="fr">
                                <a href="javascript:;" className="btn_black" onClick={()=>this.approvalSearch.show()}>{this.props.messages.ticket_manager_searching}</a>
                            </div>
                        </div>
                        
                        {/* S:Table */}
                        <table className="tbl_row">
                            <caption>티켓 담당자 정보 목록</caption>
                            <colgroup>
                                <col style={{width:'10%'}}/>
                                <col style={{width:'40%'}}/>
                                <col style={{width:'10%'}}/>
                                <col style={{width:'40%'}}/>
                            </colgroup>
                            <tbody>
                                <tr>
                                    <th scope="row">{this.props.messages.contract_name}</th>
                                    <td className="input" colSpan="3">
                                        {this.state.ticketNextNm}
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">{this.props.messages.contract_e_mail}</th>
                                    <td className="input">{this.state.ticketNextEmail}</td>
                                    <th className="row">{this.props.messages.contract_position}</th>
                                    <td className="input">{this.state.ticketNextPositionNm}</td>
                                </tr>
                                <tr>
                                    <th scope="row">{this.props.messages.contract_phone}</th>
                                    <td className="input">{this.state.ticketNextCblePhonNo}</td>
                                    <th scope="row">{this.props.messages.contract_cell_phone}</th>
                                    <td className="input">{this.state.ticketNextMoblPhonNo}</td>
                                </tr>
                            </tbody>
                        </table>
                        {/* E:Table */}





                        <div className="box_com">
                            <div className="fl">
                                <h3 className="ctitle">{this.props.messages.contract_contract_information}</h3>
                            </div>
                            <div className="fr">
                                <div className="desc">
                                    <span className="tc_red">*</span> {this.props.messages.contract_reguired}
                                </div>
                            </div>
                        </div>

                        {/* S:Table */}
                        <table className="tbl_row">
                            <caption>계약 정보 테이블</caption>
                            <colgroup>
                                <col style={{width:'10%'}}/>
                                <col style={{width:'40%'}}/>
                                <col style={{width:'10%'}}/>
                                <col style={{width:'40%'}}/>
                            </colgroup>
                            <tbody>
                                <tr>
                                    <th scope="row">{this.props.messages.contract_service_application_date} <span className="tc_red">*</span></th>
                                    <td  className="input" colSpan={3}>
                                        {/* s: 캘린더폼 */}
                                        <div className="date_box">
                                            <Calendar className="ui_cal" 
                                                dateFormat="YYYY-MM-DD"
                                                onChange={(data) => this.setState({svcAplcDate: data})}
                                                selected={this.state.svcAplcDate}
                                                name="svcAplcDate"/>
                                        </div>
                                        {/* e: 캘린더폼 */}
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">{this.props.messages.contract_provider} <span className="tc_red">*</span></th>
                                    <td className="input">
                                        <span className="input_btn_box">
                                            <input type="hidden" name="splyUsrNo" value={this.state.splyUsrNo}  onChange={this.handleChange}/>
                                            <input type="text" className="ui_input" name="splyUsrName" value={this.state.splyUsrName}  onChange={this.handleChange} readOnly={true}/>
                                            <button type="button" className="tbtn_pos" onClick={() => {this.providerSearch.show();}}>{this.props.messages.contract_provider} {this.props.messages.contract_search_1}</button>
                                        </span>
                                    </td>

                                    <th scope="row">{this.props.messages.contract_customer_manager}</th>
                                    <td className="input">
                                        <input type="text" className="ui_input" name="customerManager" value={this.state.customerManager} onChange={this.handleChange} readOnly={true}/>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">{this.props.messages.contract_contract_start_date} <span className="tc_red">*</span></th>
                                    <td className="input">
                                        {/* s: 캘린더폼 */}
                                        <div className="date_box">
                                            <Calendar className="ui_cal" 
                                            dateFormat="YYYY-MM-DD"
                                            onChange={(data) => this.setState({ctrtStrDate: data})}
                                            selected={this.state.ctrtStrDate}
                                            name="ctrtStrDate"/>
                                        </div>
                                        {/* e: 캘린더폼 */}
                                    </td>
                                    <th scope="row">{this.props.messages.contract_contract_end_date} <span className="tc_red">*</span></th>
                                    <td className="input">
                                        {/* s: 캘린더폼 */}
                                        <div className="date_box">
                                            <Calendar className="ui_cal" 
                                            dateFormat="YYYY-MM-DD"
                                            onChange={(data) => this.setState({ctrtEndDate: data})}
                                            selected={this.state.ctrtEndDate}
                                            name="ctrtEndDate"/>
                                        </div>
                                        {/* e: 캘린더폼 */}
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">{this.props.messages.contract_service_start_date} <span className="tc_red">*</span></th>
                                    <td className="input">
                                        {/* s: 캘린더폼 */}
                                        <div className="date_box">
                                            <Calendar className="ui_cal" 
                                            dateFormat="YYYY-MM-DD"
                                            onChange={(data) => this.setState({svcStrDate: data})}
                                            selected={this.state.svcStrDate}
                                            name="svcStrDate"/>
                                        </div>
                                        {/* e: 캘린더폼 */}
                                    </td>
                                    <th scope="row">{this.props.messages.contract_service_end_date} <span className="tc_red">*</span></th>
                                    <td className="input">
                                        {/* s: 캘린더폼 */}
                                        <div className="date_box">
                                            <Calendar className="ui_cal" 
                                            dateFormat="YYYY-MM-DD"
                                            onChange={(data) => this.setState({svcEndDate: data})}
                                            selected={this.state.svcEndDate}
                                            name="svcEndDate"/>
                                        </div>
                                        {/* e: 캘린더폼 */}
                                    </td>
                                </tr>
                                <tr>
                                <th scope="row">{this.props.messages.contract_billing} <span className="tc_red">*</span></th>
                                    <td className="input">
                                        <CodeSelect className="ui-sel sel_white" 
                                                    name="billingMethodCode" 
                                                    value={this.state.billingMethodCode} 
                                                    selec
                                                    onChange={this.handleChange} 
                                                    groupCode="CL003"/>
                                    </td>
                                    <th scope="row">{this.props.messages.contract_billing_date}({this.props.messages.contract_monthly}) <span className="tc_red">*</span></th>
                                    <td className="input">
                                        <CodeSelect className="ui-sel sel_white" 
                                                    name="billingSetleDayCode" 
                                                    value={this.state.billingSetleDayCode} 
                                                    onChange={this.handleChange} 
                                                    groupCode="CL004"/>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">{this.props.messages.contract_billing_start_date} <span className="tc_red">*</span></th>
                                    <td className="input">
                                        {/* s: 캘린더폼 */}
                                        <div className="date_box">
                                            <Calendar className="ui_cal" 
                                            dateFormat="YYYY-MM-DD"
                                            onChange={(data) => this.setState({billingStrDate: data})}
                                            selected={this.state.billingStrDate}
                                            name="billingStrDate"/>
                                        </div>
                                        {/* e: 캘린더폼 */}
                                    </td>
                                    <th scope="row">{this.props.messages.contract_billing_end_date} <span className="tc_red">*</span></th>
                                    <td className="input">
                                        {/* s: 캘린더폼 */}
                                        <div className="date_box">
                                            <Calendar className="ui_cal" 
                                            dateFormat="YYYY-MM-DD"
                                            onChange={(data) => this.setState({billingEndDate: data})}
                                            selected={this.state.billingEndDate}
                                            name="billingEndDate"/>
                                        </div>
                                        {/* e: 캘린더폼 */}
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">{this.props.messages.contract_sales_remark}</th>
                                    <td className="input">
                                        <textarea className="ui_textarea" name="bizFetuMemoText" value={this.state.bizFetuMemoText} onChange={this.handleChange} maxLength={4000}></textarea>
                                    </td>
                                    <th scope="row">{this.props.messages.contract_contract_issue}</th>
                                    <td className="input">
                                        <textarea className="ui_textarea" name="ctrtIssueMemoText" value={this.state.ctrtIssueMemoText} onChange={this.handleChange} maxLength={1000}></textarea>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">{this.props.messages.contract_attached}</th>
                                    <td className="input" colSpan={3}>
                                        <AttachFile onRef={ref => (this.attachFile = ref)} 
                                        files={this.state.files} 
                                        onChange={this.handleFileChange} 
                                        onUploadResult={this.handleContractSave}
                                        isFileSearch={true}/>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                        {/* E:Table */}

                        <div className="box_com">
                            <div className="fl">
                                <h3 className="ctitle">{this.props.messages.contract_customer_information}</h3>
                            </div>
                            <div className="fr">
                                <div className="desc">
                                    <span className="tc_red">*</span> {this.props.messages.contract_reguired}
                                </div>
                            </div>
                        </div>

                        {/* S:Table */}
                        <table className="tbl_row">
                            <caption>고객 정보 테이블</caption>
                            <colgroup>
                                <col style={{width:'10%'}}/>
                                <col style={{width:'40%'}}/>
                                <col style={{width:'10%'}}/>
                                <col style={{width:'40%'}}/>
                            </colgroup>
                            <tbody>
                                <tr>
                                    <th scope="row">{this.props.messages.contract_customer_name} <span className="tc_red">*</span></th>
                                    <td  className="input">
                                        <span className="input_btn_box">
                                            <input type="hidden" name="demndUsrNo" value={this.state.demndUsrNo} onChange={this.handleChange} />
                                            <input type="text" className="ui_input" name="demndUsrName" value={this.state.demndUsrName} onChange={this.handleChange} readOnly={true}/>
                                            <button type="button" className="tbtn_pos" onClick={() => {this.customerSearch.show();}}>{this.props.messages.contract_customer_searching_1}</button>
                                        </span>
                                    </td>
                                    <th scope="row">{this.props.messages.contract_customer_division} <span className="tc_red">*</span></th>
                                    <td className="input">
                                        <ul className="ip_list">
                                            <li>
                                                <span className="input_ico_box">
                                                    <input type="radio" name="customerClasCode" id={"contract_rdo_1"} value="01" checked={this.state.customerClasCode === "01"} onChange={this.handleChange} readOnly={true}/>
                                                    {<label htmlFor={"contract_rdo_1"}>법인</label>}
                                                </span>
                                            </li>
                                            <li>
                                                <span className="input_ico_box">
                                                    <input type="radio" name="customerClasCode" id={"contract_rdo_2"}  value="02" checked={this.state.customerClasCode === "02"} onChange={this.handleChange} readOnly={true}/>
                                                    {<label htmlFor={"contract_rdo_2"}>개인</label>}
                                                </span>
                                            </li>
                                        </ul>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">{this.props.messages.contract_representative_1}</th>
                                    <td className="input" >
                                        <input type="text" className="ui_input" name="ceoName" value={this.state.ceoName} onChange={this.handleChange} readOnly={true}/>
                                    </td>
                                    <th scope="row">{this.props.messages.contract_business_number}</th>
                                    <td className="input">
                                        <input type="text" className="ui_input" name="bizno" value={this.state.bizno} onChange={this.handleChange} readOnly={true}/>
                                        <span className="tt">* {this.props.messages.contract_corporation_individual_input_message}</span>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">{this.props.messages.contract_address} <span className="tc_red">*</span></th>
                                    <td className="input">
                                        <input type="text" className="ui_input" name="coAddr" value={this.state.coAddr} onChange={this.handleChange} readOnly={true}/>
                                    </td>
                                    <th scope="row">{this.props.messages.contract_web_url}</th>
                                    <td className="input">
                                        <input type="text" className="ui_input" name="hmpageUrl" value={this.state.hmpageUrl} onChange={this.handleChange} readOnly={true}/>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">{this.props.messages.contract_manager_name}</th>
                                    <td className="input">
                                        <input type="text" className="ui_input" name="chargeUsrName" value={this.state.chargeUsrName} onChange={this.handleChange} readOnly={true}/>
                                    </td>
                                    <th scope="row">{this.props.messages.contract_e_mail} </th>
                                    <td className="input">
                                        <input type="text" className="ui_input" name="chargeUsrEmail" value={this.state.chargeUsrEmail} onChange={this.handleChange} readOnly={true}/>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">{this.props.messages.contract_company_name_1}</th>
                                    <td className="input">
                                        <input type="text" className="ui_input" name="coName" value={this.state.coName} onChange={this.handleChange} readOnly={true}/>
                                    </td>
                                    <th scope="row">{this.props.messages.contract_department}</th>
                                    <td className="input">
                                        <input type="text" className="ui_input" name="chargeUsrDept" value={this.state.chargeUsrDept} onChange={this.handleChange} readOnly={true}/>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">{this.props.messages.contract_phone}</th>
                                    <td className="input">
                                        <input type="text" className="ui_input" name="chargeUsrTel" value={this.state.chargeUsrTel} onChange={this.handleChange} readOnly={true}/>
                                    </td>
                                    <th scope="row">{this.props.messages.contract_cell_phone} </th>
                                    <td className="input">
                                        <input type="text" className="ui_input" name="chargeUsrMobileNo" value={this.state.chargeUsrMobileNo} onChange={this.handleChange} readOnly={true}/>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                        {/* E:Table */}

                        <div className="box_com">
                            <div className="fl">
                                <h3 className="ctitle">{this.props.messages.contract_product_information}</h3>
                            </div>
                            <div className="fr">
                                <button type="button" className="btn_pos" onClick={() => {this.productSearch.show();}}>{this.props.messages.contract_product_searching}</button>
                            </div>
                        </div>

                        {/* DESC : 상품 정보 영역 기획 최종 아님. 변경 될 수 있음 */}
                        {/* S:상품 결과 있는 경우 */}
                        {/* S:Table */}
                        <table className="tbl_row">
                            <caption>상품 정보 목록</caption>
                            <colgroup>
                                <col style={{width:'10%'}}/>
                                <col style={{width:'40%'}}/>
                                <col style={{width:'10%'}}/>
                                <col style={{width:'40%'}}/>
                            </colgroup>
                            <tbody>
                                <tr>
                                    <th scope="row">상품명</th>
                                    <td colSpan={3} >
                                        <div className="box_com" style={{marginBottom:'-7px', marginTop:'-7px', marginRight:'-10px'}}>
                                            <div className="fl" style={{marginTop:'5px'}}>
                                                {this.state.productName}
                                            </div>
                                            <div className="fr">
                                                {/*<button type="button" className="tbtn_pos">자세히</button>*/}
                                                {
                                                this.state.productNo != null && this.state.productNo != ''
                                                ?
                                                <Link to={{ pathname: "/popupDetail", query: { item:'product', productNo: this.state.productNo } }} className="tbtn_pos" target="_blank">자세히</Link>
                                                :
                                                ''
                                                }
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">월 과금액</th>
                                    <td className="input">{this.state.lastSumAmt}</td>
                                    <th scope="row">계약기간 합계금액</th>
                                    <td className="input">{this.state.totalSumAmt}</td>
                                </tr>
                            </tbody>
                        </table>

                        
                        {/* E:Table */}
                        {/* E:상품 결과 있는 경우 */}

                        {/* S:상품 결과 없는 경우 */}
                        {/* S:Table */}
                        {/*
                        <table className="tbl_col">
                            <caption>상품 정보 목록</caption>
                            <colgroup>
                                <col style="width:50%;">
                                <col style="width:50%;">
                            </colgroup>

                            <tbody>
                                <tr>
                                    <td className="noresults" colspan="2">
                                        <div className="box_noresults">
                                            <div className="ver_mid">
                                                <i className="ico ico_no_result"></i>
                                                <span className="lb">계약할 상품을 검색 하세요.</span>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                        */}
                        {/* E:Table */}
                        {/* E:상품 결과 없는 경우 */}
                    </div>
                    {/* E:content_inner */}
                </div>
                {/* E:content_body */}
                <ProviderSearch onRef={ref => (this.providerSearch = ref)} onProviderComplete={this.handleProviderComplete}/>

                <CustomerSearch onRef={ref => (this.customerSearch = ref)} onCustomerComplete={this.handleCustomerComplete}/>

                <ApprovalSearch onRef={ref => (this.approvalSearch = ref)} onComplete={this.handleApprovalComplete}/>

                <ProductSearch onRef={ref => (this.productSearch = ref)} onProductSearchComplete={this.handleGetProduct}/>
            </div>
        );
    }
}

export default connect(mapStateToProps)(ContractCreate);

