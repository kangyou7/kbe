import React from 'react';

import { browserHistory } from 'react-router';

import ApprovalLineSetting from '../common/ApprovalLineSetting';

import Calendar from '../common/Calendar';
import CodeSelect from '../common/CodeSelect';
import AttachFile from '../common/AttachFile';

import {REST_API_URL} from '../../config/api-config.js';

import axios from 'axios';

/*다국어 모듈 시작*/
import { connect } from 'react-redux';
import { changeLangauge, mapStateToProps } from '../../language/Actions';
/*다국어 모듈 종료*/

import validator from 'validator';

class CntrlScheduleCreate extends React.Component {

	constructor(props) {
		super(props);

		this.state = {
			scheTitle : "",
			scheMsg : "",
			attachFile: []
		}

		this.handleChange = this.handleChange.bind(this);

		this.handleSave = this.handleSave.bind(this);

		this.handleFileChange = this.handleFileChange.bind(this);

		this.handleScheduleSave = this.handleScheduleSave.bind(this);
		
	}

	handleInitState() {
		
		this.setState({
			scheTitle : "",
			scheMsg : "",
			attachFile: []
		});
	}

	handleFileChange(attachFile) {
		this.setState({
			attachFile : attachFile
		})
	}

	handleScheduleSave(attachFile) {

		if (this.validationCheck()) {

			this.setState({
				attachFile : attachFile
			});
	
			let data = this.state;

			let memberInfo = JSON.parse(localStorage.getItem("memberInfo"));
       		data.loginUserNo = memberInfo.user_no;
			
			$.ajax({
				url: REST_API_URL+"/cntrl/Create",
				dataType: 'json',
				type: "post",
				data: {paramJson : JSON.stringify(data)},
				xhrFields : {
					withCredentials : true
				},
	
				success: function(result) {
					
					if (result.response == "SUCCESS") {
						alert("등록되었습니다.");
						location.href="/cntrlSchedule";
					} else {
						alert("등록 도중 오류가 발생하였습니다. 관리자에게 문의바랍니다.");
						return;
					}
	
				}.bind(this),
					error: function(xhr, status, err) {
					console.log(xhr + " : " + status + " : " + err);
				}.bind(this)
			});	
		}
	}

	handleSave() {

		if (confirm("등록하시겠습니까?")) {
			if(this.state.attachFile.length > 0) {
				this.attachFile.fileUpload();
			} else {
				this.handleScheduleSave("");
			}
		}
	}

	validationCheck() {
		if(validator.trim(this.state.scheTitle) == "") {
			alert("제목을 입력해 주세요.");
			return false;
		} else {
			if (!validator.isLength(this.state.scheTitle,{min:0, max: 300})) {
				alert("제목은 300자 이내로 입력바랍니다.");
				return false;
			}
		}

		if(validator.trim(this.state.scheMsg) == "") {
			alert("내용을 입력해 주세요.");
			return false;
		} else {
			if (!validator.isLength(this.state.scheMsg,{min:0, max: 1000})) {
				alert("내용은 1000자 이내로 입력바랍니다.");
				return false;
			}
		}
		
		// if(this.state.attachFile.length == 0) {
		// 	alert("파일을 첨부해 주세요.");
		// 	return false;
		// }
		
		return true;
	}

	handleChange(e) {
		let nextState = {};
		nextState[e.target.name]=e.target.value;
		this.setState(nextState);
	}

	goList() {
		if (confirm("이 페이지에서 나가시겠습니까?\n작성중인 내용이 저장되지 않습니다.")) {
			location.href="/cntrlSchedule";
		}
	}

	componentDidMount() {
		$("#tab-cont1").show();
	}
	
    render() {
		const fncBtnInfo = this.props.memberInfo.dspUserFncBtnInfo;
        return (
			<section className="body">

				{/* S:wrapper */}
				<div className="wrapper">

					{/* S:page_header */}
					<div className="page_header">
						<h2 className="ptitle">{this.props.messages.cntrl_monitoring_schedule_registration}</h2>
						<div className="page_nav">
							{/*<ul>
								<li><a href="/">Home</a></li>
								<li><a href="/cntrlSchedule">{this.props.messages.cntrl_monitoring_service_management}</a></li>
								<li className="here">{this.props.messages.cntrl_monitoring_schedule_registration}</li>
							</ul>*/}
						</div>
					</div>
					{/* E:page_header */}

					{/* S:content_wrap */}
					<div className="content_wrap">
						{/* S:content_outbox */}
						<div className="content_outbox">
							{/* S:tab_wrap */}
							<div className="tab_wrap tab-wrap">
								{/* S:tab_header */}
								<div className="box_both tab_header">
									<div className="fl">
										<ul className="tabs">
											<li className="tab_item tab-item">
												<a href="#tab-cont1" className="tab-link" onClick={() => {this.goList()}}><span>{this.props.messages.common_list}</span></a>
											</li>
											<li className="tab_item tab-item on">
												<a href="#tab-cont1" className="tab-link"><span>{this.props.messages.common_detail}</span></a>
											</li>
										</ul>
									</div>
									<div className="fr">
										<div className="btn_group">
											<button type="button" className="btn_pos" onClick={() => {this.handleInitState()}}>{this.props.messages.common_reset}</button>
											{/* <button type="button" className="btn_pos" onClick={() => {this.handleSave('T')}}>임시저장</button> */}
											<button disabled={fncBtnInfo['funcRegYn']=='N'} type="button" className="btn_black" onClick={() => {this.handleSave()}}>{this.props.messages.cntrl_ok}</button>
										</div>
									</div>
								</div>
								{/* E:tab_header */}

								{/* S:tab_content 활성화시 display:block/none  */}
								<div id="tab-cont1" className="tab_content tab-cont" >
									{/* S:content_body */}
									<div className="content_body">
										{/* S:content_inner */}
										<div className="content_inner">

											<div className="box_com">
												<div className="fl">
													<h3 className="ctitle">{this.props.messages.cntrl_monitoring_schedule_registration}</h3>
												</div>
												<div className="fr">
													<div className="desc">
														<span className="tc_red">*</span> {this.props.messages.cntrl_required}
													</div>
												</div>
											</div>

											{/* S:Table */}
											<table className="tbl_row">
												<caption>스케줄 작성 목록</caption>
												<colgroup>
													<col style={{width:'150px'}}/>
													<col style={{width:'auto'}}/>
												</colgroup>
												<tbody>
												<tr>
													<th scope="row">{this.props.messages.cntrl_registrant}</th>
													<td>{this.props.memberInfo.user_name}</td>
												</tr>
												{/* <tr>
													<th scope="row">{this.props.messages.cntrl_registration_date}</th>
											
													<td>추후 세션처리</td>
												</tr> */}
												<tr>
													<th scope="row">{this.props.messages.cntrl_title} <span className="tc_red">*</span></th>
													<td className="input">
														<input type="text" className="ui_input" maxLength="300" name="scheTitle" onChange={this.handleChange} value={this.state.scheTitle}/>
													</td>
												</tr>
												<tr>
													<th scope="row">{this.props.messages.cntrl_content} <span className="tc_red">*</span></th>
													<td className="input">
														<textarea className="ui_textarea h_large" maxLength="1000" name="scheMsg" onChange={this.handleChange} value={this.state.scheMsg}></textarea>
													</td>
												</tr>
												<tr>
													<th scope="row">{this.props.messages.cntrl_attached} </th>
													<td className="input">
														<AttachFile onRef={ref => (this.attachFile = ref)}
														files={this.state.attachFile} 
														onChange={this.handleFileChange} 
														onUploadResult={this.handleScheduleSave}
														isFileSearch={true}/>
													</td>
												</tr>
												</tbody>
											</table>
											{/* E:Table */}
										</div>
										{/* E:content_inner */}
									</div>
									{/* E:content_body */}
								</div>
							
							{/* E:tab_content  */}
							</div>
						{/* E:tab_wrap */}
						</div>
					</div>
				</div>

			</section>
        );
    }
}

export default connect(mapStateToProps)(CntrlScheduleCreate);
