/*jshint esversion: 6 */
import React from 'react';
import { Link } from 'react-router';
import { browserHistory } from 'react-router';

import AuthGroupList from './AuthGroupList';
import AuthGroupDetail from './AuthGroupDetail';

import {REST_API_URL} from '../../config/api-config.js';

/*다국어 모듈 시작*/
import { connect } from 'react-redux';
import { changeLangauge, mapStateToProps, changeToken, actionlogin } from '../../language/Actions';
/*다국어 모듈 종료*/

class AuthGroup extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      groupSeq : "",
      file : null,
      displadyState : "L",
      pageInfo : {},
      list : [],
    };

    this.handleDetailView = this.handleDetailView.bind(this);
    this.handleExcelDownload = this.handleExcelDownload.bind(this);
    this.handleBulkUploadPopup = this.handleBulkUploadPopup.bind(this);
    this.handleBulkUpload = this.handleBulkUpload.bind(this);
    this.handleBulkUploadSample = this.handleBulkUploadSample.bind(this);
    this.handleBulkFileChange = this.handleBulkFileChange.bind(this);
    this.handleDisplaySetting = this.handleDisplaySetting.bind(this);
    this.handlePageInfoChange = this.handlePageInfoChange.bind(this);
  }
  
  handleDetailView(groupSeq) {
    this.state.groupSeq = groupSeq;
    this.handleDisplaySetting('D');
  }

  handleExcelDownload() {
    this.AuthGroupList.getExcelDownload();
  }

  componentWillMount() {
    const qs = require('query-string');
    const parsed = qs.parse(location.search);
    if(parsed.type == 'Create') {
      this.handleDisplaySetting('C');
    }
  }

  componentDidMount() {
    if(!this.props.messages){
			this.constructor.fetchData(this.props.dispatch);
    }

    if ( $('.ui-sel').length > 0 ){
        $('.ui-sel').each(function(){
            $(this).selectric();//초기화
        });	
    }
  }

  handleBulkFileChange(file) {
    this.setState({
      file : file
    });
  }

  handleBulkUploadPopup() {
    this.refs.bulkUpload.show();

    this.setState({
      file : null
    });
  }

  handleBulkUpload() {

    if(this.state.file == null || this.state.file.length < 1) {
      alert(this.props.messages.AuthGroup_fileupload_select);
      return;
    }

		let formData = new FormData();
    formData.append("file", this.state.file);
    
		axios.post(REST_API_URL + "/api/custm/BulkUpload", formData, {
			headers: { "X-Requested-With": "XMLHttpRequest" },
		})
		.then( response => { 
      if(response.data.bulkUploadError === undefined) {
        this.refs.bulkUpload.hide();
        this.AuthGroupList.getList();
      } else {
        console.log(response.data.bulkUploadError);
      }
		})
		.catch( response => { console.log(response); } );
  }

  handleBulkUploadSample() {
    var form = "<form action='" + REST_API_URL + "/AuthGroup/BulkUploadSampleDownload' method='post'>";
    form += "</form>"; 
    jQuery(form).appendTo("body").submit().remove();
  }

  handleDisplaySetting(state) {
    this.setState({displadyState : state});
  }

  handlePageInfoChange(pageInfo, reload) {
    this.setState({
        pageInfo : pageInfo
    });

    if(reload) {
      this.AuthGroupList.getList();
    }
  }
  handleTabsChange(tab) {

    if(tab === 'Detail') {
      if(this.state.custmNo === "") {
        alert("리스트의 Provider를 선택하세요.");
      } else {
        $("#tab-cont1").hide();
        //$(".fr").hide();
        $("#tab-cont2").show();

        $("#groupList").hide();
        $("#groupCreate").show();

        $(".tabs li").eq(0).removeClass('on');
        $(".tabs li").eq(1).addClass('on');
      }
    } else {
      if (confirm("이 페이지에서 나가시겠습니까?\n작성중인 내용이 저장되지 않습니다.")) {
        this.setState({displadyState:'L'});
      } 
      
    }
  }

  render() {
    const fncBtnInfo = this.props.memberInfo.dspUserFncBtnInfo;
        return (
          <section className="body">

            <div className="wrapper">

              <div className="page_header">
                <h2 className="ptitle">{this.state.displadyState == 'C' ? this.props.messages.auth_group_registration : this.props.messages.auth_group_status}</h2>
                <div className="page_nav">
                  {/*<ul>
                    <li><Link to="/">Home</Link></li>
                    <li><Link to="/userlist">{this.props.messages.user_management}</Link></li>
                    <li className="here">{this.state.displadyState == 'C' ? this.props.messages.auth_group_registration : this.props.messages.auth_group_status}</li>
                  </ul>*/}
                </div>
              </div>
              <div className="content_wrap">

                <div className="content_outbox">

                  <div className="tab_wrap tab-wrap">

                    <div className="box_both tab_header">
                      <div className="fl">
                        <ul className="tabs">
                          <li  className={this.state.displadyState == 'L' ? "tab_item tab-item on" : "tab_item tab-item"}>
                            <a href="javascript:;" onClick={() => {this.handleTabsChange('List')}} className="tab-link"><span>{this.props.messages.common_list}</span></a>
                          </li>
                          <li className={this.state.displadyState != 'L' ? "tab_item tab-item on" : "tab_item tab-item"}>
                            <a href="javascript:;" className={this.state.displadyState == 'L' ? "tab-link disabled" : "tab-link"}><span>{this.props.messages.common_detail}</span></a>
                          </li>
                        </ul>
                      </div>
                      <div className="fr">
                        <div className="btn_group" style={this.state.displadyState === 'C' ? {} : {display:'none'}}>
                          <button type="button" className="btn_pos" onClick={() => {this.AuthGroupCreate.handleInitState()}}>{this.props.messages.common_reset}</button>
                          <button disabled={fncBtnInfo['funcModYn']=='N'} type="button" className="btn_black" onClick={() => {this.AuthGroupCreate.handleSave('')}}>{this.props.messages.common_ok}</button>
                        </div>
                        <div className="btn_group" style={this.state.displadyState === 'R' ? {} : {display:'none'}}>
                        <button type="button" className="btn_black" onClick={() => this.setState({displadyState:'L'})}>{this.props.messages.common_cancel}</button>
                          <button disabled={fncBtnInfo['funcModYn']=='N'} type="button" className="btn_black" onClick={() => {this.authGroupDetail.handleSave('R')}}>{this.props.messages.common_ok}</button>
                        </div>
                      </div>
                    </div>
                    {this.state.displadyState == 'L' 
                                    ? <AuthGroupList onRef={ref => (this.AuthGroupList = ref)}
                                                    onDisplaySetting={this.handleDisplaySetting} 
                                                    onDetailView={this.handleDetailView}
                                                    pageInfo={this.state.pageInfo}
                                                    onPageInfoChange={this.handlePageInfoChange}
                                                    /> 
                                    : <AuthGroupDetail onRef={ref => (this.authGroupDetail = ref)} onDisplaySetting={this.handleDisplaySetting} groupSeq={this.state.groupSeq}/>
                    }

                  </div>

                </div>

              </div>

            </div>
          </section>
        );
    }
}

export default connect(mapStateToProps)(AuthGroup);
