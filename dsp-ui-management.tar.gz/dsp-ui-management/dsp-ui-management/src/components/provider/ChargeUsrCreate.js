/*jshint esversion: 6 */
import React from 'react';

import {REST_API_URL} from '../../config/api-config.js';

/*다국어 모듈 시작*/
import { connect } from 'react-redux';
import { changeLangauge, mapStateToProps, actionlogin } from '../../language/Actions';
import { parse } from 'query-string';
/*다국어 모듈 종료*/

/* 유효성 체크 */
import validator from 'validator';

const initialState ={
    custmNo : 0,
    chargeUsrSeq : 0,
    chargeUsrName : "",
    chargeUsrDeptName : "",
    chargeUsrPositName : "",
    chargeUsrEmail : "",
    chargeUsrTel : "",
    chargeUsrMobileNo : "",
    chargeUsrClasCode : "",
    chargeUsrClasName : "",
    rpsntYn : "",
}

class ChargeUsrCreate extends React.Component {

	constructor(props) {
		super(props);

        this.state = $.extend(true, {}, initialState);
        

		this.handleChange = this.handleChange.bind(this);
        this.handleSave = this.handleSave.bind(this);

    }

    //컴포넌트가 만들어지고 첫 렌더링을 다 마친 후 실행되는 메소드입니다.
	componentDidMount() {
        this.props.onRef(this);

        this.state = $.extend(true, {}, initialState);
       
        this.initEvent();
    }
    
    initEvent(){

        let self = this;

        $('#chargeUsrClasCode').on('change',function(obj){
			self.handleChange(obj);

        });
    }

	//컴포넌트가 DOM 에서 사라진 후 실행되는 메소드입니다.
	componentWillUnmount() {
		this.props.onRef(null);
	}

    handleSave() {

        console.log("전달 되는 객체 ==>"+JSON.stringify(this.state));

        if(this.validationChecke()) {
            this.props.onChargeUsrAdd(this.state);

            this.hide();
        }
        
    }

	validationChecke() {


        if(this.state.chargeUsrName.trim() == "") {
            alert("담당자 이름을 입력하세요.");
            return false;
        }

        if(this.state.chargeUsrEmail.trim() == "") {
            alert("담당자 E-mail을 입력하세요.");
            return false;
        }else {
            if (!validator.isEmail(this.state.chargeUsrEmail)) {
                alert("이메일 형식이 잘못 입력 되었습니다.");
                return false;
            }
        }

        if(this.state.chargeUsrTel.trim() == "") {
            alert("전화번호를 입력하세요.");
            return false;
        }

        if(this.state.chargeUsrMobileNo.trim() == "") {
            alert("휴대폰번호를 입력하세요.");
            return false;
        }

        if(this.props.rpsntYn && this.state.rpsntYn != 'Y'){
           alert('대표자 지정을 체크 하세요');
           return false; 
        }

		return true;

    }
    maxLengthCheck(e){
        e.target.value = e.target.value.replace(/[^0-9]/g,"");
    
        if(e.target.value.length > e.target.maxLength){
          e.target.value = e.target.value.slice(0, e.target.maxLength);
        }
    }

	handleChange(e) {
        if(e.target.name=='rpsntYn'){
            if($('input[name=rpsntYn]:checked')){
                this.setState({
                    rpsntYn : 'Y'
                });
            }

        }else if(e.target.name=='chargeUsrClasCode'){
            let nextState = {
                chargeUsrClasCode : e.target.value,
                chargeUsrClasName : $('#chargeUsrClasCode option:selected').text()
            };
            this.setState(nextState);
        }else{
            let nextState = {};
            nextState[e.target.name]=e.target.value;
            this.setState(nextState);
        }

        console.log(JSON.stringify(this.state));

    }

    complete() {
        this.props.onProviderUsrComplete(this.state);
        this.hide();
    }

    hide() {
        layer_close(".pop-pvmanager-register");
    }

    show() {

        this.state = $.extend(true, {}, initialState);
        this.initSelect();

        let nextState = ({
            custmNo : this.props.custmNo,
        });

        this.setState(nextState);

        
        layer_open(".pop-pvmanager-register");
    }

    initSelect(){
        if ( $('.ui-sel').length > 0 ){
            $('.ui-sel').each(function(){
                $(this).selectric();//초기화
            });	
        }
    }

    getListProviderUsr() {
        $.ajax({
            url: REST_API_URL + "/provider/chargeUsrList",
            dataType: 'json',
            type: "post",
            data: {custmNo : this.state.custmNo},
            cache: false,
            success: function(result) {

                console.log(JSON.stringify(result));
                this.props.onPageInfoChange(result.response.pageInfo, false);
                this.setState({
                    list: result.response.list
                });
            }.bind(this),
            error: function(xhr, status, err) {
            console.log(xhr + " : " + status + " : " + err);
            }.bind(this),
            xhrFields: {
            withCredentials: true
            }
        });
    
    }
    
    render() {
        return (
            <div className="lpopup">
                <div className="dimmed" />
                <div className="popup_layer pop_manager_register pop-pvmanager-register mid">
                    <div className="pop_container">
                        <div className="pop_header">
                            <h1>담당자 정보</h1>
                        </div>
                        { /* pop_contents */ }
                        <div className="pop_contents">
                            <div className="pop_inner">
                                <table className="tbl_row">
                                    <caption>담당자 정보 목록</caption>
                                    <colGroup>
                                        <col style={{width:"130px"}}/>
                                        <col style={{width:"auto"}}/>
                                    </colGroup>
                                    <tbody>
                                        <tr>
                                            <th scope="row">담당자 이름 <span className="tc_red">*</span></th>
                                            <td className="input">
                                                <input type="text" 
                                                    className="ui_input" 
                                                    name="chargeUsrName" 
                                                    value={this.state.chargeUsrName}  
                                                    onChange={this.handleChange}
                                                    maxLength={100}
                                                />
                                            </td>
                                        </tr>
                                        <tr>
                                            <th scope="row">부서</th>
                                            <td className="input">
                                                <input type="text" 
                                                    className="ui_input" 
                                                    name="chargeUsrDeptName" 
                                                    value={this.state.chargeUsrDeptName}  
                                                    onChange={this.handleChange}
                                                    maxLength={100}
                                                />
                                            </td>
                                        </tr>
                                        <tr>
                                            <th scope="row">직위</th>
                                            <td className="input">
                                                <input type="text" 
                                                    className="ui_input" 
                                                    name="chargeUsrPositName" 
                                                    value={this.state.chargeUsrPositName}
                                                    onChange={this.handleChange}
                                                    maxLength={100}
                                                />
                                            </td>
                                        </tr>
                                        <tr>
                                            <th scope="row">담당자 이메일 <span className="tc_red">*</span></th>
                                            <td className="input">
                                                <input type="text" 
                                                    className="ui_input" 
                                                    name="chargeUsrEmail" 
                                                    value={this.state.chargeUsrEmail}  
                                                    onChange={this.handleChange}
                                                    maxLength={50}
                                                />
                                            </td>
                                        </tr>
                                        <tr>
                                            <th scope="row">전화번호 <span className="tc_red">*</span></th>
                                            <td className="input">
                                                <input type="text" 
                                                    className="ui_input" 
                                                    name="chargeUsrTel" 
                                                    value={this.state.chargeUsrTel} 
                                                    onChange={this.handleChange}
                                                    onInput={this.maxLengthCheck.bind(this)}
                                                    maxLength={20}
                                                />
                                            </td>
                                        </tr>
                                        <tr>
                                            <th scope="row">휴대폰번호 <span className="tc_red">*</span></th>
                                            <td className="input">
                                                <input type="text" 
                                                    className="ui_input" 
                                                    name="chargeUsrMobileNo" 
                                                    value={this.state.chargeUsrMobileNo} 
                                                    onChange={this.handleChange}
                                                    onInput={this.maxLengthCheck.bind(this)}
                                                    maxLength={20}
                                                />
                                            </td>
                                        </tr>
                                        <tr>
                                            <th scope="row">담당업무</th>
                                            <td className="input">
                                                <select className="ui_sel" id='chargeUsrClasCode' name="chargeUsrClasCode" value={this.state.chargeUsrClasCode}>
                                                    <option value="">선택</option>
                                                    <option value="01">계약</option>
                                                    <option value="02">정산</option>
                                                    <option value="03">영업</option>
                                                    <option value="04">관리</option>
                                                </select>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th scope="row">대표자 지정</th>
                                            <td className="input">
                                            <input type="checkbox" 
                                                className="ui_input" 
                                                name="rpsntYn" 
                                                value="Y"
                                                checked={this.state.rpsntYn === 'Y' ? true : false}
                                                onChange={this.handleChange}
                                            />
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>	
                        { /*// pop_contents*/ }
                        <div className="pop_bottom">
                            <button type="button" className="pbtn_pos" onClick={() => {this.hide();}} >취소</button>
                            <button type="button" className="pbtn_black" onClick={this.handleSave}>확인</button>
                        </div>
                    </div>{ /*// pop_container */ }
                    <a onClick={() => {this.hide()}} className="btn_pop_close"><span className="offscreen">닫기</span></a>
                </div>
                { /*// popup_layer */ }
            </div>
        );
    }
}

export default connect(mapStateToProps)(ChargeUsrCreate);

