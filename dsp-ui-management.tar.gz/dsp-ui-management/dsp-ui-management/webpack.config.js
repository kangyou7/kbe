var ExtractTextPlugin = require('extract-text-webpack-plugin');


var NODE_ENV = process.env.active || 'dev'
var webpack = require('webpack');

module.exports = {

  	entry: "./src/index.js",
  
  module: {
	  loaders: [
	      {
	          test: [/\.jsx?$/, /\.js?$/],
	          loader: 'babel-loader',
	          exclude: /node_modules/,
	          query: {
	              cacheDirectory: true,
	              presets: ['es2015', 'react']
	          }
	      },
	      {
	          test: /\.css$/,
	          loader : "style-loader!css-loader"
	        },
	      
	     { test: /\.(png|woff|woff2|eot|ttf|svg)$/, loader: 'url-loader?limit=100000' }
	  ]
  },
  
  output: {
	path: __dirname + '/public',
    filename: "app.bundle.js",
	publicPath: '/public/',

  },
  
	plugins: [
		new ExtractTextPlugin("styles.css")
		,new webpack.DefinePlugin({
			'process.env.active': JSON.stringify(NODE_ENV)
		})
		/*
		,new webpack.LoaderOptionsPlugin({
			options: {
				'active': 'ssssaaaa'
			}
		})
		*/
	],
  
  devServer: {
      inline: true,
      //host: '10.250.238.147',
      contentBase: __dirname + '/public/',
      historyApiFallback: true
  }
  
};