import React from 'react';
import { Link, browserHistory } from 'react-router';
/*다국어 모듈 시작*/
import { connect } from 'react-redux';
import { changeLangauge, mapStateToProps } from './language/Actions';
import { bindActionCreators } from 'redux';

/*다국어 모듈 종료*/
import {REST_API_URL, SITE_DOMAIN, REST_AUTH_URL} from './config/api-config.js';
import AttachFile from './components/common/AttachFile';


class Main extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            ticketCount : {
              waitingCnt : "0",
              approveCnt : "0",
              refuseCnt : "0"
            },
            tempSaveList : [],
            noticeList : [],
            processNoticeList : [],
            tempSaveListCnt : "0",
            processNoticeCnt : "0",
            searchKeyCode : "",
            searchKeyWord : "",
            pageInfo:{
              searchCode : "02",
              //totalCount : 0,
              perPageNum : 0
              //page : 0
            }
        }
    }
    componentWillMount() {
        $("body").attr('class','main_height');
    }

    static fetchData(dispatch){
		var cl = bindActionCreators(changeLangauge, dispatch);
		return Promise.all([
			cl.changeLang()
		]);
    }

    getUserTicketCount() {
        let memberInfo = JSON.parse(localStorage.getItem("memberInfo"));

        $.ajax({
            url: REST_API_URL+"/main/getUserTicketCount",
            dataType: 'json',
            type: "post",
            data : {
              loginUserNo : memberInfo.user_no
            },
            xhrFields : {
              withCredentials : true
            },
            success: function(result) {
              if (result.response != null) {
                this.setState({
                  ticketCount : result.response
                })
              }
            }.bind(this),
            error: function(xhr, status, err) {
                console.log(xhr + " : " + status + " : " + err);
            }.bind(this)
        });
    }

    getTempSaveList() {
        let memberInfo = JSON.parse(localStorage.getItem("memberInfo"));

        $.ajax({
            url: REST_API_URL+"/main/getTempSaveList",
            dataType: 'json',
            type: "post",
            data : {
              loginUserNo : memberInfo.user_no
            },
            xhrFields : {
              withCredentials : true
            },
            success: function(result) {
              this.setState({
                tempSaveList : result.response.tempSaveList,
                tempSaveListCnt : result.response.tempSaveListCnt
              })
            }.bind(this),
                error: function(xhr, status, err) {
                console.log(xhr + " : " + status + " : " + err);
            }.bind(this)
        });
    }

    getNoticeList() {
      this.state.pageInfo.perPageNum = "5";

      $.ajax({
        url: REST_API_URL+"/main/getNoticeList",
        dataType: 'json',
        type: "post",
        data: this.state.pageInfo,
        xhrFields : {
          withCredentials : true
        },
        success: function(result) {
          
          this.setState({
            noticeList : result.response.list
          });
        }.bind(this),
        error: function(xhr, status, err) {
          console.log(xhr + " : " + status + " : " + err);
        }.bind(this)
      });
    }

    getProcessNoticeList() {
      this.state.pageInfo.perPageNum = "0";
      this.state.pageInfo.searchCode = "03";

      $.ajax({
        url: REST_API_URL+"/main/getNoticeList",
        dataType: 'json',
        type: "post",
        data: this.state.pageInfo,
        xhrFields : {
          withCredentials : true
        },
        success: function(result) {
          
          this.setState({
            processNoticeList : result.response.list,
            processNoticeCnt : result.response.list.length
          });
        }.bind(this),
        error: function(xhr, status, err) {
          console.log(xhr + " : " + status + " : " + err);
        }.bind(this)
      });
    }

    logOut() {
      if (confirm("로그아웃 하시겠습니까?")) {
        $.ajax({
          url: REST_AUTH_URL+"/log_out",
          dataType: 'json',
          type: "post",
          data: "",
          xhrFields : {
            withCredentials : true
          },
          success: function(result) {
            
            this.setState({
              processNoticeList : result.response.list,
              processNoticeCnt : result.response.list.length
            });
          }.bind(this),
          error: function(xhr, status, err) {
            alert(JSON.stringify(xhr.responseJSON.message));
            console.log(JSON.stringify(xhr) + " : " + status + " : " + err);
          }.bind(this)
        });
  
        localStorage.clear(); 
  
        browserHistory.push("/login");
      }
    }

    goTicket() {
      location.href = "ticket";
    }

    popShow() {
        this.getTempSaveList();
        layer_open(".pop-temp-inbox");
    }

    popHide() {
        layer_close(".pop-temp-inbox");
    }

    tabClick(tabId) {

      //tab활성화 변경
      $(".tab_item").each(function (){
        $(this).removeClass("on");
      });

      if (tabId == "tab-cont1") {
        $(".tab_item").eq(0).addClass("on");
      }
      if (tabId == "tab-cont2") {
        $(".tab_item").eq(1).addClass("on");
      }
      if (tabId == "tab-cont3") {
        $(".tab_item").eq(2).addClass("on");
      }

      //내용 활성화
      $("#tab-cont1").hide();
      $("#tab-cont2").hide();
      $("#tab-cont3").hide();

      $("#"+tabId).show();
    }

    noticeDetail(noticeNo) {
      location.href="/providerNotice?noticeNo=" + noticeNo;      
    }

    componentDidUpdate(){
      // this.props.onRef(null)
      if(this.state.processNoticeCnt != "0"){
        if ($('.mbox-process').find('.process-slide > ul > li').length > 0){
          prevNextRollingBanner('.mbox-process', '.process-slide > ul', 3000);
        }
      }
    }
    
    componentDidMount(){
      // this.props.onRef(this)
      if(!this.props.messages){
        this.constructor.fetchData(this.props.dispatch);
      }
      this.getUserTicketCount();
      this.getNoticeList();
      this.getProcessNoticeList();
    }

    // componentDidMount() {
    //   this.props.onRef(this)
    //   $("#tab-cont1").show();
    // }
    // componentWillUnmount() {
    //   this.props.onRef(null)
    // }

    getcookie(name) {
      var value = document.cookie.match('(^|;) ?' + name + '=([^;]*)(;|$)');
      return value? value[2] : null;
    }

    render() {
    
      const memberInfo = JSON.parse(localStorage.getItem('memberInfo'));
      if(!memberInfo) {
        browserHistory.push("/login");   
      }
          const mapToNoticeList = (data) => {
            if(data.length > 0) {
              
                return data.map((noticeData, i) => {
                  //console.log(noticeData.noticeNo);
                  if (noticeData.attachFile.length != 0) {
                    return(
                      <tr key={i}>
                          <td><a href="javascript:" onClick={() => {this.noticeDetail(noticeData.noticeNo)}} className="tc_gray">{noticeData.noticeTitle}</a></td>
                          <td>
                            <AttachFile key={i} onRef={ref => (this.attachFile = ref)}
                            attachFileId={noticeData.attachFileId}
                            files={noticeData.attachFile} 
                            onChange={this.handleFileChange} 
                            onUploadResult={this.handleScheduleSave}
                            />
                            
                          </td>
                          <td>{noticeData.regUsrName}</td>
                          <td>{noticeData.noticeStrDate}</td>
                      </tr>
                    );
                  } else {
                    return(
                      <tr key={i}>
                          <td><a href="javascript:" onClick={() => {this.noticeDetail(noticeData.noticeNo)}} className="tc_gray">{noticeData.noticeTitle}</a></td>
                          <td>-</td>
                          <td>{noticeData.regUsrName}</td>
                          <td>{noticeData.noticeStrDate}</td>
                      </tr>
                    );
                  }
                });
            } else {
                return (
                  <tr>
                    <td className="noresults" colSpan={4}>
                      <div className="box_noresults">
                        <div className="ver_mid">													
                          <i className="ico ico_no_result"></i>
                          <span className="lb">{this.props.messages.common_no_data}</span>
                        </div>
                      </div>
                    </td>
                  </tr>
                );
            }
          }

        const mapToProcessNoticeList = (data) => {
          if(data.length > 0) {
              return data.map((noticeData, i) => {
                let strDate = noticeData.noticeStrDate;
                  return(
                      <li key={i}>
                        <span className="lb">{this.props.messages.main_process_change}</span>
                        {/* <!-- Com : 20180223 프로세스 변경 안내 title 영역이 link가 아닌 경우 strong 태그 사용 --> */}
                        <strong className="title">[{noticeData.procChgDstnctName}] {noticeData.noticeTitle}</strong>
                        <span className="gap"></span>
                        <span className="date">{strDate.substring(0,10)}</span>
                      </li>
                  );
              });
          }
        }

        const mapToTempList = (data) => {
            if(data.length > 0) {
                return data.map((tempData, i) => {
                    return(
                        <tr key={i}>
                            <td>{tempData.rownum}</td>
                            {/*<td>{tempData.cntrctClasCode}</td>*/}
                            <td>{tempData.cntrctClasCodeName}</td>
                            {/*<td>{tempData.productName}</td>*/}
                            <td>{tempData.customName}</td>
                            <td>{tempData.regDate}</td>
                        </tr>
                    );
                });
            } else {
                return (
                    <tr>
                        <td className="noresults" colSpan={5}>
                            <div className="box_noresults">
                                <div className="ver_mid">													
                                    <i className="ico ico_no_result"></i>
                                    <span className="lb">{this.props.messages.common_no_data}</span>
                                </div>
                            </div>
                        </td>
                    </tr>
                );
            }
        }
        return (
            <section className="body">
            <div className="wrapper">
              <div className="page_header offscreen">
                <h2 className="ptitle">메인</h2>
              </div>
              <div className="content_wrap">
                <div className="m_row_group">
                  <div className="moutbox mbox_userinfo">
                    <div className="profile_box">
                      <div className="profile_info">
                        <strong className="name" title={this.props.memberInfo.user_name}>{this.props.memberInfo.user_name}</strong>
                        <span className="business_num" title={this.props.memberInfo.user_id}>{this.props.memberInfo.user_id}</span>
                      </div>
                      <a href="javascript:;" onClick={() => {this.logOut()}} className="btn_pos">{this.props.messages.main_logout}</a>
                    </div>
                    
                    <div className="con_box">
                      <a href="javascript:;" onClick={() => {this.goTicket()}} className="ctitle"><i className="ico_list"></i>{this.props.messages.main_my_tasks}</a>
                      
                      <ul className="confirm_status">
                        <li>
                          <span className="stitle">{this.props.messages.main_in_progress} / {this.props.messages.main_completed}</span>
                          {/* <!-- Com : 20180222 결재건수가 링크태그인 경우 a태그 사용 --> */}
                          <span className="count_num">
                            <span className="tc_blue">{this.state.ticketCount.waitingCnt}</span> / <span className="tc_blue"> {this.state.ticketCount.approveCnt}</span>
                           {this.props.messages.main_count}
                          </span>
                        </li>
                        {/* <li>
                          <span className="stitle">{this.props.messages.main_completed}</span>
                          <span className="count_num"><span className="tc_blue">{this.state.ticketCount.approveCnt}</span> {this.props.messages.main_count}</span>
                        </li> */}
                        <li>
                          <span className="stitle">{this.props.messages.main_postpone}</span>
                          {/* <!-- Com : 20180222 결재건수가 링크태그가 아닌 경우 span태그 사용 --> */}
                          {/* <span className="count_num"><a href="javascript:;" className="tc_blue">{this.state.ticketCount.refuseCnt}</a> 건</span> */}
                          <span className="count_num"><span className="tc_blue">{this.state.ticketCount.refuseCnt}</span> {this.props.messages.main_count}</span>
                          {/* <!-- <span className="count_num"><span className="tc_blue">2</span> 건</span> --> */}
                        </li>
                      </ul>
                    </div>
                    
                    <div className="con_box">
                      <a href="javascript:;" onClick={() => {this.popShow();}} className="ctitle"><i className="ico_inbox"></i>{this.props.messages.main_temporary_documents}</a>
                    </div>
                  </div>
                  <div className="moutbox mbox_notice">
                    <div className="box_com">
                      <div className="fl">
                        <h3 className="ctitle">{this.props.messages.main_notices}</h3>
                      </div>
                      <div className="fr">
                        <Link to="/providerNotice" className="btn_pos">{this.props.messages.main_more}</Link>
                        {/* <a href="javascript:;" className="btn_pos">더보기</a> */}
                      </div>
                    </div>
                    
                    <table className="tbl_col">
                      <caption>공지사항 목록</caption>
                      <colgroup>
                        <col style={{width: '30%'}}/>
                        <col style={{width: '20%'}}/>
                        <col style={{width: '25%'}}/>
                        <col style={{width: '25%'}}/>
                      </colgroup>
                      
                      <thead>
                        <tr>
                          <th scope="col">{this.props.messages.main_title}</th>
                          <th scope="col">{this.props.messages.main_attachments}</th>
                          <th scope="col">{this.props.messages.main_writer}</th>
                          <th scope="col">{this.props.messages.main_registration_date}</th>
                        </tr>
                      </thead>
                      
                      <tbody>
                        {mapToNoticeList(this.state.noticeList)}
                      </tbody>
                    </table>
                  </div>
                </div>
               
                <div className="m_row_group">
                  <div className="moutbox mbox_process mbox-process">
                    <div className="process_slide process-slide">
                      <ul>
                        {mapToProcessNoticeList(this.state.processNoticeList)}
                      </ul>
                    </div>
                    
                    <div className="controls">
                      <span className="num_wrap">
                        <span className="num-current tc_blue">1</span>
                        /
                        <span className="num_total num-total">{this.state.processNoticeCnt}</span>
                      </span>
                      <div className="btn_wrap">
                        <a href="javascript:;" className="prev"><span className="offscreen">이전내용</span></a>
                        <a href="javascript:;" className="next"><span className="offscreen">다음내용</span></a>
                      </div>
                    </div>
                  </div>
                </div>
               
                
               
                <div className="content_outbox m_row_group">
                 
                  <div className="tab_wrap tab-wrap">
                    
                    <div className="box_both tab_header">		
                      <div className="fl">
                        <ul className="tabs">
                          <li className="tab_item tab-item on" onClick={() => {this.tabClick('tab-cont1');}}>
                            <a href="#tab-cont1"  className="tab-link"><span>{this.props.messages.main_work_progress}</span></a>
                          </li>
                          <li className="tab_item tab-item" onClick={() => {this.tabClick('tab-cont2');}} style={{display:'none'}}>
                            <a href="#tab-cont2"  className="tab-link"><span>{this.props.messages.main_sales_progress}</span></a>
                          </li>
                          <li className="tab_item tab-item" onClick={() => {this.tabClick('tab-cont3');}} style={{display:'none'}}>
                            <a href="#tab-cont3"  className="tab-link"><span>{this.props.messages.main_execution_progress}</span></a>
                          </li>
                        </ul>
                      </div>
                      <div className="fr">
                      </div>
                    </div>

                    <div id="tab-cont1" className="tab_content tab-cont no_paging" style={{display: 'block'}}>
                      <div className="content_body">
                        <div className="content_inner">
                          <img src="../../images/temp/process_01.png" alt="" />
                        </div>
                      </div>
                    </div>

                    <div id="tab-cont2" className="tab_content tab-cont no_paging" style={{display: 'none'}}>
                      <div className="content_body">
                        <div className="content_inner">
                          추후 이미지는 교체 작업이 예정
                        </div>
                      </div>
                    </div>
                    
                    <div id="tab-cont3" className="tab_content tab-cont no_paging" style={{display: 'none'}}>
                      <div className="content_body">
                        <div className="content_inner">
                          추후 이미지는 교체 작업이 예정
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="lpopup">
                <div className="dimmed"></div>
                <div className="popup_layer pop_temp_inbox pop-temp-inbox lg">
                    <div className="pop_container">
                        <div className="pop_header">
                            <h1>{this.props.messages.main_temporary_documents}</h1>
                        </div>
                        <div className="pop_contents scroll_wrap">
                            <div className="pop_inner">
                                <div className="box_com">
                                    <div className="fl">
                                        {this.props.messages.main_temporary_document} : 
                                        <span className="total">{this.props.messages.main_total} 
                                        <span className="tc_blue">{this.state.tempSaveListCnt}</span>{this.props.messages.main_count}</span>
                                    </div>
                                    {/* <div className="fr">
                                        <a href="javascript:;" className="btn_pos">삭제</a>
                                    </div> */}
                                </div>
                                <table className="tbl_col">
                                    <caption>임시문서함 목록</caption>
                                    <colgroup>
                                        <col style={{width: '8%'}}/>
                                        <col style={{width: '20%'}}/>
                                        <col style={{width: '52%'}}/>
                                        <col style={{width: '20%'}}/>
                                    </colgroup>
                                    
                                    <thead>
                                        <tr>
                                            <th scope="col">No</th>
                                            {/*<th scope="col">{this.props.messages.main_division}</th>*/}
                                            <th scope="col">{this.props.messages.main_contract_division}</th>
                                            {/*<th scope="col">{this.props.messages.main_title}</th>*/}
                                            <th scope="col">{this.props.messages.main_customer_name}</th>
                                            <th scope="col">{this.props.messages.main_update_time}</th>
                                        </tr>
                                    </thead>
                                    
                                    <tbody>
                                        {mapToTempList(this.state.tempSaveList)}
                                    </tbody>
                                </table>
                            </div>
                        </div>	
                        
                        <div className="pop_bottom">
                            <a href="javascript:;" onClick={() => {this.popHide();}} className="pbtn_black">{this.props.messages.main_ok}</a>
                        </div>
                    </div>
                    <a href="javascript:;" onClick={() => {this.popHide();}} className="btn_pop_close"><span className="offscreen">{this.props.messages.main_close}</span></a>
                </div>
            </div>
          </section>
        );
    }
}



//export default Main;
export default connect(mapStateToProps)(Main);
