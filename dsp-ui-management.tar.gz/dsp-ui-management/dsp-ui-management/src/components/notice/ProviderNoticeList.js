import React from 'react';

import { Link } from 'react-router';
import { browserHistory } from 'react-router';

import PagingView from '../common/PagingView';
import ColumnChange from '../common/ColumnChange';
import {TableThead, TableColgroup} from '../common/TableThead';
//import TableThead from '../common/TableThead';

import {REST_API_URL} from '../../config/api-config.js';

/*다국어 모듈 시작*/
import { connect } from 'react-redux';
import { changeLangauge, mapStateToProps } from '../../language/Actions';
/*다국어 모듈 종료*/


class ProviderNoticeList extends React.Component {

  constructor(props) {
    super(props);

    this.state = {
      searchKeyCode : "",
      searchKeyWord : "",

      checkedIndex : "",
      checkednoticeNo : "",
      list : [],
      pageInfo:{
        searchCode : "02"
        //totalCount : 0,
        //perPageNum : 0,
        //page : 0
      }
    }

    this.handleChange = this.handleChange.bind(this);
    this.handleSearch = this.handleSearch.bind(this);
    this.handlePageChange = this.handlePageChange.bind(this);

    this.handleColumnChangeView = this.handleColumnChangeView.bind(this);
    this.handleColumnChange = this.handleColumnChange.bind(this);
    this.handleDetailView = this.handleDetailView.bind(this);
    this.handleSort = this.handleSort.bind(this);
    this.handleDelete = this.handleDelete.bind(this);
    this.handleCheckBoxClick = this.handleCheckBoxClick.bind(this);
  }

  handleChange(e) {
    let nextState = {};
    nextState[e.target.name]=e.target.value;
    this.setState(nextState);
  }

  getList() {
    
    $.ajax({
      url: REST_API_URL+"/notice/List",
      dataType: 'json',
      type: "post",
      data: this.state.pageInfo,
      xhrFields : {
        withCredentials : true
      },
      success: function(result) {
        
        this.setState({
          list: result.response.list,
          pageInfo : result.response.pageInfo
        });

        $("#listChkAll").prop("checked",false);
        $("input[name='listCheck']").prop("checked",false);
        
      }.bind(this),
      error: function(xhr, status, err) {
        console.log(xhr + " : " + status + " : " + err);
      }.bind(this)
    });
  }

  handleSearch() {
    let pageInfo = this.state.pageInfo;
    pageInfo.searchKeyCode = this.state.searchKeyCode;
    pageInfo.searchKeyWord = this.state.searchKeyWord;
    this.setState({
      pageInfo : pageInfo
    })
    this.getList();
  }



  //페이지 변경 및 페이지 출력 갯수 변경
  handlePageChange(perPageNum, page) {

    let changePage = this.state.pageInfo;
    changePage.perPageNum = perPageNum;
    changePage.page = page;
    this.setState({
      pageInfo:changePage
    })


    this.getList();

  }

  handleSort(sort) {
    let sortPage = this.state.pageInfo;
    sortPage.sortColumn = sort.sortColumn;
    sortPage.sortType = sort.sortType;
    this.setState({
        pageInfo:sortPage
    })

    this.getList();
}


  //항목변경 팝업 호출
  handleColumnChangeView(e) {
    this.columnChange.show();
 }

 //항목변경 팝업에서 항목 변경 후 state 정보 변경
 handleColumnChange(changeThead) {
   this.setState({
     listThead : changeThead
   });
 }

 handleDetailView(index) {
   this.props.onDetailView(this.state.list[index].noticeNo);
 }
 
 //선택항목 삭제
 handleDelete() {
   var reqParam;
   var checkedNotice = "";

   $("input[name='listCheck']").each(function() {
     if ( $(this).is(":checked") ) {

      if (checkedNotice != "") {
        checkedNotice += "|" + $(this).val();
      } else {
        checkedNotice = $(this).val();
      }
     }
   });

   if (checkedNotice == "") {
     alert("삭제할 대상을 선택하시기 바랍니다.");
   } else {
     if (confirm("삭제하시겠습니까?")) {
      reqParam = new Object();
      reqParam.noticeNo = checkedNotice;
      
      $.ajax({
        url: REST_API_URL+"/notice/Delete",
        dataType: 'json',
        type: "post",
        data: reqParam,
        xhrFields : {
          withCredentials : true
        },
        success: function(result) {
          if ( result.response == "SUCCESS" ) {
            alert("삭제 되었습니다.");
            this.getList();
            return;
          } else {
            alert("ERROR..! 관리자에게 문의 바랍니다.");
            return;
          }
          
        }.bind(this),
        error: function(xhr, status, err) {
          console.log(xhr + " : " + status + " : " + err);
        }.bind(this)
        });
     }
   }
 }

 handleCheckBoxClick(e) {
  this.setState({
    checkedAssetsSeq : $(e.target).val(),
    checkedIndex : $(e.target).attr("id")
  });
}

handleCheckAll() {
        
  $("input[name='listCheck']").prop("checked", $("#listChkAll").is(":checked"));
}

  //페이지 로딩 시 목록 조회
  componentDidMount() {
    this.getList();
  }

  render() {
    const fncBtnInfo = this.props.memberInfo.dspUserFncBtnInfo;
      const mapToComponent = (data) => {
        if(data.length > 0) {
          return data.map((notice, i) => {//map
            
            if (notice.fileCnt != "0") {
              if (notice.noticeNewYn == "Y") {
                return(<tr key={i}>
              
                  <td className="ui_only_chk">
                      <span className="input_ico_box">
                        <input type="checkbox" name="listCheck" id={i} value={notice.noticeNo} onClick={this.handleCheckBoxClick}/>
                        <label htmlFor={i}></label>
                      </span>
                  </td>
    
                  <td>{notice.rownum}</td>
                  <td className="input"><i className="ico_file"></i></td>
                  <td><a href="javascript:;" onClick={() => {this.handleDetailView(i);}}>{notice.noticeTitle}<i className="ico_new"><span className="offscreen">새로 등록된 공지</span></i></a></td>
                  <td>{notice.targtTmcnt}</td>
                  <td>{notice.noticeStrDate}</td>
                </tr>);
              } else {
                return(<tr key={i}>
              
                  <td className="ui_only_chk">
                      <span className="input_ico_box">
                        <input type="checkbox" name="listCheck" id={i} value={notice.noticeNo} onClick={this.handleCheckBoxClick}/>
                        <label htmlFor={i}></label>
                      </span>
                  </td>
    
                  <td>{notice.rownum}</td>
                  <td className="input"><i className="ico_file"></i></td>
                  <td><a href="javascript:;" onClick={() => {this.handleDetailView(i);}}>{notice.noticeTitle}</a></td>
                  <td>{notice.targtTmcnt}</td>
                  <td>{notice.noticeStrDate}</td>
                </tr>);
              }
            } else {
              if (notice.noticeNewYn == "Y") {
                return(<tr key={i}>
              
                  <td className="ui_only_chk">
                      <span className="input_ico_box">
                        <input type="checkbox" name="listCheck" id={i} value={notice.noticeNo} onClick={this.handleCheckBoxClick}/>
                        <label htmlFor={i}></label>
                      </span>
                  </td>
    
                  <td>{notice.rownum}</td>
                  <td className="input"></td>
                  <td><a href="javascript:;" onClick={() => {this.handleDetailView(i);}}>{notice.noticeTitle}<i className="ico_new"><span className="offscreen">새로 등록된 공지</span></i></a></td>
                  <td>{notice.targtTmcnt}</td>
                  <td>{notice.noticeStrDate}</td>
                </tr>);
              } else {
                return(<tr key={i}>
              
                  <td className="ui_only_chk">
                      <span className="input_ico_box">
                        <input type="checkbox" name="listCheck" id={i} value={notice.noticeNo} onClick={this.handleCheckBoxClick}/>
                        <label htmlFor={i}></label>
                      </span>
                  </td>

                  <td>{notice.rownum}</td>
                  <td className="input"></td>
                  <td><a href="javascript:;" onClick={() => {this.handleDetailView(i);}}>{notice.noticeTitle}</a></td>
                  <td>{notice.targtTmcnt}</td>
                  <td>{notice.noticeStrDate}</td>
                </tr>);
              }
            }  
          });
        } else {
          return (
            <tr>
              <td className="noresults" colSpan={6}>
                <div className="box_noresults">
                  <div className="ver_mid">
                    <i className="ico ico_no_result"></i>
                    <span className="lb">{this.props.messages.common_no_data}</span>
                  </div>
                </div>
              </td>
            </tr>
          );
        }
      }

      return (
          <div id="tab-cont1" className="tab_content tab-cont" >

            <div className="content_body">

              <div className="content_inner">


                <div className="box_com term_wrap">
                  <div className="fl">
                    <select className="ui_sel" name="searchKeyCode" value={this.state.searchKeyCode} onChange={this.handleChange} >
                      <option value="">선택</option>
                      <option value="noticeTitle">제목</option>
                      <option value="noticeStrDate">게시일</option>
                    </select>
                  </div>
                    <span className="input_search_box" style={{marginLeft: '6px'}}>
                    <input type="text" className="ui_input" name="searchKeyWord" value={this.state.searchKeyWord} onChange={this.handleChange}/>
                    <a id="searchAssets" className="btn_search" href="javascript:void(0);"
                    onClick={this.handleSearch}><span className="offscreen">검색</span></a>
                    </span>

                    <div className="fr">
                    <button type="button" disabled={fncBtnInfo['funcDelYn']=='N'} className="btn_pos" id="btnDelete" onClick={this.handleDelete}>{this.props.messages.notice_delete}</button>
                    <Link to="/providerNoticeCreate" className="gnb_link"><button disabled={fncBtnInfo['funcRegYn']=='N'} type="button" className="btn_black">{this.props.messages.notice_registration}</button></Link>
                    </div>
                </div>


                <table className="tbl_col">
                  <caption>Provider 공지</caption>
                  <colgroup>
                    <col style={{width : "2%"}}/>
                    <col style={{width : "2%"}}/>
                    <col style={{width : "3%"}}/>
                    <col style={{width : "63%"}}/>
                    <col style={{width : "10%"}}/>
                    <col style={{width : "15%"}}/>
                  </colgroup>
                  <thead>
                    <tr>
                      <th scope="col" className="ui_only_chk">
                          <span className="input_ico_box">
                              <input type="checkbox" name="chk_box" id="listChkAll" onClick={() => {this.handleCheckAll()}}/>
                              <label htmlFor="listChkAll"></label>
                          </span>
                      </th>
                      <th scope="col">No</th>
                      <th scope="col" className="input"><i className="ico_file"></i></th>
                      <th scope="col">{this.props.messages.notice_title}</th>
                      <th scope="col">{this.props.messages.notice_inquiry_count}</th>
                      <th scope="col">{this.props.messages.notice_post_date}</th>
                    </tr>
                  </thead>
                  
                  {/* <TableColgroup listThead={this.state.listThead} />
                  <TableThead listThead={this.state.listThead} onSort={this.handleSort}/> */}

                  <tbody id="contractTbody">
                    {mapToComponent(this.state.list)}
                  </tbody>
                </table>

              </div>

            </div>

            <PagingView pageInfo={this.state.pageInfo} onPageChange={this.handlePageChange}/>

            {/* <ColumnChange ref="columnChange" listThead={this.state.listThead} onColumnChange={this.handleColumnChange} /> */}
            
          </div>

      );
    }
}

export default connect(mapStateToProps)(ProviderNoticeList);
