import React from 'react';

import axios from 'axios';

import {REST_API_URL} from '../../config/api-config.js';

/*다국어 모듈 시작*/
import { connect } from 'react-redux';
import { changeLangauge, mapStateToProps } from '../../language/Actions';
/*다국어 모듈 종료*/

class CodeSelect extends React.Component {

    constructor(props) {
        super(props);

        this.state = {
            upprCommCode : "",
            codeList : []
        }
    }
    componentDidMount() {

        if ( $('.ui-sel').length > 0 ){
            $('.ui-sel').each(function(){
                $(this).selectric();//초기화
            });	
        }

        
        if(this.props.upperCode === undefined) {
            let searchCode = {
                commCodeListId : this.props.groupCode
            }
            this.getCode(searchCode, true);
        }

        let self = this;
        $("#" + this.props.name).on("change", function(obj){
            self.props.onChange(obj);
        })
    }

    componentWillReceiveProps(nextProps){

        if(nextProps.upperCode != undefined && nextProps.upperCode != "") {
            if(this.state.upprCommCode != nextProps.upperCode.upprCommCode) {
                let searchCode = {
                    commCodeListId : nextProps.groupCode,
                    upprCommCodeListId : nextProps.upperCode.upprCommCodeListId,
                    upprCommCode : nextProps.upperCode.upprCommCode
                }
                this.setState({
                    upprCommCode : nextProps.upperCode.upprCommCode,
                })
                this.getCode(searchCode, false);
            }
        }
    }

    componentDidUpdate() {
        $("#" + this.props.name).data("selectric").refresh();
    }

    getCode(searchCode, type) {
        let url = "/code/CommCodeList";
        if(!type) {
            url = "/code/getChildCommCodeList";
        }
		$.ajax({
			url: REST_API_URL + url,
			dataType: 'json',
			type: "post",
            data: searchCode,
			cache: false,
			success: function(result) {
				this.setState({
                    codeList:result.response.list
                });

                if ( $('.ui-sel').length > 0 ){
                    $('.ui-sel').each(function(){
                        $(this).selectric();//초기화
                    });	
                }
			}.bind(this),
				error: function(xhr, status, err) {
				console.log(xhr + " : " + status + " : " + err);
			}.bind(this),
            xhrFields: {
              withCredentials: true
            }
        });
	}

    

    
    render() {
		const mapToCodeList = (data) => {

            if(data != null) {
                return data.map((item, i) => {//map
                    //console.log(item.files);
                    return(
                        <option value={item.commCode} key={i}>{item.commCodeName}</option>
                    );
                });
            }
		}
        return(
            <select className={this.props.className} id={this.props.name} name={this.props.name}  value={this.props.value == null ? "" : this.props.value}>
                {/*<select className={this.props.className} name={this.props.name} onChange={this.props.onChange} value={this.props.value}>*/}
                {/* DESC : option 비활성화시 disabled="disabled" 속성 추가 */}
                <option value="">{this.props.messages.contract_select}</option>
                {mapToCodeList(this.state.codeList)}
            </select>
        );
    }
}

export default connect(mapStateToProps)(CodeSelect);