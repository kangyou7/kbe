/*jshint esversion: 6 */
import React from 'react';

import { Link } from 'react-router';
import { browserHistory } from 'react-router';

import Search from '../common/Search';
import PagingView from '../common/PagingView';
import ColumnChange from '../common/ColumnChange';

import {TableThead, TableColgroup} from '../common/TableThead';

import {REST_API_URL} from '../../config/api-config.js';

/*다국어 모듈 시작*/
import { connect } from 'react-redux';
import { changeLangauge, mapStateToProps, actionlogin } from '../../language/Actions';
/*다국어 모듈 종료*/

class CustomerList extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      listThead : [
        {name:props.messages.customer_no,                   sort:false, sortColumn:"", view:true, target:false, width:'4%'},
        {name:props.messages.customer_clas_name,            sort:false, sortColumn:"", view:true, target:true, width:'12%'},
        {name:props.messages.customer_custm_no,             sort:false, sortColumn:"", view:true, target:true, width:'12%'},
        {name:props.messages.customer_biz_no,               sort:false, sortColumn:"", view:true, target:true, width:'12%'},
        {name:props.messages.customer_custm_name,           sort:true, sortColumn:"co_name", view:true, target:true, width:'12%'},
        {name:props.messages.customer_branch_count,         sort:true, sortColumn:"branch_count", view:true, target:true, width:'12%'},
        {name:props.messages.customer_provider_name,        sort:true, sortColumn:"prvdr_name", view:true, target:true, width:'12%'},
        {name:props.messages.customer_reg_user_name,        sort:true, sortColumn:"reg_user_name", view:true, target:true, width:'12%'},
        {name:props.messages.customer_reg_user_date,        sort:true, sortColumn:"reg_date", view:true, target:true, width:'12%'},
      ],
      searchSelectOption : [
        {value:'', text: props.messages.customer_search_select},
        {value:'1', text : props.messages.customer_search_type1},
        {value:'2', text : props.messages.customer_search_type2},
        {value:'3', text : props.messages.customer_search_type3},
      ],
      list : [],
      pageInfo:{
      }
    };

    this.handleSearch = this.handleSearch.bind(this);
    this.handlePageChange = this.handlePageChange.bind(this);
    this.handleColumnChange = this.handleColumnChange.bind(this);
    this.handleDetailView = this.handleDetailView.bind(this);
    this.handleSort = this.handleSort.bind(this);
  }

  

  getExcelDownload() {
    var form = "<form action='" + REST_API_URL + "/customer/excel_download' method='post'>"; 
    form += "<input type='hidden' name='sortColumn' value='"+this.props.pageInfo.sortColumn+"' />"; 
    form += "<input type='hidden' name='sortType' value='"+this.props.pageInfo.sortType+"' />"; 
    form += "<input type='hidden' name='searchKeyCode' value='"+this.props.pageInfo.searchKeyCode+"' />"; 
    form += "<input type='hidden' name='searchKeyWord' value='"+this.props.pageInfo.searchKeyWord+"' />"; 
    form += "</form>"; 
    jQuery(form).appendTo("body").submit().remove(); 
  }

  handleSearch(searchInfo) {

    let pageInfo = this.props.pageInfo;
    
    pageInfo.searchKeyCode = searchInfo.searchKeyCode;
    pageInfo.searchKeyWord = searchInfo.searchKeyWord;

    this.props.onPageInfoChange(pageInfo, true);
  }



  //페이지 변경 및 페이지 출력 갯수 변경
  handlePageChange(perPageNum, page) {

    let changePage = this.props.pageInfo;
    changePage.perPageNum = perPageNum;
    changePage.page = page;

    this.props.onPageInfoChange(changePage, true);
  }

  handleSort(sort) {
    let sortPage = this.props.pageInfo;
    sortPage.sortColumn = sort.sortColumn;
    sortPage.sortType = sort.sortType;
    
    this.props.onPageInfoChange(sortPage, true);
}

 //항목변경 팝업에서 항목 변경 후 state 정보 변경
 handleColumnChange(changeThead) {
   this.setState({
     listThead : changeThead
   });
 }

 handleDetailView(custmNo) {
   this.props.onDetailView(custmNo);
 }

  //컴포넌트가 만들어지고 첫 렌더링을 다 마친 후 실행되는 메소드입니다.
  componentDidMount() {
    this.props.onRef(this);
    this.getList();
  }

  //컴포넌트가 DOM 에서 사라진 후 실행되는 메소드입니다.
  componentWillUnmount() {
    this.props.onRef(null);
  }

  //컴포넌트가 prop 을 새로 받았을 때 실행됩니다.
  componentWillReceiveProps(nextProps) {
    if(this.props.locale !== nextProps.locale) {
      let listThead = this.state.listThead;

      listThead[0].name = nextProps.messages.customer_no;
      listThead[1].name = nextProps.messages.customer_clas_name;
      listThead[2].name = nextProps.messages.customer_custm_no;
      listThead[3].name = nextProps.messages.customer_bizno;
      listThead[4].name = nextProps.messages.customer_custm_name;
      listThead[5].name = nextProps.messages.customer_branch_count;
      listThead[6].name = nextProps.messages.customer_provider_name;
      listThead[7].name = nextProps.messages.customer_reg_user_name;
      listThead[8].name = nextProps.messages.customer_reg_user_date;

      let searchSelectOption = this.state.searchSelectOption;

      console.log("prop를 새로 받을 경우 실행 : "+JSON.stringify(searchSelectOption));
      
      searchSelectOption[0].text = nextProps.messages.customer_search_select;
      searchSelectOption[1].text = nextProps.messages.customer_search_type1;
      searchSelectOption[2].text = nextProps.messages.customer_search_type2;
      searchSelectOption[3].text = nextProps.messages.customer_search_type3;
    }

  }

  getList() {

    console.log(JSON.stringify(this.props.pageInfo));

    let data = this.props.pageInfo;

    data.loginUserNo = this.props.memberInfo.user_no;
    data.loginUserDstnctCode = this.props.memberInfo.user_dstnct_code;

    console.log("조회 파라미터 : "+JSON.stringify(data));

    $.ajax({
    url: REST_API_URL + "/customer/list",
    dataType: 'json',
    type: "post",
    data: data,
    cache: false,
    success: function(result) {

      //this.props.onPageInfoChange(this.props.pageInfo, false);
      let _list = [];
      _list = result.response.list;
      console.log(JSON.stringify(_list));
      this.props.onPageInfoChange(result.response.pageInfo, false);
      this.setState({
        list: _list
      });
    }.bind(this),
    error: function(xhr, status, err) {
      console.log(xhr + " : " + status + " : " + err);
    }.bind(this),
    xhrFields: {
      withCredentials: true
    }
    });

  }
  render() {
    const fncBtnInfo = this.props.memberInfo.dspUserFncBtnInfo;
    const mapToComponent = (data, thead) => {
      console.log("mapToComponent : " + JSON.stringify(data));
      if(data.length > 0) {
        return data.map((customer, i) => {//map
          return(
            <tr key={i}>
              <td style={thead[0].view ? {} : {display:'none'}}>{customer.rownum}</td>
              <td style={thead[1].view ? {} : {display:'none'}}>{customer.customerClasName}</td>
              <td style={thead[2].view ? {} : {display:'none'}}>{customer.custmNo}</td>
              <td style={thead[3].view ? {} : {display:'none'}}>{customer.bizno}</td>
              <td style={thead[4].view ? {} : {display:'none'}}>
                <a onClick={() => {this.handleDetailView(customer.custmNo);}}>{customer.coName}</a>
              </td>
              <td style={thead[5].view ? {} : {display:'none'}}>{customer.branchCount}</td>
              <td style={thead[6].view ? {} : {display:'none'}}>{customer.prvdrName}</td>
              <td style={thead[7].view ? {} : {display:'none'}}>{customer.regUserName}</td>
              <td style={thead[8].view ? {} : {display:'none'}}>{customer.regDate}</td>
            </tr>
          );
        });
      } else {
        let colspan = thead.length;
        for(var i = 0; i<thead.length; i++) {
            colspan -= thead[i].view ? 0 : 1;
        }
        return (
          <tr>
            <td className="noresults" colSpan={colspan}>
              <div className="box_noresults">
                <div className="ver_mid">
                  <i className="ico ico_no_result"></i>
                  <span className="lb">{this.props.messages.customer_there_are_no_results}</span>
                </div>
              </div>
            </td>
          </tr>
        );
      }
    }

    return (
      <div id="tab-cont1" className="tab_content tab-cont" style={{display:'block'}}>
        <div className="content_body">
          <div className="content_inner">
            <div className="box_com term_wrap">
                <Search onSearch={this.handleSearch} searchSelectOption={this.state.searchSelectOption} 
                  searchInfo={{"searchKeyCode":this.props.pageInfo.searchKeyCode, "searchKeyWord":this.props.pageInfo.searchKeyWord}}/>

                <div className="fr">
                  <button onClick={() => this.props.onDisplaySetting('C')} 
                    className="btn_black"
                    disabled={fncBtnInfo['funcRegYn']=='N'} 
                  >
                  {this.props.messages.customer_registration}
                  </button>
                  <span className="gap"></span>
                  <button type="button" 
                          className="btn_pos" 
                          onClick={() => this.columnChange.show()}
                  >
                  {this.props.messages.customer_change_item}
                  </button>
                </div>
            </div>

            <table className="tbl_col">
              <caption>{this.props.messages.customer_list}</caption>
              <TableColgroup listThead={this.state.listThead} />
              <TableThead listThead={this.state.listThead} onSort={this.handleSort}/>
              <tbody id="contractTbody">
                {mapToComponent(this.state.list, this.state.listThead)}
              </tbody>
            </table>
          </div>
        </div>
        <PagingView pageInfo={this.props.pageInfo} onPageChange={this.handlePageChange}/>
        <ColumnChange onRef={ref => (this.columnChange = ref)} listThead={this.state.listThead} onColumnChange={this.handleColumnChange} />
      </div>
    );
  }
}
export default connect(mapStateToProps)(CustomerList);