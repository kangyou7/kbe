import React from 'react';

import { browserHistory } from 'react-router';

import ApprovalLineSetting from '../common/ApprovalLineSetting';

import CustomerSearch from '../common/CustomerSearch';
import ModelSearch from '../common/ModelSearch';

import Calendar from '../common/Calendar';
import CodeSelect from '../common/CodeSelect';
import AttachFile from '../common/AttachFile';

import {REST_API_URL} from '../../config/api-config.js';

import axios from 'axios';

import { Link } from 'react-router';

/*다국어 모듈 시작*/
import { connect } from 'react-redux';
import { changeLangauge, mapStateToProps } from '../../language/Actions';
/*다국어 모듈 종료*/

import validator from 'validator';


class AssetsCreate extends React.Component {

	constructor(props) {
		super(props);

		this.state = {
			equipModelNo : "",
			equipModelName : "",
			equipClasCode : "",
			equipClasName : "",
			equipVendorName : "",
			assetsOwnerSeCode : "I",
			custmNo : "",
			assetsNatvNoTypeCode : "",
			assetsNatvNoValue : "",
			licExpDate : "",
			getDate : "",
			dprcExpDate : "",
			firmwareVer : "",
			signatureVer : "",
			assetsMgmtCode : "",
			getPrice : "",
			assetsDesc : "",
			cstmrNm : ""
		}

		//this.initState = this.state;


		this.handleChange = this.handleChange.bind(this);

		/*고객 찾기*/
		this.handleCustomerComplete = this.handleCustomerComplete.bind(this);

		/*모델 찾기*/
		this.handleModelComplete = this.handleModelComplete.bind(this);

		this.handleModelSave = this.handleModelSave.bind(this);
	}

	handleInitState() {
		
		//this.setState(this.this.initState);
		this.setState({
			equipModelNo : "",
			equipModelName : "",
			equipClasCode : "",
			equipClasName : "",
			equipVendorName : "",
			assetsOwnerSeCode : "I",
			custmNo : "",
			assetsNatvNoTypeCode : "",
			assetsNatvNoValue : "",
			licExpDate : "",
			getDate : "",
			dprcExpDate : "",
			firmwareVer : "",
			signatureVer : "",
			assetsMgmtCode : "",
			getPrice : "",
			assetsDesc : "",
			cstmrNm : ""
		});

		$("#spanCstmrNm").hide();
	}

	handleModelSave() {

		if (this.validationCheck()) {
			let data = this.state;

			if (confirm("등록하시겠습니까?")) {

				let memberInfo = JSON.parse(localStorage.getItem("memberInfo"));

				data.loginUserNo = memberInfo.user_no;

				$.ajax({
					url: REST_API_URL+"/assets/Create",
					dataType: 'json',
					type: "post",
					xhrFields : {
						withCredentials : true
					},
					data: {paramJson : JSON.stringify(data)},
		
					success: function(result) {
						
						if (result.response == "SUCCESS") {
							alert("등록되었습니다.");
							location.href="/assets";
						} else {
							alert("등록 도중 오류가 발생하였습니다. 관리자에게 문의바랍니다.");
							return;
						}
		
					}.bind(this),
						error: function(xhr, status, err) {
						console.log(xhr + " : " + status + " : " + err);
					}.bind(this)
				});
			}		
		}
	}

	handleSave() {

		this.handleModelSave();
		
	}

	validationCheck() {

		if(this.state.equipModelNo == "") {
			alert("모델을 선택해 주세요.");
			return false;
		}

		if(this.state.assetsOwnerSeCode == "C" || this.state.assetsOwnerSeCode == "R") {
			if(this.state.custmNo == "") {
				alert("고객사를 선택해 주세요.");
				return false;
			}
		}

		if(this.state.assetsNatvNoTypeCode == "") {
			alert("고유 Code 종류를 선택 하세요.");
			return false;
		}

		if(this.state.assetsNatvNoValue == "") {
			alert("고유 Code No.를 입력 하세요.");
			return false;
		} else {
			if (!validator.isLength(this.state.assetsNatvNoValue,{min:0, max: 50})) {
				alert("고유 Code No.는 50자 이내로 입력바랍니다.");
				return false;
			}

			if (this.state.assetsNatvNoTypeCode == "IP") {
				if (!validator.isIP(this.state.assetsNatvNoValue)) {
					alert("IP 형태로 입력바랍니다.");
					return false;
				}
			} else if (this.state.assetsNatvNoTypeCode == "MAC") {
				if (!validator.isMACAddress(this.state.assetsNatvNoValue)) {
					alert("MAC Address 형태로 입력바랍니다.");
					return false;
				}
			}
		}

		if(this.state.licExpDate == "") {
			alert("License 만료일을 지정하세요.");
			return false;
		}

		if(this.state.getDate == "") {
			alert("취득일 지정하세요.");
			return false;
		}

		if(this.state.getPrice == "") {
			alert("취득가액을 입력하세요.");
			return false;
		} else {
			if (!validator.isNumeric(this.state.getPrice)) {
				alert("취득가액은 숫자만 입력바랍니다.");
				return false;
			}
		}

		if(this.state.firmwareVer == "") {
			alert("펌웨어 버전을 입력하세요.");
			return false;
		} else {
			if (!validator.isLength(this.state.firmwareVer,{min:0, max: 50})) {
				alert("펌웨어버전은 50자 이내로 입력바랍니다.");
				return false;
			}
		}

		if(this.state.signatureVer == "") {
			alert("Signature 버전을 입력하세요.");
			return false;
		} else {
			if (!validator.isLength(this.state.signatureVer,{min:0, max: 50})) {
				alert("Signature 버전은 50자 이내로 입력바랍니다.");
				return false;
			}
		}
		
		return true;
	}

	handleChange(e) {

		if(e.target.name === "assetsOwnerSeCode") {
			if (e.target.value == "I") {
				$("#spanCstmrNm").hide();
			} else {
				$("#spanCstmrNm").show();
			}
		}
			
		let nextState = {};
		nextState[e.target.name]=e.target.value;
		this.setState(nextState);
	}

	handleModelComplete(model) {
	
		this.setState({
			equipModelNo : model.equipModelNo,
			equipModelName : model.equipModelName,
			equipClasCode : model.equipClasCode,
			equipClasName : model.equipClasName,
			equipVendorName : model.equipVendorName
		})
	}

	handleCustomerComplete(customer) {
		this.setState({
			custmNo : customer.custmNo,
			cstmrNm : customer.coName
		})
	}

	goList() {
		if (confirm("이 페이지에서 나가시겠습니까?\n작성중인 내용이 저장되지 않습니다.")) {
			location.href="/assets";
		} 
	}
	

	componentDidMount() {
		$("#tab-cont1").show();

		if ( $('.ui-sel').length > 0 ){
            $('.ui-sel').each(function(){
                $(this).selectric();//초기화
            });	
        }

		this.handleInitState();
	}

	handleOnlyNumber(smallPoint, e) {

        if(smallPoint > 0 ) {
            //let regexp = /^\d*(\.\d{0,2})?$/;
            let regexp = new RegExp("^\\d*(\\.\\d{0," + smallPoint + "})?$");
            if(e.target.value.search(regexp) == -1) {
                e.target.value=e.target.value.substring(0, e.target.value.length -1);
            } else  {
                e.target.value=e.target.value;
            }
        } else {
            e.target.value = e.target.value.replace(/[^0-9]/g,"")
        }
    }
	
    render() {
		const fncBtnInfo = this.props.memberInfo.dspUserFncBtnInfo;
		/*const mapToFiles = (data) => {
			return data.map((item, i) => {//map
				//console.log(item.files);
				return(
					<span className="file_item" key={i}>
						<span>{item.name}</span>
						<a href="javascript:;" className="ibtn_del" onClick={() => {this.handleFileRemove(i)}}><i className="ico_del"><span className="offscreen">삭제</span></i></a>
					</span>
				);
			});
		}*/

        return (
			<section className="body">

				{/* S:wrapper */}
				<div className="wrapper">

					{/* S:page_header */}
					<div className="page_header">
						<h2 className="ptitle">{this.props.messages.assets_registration}</h2>
						<div className="page_nav">
							{/*<ul>
								<li><a href="/">Home</a></li>
								<li><a href="/assets">{this.props.messages.assets_management}</a></li>
								<li className="here">{this.props.messages.assets_registration}</li>
							</ul>*/}
						</div>
					</div>
					{/* E:page_header */}

					{/* S:content_wrap */}
					<div className="content_wrap">
						{/* S:content_outbox */}
						<div className="content_outbox">
							{/* S:tab_wrap */}
							<div className="tab_wrap tab-wrap">
								{/* S:tab_header */}
								<div className="box_both tab_header">
									<div className="fl">
										<ul className="tabs">
											<li className="tab_item tab-item">
												<a href="#tab-cont1" className="tab-link" onClick={() => {this.goList()}}><span>{this.props.messages.common_list}</span></a>
											</li>
											<li className="tab_item tab-item on">
												<a href="#tab-cont1" className="tab-link"><span>{this.props.messages.common_detail}</span></a>
											</li>
										</ul>
									</div>
									<div className="fr">
										<div className="btn_group">
											<button type="button" className="btn_pos" onClick={() => {this.handleInitState()}}>{this.props.messages.common_reset}</button>
											{/* <button type="button" className="btn_pos" onClick={() => {this.handleSave('T')}}>임시저장</button> */}
											<button disabled={fncBtnInfo['funcRegYn']=='N'}  type="button" className="btn_black" onClick={() => {this.handleSave()}}>{this.props.messages.assets_ok}</button>
										</div>
									</div>
								</div>
								{/* E:tab_header */}

								{/* S:tab_content 활성화시 display:block/none  */}
								<div id="tab-cont1" className="tab_content tab-cont" >
									{/* S:content_body */}
									<div className="content_body">
										{/* S:content_inner */}
										<div className="content_inner">

											<div className="box_com">
												<div className="fl">
													<h3 className="ctitle">{this.props.messages.assets_information}</h3>
												</div>
												<div className="fr">
													<div className="desc">
														<span className="tc_red">*</span> {this.props.messages.assets_required}
													</div>
												</div>
											</div>

											{/* S:Table */}
											<table className="tbl_row">
												<caption>자산 정보 목록</caption>
												<colgroup>
													<col style={{width:'10%'}}/>
													<col style={{width:'40%'}}/>
													<col style={{width:'10%'}}/>
													<col style={{width:'40%'}}/>
												</colgroup>
												<tbody>
													<tr>
														<th scope="row">{this.props.messages.assets_model_name} <span className="tc_red">*</span></th>
														<td className="input">
															<span className="input_btn_box">
																<input type="text" className="ui_input" readOnly name="equipModelName" value={this.state.equipModelName}  onChange={this.handleChange}/>
																<a href="javascript:;" className="tbtn_pos" onClick={() => {this.modelSearch.show()}}>{this.props.messages.assets_model_searching}</a>
															</span>
														</td>
														<th scope="row">{this.props.messages.assets_type} <span className="tc_red">*</span></th>
														<td className="input">
															<input type="text" className="ui_input" readOnly name="equipClasName" value={this.state.equipClasName} onChange={this.handleChange}/>
														</td>
													</tr>
													<tr>
														<th scope="row">{this.props.messages.assets_vendor_name} <span className="tc_red">*</span></th>
														<td className="input">
															<input type="text" className="ui_input" readOnly name="equipVendorName" value={this.state.equipVendorName} onChange={this.handleChange}/>
														</td>
														<th scope="row">{this.props.messages.assets_possesion}  <span className="tc_red">*</span></th>
														<td className="input">
															<ul className="ip_list">
																<li>
																	<span className="input_ico_box">
																		{/* <!-- DESC : 인포섹 default checked --> */}
																	<input type="radio" name="assetsOwnerSeCode" id="rdo-2-1" value="I" checked={this.state.assetsOwnerSeCode === "I"} onChange={this.handleChange}/>
																	<label htmlFor={"rdo-2-1"}>{this.props.messages.assets_owner_infosec}</label>
																	</span>
																</li>
																<li>
																	<span className="input_ico_box">
																	<input type="radio" name="assetsOwnerSeCode" id="rdo-2-3" value="R" checked={this.state.assetsOwnerSeCode === "R"} onChange={this.handleChange}/>
																	<label htmlFor={"rdo-2-3"}>{this.props.messages.assets_owner_rent}</label>
																	</span>
																</li>
																<li>
																	<span className="input_ico_box">
																	<input type="radio" name="assetsOwnerSeCode" id="rdo-2-2" value="C" checked={this.state.assetsOwnerSeCode === "C"} onChange={this.handleChange}/>
																	<label htmlFor={"rdo-2-2"}>{this.props.messages.assets_owner_customer}</label>
																	</span>
																	{/* <!-- DESC : 고객사 선택시 input_btn_box 영역 style="display:inline-block" 추가
																			고객사 이외 다른방법 선택 시, input_btn_box 영역 style="display:none;" 추가 --> */}
																	<span className="input_btn_box" id="spanCstmrNm">
																		<input type="text" className="ui_input" readOnly name="cstmrNm" value={this.state.cstmrNm}/>
																		<a href="javascript:;" className="tbtn_pos" onClick={() => {this.customerSearch.show()}}>{this.props.messages.contract_customer_searching_1}</a>
																	</span>
																</li>
															</ul>
														</td>
													</tr>
													<tr>
														<th scope="row">{this.props.messages.assets_serial_no}<span className="tc_red">*</span></th>
														<td className="input" colSpan={3}>
															<CodeSelect className="ui-sel sel_white" 
																name="assetsNatvNoTypeCode" 
																value={this.state.assetsNatvNoTypeCode} 
																onChange={this.handleChange} 
																groupCode="ASSETS_NATV_TYPE"/>
															<input type="text" className="ui_input" maxLength="50" name="assetsNatvNoValue" value={this.state.assetsNatvNoValue} onChange={this.handleChange}/>
														</td>
													</tr>
													<tr>
														<th scope="row">{this.props.messages.assets_license_termination_date} <span className="tc_red">*</span></th>
														<td className="input">
															{/* <!-- s: 캘린더폼 --> */}
															<div className="date_box">
																{/* <input type="text" data-role="datepicker" className="ui_cal" /> */}
																<Calendar className="ui_cal" 
																dateFormat="YYYY-MM-DD"
																name="licExpDate"
																selected={this.state.licExpDate}
																onChange={(data) => this.setState({licExpDate: data})}/>
															</div>
															{/* <!-- e: 캘린더폼 --> */}
														</td>
														{/* <th scope="row">감가상각 만료일 <span className="tc_red">*</span></th>
														<td className="input">
												
															<div className="date_box">
																
																<Calendar className="ui_cal" 
																dateFormat="YYYY-MM-DD"
																onChange={(data) => this.setState({dprcExpDate: data})}/>
															</div>
															
														</td> */}
														<th scope="row">{this.props.messages.assets_acquisition_date} <span className="tc_red">*</span></th>
														<td className="input">
															{/* <!-- s: 캘린더폼 --> */}
															<div className="date_box">
																{/* <input type="text" data-role="datepicker" className="ui_cal" /> */}
																<Calendar className="ui_cal" 
																dateFormat="YYYY-MM-DD"
																name="getDate"
																selected={this.state.getDate}
																onChange={(data) => this.setState({getDate: data})}/>
															</div>
															{/* <!-- e: 캘린더폼 --> */}
														</td>
													</tr>
													<tr>
														<th scope="row">{this.props.messages.assets_acquisition_cost} <span className="tc_red">*</span></th>
														<td className="input">
															<input type="number" className="ui_input" name="getPrice" value={this.state.getPrice} maxLength={20} onChange={this.handleChange} onInput={this.handleOnlyNumber.bind(this, 0)}/>
														</td>
														<th scope="row">{this.props.messages.assets_asset_code}</th>
														<td className="input">
															<input type="text" className="ui_input" maxLength="50" name="assetsMgmtCode" value={this.state.assetsMgmtCode} onChange={this.handleChange}/>
														</td>
													</tr>
													<tr>
														<th scope="row">{this.props.messages.assets_firmware_version} <span className="tc_red">*</span></th>
														<td className="input">
															<input type="text" className="ui_input" maxLength="50" name="firmwareVer" value={this.state.firmwareVer} onChange={this.handleChange}/>
														</td>
														<th scope="row">{this.props.messages.assets_signature_version} <span className="tc_red">*</span></th>
														<td className="input">
															<input type="text" className="ui_input" maxLength="50" name="signatureVer" value={this.state.signatureVer} onChange={this.handleChange}/>
														</td>
													</tr>
													<tr>
														<th scope="row">{this.props.messages.assets_remark}</th>
														<td className="input" colSpan={3}>
															<textarea className="ui_textarea" maxLength="4000" name="assetsDesc" value={this.state.assetsDesc} onChange={this.handleChange}></textarea>
														</td>
													</tr>
												</tbody>
											</table>
											{/* E:Table */}
										</div>
										{/* E:content_inner */}
									</div>
									{/* E:content_body */}
								</div>
							
							{/* E:tab_content  */}
							</div>
						{/* E:tab_wrap */}
						</div>
					</div>
				</div>
				
				<ModelSearch onRef={ref => (this.modelSearch = ref)} onModelComplete={this.handleModelComplete}/>
				<CustomerSearch onRef={ref => (this.customerSearch = ref)} onCustomerComplete={this.handleCustomerComplete}/>
			</section>

        );
    }
}

export default connect(mapStateToProps)(AssetsCreate);
