import React from 'react';

import { browserHistory } from 'react-router';

import ApprovalLineSetting from '../common/ApprovalLineSetting';

import MtnceEntpChargeRegist from './MtnceEntpChargeRegist';

import Calendar from '../common/Calendar';
import CodeSelect from '../common/CodeSelect';
import AttachFile from '../common/AttachFile';

import {REST_API_URL} from '../../config/api-config.js';

import axios from 'axios';

/*다국어 모듈 시작*/
import { connect } from 'react-redux';
import { changeLangauge, mapStateToProps } from '../../language/Actions';
/*다국어 모듈 종료*/

import validator from 'validator';

class MtnceEntpCreate extends React.Component {

	constructor(props) {
		super(props);

		this.state = {
			maintCoName : "",
			equipVendorNo : "",
			chargeArea1Name : "",
			chargeArea2Name : "",
			chargeArea3Name : "",
			refMemo : "",
			vendorList : [],
			charges : []
		}

		this.handleChange = this.handleChange.bind(this);

		this.handleSave = this.handleSave.bind(this);

		this.handleMtnceEntpSave = this.handleMtnceEntpSave.bind(this);

		/*담당자 등록*/
		this.handleChargeComplete = this.handleChargeComplete.bind(this);

		this.handleDelete = this.handleDelete.bind(this);
		
	}

	handleInitState() {
		
		this.setState({
			maintCoName : "",
			equipVendorNo : "",
			chargeArea1Name : "",
			chargeArea2Name : "",
			chargeArea3Name : "",
			refMemo : "",
			charges : []
		});
	}

	handleChargeComplete(charge) {
		
		let chargeArray = this.state.charges;
		chargeArray.push(charge);

		this.setState({
			charges: chargeArray
		});
	}

	handleMtnceEntpSave() {

		if (this.validationCheck()) {
			let data = this.state;

			if (confirm("등록하시겠습니까?")) {

				let memberInfo = JSON.parse(localStorage.getItem("memberInfo"));
				data.loginUserNo = memberInfo.user_no;
		
				$.ajax({
					url: REST_API_URL+"/assets/MtnceEntpCreate",
					dataType: 'json',
					type: "post",
					data: {paramJson : JSON.stringify(data)},
					xhrFields : {
						withCredentials : true
					},
		
					success: function(result) {
						
						if (result.response == "SUCCESS") {
							alert("등록되었습니다.");
							location.href="/mtnceEntp";
						} else {
							alert("등록 도중 오류가 발생하였습니다. 관리자에게 문의바랍니다.");
							return;
						}
		
					}.bind(this),
						error: function(xhr, status, err) {
						console.log(xhr + " : " + status + " : " + err);
					}.bind(this)
				});
			}		
		}
	}

	handleSave() {

		this.handleMtnceEntpSave();
		
	}

	validationCheck() {

		if(validator.trim(this.state.maintCoName) == "") {
			alert("업체명을 입력해 주세요.");
			return false;
		} else {
			if (!validator.isLength(this.state.maintCoName,{min:0, max: 100})) {
				alert("업체명은 100자 이내로 입력바랍니다.");
				return false;
			}
		}

		if(validator.trim(this.state.equipVendorNo) == "") {
			alert("담당 벤더를 선택해 주세요.");
			return false;
		}

		if(validator.trim(this.state.chargeArea1Name) == "") {
			alert("담당지역을 입력해 주세요.");
			return false;
		} else {
			if (!validator.isLength(this.state.chargeArea1Name,{min:0, max: 100})) {
				alert("담당지역은 100자 이내로 입력바랍니다.");
				return false;
			}
		}
		
		return true;
	}

	handleChange(e) {
			
		let nextState = {};
		nextState[e.target.name]=e.target.value;
		this.setState(nextState);
	}

	handleCheckAll() {
        
        $("input[name='listCheck']").prop("checked", $("#listChkAll").is(":checked"));
	}
	
	handleDelete() {
		
		let charges = this.state.charges;

		let removeCharges = new Array();

		$("input[name='listCheck']").each(function() {
			if ( $(this).is(":checked") ) {
				removeCharges.push(charges[$(this).val()]);
			}
		});
		
		for (var i=0; i<removeCharges.length; i++) {
			charges.splice($.inArray(removeCharges[i], charges),1);
		}

		this.setState({
			charges: charges
		});
	}

	goList() {
		if (confirm("이 페이지에서 나가시겠습니까?\n작성중인 내용이 저장되지 않습니다.")) {
			location.href="/mtnceEntp";
		}
	}

	getVendorNoList() {
		$.ajax({
            url: REST_API_URL+"/assets/getVendorNoList",
            dataType: 'json',
            type: "post",
            xhrFields : {
				withCredentials : true
			},
            success: function(result) {
				this.setState({
					vendorList :result.response
				});
            }.bind(this),
                error: function(xhr, status, err) {
                console.log(xhr + " : " + status + " : " + err);
            }.bind(this)
        });
	}

	componentDidMount() {
		// this.props.onRef(this)
		$("#tab-cont1").show();
		this.getVendorNoList();
	}

	// componentWillUnmount() {
	// 	this.props.onRef(null)
	// }
	
    render() {

		const mapToVendorNoList = (data) => {
            if(data != null) {
                return data.map((item, i) => {//map
                    //console.log(item.files);
                    return(
                        <option value={item.equipVendorNo} key={i}>{item.equipVendorName}</option>
                    );
                });
            }
        }

		const mapToCharge = (data) => {
            if(data.length > 0) {
                return data.map((item, i) => {//map
                    return(

						<tr key={i}>
							<td className="ui_only_chk">
								<span className="input_ico_box">
									<input type="checkbox" name="listCheck" id={i} value={i} onClick={this.handleCheckBoxClick}/>
									<label htmlFor={i}></label>
								</span>	
							</td>
							<td>{item.chargeUsrName}</td>
							<td>{item.chargeUsrPosit}</td>
							<td>{item.chargeUsrTel}</td>
							<td>{item.chargeUsrMobileNo}</td>
							<td>{item.chargeUsrEmail}</td>
							<td>{item.chargeTaskMemo}</td>
						</tr>
                    );
                });
            } else {
                return (
                    <tr>
						<td className="noresults" colSpan={7}>
							<div className="box_noresults">
								<div className="ver_mid">													
									<i className="ico ico_no_result"></i>
									<span className="lb">{this.props.messages.common_no_data}</span>
								</div>
							</div>
						</td>
					</tr>
                );
            }
        }

        return (
			<section className="body">

				{/* S:wrapper */}
				<div className="wrapper">

					{/* S:page_header */}
					<div className="page_header">
						<h2 className="ptitle">{this.props.messages.mtnce_register_maintenance_company}</h2>
						<div className="page_nav">
							{/*<ul>
								<li><a href="/">Home</a></li>
								<li><a href="/assets">{this.props.messages.assets_management}</a></li>
								<li><a href="/mtnceEntp">{this.props.messages.mtnce_maintenance_company_status}</a></li>
								<li className="here">{this.props.messages.mtnce_register_maintenance_company}</li>
							</ul>*/}
						</div>
					</div>
					{/* E:page_header */}

					{/* S:content_wrap */}
					<div className="content_wrap">
						{/* S:content_outbox */}
						<div className="content_outbox">
							{/* S:tab_wrap */}
							<div className="tab_wrap tab-wrap">
								{/* S:tab_header */}
								<div className="box_both tab_header">
									<div className="fl">
										<ul className="tabs">
											<li className="tab_item tab-item">
												<a href="#tab-cont1" className="tab-link" onClick={() => {this.goList()}}><span>{this.props.messages.common_list}</span></a>
											</li>
											<li className="tab_item tab-item on">
												<a href="#tab-cont1" className="tab-link"><span>{this.props.messages.common_detail}</span></a>
											</li>
										</ul>
									</div>
									<div className="fr">
										<div className="btn_group">
											<button type="button" className="btn_pos" onClick={() => {this.handleInitState()}}>{this.props.messages.common_reset}</button>
											{/* <button type="button" className="btn_pos" onClick={() => {this.handleSave('T')}}>임시저장</button> */}
											<button type="button" className="btn_black" onClick={() => {this.handleSave()}}>{this.props.messages.assets_ok}</button>
										</div>
									</div>
								</div>
								{/* E:tab_header */}

								{/* S:tab_content 활성화시 display:block/none  */}
								<div id="tab-cont1" className="tab_content tab-cont" >
									{/* S:content_body */}
									<div className="content_body">
										{/* S:content_inner */}
										<div className="content_inner">

											<div className="box_com">
												<div className="fl">
													<h3 className="ctitle">{this.props.messages.mtnce_basic_information}</h3>
												</div>
												<div className="fr">
													<div className="desc">
														<span className="tc_red">*</span> {this.props.messages.assets_required}
													</div>
												</div>
											</div>

											{/* S:Table */}
											<table className="tbl_row">
												<caption>기본 정보 목록</caption>
												<colgroup>
													<col style={{width:'10%'}}/>
													<col style={{width:'40%'}}/>
													<col style={{width:'10%'}}/>
													<col style={{width:'40%'}}/>
												</colgroup>
												<tbody>
												<tr>
													<th scope="row">{this.props.messages.mtnce_company_name} <span className="tc_red">*</span></th>
													<td className="input" colSpan={3}>
														<input type="text" className="ui_input" maxLength="100" name="maintCoName" value={this.state.maintCoName}  onChange={this.handleChange} />
													</td>
												</tr>
												<tr>
													<th scope="row">{this.props.messages.mtnce_manage_vendor} <span className="tc_red">*</span></th>
													<td className="input">
														<select className="ui_sel" name="equipVendorNo" onChange={this.handleChange}>
															<option value="">선택</option>
															{mapToVendorNoList(this.state.vendorList)}
														</select>
														{/* <input type="text" className="ui_input" name="equipVendorNo" value={this.state.equipVendorNo}  onChange={this.handleChange}/> */}
													</td>
													<th scope="row">{this.props.messages.mtnce_area1} <span className="tc_red">*</span></th>
													<td className="input">
														<input type="text" className="ui_input" maxLength="100" name="chargeArea1Name" value={this.state.chargeArea1Name}  onChange={this.handleChange}/>
													</td>
												</tr>
												<tr>
													<th scope="row">{this.props.messages.mtnce_area2} </th>
													<td className="input">
														<input type="text" className="ui_input" maxLength="100" name="chargeArea2Name" value={this.state.chargeArea2Name}  onChange={this.handleChange}/>
													</td>
													<th scope="row">{this.props.messages.mtnce_area3} </th>
													<td className="input">
														<input type="text" className="ui_input" maxLength="100" name="chargeArea3Name" value={this.state.chargeArea3Name}  onChange={this.handleChange}/>
													</td>
												</tr>
												<tr>
													<th scope="row">{this.props.messages.mtnce_remark} </th>
													<td className="input" colSpan={3}>
														<textarea className="ui_textarea" maxLength="1000" name="refMemo" value={this.state.refMemo} onChange={this.handleChange}></textarea>
													</td>
												</tr>
												</tbody>
											</table>
											{/* E:Table */}

											<div className="box_com">
												<div className="fl">
													<h3 className="ctitle">{this.props.messages.mtnce_manager_information} </h3>
												</div>
												<div className="fr">
													<button type="button" className="btn_pos" onClick={() => {this.handleDelete()}}>{this.props.messages.assets_delete} </button>
													<button type="button" className="btn_black" onClick={() => {this.mtnceEntpChargeRegist.show();}}> {this.props.messages.mtnce_manager_registration} </button>
												</div>
											</div>
											
											<table className="tbl_col">
												<caption>담당자 정보 목록</caption>
												<colgroup>
													<col style={{width:'4%'}}/>
													<col style={{width:'16%'}}/>
													<col style={{width:'16%'}}/>
													<col style={{width:'16%'}}/>
													<col style={{width:'16%'}}/>
													<col style={{width:'16%'}}/>
													<col style={{width:'16%'}}/>
												</colgroup>
												
												<thead>
													<tr>
														<th scope="col" className="ui_only_chk">
															<span className="input_ico_box">
																<input type="checkbox" name="chk_box" id="listChkAll" onClick={() => {this.handleCheckAll()}}/>
																<label htmlFor="listChkAll"></label>
															</span>
														</th>
														<th scope="col">{this.props.messages.mtnce_manager_name}</th>
														<th scope="col">{this.props.messages.mtnce_manager_position}</th>
														<th scope="col">{this.props.messages.mtnce_manager_phone}</th>
														<th scope="col">{this.props.messages.mtnce_manager_cellphone}</th>
														<th scope="col">{this.props.messages.mtnce_email}</th>
														<th scope="col">{this.props.messages.mtnce_manager_work}</th>
													</tr>
												</thead>
												
												<tbody>	
												{mapToCharge(this.state.charges)}
												</tbody>
											</table>
										</div>
										{/* E:content_inner */}
									</div>
									{/* E:content_body */}
								</div>
							
							{/* E:tab_content  */}
							</div>
						{/* E:tab_wrap */}
						</div>
					</div>
				</div>

				<MtnceEntpChargeRegist onRef={ref => (this.mtnceEntpChargeRegist = ref)} onChargeComplete={this.handleChargeComplete}/>

			</section>
        );
    }
}

export default connect(mapStateToProps)(MtnceEntpCreate);
