import React from 'react';


/*다국어 모듈 시작*/
import { connect } from 'react-redux';
import { changeLangauge, mapStateToProps } from '../../language/Actions';
/*다국어 모듈 종료*/

class Test1 extends React.Component {
    constructor(props) {
        super(props);
    
        this.state = {
        }

    }
    
    payment() {
        window.open("/test2","PAY_WIN","width=480,height=620,toolbar=no,menubar=no,scrollbars=no,resizable=yes");
    }
   
   

    render() {
        return (

            <section className="body">
                
                <button id="open" onClick={()=>this.payment()}>결제하기</button>
            </section>



        );
    }
}

export default connect(mapStateToProps)(Test1);
