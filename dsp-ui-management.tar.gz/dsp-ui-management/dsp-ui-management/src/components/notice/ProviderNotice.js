import React from 'react';
import { Link } from 'react-router';
import { browserHistory } from 'react-router';

import axios from 'axios';

import ProviderNoticeList from './ProviderNoticeList';
import ProviderNoticeDetail from './ProviderNoticeDetail';

import {REST_API_URL} from '../../config/api-config.js';

/*다국어 모듈 시작*/
import { connect } from 'react-redux';
import { changeLangauge, mapStateToProps } from '../../language/Actions';
/*다국어 모듈 종료*/

class ProviderNotice extends React.Component {
  constructor(props) {
    super(props);

    this.state ={
      cntrlScheNo : "",
      file : null,
      buttonDispladyState : "L"
    }

    this.handleTabsChange = this.handleTabsChange.bind(this);
    this.handleDetailView = this.handleDetailView.bind(this);

    this.handleDisplaySetting = this.handleDisplaySetting.bind(this);
    
  }

  handleTabsChange(tab) {

    if(tab === 'Detail') {
      if(this.state.noticeNo === "") {
        alert("리스트의 공지사항을 선택하세요.");
      } else {
        $("#tab-cont1").hide();
        //$(".fr").hide();
        $("#tab-cont2").show();

        $("#groupList").hide();
        $("#groupCreate").show();
        $(".btn_pos").hide();
        $(".tabs li").eq(0).removeClass('on');
        $(".tabs li").eq(1).addClass('on');
        $(".tabs li").eq(1).find("a").removeClass('disabled');
      }
    } else {
      $("#tab-cont1").show();
      //$(".fr").show();
      $("#tab-cont2").hide();
      $(".tabs li").eq(0).addClass('on');
      $(".tabs li").eq(1).removeClass('on');

      $(".btn_pos").show();
      $("#groupList").show();
      $("#groupCreate").hide();
      $(".tabs li").eq(1).find("a").addClass('disabled');
      this.handleDisplaySetting('L');
    }
  }
  
  handleDetailView(noticeNo) {
    this.state.noticeNo = noticeNo;
    this.handleTabsChange('Detail');
    this.providerNoticeDetail.getNotice(noticeNo);
  }
  
  componentDidMount() {
    $("#tab-cont1").show();
    $(".fr").show();
    $("#tab-cont2").hide();

    const qs = require('query-string');
    const parsed = qs.parse(location.search);
    console.log(parsed.noticeNo);
    if (parsed.noticeNo != null) {
      this.handleDetailView(parsed.noticeNo);
    }
    
  }


  handleDisplaySetting(state) {

    console.log(state);


    // if(state === 'T') {
    //   $("#groupList").hide();
    //   $("#groupCreate").show();
    // }

    this.setState({buttonDispladyState : state});
  }

  render() {
    const fncBtnInfo = this.props.memberInfo.dspUserFncBtnInfo;
        return (
          <section className="body">

            <div className="wrapper">

              <div className="page_header">
                <h2 className="ptitle">{this.props.messages.notice_provider_notice}</h2>
                <div className="page_nav">
                  {/*<ul>
                    <li><a href="/">Home</a></li>
                    <li><a href="/monitoringNotice">{this.props.messages.notice_management}</a></li>
                    <li className="here">{this.props.messages.notice_provider_notice}</li>
                  </ul>*/}
                </div>
              </div>
              <div className="content_wrap">

                <div className="content_outbox">

                  <div className="tab_wrap tab-wrap">

                    <div className="box_both tab_header">
                      <div className="fl">
                        <ul className="tabs">
                          <li className="tab_item tab-item on">
                            <a href="javascript:;" onClick={() => {this.handleTabsChange('List')}} className="tab-link"><span>{this.props.messages.common_list}</span></a>
                          </li>
                          <li className="tab_item tab-item">
                            <a href="javascript:;" className="tab-link disabled"><span>{this.props.messages.common_detail}</span></a>
                          </li>
                        </ul>
                      </div>
                      <div className="fr">
                        <div className="btn_group" id="groupCreate" style={{display: 'none'}}>
                          <button type="button" className="btn_pos" onClick={() => {this.providerNoticeDetail.handleInitState()}}>{this.props.messages.common_reset}</button>
                          {/* <button type="button" className="btn_pos" onClick={() => {this.handleSave('T')}}>임시저장</button> */}
                          <button disabled={fncBtnInfo['funcModYn']=='N'} type="button" className="btn_black" onClick={() => {this.providerNoticeDetail.handleSave()}}>{this.props.messages.notice_ok}</button>
                        </div>
                      </div>
                    </div>

                    <ProviderNoticeList onRef={ref => (this.providerNoticeList = ref)} onDetailView={this.handleDetailView} />

                    <ProviderNoticeDetail onRef={ref => (this.providerNoticeDetail = ref)} onDisplaySetting={this.handleDisplaySetting}/>

                  </div>

                </div>

              </div>

            </div>

          </section>
        );
    }
}

export default connect(mapStateToProps)(ProviderNotice);
