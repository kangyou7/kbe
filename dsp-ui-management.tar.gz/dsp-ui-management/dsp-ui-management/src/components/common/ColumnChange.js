import React from 'react';

/*다국어 모듈 시작*/
import { connect } from 'react-redux';
import { changeLangauge, mapStateToProps } from '../../language/Actions';
/*다국어 모듈 종료*/

class ColumnChange extends React.Component {

  constructor(props) {
    super(props);

    this.state = {
      isChecked : true
    }

    this.allChecked = this.allChecked.bind(this);
    this.handleCancel = this.handleCancel.bind(this);
    this.handleComplete = this.handleComplete.bind(this);
    this.handleClose = this.handleClose.bind(this);

  }


  //컴포넌트가 만들어지고 첫 렌더링을 다 마친 후 실행되는 메소드입니다.
  componentDidMount() {
    this.props.onRef(this)
  }

  //컴포넌트가 DOM 에서 사라진 후 실행되는 메소드입니다.
  componentWillUnmount() {
    this.props.onRef(null)
  }

  allChecked(obj) {
    $("input[name='columnCheck']").prop("checked", $(obj.target).is(":checked"));
  }

  handleCancel() {
    this.handleClose();
  }




  handleComplete() {

    let changeThead = this.props.listThead;

    $("input[name='columnCheck']").each(function(index) {

      changeThead[Number($(this).val())].view = $(this).is(":checked");
    });

    this.props.onColumnChange(changeThead);

    this.handleClose();
  }

  handleClose() {
    layer_close(".pop-list-change");
  }

  show() {
    layer_open(".pop-list-change");
  }

  render() {
    const mapToComponent = (data) => {
        return data.map((contract, i) => {//map
          if(contract.target) {
            return(
              <li key={i}>
                <span className="input_ico_box">
                  <input type="checkbox" name="columnCheck" id={'columnCheck_' + i} value={i} defaultChecked={contract.view}/>
                  <label htmlFor={'columnCheck_' + i}>{contract.name}</label>
                </span>
              </li>
            );
          }
        });

      }


    return(

      <div className="lpopup">

      	<div className="dimmed"></div>
      	<div className="popup_layer pop_list_change pop-list-change sm">
      		<div className="pop_container">
      			<div className="pop_header">
      				<h1>{this.props.messages.contract_select_item}</h1>
      			</div>

      			<div className="pop_contents scroll_wrap">
      				<div className="pop_inner">

      					<ul className="ip_row_list">
      						<li>
      							<span className="input_ico_box">
      								<input type="checkbox" name="all" id="all" defaultChecked={true} onClick={this.allChecked}/>
      								<label htmlFor="all">ALL</label>
      							</span>
      						</li>


                {mapToComponent(this.props.listThead)}



      					</ul>
      				</div>
      			</div>

      			<div className="pop_bottom">
      				<button type="button" className="pbtn_pos" onClick={this.handleCancel}>{this.props.messages.contract_cancel}</button>
      				<button type="button" className="pbtn_black" onClick={this.handleComplete}>{this.props.messages.contract_ok}</button>
      			</div>
      			<a href="javascript:void(0);" onClick={this.handleClose} className="btn_pop_close"><span className="offscreen">{this.props.messages.ticket_close}</span></a>
      		</div>
      	</div>
      </div>


    );
  }
}

ColumnChange.defaultProps = {
    onColumnChange: () => {console.error("onColumnChange not defined"); }
}

export default connect(mapStateToProps)(ColumnChange);
