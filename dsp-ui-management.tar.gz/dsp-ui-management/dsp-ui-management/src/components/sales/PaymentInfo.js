import React from 'react';

import {REST_API_URL} from '../../config/api-config.js';

/*다국어 모듈 시작*/
import { connect } from 'react-redux';
import { changeLangauge, mapStateToProps } from '../../language/Actions';
/*다국어 모듈 종료*/

class PaymentInfo extends React.Component {
    constructor(props) {
        super(props);
    
        this.state = {
            
        }

        this.handlePaymentCancel = this.handlePaymentCancel.bind(this);
        
    }

    getWebSocket(num) {
        let serverIp = "175.158.12.140";
        let switchIp = "218.50.55.107";
        let serverPort = "9102";

        let server = 1 <= num && 3 >= num ? serverIp : switchIp;


        let ws = new WebSocket("ws://" + server + ":" + serverPort);

        return ws;
    }

    handlePaymentCancel() {
        
         if(confirm("취소하시겠습니까?")) {

            $.ajax({
                url: REST_API_URL + "/sales/paymentCancel",
                dataType: 'json',
                type: "post",
                data:  {
                    salesSeq : this.props.setleInfo.salesSeq,
                    setleSeq : this.props.setleInfo.setleSeq
                },
                cache: false,
                success: function(result) {
                    if(result.response.cancelResult.resultCd == "0000") {
                        alert("취소되었습니다.");
                        this.props.onDisplaySetting("L");
                    } else {
                        alert("실패하였습니다.\n\n" + result.response.cancelResult.resultMsg);
                        this.props.onDisplaySetting("L");
                    }

                }.bind(this),
                    error: function(xhr, status, err) {
                    console.log(xhr + " : " + status + " : " + err);
                }.bind(this),
                xhrFields: {
                  withCredentials: true
                }
            });
        }


        

        
        
        
        
        
    }


    

    render() {
        return (

            <span>
                <div style={{height:'17px'}}></div>
                <div className="box_com">
                    <div className="fl">
                        <h3 className="ctitle">{this.props.messages.sales_billing_information}</h3>
                    </div>
                    <div className="fr">
                        {
                        this.props.setleInfo.setleWayClasCode == 'CN' ?
                            <a href="javascript:;" className="btn_pos" onClick={this.handlePaymentCancel}>{this.props.messages.sales_cancel_2}</a>
                        :
                            ''
                        }
                    </div>
                </div>

                <table className="tbl_row">
                    <caption>결제정보</caption>
                    <colgroup>
                        <col style={{width:'10%'}}/>
                        <col style={{width:'40%'}}/>
                        <col style={{width:'10%'}}/>
                        <col style={{width:'40%'}}/>
                    </colgroup>
                    <tbody>
                        <tr>
                            <th scope="row">{this.props.messages.sales_payment_method}</th>
                            <td>{this.props.setleInfo.setleWayClasCodeName}</td>
                            <th scope="row">{this.props.messages.sales_payment_method_2}</th>
                            <td>{this.props.messages.sales_single_payment}</td>
                        </tr>
                        <tr>
                            <th scope="row">{this.props.messages.sales_detail_information}</th>
                            <td>{this.props.setleInfo.setleWayCoName}{this.props.setleInfo.setleWayClasCode == 'CN' ? '(' + this.props.setleInfo.setleWayNo + ')' : ''}</td>
                            <th scope="row">{this.props.messages.sales_approval_date}</th>
                            <td>{this.props.setleInfo.setleConfDt}</td>
                        </tr>
                        <tr>
                            <th scope="row">{this.props.messages.sales_final_payment}</th>
                            <td colSpan='3'>{this.props.setleInfo.lastSetleAmt}</td>
                        </tr>
                    </tbody>
                </table>
            </span>
        );
    }
}

export default connect(mapStateToProps)(PaymentInfo);
