import React from 'react';
import { Link } from 'react-router';
import List from './List';
import Detail from './Detail';
import Create from './Create';

/*다국어 모듈 시작*/
import { connect } from 'react-redux';
import { changeLangauge, mapStateToProps } from '../../language/Actions';
/*다국어 모듈 종료*/

class Product extends React.Component {
    constructor(props) {
        super(props);
    
        this.state = {
            displadyState : "L",
            productNo : "",
            approverYn : "N",
            approvalButtonDisabled : true,
            pageInfo : {},
            listThead : [
                {name:props.messages.contract_no,               sort:false, sortColumn:"", view:true, target:false, width:'4%'},
                {name:props.messages.product_product_id,        sort:true,  sortColumn:"product_no", view:true, target:true, width:'10%'},
                {name:props.messages.product_division,          sort:true,  sortColumn:"product_dstnct_code_name", view:true, target:true, width:'10%'},
                {name:props.messages.product_usage,             sort:true, sortColumn:"product_use_purpose_code_name", view:true, target:true, width:'10%'},
                {name:props.messages.product_product_name,      sort:true, sortColumn:"product_name", view:true, target:true, width:'16%'},
                {name:props.messages.product_sales_status,      sort:true, sortColumn:"product_vdt_status_code_name", view:true, target:true, width:'10%'},
                {name:props.messages.product_writer,            sort:true, sortColumn:"reg_usr_name", view:true, target:true, width:'10%'},
                {name:props.messages.product_registration_date, sort:true, sortColumn:"reg_date", view:true, target:true, width:'10%'},
                {name:props.messages.product_approval_status,   sort:true, sortColumn:"aprv_status_code", view:true, target:true, width:'10%'},
                {name:props.messages.product_approver,          sort:true, sortColumn:"approver_name", view:true, target:true, width:'10%'}
            ],
            searchSelectOption : [
                {value:"", text : props.messages.product_select},
                {value:"product_id", text : props.messages.product_product_id},
                {value:"product_nm", text : props.messages.product_product_name},
                {value:"sale_state", text : props.messages.product_sales_status},
                {value:"register_id", text : props.messages.product_writer}
            ]
        }

        this.handleDisplaySetting = this.handleDisplaySetting.bind(this);

        this.handlePageInfoChange = this.handlePageInfoChange.bind(this);

        this.handleDetailView = this.handleDetailView.bind(this);

        this.approvalButtonState = this.approvalButtonState.bind(this);

        this.handleListReload = this.handleListReload.bind(this);
    }

    approvalButtonState(data) {

        if(data != this.state.approvalButtonDisabled) {
            this.setState({
                approvalButtonDisabled : data
            });
        }
    }

    componentDidMount() {
        if(this.props.location.pathname == "/productCreate") {
            this.handleDisplaySetting('C');
        } else {
            this.handleDisplaySetting('L');
        }
    }

    //컴포넌트가 prop 을 새로 받았을 때 실행됩니다.
    componentWillReceiveProps(nextProps) {
        if(this.props.locale !== nextProps.locale) {
            let listThead = this.state.listThead;

            listThead[0].name = nextProps.messages.contract_no;
            listThead[1].name = nextProps.messages.product_product_id;
            listThead[2].name = nextProps.messages.product_division;
            listThead[3].name = nextProps.messages.product_usage;
            listThead[4].name = nextProps.messages.product_product_name;
            listThead[5].name = nextProps.messages.product_sales_status;
            listThead[6].name = nextProps.messages.product_writer;
            listThead[7].name = nextProps.messages.product_registration_date;
            listThead[8].name = nextProps.messages.product_approval_status;
            listThead[9].name = nextProps.messages.product_approver;

            let searchSelectOption = this.state.searchSelectOption;

            searchSelectOption[0].text = nextProps.messages.product_select;
            searchSelectOption[1].text = nextProps.messages.product_product_id;
            searchSelectOption[2].text = nextProps.messages.product_product_name;
            searchSelectOption[3].text = nextProps.messages.product_sales_status;
            searchSelectOption[4].text = nextProps.messages.product_writer;
        }

        if(nextProps.location.pathname == "/productCreate") {
            this.handleDisplaySetting('C');
        } else {
            this.handleDisplaySetting('L');
        }
    }
    handleDisplaySetting(state) {
        if(this.state.displadyState == 'C' || this.state.displadyState == 'T' || this.state.displadyState == 'A' || this.state.displadyState == 'E') {
            if (!confirm("이 페이지에서 나가시겠습니까?\n작성중인 내용이 저장되지 않습니다.")) {
                return;
            }
        } 
        this.setState({displadyState : state});
    }

    handlePageInfoChange(pageInfo, reload) {
        this.setState({
            pageInfo : pageInfo
        });

        if(reload) {
            this.list.getList();
        }
    }

    handleDetailView(productNo, approverYn) {
        this.state.productNo = productNo;
        this.state.approverYn = approverYn;
        //this.contractDetail.getContract(contractId);
        this.handleDisplaySetting('D');
    }

    handleListReload() {
        //this.handleDisplaySetting('L');
        this.setState({
            displadyState : 'L'
        })
        this.contractList.getList();
    }

    render() {
        const fncBtnInfo = this.props.memberInfo.dspUserFncBtnInfo;
        return (

            <section className="body">
                
                <div className="wrapper">
                    
                    <div className="page_header">
                        <h2 className="ptitle">{this.state.displadyState == 'C' ? this.props.messages.product_product_registration : this.props.messages.product_product_status}</h2>
                        <div className="page_nav">
                            {/*<ul>
                                <li><Link to="/">Home</Link></li>
                                <li><a href="javascript:;" onClick={() => this.setState({displadyState:'L'})}>{this.props.messages.product_product_management}</a></li>
                                <li className="here">{this.state.displadyState == 'C' ? this.props.messages.product_product_registration : this.props.messages.product_product_status}</li>
                            </ul>*/}
                        </div>
                    </div>

                    <div className="content_wrap">
                        <div className="content_outbox">
                            <div className="tab_wrap tab-wrap">
                                <div className="box_both tab_header">		
                                    <div className="fl">
                                        <ul className="tabs">
                                            <li className={this.state.displadyState == 'L' ? "tab_item tab-item on" : "tab_item tab-item"}>
                                                <a href="javascript:;" onClick={() => this.handleDisplaySetting('L')} className="tab-link"><span>{this.props.messages.product_list}</span></a>
                                            </li>
                                            <li className={this.state.displadyState != 'L' ? "tab_item tab-item on" : "tab_item tab-item"}>
                                                <a href="javascript:;" className={this.state.displadyState == 'L' ? "tab-link disabled" : "tab-link"}><span>{this.props.messages.product_detail}</span></a>
                                            </li>
                                        </ul>
                                    </div>
                                    <div className="fr">
                                        <div className="btn_group" style={this.state.displadyState === 'C' ? {} : {display:'none'}}>
                                            <button type="button" className="btn_pos" onClick={() => {this.create.handleInitState()}}>{this.props.messages.product_reset}</button>
                                            <button type="button" disabled={fncBtnInfo['funcRegYn']=='N'} className="btn_pos" onClick={() => {this.create.handleSave('T')}}>{this.props.messages.product_ok}</button>
                                            <button type="button" disabled={fncBtnInfo['funcRegYn']=='N'} className="btn_black" onClick={() => {this.create.handleSave('W')}}>{this.props.messages.product_approval_request}</button>
                                        </div>

                                        <div className="btn_group" style={this.state.displadyState === 'T' ? {} : {display:'none'}}>
                                            <button type="button" disabled={fncBtnInfo['funcModYn']=='N'} className="btn_pos" onClick={() => {this.detail.handleSave('T')}}>{this.props.messages.product_ok}</button>
                                            <button type="button" disabled={fncBtnInfo['funcModYn']=='N'} className="btn_black" onClick={() => {this.detail.handleSave('W')}}>{this.props.messages.product_approval_request}</button>
                                        </div>

                                        <div className="btn_group" style={this.state.displadyState === 'A' ? {} : {display:'none'}}>
                                            <button type="button" disabled={fncBtnInfo['funcModYn']=='N'} className="btn_pos" onClick={() => {this.detail.handleApproval('R')}}>{this.props.messages.product_reject}</button>
                                            <button type="button" disabled={fncBtnInfo['funcModYn']=='N'} className="btn_black" onClick={() => {this.detail.handleApproval('A')}}>{this.props.messages.product_approved_2}</button>
                                        </div>

                                        <div className="btn_group" style={this.state.displadyState === 'E' ? {} : {display:'none'}}>
                                            <button type="button" disabled={fncBtnInfo['funcDelYn']=='N'} className="btn_pos" onClick={() => {this.detail.handleSave('DELETE')}}>{this.props.messages.product_delete}</button>
                                            <button type="button" disabled={fncBtnInfo['funcModYn']=='N'} className="btn_pos" onClick={() => {this.detail.handleSave('T')}}>{this.props.messages.product_ok}</button>
                                            <button type="button" disabled={fncBtnInfo['funcModYn']=='N'} className="btn_black" onClick={() => {this.detail.handleSave('W')}} disabled={this.state.approvalButtonDisabled}>{this.props.messages.product_approval_request}</button>
                                        </div>
                                    </div>
                                </div>
                                {/*
                                onDetailView={this.handleDetailView} 
                                                       pageInfo={this.state.pageInfo} 
                                                       
                                */}
                                {
                                this.state.displadyState == 'L' 
                                    ? <List onRef={ref => (this.list = ref)} onDisplaySetting={this.handleDisplaySetting} 
                                                        onDetailView={this.handleDetailView}
                                                        pageInfo={this.state.pageInfo} 
                                                        onPageInfoChange={this.handlePageInfoChange}
                                                        listThead={this.state.listThead}
                                                        searchSelectOption={this.state.searchSelectOption}
                                                        /> 
                                    : this.state.displadyState == 'C' 
                                        ? <Create onRef={ref => (this.create = ref)} onDisplaySetting={this.handleDisplaySetting} onListReload={this.handleListReload}/>
                                        : <Detail onRef={ref => (this.detail = ref)} onDisplaySetting={this.handleDisplaySetting} 
                                                        productNo={this.state.productNo}
                                                        approverYn={this.state.approverYn}
                                                        onApprovalButtonState={this.approvalButtonState}
                                                        onListReload={this.handleListReload}/>
                                }
                            </div>
                        </div>
                    </div>
                </div>

            </section>



        );
    }
}

export default connect(mapStateToProps)(Product);
