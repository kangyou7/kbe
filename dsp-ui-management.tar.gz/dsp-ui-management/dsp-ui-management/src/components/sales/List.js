import React from 'react';

import Search from './Search';
import PagingView from '../common/PagingView';
import ColumnChange from '../common/ColumnChange';

import {TableThead, TableColgroup} from '../common/TableThead';

import {REST_API_URL} from '../../config/api-config.js';

/*다국어 모듈 시작*/
import { connect } from 'react-redux';
import { changeLangauge, mapStateToProps } from '../../language/Actions';
/*다국어 모듈 종료*/

import validator from 'validator';

class List extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            list : [],
            pageInfo:{},
            salesSum : {}
        }

        this.handleDetailView = this.handleDetailView.bind(this);

        this.handleColumnChange = this.handleColumnChange.bind(this);
        this.handleSearch = this.handleSearch.bind(this);
        this.handlePageChange = this.handlePageChange.bind(this);
        this.handleSort = this.handleSort.bind(this);
    }

    //컴포넌트가 만들어지고 첫 렌더링을 다 마친 후 실행되는 메소드입니다.
	componentDidMount() {
        this.props.onRef(this);
        //this.getList();

        if(this.props.pageInfo.adjustYmStr != undefined) {
            this.getList();
        }
	}

	//컴포넌트가 DOM 에서 사라진 후 실행되는 메소드입니다.
	componentWillUnmount() {
		this.props.onRef(null);
    }
    
    //항목변경 팝업에서 항목 변경 후 state 정보 변경
    handleColumnChange(changeThead) {
        this.setState({
            listThead : changeThead
        });
    }

    handleSearch(searchInfo) {
        
        let pageInfo = this.props.pageInfo;
        pageInfo.adjustYmStr = searchInfo.adjustYmStr;
        pageInfo.adjustYmEnd = searchInfo.adjustYmEnd;
        pageInfo.splyUsrNo = searchInfo.splyUsrNo;
        pageInfo.demndUsrNo = searchInfo.demndUsrNo;
        pageInfo.rcvStatusCode = searchInfo.rcvStatusCode;
        pageInfo.searchKeyCode = searchInfo.searchKeyCode;
        pageInfo.searchKeyWord = searchInfo.searchKeyWord;
        
        this.props.onPageInfoChange(pageInfo, true);
    }
    //페이지 변경 및 페이지 출력 갯수 변경
    handlePageChange(perPageNum, page) {
        let changePage = this.props.pageInfo;
        changePage.perPageNum = perPageNum;
        changePage.page = page;
   
        this.props.onPageInfoChange(changePage, true);
    }
    handleSort(sort) {
        let sortPage = this.props.pageInfo;
        sortPage.sortColumn = sort.sortColumn;
        sortPage.sortType = sort.sortType;

        this.props.onPageInfoChange(sortPage, true);
    }

    handleDetailView(index) {
        this.props.onDetailView(this.state.list[index].salesSeq);
    }
   
    getList() {
        if(this.props.pageInfo.searchKeyCode != undefined && this.props.pageInfo.searchKeyCode == 'contract') {
            if(!(this.props.pageInfo.searchKeyWord == '' || validator.isNumeric(this.props.pageInfo.searchKeyWord))) {
                alert("계약ID는 숫자로만 입력하세요.");
                return;
            }
        }

        let data = this.props.pageInfo;

        data.loginUserNo = this.props.memberInfo.user_no;
        data.loginUserDstnctCode = this.props.memberInfo.user_dstnct_code;

        $.ajax({
            url: REST_API_URL + "/sales/List",
            dataType: 'json',
            type: "post",
            data: data,
            cache: false,
            success: function(result) {
                this.props.onPageInfoChange(result.response.pageInfo, false);
                this.setState({
                    list: result.response.list,
                    salesSum: result.response.salesSum
                    //pageInfo : result.pageInfo
                });
            }.bind(this),
            error: function(xhr, status, err) {
                console.log(xhr + " : " + status + " : " + err);
            }.bind(this),
			xhrFields: {
			  withCredentials: true
			}
        });
    }
    



    render() {

        const mapToList = (data, thead) => {
            if(data.length > 0) {
                return data.map((item, i) => {//map
                    return(
                        <tr key={i}>
                            <td style={thead[0].view ? {} : {display:'none'}}>{item.rownum}</td>
                            <td style={thead[1].view ? {} : {display:'none'}}>{item.splyUsrName}</td>
                            <td style={thead[2].view ? {} : {display:'none'}}><a href="javascript:;" onClick={() => {this.handleDetailView(i);}}>{item.demndUsrName}</a></td>
                            <td style={thead[3].view ? {} : {display:'none'}}>{item.ctrtNo}</td>
                            <td style={thead[4].view ? {} : {display:'none'}}>{item.billingStrDate}</td>
                            <td style={thead[5].view ? {} : {display:'none'}}>{item.billingEndDate}</td>
                            <td style={thead[6].view ? {} : {display:'none'}}>{item.trafficUp1}/<span className={item.trafficUp1 < item.trafficUp2 ? "tc_red" : ''}>{item.trafficUp2}</span></td>
                            <td style={thead[7].view ? {} : {display:'none'}}>{item.trafficDown1}/<span className={item.trafficDown1 < item.trafficDown2 ? "tc_red" : ''}>{item.trafficDown2}</span></td>
                            <td style={thead[8].view ? {} : {display:'none'}}>{item.storageCapacity1}/<span className={item.storageCapacity1 < item.storageCapacity2 ? "tc_red" : ''}>{item.storageCapacity2}</span></td>
                            <td style={thead[9].view ? {} : {display:'none'}}>{item.adjustYm}</td>
                            <td style={thead[10].view ? {} : {display:'none'}}>{item.thmonFeeSumAmt}</td>
                            <td style={thead[11].view ? {} : {display:'none'}}>{item.adjustDstnctCodeName}</td>
                            <td style={thead[12].view ? {} : {display:'none'}}>{item.rectStatusCodeName}</td>
                        </tr>
                    );
                });
            } else {
                let colspan = thead.length;
                for(var i = 0; i<thead.length; i++) {
                    colspan -= thead[i].view ? 0 : 1;
                }
                return (
                    <tr>
                        <td className="noresults" colSpan={colspan}>
                            <div className="box_noresults">
                                <div className="ver_mid">
                                    <i className="ico ico_no_result"></i>
                                    <span className="lb">{this.props.messages.product_search}</span>
                                </div>
                            </div>
                        </td>
                    </tr>
                );
            }
        }

        return (

            <div id="tab-cont2" className="tab_content tab-cont" style={{display:'block'}}>
                {/*S:content_body */}
                <div className="content_body sales_container">
                    {/*S:content_inner */}
                    <div className="content_inner">
                        
                            
                    
                        {/*<Search onSearch={this.handleSearch} 
                                searchSelectOption={this.props.searchSelectOption} 
                                searchInfo={{"searchKeyCode":this.props.pageInfo.searchKeyCode, "searchKeyWord":this.props.pageInfo.searchKeyWord}}
                        />*/}
                        <Search onSearch={this.handleSearch} 
                                searchSelectOption={this.props.searchSelectOption} 
                                searchInfo={this.props.pageInfo}
                                />
                        <div className="box_com">
                            <div className="fr">
                                
                                <a href="javascript:;" className="btn_pos" onClick={() => this.columnChange.show()}>{this.props.messages.contract_change_item}</a>
                                {/*<ul className="sort_wrap">
                                    <li className="active"><a href="javascript:;">List</a></li>
                                    <li><a href="javascript:;">Tree</a></li>
                                </ul>*/}
                            </div>
                        </div>
		
                        
                        <table className="tbl_row">
                            <caption>합계 목록</caption>
                            <colgroup>
                                <col style={{width:'10%'}}/>
                                <col style={{width:'40%'}}/>
                                <col style={{width:'10%'}}/>
                                <col style={{width:'40%'}}/>
                            </colgroup>
                            <tbody>
                                <tr>
                                    <th scope="row">{this.props.messages.sales_provider_total} {/*<br />매출금액 (전체)*/}</th>
                                    <td><span className="sales_price">{this.state.salesSum == null ? 0 : this.state.salesSum.providerSum}</span>{this.props.messages.product_won}</td>
                                    <th scope="row">{this.props.messages.sales_customer_total}{/*<br />매출금액 (전체)*/}</th>
                                    <td><span className="sales_price">{this.state.salesSum == null ? 0 : this.state.salesSum.customSum}</span>{this.props.messages.product_won}</td>
                                </tr>
                            </tbody>
                        </table>
                        
                        <table className="tbl_col">
                            <caption>매출현황 목록</caption>

                            <TableColgroup listThead={this.props.listThead} />
                            <TableThead listThead={this.props.listThead} onSort={this.handleSort}/>
                            
                            <tbody>

                                {mapToList(this.state.list, this.props.listThead)}
                               
                            </tbody>
                        </table>
                    </div>
                    {/*E:content_inner */}
                </div>

                <PagingView pageInfo={this.props.pageInfo} onPageChange={this.handlePageChange}/>

                <ColumnChange onRef={ref => (this.columnChange = ref)} listThead={this.props.listThead} onColumnChange={this.handleColumnChange} />
                
            </div>

        );
    }
}

export default connect(mapStateToProps)(List);
