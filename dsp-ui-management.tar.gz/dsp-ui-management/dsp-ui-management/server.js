/*jshint esversion: 6 */
var path = require('path');
var webpack = require('webpack');
var WebpackDevServer = require('webpack-dev-server');
var config = require('./webpack.config');
require("node-express-async");

///////////////////////////////////////////////////////////////////
var express = require('express');
var url = require('url');
var bodyParser = require('body-parser');
var axios = require('axios');
var ip = require('ip');
var iconv = require('iconv-lite');

var euckrDecode = require('./euckrDecode');


const router = express.Router();

const app = express();
const port = 8888;
const devPort = 8080;

let domain = "https://api.secudiumiot.com/manage";

if(process.env.active == 'local') {
    domain = "http://localhost:8081";
}

console.log("process.env.active : " + process.env.active);
console.log("domain : " + domain);

app.use(bodyParser.urlencoded({ extended: true })); // support encoded bodies
app.use(bodyParser.json());
app.use('/', express.static(path.join(__dirname, './public')));
app.post('/paymentNoti', async (req, res) => {

    console.log("결제 결과");

    /*카드, 이체 공통 리턴*/
    console.log("1 " + req.body.Resultcd);				/* 결과코드 */  
    console.log("2 " + euckrDecode.decodeURIforEUCKR(req.body.Resultmsg));			    /* 결과메세지 */  
    console.log("3 " + req.body.Svcid);					/* 서비스아이디 */  
    console.log("4 " + req.body.Mobilid);				/* 모빌리언스 거래번호 */
    console.log("5 " + req.body.Signdate);				/* 결제일자 */
    console.log("6 " + req.body.Tradeid);				/* 상점거래번호 */
    console.log("7 " + req.body.Prdtnm);				/* 상품명 */
    console.log("8 " + req.body.Prdtprice);				/* 상품가격 */
    console.log("9 " + req.body.Userid);				/* 사용자ID */
    console.log("10 " + req.body.MSTR);					/* 가맹점 전달 콜백변수 */

    /*카드 리턴*/
    console.log("11 " + req.body.CASH_GB); 				/* 결제수단(CN)*/
    console.log("12 " + req.body.Install);				/* 할부개월 */
    console.log("13 " + req.body.MxHASH);				/* 결과값 검증 hash데이터 */
    console.log("14 " + req.body.Payeremail);			/* 결제자이메일 */
    console.log("15 " + req.body.CardNum);				/* 결제 카드번호 */
    console.log("16 " + req.body.CardCd);				/* 결제 카드코드 */
    console.log("17 " + euckrDecode.decodeURIforEUCKR(req.body.CardNm));				/* 결제 카드사명 */

    /*이체 리턴 */
    console.log("18 " + req.body.Mrchid);               /*[   8byte 고정] 상점ID*/
    console.log("19 " + req.body.Banknm);               /*은행 명*/ 

    var mstr = req.body.MSTR;
    //mstr = mstr.replace(/&amp;quot;/g,"\""));
    //mstr = mstr.replace(/&quot;/g,"\"");
    mstr = mstr.replace(/\|/g,"\"");
    

    console.log(mstr);
    console.log("GGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGG");
    var trans = JSON.parse(mstr);
    console.log(trans);
    console.log("ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ");

    axios.post(domain + '/sales/paymentNoti', 
        { 
            /*카드, 이체 공통 리턴*/
            resultcd : req.body.Resultcd,				/* 결과코드 0000 : 결제 성공, 그외 결제 실패*/  
            resultmsg : euckrDecode.decodeURIforEUCKR(req.body.Resultmsg),			    /* 결과메세지 */  
            svcid : req.body.Svcid,					/* 서비스아이디 */  
            mobilid : req.body.Mobilid,				/* 모빌리언스 거래번호 */
            signdate : req.body.Signdate,				/* 결제일자 */
            tradeid : req.body.Tradeid,				/* 상점거래번호 */
            prdtnm : req.body.Prdtnm,				/* 상품명 */
            prdtprice : req.body.Prdtprice,				/* 상품가격 */
            userid : req.body.Userid,				/* 사용자ID */
            mstr : mstr,					/* 가맹점 전달 콜백변수 */

            /*카드 리턴*/
            cashGb : req.body.CASH_GB, 				/* 결제수단(CN)*/
            install : req.body.Install,				/* 할부개월 */
            mxHash : req.body.MxHASH,				/* 결과값 검증 hash데이터 */
            payereEail : req.body.Payeremail,			/* 결제자이메일 */
            cardNum : req.body.CardNum,				/* 결제 카드번호 */
            cardCd : req.body.CardCd,				/* 결제 카드코드 */
            cardNm : euckrDecode.decodeURIforEUCKR(req.body.CardNm),				/* 결제 카드사명 */

            /*이체 리턴 */
            mrchid : req.body.Mrchid,                 /*[   8byte 고정] 상점ID*/
            banknm : req.body.Banknm,
            trans : trans
        }
    )
    .then( response => { 

        if(response.data.response.resultMsg){
            if(req.body.CASH_GB == 'CN'){
                res.send("ACK=200OKOK");
            } else {
                res.send("SUCCESS");
            }
        } else {
            if(req.body.CASH_GB == 'CN'){
                res.send("ACK=400FAIL");
            } else {
                res.send("FAIL");
            }
        }
     } )
    .catch( response => { 
        if(req.body.CASH_GB == 'CN'){
            res.send("ACK=400FAIL");
        } else {
            res.send("FAIL");
        }
    });
});

app.post('/paymentOk', function(req, res) {
    //완료 화면 호출
    console.log("paymentOk");

    /*카드, 이체 공통 리턴*/
    console.log("1 " + req.body.CASH_GB); /* 결제수단(CN)*/
    console.log("2 " + req.body.Svcid); /* 서비스아이디 */
    console.log("3 " + req.body.Mobilid); /* 모빌리언스 거래번호 */
    console.log("4 " + req.body.Signdate); /* 결제일자 */
    console.log("5 " + req.body.Tradeid); /* 상점거래번호 */
    console.log("6 " + req.body.Prdtnm); /* 상품명 */
    console.log("7 " + req.body.Prdtprice); /* 상품가격 */
    console.log("8 " + req.body.Userid); /* 사용자아이디*/
    console.log("9 " + req.body.Resultcd); /* 결과코드 */
    console.log("10 " + euckrDecode.decodeURIforEUCKR(req.body.Resultmsg)); /* 결과메세지 */
    console.log("11 " + req.body.Payeremail); /* 결제자 이메일 */
    console.log("12 " + req.body.MSTR); /* 가맹점 전달 콜백변수 */

    /*카드 리턴*/
    console.log("13 " + req.body.Install); /* 할부개월수 */

    /*이체 리턴 */
    console.log("14 " + req.body.Mrchid); /* 상점ID */

    var mstr = req.body.MSTR;
    //mstr = mstr.replace(/&amp;quot;/g,"\""));
    //mstr = mstr.replace(/&quot;/g,"\"");
    mstr = mstr.replace(/\|/g,"\"");
    

    console.log(mstr);
    console.log("GGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGG");
    var trans = JSON.parse(mstr);
    console.log(trans);
    console.log("ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ");

    

    res.redirect(url.format({
        pathname:"/paymentResult",
        query : {
            Resultcd : req.body.Resultcd,
            Resultmsg : req.body.Resultmsg,
            salesSeq : trans.salesSeq
        }
    }))
});




app.get('*', (req, res) => {
    res.sendFile(path.resolve(__dirname, './public/index.html'));
});

app.use(function(err, req, res, next) {
  console.error(err.stack);
  res.status(500).send('Something broke!');
});


//Express 서버 포트 설정
app.listen(port, () => {
    console.log('Express is listening on port', port);
});

module.exports = router;

if(process.env.active == 'local') {     
    const compiler = webpack(config);
    const devServer = new WebpackDevServer(compiler, config.devServer);
    devServer.listen(
        devPort, () => {
            console.log('webpack-dev-server is listening on port', devPort);
        }
    );
} else {
    new WebpackDevServer(webpack(config), {
        inline: true,
        contentBase: config.output.path,
        publicPath: config.output.publicPath,
        hot: true,
        historyApiFallback: true,
        stats: {
        colors: true
        },
        host: '0.0.0.0',
        disableHostCheck: true,
            proxy: {
                    "*": "http://" + ip.address() + ":" + port,
                    target:"https://api.secudiumiot.com",
                    secure: false
            }
    }).listen(devPort, function (err) {
        if (err) {
            console.log(err);
        }
        console.log('✅  Server is listening at http://localhost:8080');
    });
}

