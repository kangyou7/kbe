import React from 'react';
import axios from 'axios';

import {REST_API_URL} from '../../config/api-config.js';
//import {listNoData} from '../sub/ListNoData';

/*다국어 모듈 시작*/
import { connect } from 'react-redux';
import { changeLangauge, mapStateToProps } from '../../language/Actions';
/*다국어 모듈 종료*/

class NoticeDetailPopup extends React.Component{

    constructor(props) {
        super(props);
        this.state = {
            noticeTitle : "",
            noticeContent : ""
        }
    }

    closeNoticeDetailPopup() {
        layer_close('.pop-layer-notice-detail');
    }

    componentWillReceiveProps(nextProps) {
        this.setState({
            noticeTitle : nextProps.notice.noticeTitle,
            noticeContent : nextProps.notice.noticeContent
        })
    }

    render(){
        const divListStyleOff = {color: 'rgb(0, 0, 0)', fontSize: '13px'};
        const divListStyleOn = {color: 'rgb(68, 68, 68)', fontSize: '13px'};

        return(
            <div className="lpopup" style={{display: 'none'}}>
                <div className="dimmed"></div>
                <div className="popup_layer pop_layer_notice_detail pop-layer-notice-detail lg" style={{'left': '610px', 'top': '0px', 'msOverflowY': 'hidden'}}>
                    <div className="pop_container">
                        <div className="pop_header">
                            <h1>Notice</h1>
                        </div>
                        { /* <!-- pop_contents --> */ }
                        <div className="pop_contents scroll_wrap" data-origin-height="574.8">
                            <div className="pop_inner">
                                <div className="notice_cont">
                                { /* <!-- S:본문상세 --> */ }
                                    <div className="subject">{this.state.noticeTitle }</div>

                                    <div dangerouslySetInnerHTML={{ __html: this.state.noticeContent }}></div>
                                { /* <!-- E:본문상세 --> */ }
                                </div>
                                { /* <!-- E:notice_cont --> */ }
                            </div>
                        </div>	
                        { /* <!--// pop_contents--> */ }
                        { /* <!-- <div className="pop_bottom">
                            <a href="javascript:;" className="pbtn_pos" onClick="javascript:layer_close('.pop-layer-ex');">취소</a>
                            <a href="javascript:;" className="pbtn_black" onClick="javascript:layer_close('.pop-layer-ex');">확인</a>
                        </div> --> */ }
                    </div>{ /* <!--// pop_container --> */ }
                    <a className="btn_pop_close" onClick={this.closeNoticeDetailPopup.bind(this)} href="javascript:;"><span className="offscreen">닫기</span></a>
                </div>{ /* <!--// popup_layer --> */ }
            </div>
        );
    }

}

export default connect(mapStateToProps)(NoticeDetailPopup);

