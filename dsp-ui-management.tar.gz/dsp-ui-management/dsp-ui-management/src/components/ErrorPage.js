import React from 'react';

class LoginPage extends React.Component {
    render() {
        return (
            <div>
                <h2>없는 페이지입니다.</h2>
            </div>
        );
    }
}

export default LoginPage;
