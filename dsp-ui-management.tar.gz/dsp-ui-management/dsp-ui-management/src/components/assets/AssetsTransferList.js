import React from 'react';

import { Link } from 'react-router';
import { browserHistory } from 'react-router';

import PagingView from '../common/PagingView';
import ColumnChange from '../common/ColumnChange';
import {TableThead, TableColgroup} from '../common/TableThead';

import {REST_API_URL} from '../../config/api-config.js';

/*다국어 모듈 시작*/
import { connect } from 'react-redux';
import { changeLangauge, mapStateToProps } from '../../language/Actions';
/*다국어 모듈 종료*/



class AssetsTransferList extends React.Component {

  constructor(props) {
    super(props);

    this.state = {
      searchKeyCode : "",
      searchKeyWord : "",
      checkedIndex : "",
      checkedAssetsSeq : "",
      checkedAssetsStatus : "",
      listThead : [
        {name:"NO",   sort:false, sortColumn:"rownum", view:true, target:false, width:'5%'},
        {name:"구분",  sort:true, sortColumn:"equipTransferDstinctCode", view:true, target:true, width:'10%'},
        {name:"고객명",     sort:true, sortColumn:"coName", view:true, target:true, width:'10%'},
        {name:"벤더명",   sort:true, sortColumn:"equipVendorName", view:true, target:true, width:'15%'},
        {name:"모델명",   sort:true, sortColumn:"equipModelName", view:true, target:true, width:'15%'},
        {name:"고유 Code No",   sort:true, sortColumn:"assetsNatvNoValue", view:true, target:true, width:'15%'},
        {name:"이관 신청자",   sort:true, sortColumn:"transferReqUsrName", view:true, target:true, width:'15%'},
        // {name:"이관 요청일",   sort:true, sortColumn:"equipTransferReqDate", view:true, target:true, width:'10%'},
        {name:"장비 이관일",   sort:true, sortColumn:"equipTransferDate", view:true, target:true, width:'15%'}
        // {name:"출고처", sort:true, sortColumn:"wrplResNoCustomerNm", view:true, target:true}
      ],
      list : [],
      pageInfo:{
        //totalCount : 0,
        //perPageNum : 0,
        //page : 0
      }

    }
    this.handleChange = this.handleChange.bind(this);
    this.handleSearch = this.handleSearch.bind(this);
    this.handlePageChange = this.handlePageChange.bind(this);

    this.handleColumnChangeView = this.handleColumnChangeView.bind(this);
    this.handleColumnChange = this.handleColumnChange.bind(this);
    this.handleDetailView = this.handleDetailView.bind(this);
    this.handleSort = this.handleSort.bind(this);
    
  }

  handleChange(e) {
    let nextState = {};
    nextState[e.target.name]=e.target.value;
    this.setState(nextState);
  }

  getList() {
    
    $.ajax({
      url: REST_API_URL+"/assets/TransferList",
      dataType: 'json',
      type: "post",
      data: this.state.pageInfo,
      xhrFields : {
        withCredentials : true
      },
      success: function(result) {
        this.setState({
          list: result.response.list,
          pageInfo : result.response.pageInfo
        });
      }.bind(this),
      error: function(xhr, status, err) {
        console.log(xhr + " : " + status + " : " + err);
      }.bind(this)
    });
  }

  handleSearch() {
    let pageInfo = this.state.pageInfo;
    pageInfo.searchKeyCode = this.state.searchKeyCode;
    pageInfo.searchKeyWord = this.state.searchKeyWord;
    this.setState({
      pageInfo : pageInfo
    })
    this.getList();
  }
  //페이지 변경 및 페이지 출력 갯수 변경
  handlePageChange(perPageNum, page) {

    let changePage = this.state.pageInfo;
    changePage.perPageNum = perPageNum;
    changePage.page = page;
    this.setState({
      pageInfo:changePage
    })


    this.getList();

  }

  handleSort(sort) {
    let sortPage = this.state.pageInfo;
    sortPage.sortColumn = sort.sortColumn;
    sortPage.sortType = sort.sortType;
    this.setState({
        pageInfo:sortPage
    })

    this.getList();
}


  //항목변경 팝업 호출
  handleColumnChangeView(e) {
    this.refs.columnChange.show();
 }

 //항목변경 팝업에서 항목 변경 후 state 정보 변경
 handleColumnChange(changeThead) {
   this.setState({
     listThead : changeThead
   });
 }

 handleDetailView(index) {
   this.props.onDetailView(this.state.list[index].assetsNo, this.state.list[index].regDate, this.state.list[index].equipTransferSeq);
 }
  //페이지 로딩 시 목록 조회
  componentDidMount() {
    this.props.onRef(this)
    this.getList();
  }

  componentWillUnmount() {
    this.props.onRef(null)
  }

  render() {
    const fncBtnInfo = this.props.memberInfo.dspUserFncBtnInfo;
      const mapToComponent = (data, thead) => {
        if(data.length > 0) {
          return data.map((assets, i) => {//map
            return(<tr key={i}>
              <td style={thead[0].view ? {} : {display:'none'}}>{assets.rownum}</td>
              <td style={thead[1].view ? {} : {display:'none'}}>{assets.equipTransferDstinctCode}</td>
              <td style={thead[2].view ? {} : {display:'none'}}>{assets.coName}</td>
              <td style={thead[3].view ? {} : {display:'none'}}>{assets.equipVendorName}</td>
              <td style={thead[4].view ? {} : {display:'none'}}><a href="javascript:;" onClick={() => {this.handleDetailView(i);}}>{assets.equipModelName}</a></td>
              <td style={thead[5].view ? {} : {display:'none'}}>{assets.assetsNatvNoValue}</td>
              <td style={thead[6].view ? {} : {display:'none'}}>{assets.transferReqUsrName}</td>
              {/* <td style={thead[7].view ? {} : {display:'none'}}>{assets.equipTransferReqDate}</td> */}
              <td style={thead[7].view ? {} : {display:'none'}}>{assets.equipTransferDate}</td>
              {/* <td style={thead[9].view ? {} : {display:'none'}}>{assets.wrplResNoCustomerNm}</td> */}
            </tr>);
          });
        } else {
          return (
            <tr>
              <td className="noresults" colSpan={9}>
                <div className="box_noresults">
                  <div className="ver_mid">
                    <i className="ico ico_no_result"></i>
                    <span className="lb">검색결과가 없습니다.</span>
                  </div>
                </div>
              </td>
            </tr>
          );
        }
      }

      return (
          <div id="tab-cont1" className="tab_content tab-cont" >

            <div className="content_body">

              <div className="content_inner">


                <div className="box_com term_wrap">
                    {/* <Search onSearch={this.handleSearch}/> */}
                  
                  <div className="fl">
                    <select className="ui_sel" name="searchKeyCode" value={this.state.searchKeyCode} onChange={this.handleChange} >
                      <option value="">{this.props.messages.assets_select}</option>
                      <option value="vendorNm">{this.props.messages.assets_vendor_name}</option>
                      <option value="modelNm">{this.props.messages.assets_model_name}</option>
                      <option value="serialNo">{this.props.messages.assets_serial_no}</option>
                  </select>
										<span className="input_search_box" style={{marginLeft: '6px'}}>
                      <input type="text" className="ui_input" name="searchKeyWord" value={this.state.searchKeyWord} onChange={this.handleChange}/>
                      <a id="searchAssets" className="btn_search" href="javascript:void(0);"
                      onClick={this.handleSearch}><span className="offscreen">검색</span></a>
                    </span>
		
									</div>
                </div>


                <table className="tbl_col">
                  <caption>장비 이관 목록</caption>
                  <TableColgroup listThead={this.props.listThead} />
                  <TableThead listThead={this.props.listThead} onSort={this.handleSort}/>

                  <tbody id="contractTbody">

                    {mapToComponent(this.state.list, this.props.listThead)}


                  </tbody>
                </table>

              </div>

            </div>

            <PagingView pageInfo={this.state.pageInfo} onPageChange={this.handlePageChange}/>

            <ColumnChange onRef={ref => (this.columnChange = ref)} listThead={this.props.listThead} onColumnChange={this.handleColumnChange} />
            
          </div>

      );
    }
}

export default connect(mapStateToProps)(AssetsTransferList);
