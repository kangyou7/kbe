cd /dsp-ui-management
npm run stg
