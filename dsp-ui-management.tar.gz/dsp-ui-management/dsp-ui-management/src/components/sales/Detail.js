import React from 'react';

import { Link } from 'react-router';

import {REST_API_URL} from '../../config/api-config.js';

import Payment from './Payment';
import PaymentInfo from './PaymentInfo';

/*다국어 모듈 시작*/
import { connect } from 'react-redux';
import { changeLangauge, mapStateToProps, loginAction } from '../../language/Actions';
/*다국어 모듈 종료*/

const initialState = {
    
    salesSeq : "",
	cntrctNo : "",
	splyUsrNo : "",
	demndUsrNo : "",
	billingStrDate : "",
    billingEndDate : "",
    adjustYm : "",
    adjustDstnctCode : "",
    salesSumAmt : "",
    dcRate : "",
    dcFee : "",
    dcFeeSumAmt : "",
    nopayCg : "",
    vat : "",
    thmonFeeSumAmt : "",
    rcvrectStatusCodeStatusCode : "",
    customerInfo : {},
    providerInfo : {},
    contractInfo : {},
    usage : [],
    asset : [],
    controlUi : [],
    function : [],
    offline : [],
};



class Detail extends React.Component {
    constructor(props) {
        super(props);

        this.state = $.extend(true, {}, initialState);
    
    }

    //컴포넌트가 만들어지고 첫 렌더링을 다 마친 후 실행되는 메소드입니다.
	componentDidMount() {
        this.props.onRef(this);
        this.getSales(this.props.salesSeq);
	}

	//컴포넌트가 DOM 에서 사라진 후 실행되는 메소드입니다.
	componentWillUnmount() {
		this.props.onRef(null);
    }
    

    getSales(salesSeq) {
        
        $.ajax({
            url: REST_API_URL + "/sales/getSales",
            dataType: 'json',
            type: "post",
            data: {
                salesSeq:salesSeq
            },
            cache: false,
            success: function(result) {
                this.setState(result.response.sales);
                console.log(result.response.sales);
            }.bind(this),
            error: function(xhr, status, err) {
                console.log(xhr + " : " + status + " : " + err);
            }.bind(this),
			xhrFields: {
			  withCredentials: true
			}
        });
    }
    
    

    render() {
        const mapToUsage = (data) => {
            if(data.length > 0) {
                return data.map((item, i) => {//map
                    return(
                        <tr key={i}>
                            <td>{item.productDtlTypeCodeName}</td>
                            <td><span className={item.productBasProviderCap < item.ctrtProductThmonUseCap ? "tc_red" : ''}>{item.ctrtProductThmonUseCap}</span></td>
                            <td>{item.productBasProviderCap}</td>
                            <td>{item.productBasFee}</td>
                            <td><span className={item.ctrtProductExcdUseCap > 0 ? "tc_red" : ''}>{item.ctrtProductExcdUseCap}</span></td>
                            <td>{item.ctrtProductExcdFeeUnival}</td>
                            <td>{item.ctrtProductExcdFee}</td>
                            <td>{item.ctrtProductFeeSumAmt}</td>
                        </tr>
                    );
                });
            } 
        }


        const assetServiceInfo = (data) => {
            if(data.length > 0) {
                let sum = 0;
                data.map((item, i) => {//map
                    sum += item.ctrtProductFeeSumAmt;
                });
                return (
                    <tr>
                        <td className="td_line_right">{this.props.messages.sales_assets}</td>
                        <td>-</td>
                        <td>{sum}</td>
                    </tr>
                )
            }
        }
        
        const ServiceInfoPrintType1 = (data) => {
            if(data.length > 0) {
                return data.map((item, i) => {
                    return (
                        <tr key={i}>
                            {i===0 ? <td className="td_line_right" rowSpan={data.length}>{item.productTypeCodeName}</td> : ""}
                            <td>{item.productDtlTypeCodeName}</td>
                            <td>{item.ctrtProductFeeSumAmt}</td>
                        </tr>
                    )
                });
                
            }
        }

        const ServiceInfoPrintType2TitleMerge = (data, productTypeCodeName, title) => {

            let rowspan = 0;
            data.map((item, i) => {//map
                if(item.productTypeCodeName === productTypeCodeName) {
                    rowspan++ ;
                }
            });
            
            return (
                <td rowSpan={rowspan} className="td_line_right">{productTypeCodeName + ' > ' + title}</td>
            );
        }

        const ServiceInfoPrintType2 = (data, title) => {
            if(data.length > 0) {
                let productTypeCodeName = "";
                let productTypeCodeNameTd = "";
                return data.map((item, i) => {
                    productTypeCodeNameTd = "";
                    if(productTypeCodeName != item.productTypeCodeName) {
                        productTypeCodeName = item.productTypeCodeName;
                        productTypeCodeNameTd = ServiceInfoPrintType2TitleMerge(data, productTypeCodeName, title);
                    }
                    return (
                        <tr key={i}>
                            {productTypeCodeNameTd}
                            <td>{item.productDtlTypeCodeName}</td>
                            <td>{item.ctrtProductFeeSumAmt}</td>
                        </tr>
                    )
                });
                
            }
        }
        
        

        return (

            <div id="tab-cont1" className="tab_content tab-cont no_paging" style={{display:'block'}}>
                <div className="content_body">
                    <div className="content_inner">
                        <div className="box_com">
                            <div className="fl">
                                <h3 className="ctitle">{this.props.messages.sales_customer_information}</h3>
                            </div>
                            <div className="fr">
                                <a href="javascript:;" className="btn_pos">{this.props.messages.sales_customer_details}</a>
                            </div>
                        </div>
                        
                        {/* S:고객정보 */}
                        <table className="tbl_row">
                            <caption>{this.props.messages.sales_customer_information}</caption>
                            <colgroup>
                                <col style={{width:'10%'}}/>
                                <col style={{width:'40%'}}/>
                                <col style={{width:'10%'}}/>
                                <col style={{width:'40%'}}/>
                            </colgroup>
                            <tbody>
                                <tr>
                                    <th scope="row">{this.props.messages.sales_customer_name}</th>
                                    <td className="tw_bold" colSpan="3">{this.state.customerInfo.coName}</td>
                                </tr>
                                <tr>
                                    <th scope="row">{this.props.messages.sales_customer_division}</th>
                                    <td>{this.state.customerInfo.customerClasName}</td>
                                    <th className="row">{this.props.messages.sales_representative}</th>
                                    <td>{this.state.customerInfo.ceoName}</td>
                                </tr>
                                <tr>
                                    <th scope="row">{this.props.messages.sales_business_number}</th>
                                    <td colSpan="3">{this.state.customerInfo.bizno}</td>
                                </tr>
                                <tr>
                                    <th scope="row">{this.props.messages.sales_manager}</th>
                                    <td>{this.state.customerInfo.chargeUsrName}</td>
                                    <th scope="row">{this.props.messages.sales_e_mail}</th>
                                    <td>{this.state.customerInfo.chargeUsrEmail}</td>
                                </tr>
                                <tr>
                                    <th scope="row">{this.props.messages.sales_phone}</th>
                                    <td>{this.state.customerInfo.chargeUsrTel}</td>
                                    <th scope="row">{this.props.messages.sales_cell_phone}</th>
                                    <td>{this.state.customerInfo.chargeUsrMobileNo}</td>
                                </tr>
                            </tbody>
                        </table>
                        {/* E:고객 정보 */}

                        <div className="box_com">
                            <div className="fl">
                                <h3 className="ctitle">{this.props.messages.sales_contract_information}</h3>
                            </div>
                            <div className="fr">
                                <Link to={{ pathname: "/popupDetail", query: { item:'contract', ctrtNo: this.state.ctrtNo } }} className="btn_pos" target="_blank">{this.props.messages.sales_contract_detail}</Link>
                            </div>
                        </div>
                        
                        {/* S:계약 정보 */}
                        <table className="tbl_row">
                            <caption>계약정보</caption>
                            <colgroup>
                                <col style={{width:'10%'}}/>
                                <col style={{width:'40%'}}/>
                                <col style={{width:'10%'}}/>
                                <col style={{width:'40%'}}/>
                            </colgroup>
                            <tbody>
                                <tr>
                                    <th scope="row">{this.props.messages.sales_contract_id}</th>
                                    <td>{this.state.contractInfo.ctrtNo}</td>
                                    <th scope="row">{this.props.messages.sales_product_name}</th>
                                    <td>{this.state.contractInfo.productInfo != null ? this.state.contractInfo.productInfo.productName : ''}</td>
                                </tr>
                                <tr>
                                    <th scope="row">{this.props.messages.sales_provider}</th>
                                    <td>{this.state.contractInfo.splyUsrName}</td>
                                    <th scope="row">{this.props.messages.sales_customer_manager}</th>
                                    <td></td>
                                </tr>
                                <tr>
                                    <th scope="row">{this.props.messages.sales_contract_start_date}</th>
                                    <td>{this.state.contractInfo.ctrtStrDate}</td>
                                    <th scope="row">{this.props.messages.sales_contract_end_date}</th>
                                    <td>{this.state.contractInfo.ctrtEndDate}</td>
                                </tr>
                                <tr>
                                    <th scope="row">{this.props.messages.sales_service_start_date}</th>
                                    <td>{this.state.contractInfo.svcStrDate}</td>
                                    <th scope="row">{this.props.messages.sales_service_end_date}</th>
                                    <td>{this.state.contractInfo.svcEndDate}</td>
                                </tr>
                                <tr>
                                    <th scope="row">{this.props.messages.sales_billing_start_date}</th>
                                    <td>{this.state.contractInfo.billingStrDate}</td>
                                    <th scope="row">{this.props.messages.sales_billing_end_date}</th>
                                    <td>{this.state.contractInfo.billingEndDate}</td>
                                </tr>
                            </tbody>
                        </table>
                        {/* E:계약 정보 */}


                        <div className="box_com">
                            <div className="fl">
                                <h3 className="ctitle">{this.props.messages.sales_usage}</h3>
                            </div>
                            <div className="fr">
                                <div className="desc">2018/08/01 ~ 2018/08/20 (00{this.props.messages.sales_hour})</div>
                            </div>
                        </div>
                        
                        {/* S:계약 정보 */}
                        <table className="tbl_col">
                            <caption>사용량 정보</caption>
                            <colgroup>
                                <col style={{width:'12.5%'}}/>
                                <col style={{width:'12.5%'}}/>
                                <col style={{width:'12.5%'}}/>
                                <col style={{width:'12.5%'}}/>
                                <col style={{width:'12.5%'}}/>
                                <col style={{width:'12.5%'}}/>
                                <col style={{width:'12.5%'}}/>
                                <col style={{width:'12.5%'}}/>
                            </colgroup>
                            <thead>
                                <tr>
                                    <th scope="col">{this.props.messages.sales_item}</th>
                                    <th scope="col">{this.props.messages.sales_monthly_usage}</th>
                                    <th scope="col">{this.props.messages.sales_basic_usage}</th>
                                    <th scope="col">{this.props.messages.sales_basic_rate}</th>
                                    <th scope="col">{this.props.messages.sales_excess_usage}</th>
                                    <th scope="col">{this.props.messages.sales_excess_rate}</th>
                                    <th scope="col">{this.props.messages.sales_excess_charge}</th>
                                    <th scope="col">{this.props.messages.sales_total_2}</th>
                                </tr>
                            </thead>
                            <tbody>
                                {mapToUsage(this.state.usage)}
                            </tbody>
                        </table>
                        {/* E:사용량 정보 */}


                        <div className="box_com">
                            <div className="fl">
                                <h3 className="ctitle">
                                    {this.state.adjustDstnctCode === '01' ? this.props.messages.sales_expected_payment : this.props.messages.sales_payment_information}
                                </h3>
                            </div>
                        </div>

                        <div className="msg_box">
                            <p className="desc">2018{this.props.messages.sales_year} 5{this.props.messages.sales_month} {this.state.adjustDstnctCode === '01' ? this.props.messages.sales_now : ''} {this.props.messages.sales_now_billing_amount} <span className="tc_blue tw_bold">{this.state.thmonFeeSumAmt}</span> {this.props.locale == 'KO' ? '원 입니다.' : ''} </p>
                            <p className="sub_desc">{this.props.messages.sales_period_of_use} : 18/03/01 ~ 18/03/30 (00{this.props.messages.sales_hour})</p>
                        </div>

                        <table className="tbl_col tbl_over_none">
                            <caption>세부 정보</caption>
                            <colgroup>
                                <col style={{width:'33%'}}/>
                                <col style={{width:'33%'}}/>
                                <col style={{width:'auto'}}/>
                            </colgroup>
                            <thead>
                                <tr>
                                    <th scope="col">{this.props.messages.sales_item}</th>
                                    <th scope="col">{this.props.messages.sales_detail}</th>
                                    <th scope="col">{this.props.messages.sales_price}</th>
                                </tr>
                            </thead>
                            <tbody>
                                {/*사용량 정보*/}
                                <tr>
                                    <td rowSpan='2' className="td_line_right">{this.props.messages.product_traffic}</td>
                                    <td>Up</td>
                                    <td>{this.state.usage.length <= 0 ? '' : this.state.usage[0].ctrtProductFeeSumAmt}</td>
                                </tr>
                                <tr>
                                    <td>Down</td>
                                    <td>{this.state.usage.length <= 0 ? '' : this.state.usage[1].ctrtProductFeeSumAmt}</td>
                                </tr>
                                <tr>
                                    <td className="td_line_right">{this.props.messages.product_storage_capacity}</td>
                                    <td></td>
                                    <td>{this.state.usage.length <= 0 ? '' : this.state.usage[2].ctrtProductFeeSumAmt}</td>
                                </tr>

                                {/*공통원가*/}
                                <tr>
                                    <td className="td_line_right">{this.props.messages.product_common_cost}</td>
                                    <td>-</td>
                                    <td></td>
                                </tr>
                                {/*장비*/}
                                {assetServiceInfo(this.state.asset)}

                                {/*관제UI*/}
                                {ServiceInfoPrintType1(this.state.controlUi)}
                                
                                {/*서비스 기능*/}
                                {ServiceInfoPrintType2(this.state.function, '서비스 기능')}


                                {/*Offline서비스*/}
                                {ServiceInfoPrintType1(this.state.offline)}
                            </tbody>
                        </table>


                        <table className="tbl_row">
                            <caption>합계 목록</caption>
                            <colgroup>
                                <col style={{width:'10%'}}/>
                                <col style={{width:'40%'}}/>
                                <col style={{width:'10%'}}/>
                                <col style={{width:'40%'}}/>
                            </colgroup>
                            <tbody>
                                <tr>
                                    <td scope="row">{this.props.messages.sales_total_2}</td>
                                    <td>{this.state.salesSumAmt}</td>
                                    <td scope="row">{this.props.messages.sales_discount_rate}</td>
                                    <td>{this.state.dcRate}</td>
                                </tr>
                                <tr>
                                    <td scope="row">{this.props.messages.sales_discount_price}</td>
                                    <td>{this.state.dcFee}</td>
                                    <td scope="row">{this.props.messages.sales_discount_total}</td>
                                    <td>{this.state.dcFeeSumAmt}</td>
                                </tr>
                                <tr>
                                    <td scope="row">{this.props.messages.sales_unpaid_2}</td>
                                    <td>{/*this.state.nopayCg*/}</td>
                                    <td scope="row">{this.props.messages.sales_vat}</td>
                                    <td>{this.state.vat}</td>
                                </tr>
                                <tr>
                                    <td scope="row">{this.props.messages.sales_monthly_total}</td>
                                    <td colSpan="3">{this.state.thmonFeeSumAmt}</td>
                                </tr>
                            </tbody>
                        </table>
                    


                        {/*
                        미정산이면 출력하지 않음.
                        지급이면 갑(인포섹 또는 프로바이더)사가 을(고객사)사에게 입금하는 행위인데 기획 없으므로 출력하지 않음.

                        취소이면 다시 결재할 수 있게 결제정보 출력한다.
                        */}
                        {
                        this.state.adjustDstnctCode === '01' || this.state.adjustDstnctCode === '03' 
                        ? 
                            "" 
                        : 
                            this.state.rectStatusCode === '03'
                            ?
                                <PaymentInfo setleInfo={this.state.setleInfo} onDisplaySetting={this.props.onDisplaySetting}/>
                            :
                                <Payment thmonFeeSumAmt={this.state.thmonFeeSumAmt}
                                         productName={this.state.contractInfo.productInfo != null ? this.state.contractInfo.productInfo.productName : 'aaaaaaaa'}
                                         userNo={this.props.memberInfo.user_no}
                                         userEmail={this.props.memberInfo.user_id}
                                         salesSeq={this.state.salesSeq}
                                         cardSetleSvcId={this.state.providerInfo.cardSetleSvcId}
                                         acctSetleSvcId={this.state.providerInfo.acctSetleSvcId}
                                />
                                /*{this.state.thmonFeeSumAmt}*/
                        }
                    </div>
                </div>
            </div>

        );
    }
}

export default connect(mapStateToProps)(Detail);
