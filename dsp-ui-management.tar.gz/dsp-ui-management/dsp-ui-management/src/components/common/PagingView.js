import React from 'react';

/*다국어 모듈 시작*/
import { connect } from 'react-redux';
import { changeLangauge, mapStateToProps } from '../../language/Actions';
/*다국어 모듈 종료*/

class PagingView extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      page:1,
      pager: {
        currentPage: 1,
        totalPages: 0
      }
    };


    // this.handlePerPageChange = this.handlePerPageChange.bind(this);
    this.handleChange = this.handleChange.bind(this);
    this.handleKeyPress = this.handleKeyPress.bind(this);
  }

  setPage(page) {
    //if(page < 1 || page > this.state.pager.totalPages) {
    //  return;
    //}
    
    if(page < 1) {
      return;
    }

    if(this.state.pager.totalPages === 0 || page > this.state.pager.totalPages) {
      return;
    }


    this.getPage(page);
    this.props.onPageChange(this.props.pageInfo.perPageNum, page);
  }

  getPage(page) {

    var currentPage = Number(page || 1);
    var perPageNum = this.props.pageInfo.perPageNum;

    var totalPages = Math.ceil(this.props.pageInfo.totalCount / perPageNum);
    if(totalPages === 0) {
      currentPage = 0;
    }

    this.setState({
      page : currentPage,
      pager: {
        currentPage: currentPage,
        totalPages: totalPages
      }
    });
  }

  handlePerPageChange(e) {
    console.log(e.target.value);
    this.setState({
      rowCount:Number(e.target.value)
    });
    this.props.onPageChange(e.target.value, 1);
  }

  handleChange(e) {
    if(e.target.name == "page") {
      e.target.value = e.target.value.replace(/[^0-9]/g,"");
    }

    this.setState({
      page:e.target.value
    });
  }

  handleKeyPress(e) {
    if(e.charCode===13) {
      if(this.state.pager.totalPages >= Number(e.target.value)) {
        this.getPage(this.state.page);
        this.setPage(this.state.page);
      }
    }
  }

  componentDidUpdate(prevProps, prevState) {

    if (this.props.pageInfo.totalCount !== prevProps.pageInfo.totalCount ||
      this.props.pageInfo.perPageNum !== prevProps.pageInfo.perPageNum) {
        this.getPage(this.props.pageInfo.page);
    }
  }

  componentWillReceiveProps(nextProps) {
    this.getPage(nextProps.pageInfo.page);
  }

  componentDidMount(){
    let self = this;
    $("select[name=perPage]").on("change",function(){
        let rowCount = $('select[name=perPage] option:selected').val();
        self.setState({
          rowCount : Number(rowCount)
        });

        self.forceUpdate();

        self.props.onPageChange(Number(rowCount), 1);
    });
  }

  render() {
    var pager = this.state.pager;
    return(
      <div className="content_bottom">
        <div className="bottom_inner">
          {/*<select className="ui-sel sel_white" name="perPage" onChange={this.handlePerPageChange}>*/}
          <select className="ui-sel sel_white" name="perPage" value={this.props.pageInfo.perPageNum == undefined ? "" : this.props.pageInfo.perPageNum}
          // onChange={handlePerPageChange}
          //style={selectStyle} 
          >
            <option value="30">30 rows per page</option>
            <option value="50">50 rows per page</option>
            <option value="100">100 rows per page</option>
          </select>
          <span className="gap"></span>

          {/*<div className="page_wrap">

            <button type="button" className="first" disabled={pager.currentPage <= 1 ? 'disabled' : ''} onClick={() => this.setPage(1)}><span className="offscreen">첫페이지</span></button>
            <button type="button" className="prev" disabled={pager.currentPage <= 1 ? 'disabled' : ''} onClick={() => this.setPage(pager.currentPage - 1)}><span className="offscreen">이전페이지</span></button>
            <span class="current_page">
              <input type="text" className="ui_input" value="1"  name="page" value={this.state.page} ref="page" onKeyPress={this.handleKeyPress} onChange={this.handleChange}/>
            </span>
            
            <span className="num_wrap">
            &nbsp;of&nbsp;
              <span>{pager.totalPages}</span>
            </span>
            <button type="button" className="next" disabled={pager.currentPage >= pager.totalPages ? 'disabled' : ''} onClick={() => this.setPage(pager.currentPage + 1)}><span className="offscreen">다음페이지</span></button>
            <button type="button" className="last" disabled={pager.currentPage >= pager.totalPages ? 'disabled' : ''} onClick={() => this.setPage(pager.totalPages)}><span className="offscreen">마지막페이지</span></button>
          </div>*/}
          <div className="page_wrap">
            <a href="javascript:;" className={pager.currentPage <= 1 ? 'first disabled' : 'first'} onClick={() => this.setPage(pager.currentPage == 1 ? 0 : 1)}><span className="offscreen">첫페이지</span></a>&nbsp;
            <a href="javascript:;" className={pager.currentPage <= 1 ? 'prev disabled' : 'prev'} onClick={() => this.setPage(pager.currentPage - 1)}><span className="offscreen">이전페이지</span></a>&nbsp;
            <span className="num_wrap">
              <span className="current_page">
                <input type="text" className="ui_input" value="1"  name="page" value={this.state.page} ref="page" onKeyPress={this.handleKeyPress} onChange={this.handleChange}/>
              </span>
              &nbsp;of&nbsp;
              <span>{pager.totalPages}</span>
            </span>
            <a href="javascript:;" className={pager.currentPage >= pager.totalPages ? 'next disabled' : 'next'} onClick={() => this.setPage(pager.currentPage + 1)}><span className="offscreen">다음페이지</span></a>&nbsp;
            <a href="javascript:;" className={pager.currentPage >= pager.totalPages ? 'last disabled' : 'last'} onClick={() => this.setPage(pager.currentPage == pager.totalPages ? pager.currentPage + 1 : pager.totalPages)}><span className="offscreen">마지막페이지</span></a>
          </div>

          <strong className="total_val">{this.props.messages.sales_total} &nbsp;

          {this.props.pageInfo.totalCount == undefined ? "0" : (this.props.pageInfo.totalCount + "").replace(/\B(?=(\d{3})+(?!\d))/g, ",")}

          </strong>
        </div>
      </div>

    );
  }
}


export default connect(mapStateToProps)(PagingView);
