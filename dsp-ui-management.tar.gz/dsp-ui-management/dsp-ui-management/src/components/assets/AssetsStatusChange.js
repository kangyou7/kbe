import React from 'react';
import Calendar from '../common/Calendar';

import {REST_API_URL} from '../../config/api-config.js';

/*다국어 모듈 시작*/
import { connect } from 'react-redux';
import { changeLangauge, mapStateToProps } from '../../language/Actions';
/*다국어 모듈 종료*/

class AssetsStatusChange extends React.Component {

    constructor(props) {
        super(props);

        this.state = {
            assetsDesc : "",
            disUseDlngReasonCode : "",
            disUseDlngReasonText : "",
            invntryConvReasonCode : "",
            invntryConvReasonText : ""
        }
        
        this.handleChange = this.handleChange.bind(this);
    }

    handleChange(e) {
        
        if (e.target.name == "disUseDlngReasonCode") {
            if (e.target.value == "I") {
                $("input[name='disUseDlngReasonText']").attr("disabled", false);
            } else {
                $("input[name='disUseDlngReasonText']").attr("disabled", "disabled");
            }
        }

        if (e.target.name == "invntryConvReasonCode") {
            if (e.target.value == "I") {
                $("input[name='invntryConvReasonText']").attr("disabled", false);
            } else {
                $("input[name='invntryConvReasonText']").attr("disabled", "disabled");
            }
        }

		let nextState = {};
		nextState[e.target.name]=e.target.value;
		this.setState(nextState);
    }
    
    handleInitState() {
		
		this.setState({
            assetsDesc : "",
            disUseDlngReasonCode : "",
            disUseDlngReasonText : "",
            invntryConvReasonCode : "",
            invntryConvReasonText : ""
		});
	}
    
    getAssetsDetail() {
        $.ajax({
            url: REST_API_URL+"/assets/Detail",
            dataType: 'json',
            type: "post",
            data: {
                assetsNo:this.props.assetsNo
            },
            xhrFields : {
                withCredentials : true
            },
            cache: false,
            success: function(result) {
                this.setState(result.response);
            }.bind(this),
                error: function(xhr, status, err) {
                console.log(xhr + " : " + status + " : " + err);
            }.bind(this)
        });
    }

    complete() {
        //console.log(this.state);
        let param = new Object();

        param.assetsNo = this.props.assetsNo;
        param.assetsCurStatusSeCode = this.state.assetsCurStatusSeCode;
        param.updateAssetStatusCode = this.props.checkedAssetsStatus;
        param.assetsDesc = this.state.assetsDesc;

        if (param.updateAssetStatusCode == "stockchange") {
            param.disUseDlngReasonCode = "";
            param.disUseDlngReasonText = "";
            param.invntryConvReasonCode = this.state.invntryConvReasonCode == null ? "R" : this.state.invntryConvReasonCode;
            param.invntryConvReasonText = this.state.invntryConvReasonText;
        } else {
            param.invntryConvReasonCode = "";
            param.invntryConvReasonText = "";
            param.disUseDlngReasonCode = this.state.disUseDlngReasonCode == null ? "O" : this.state.disUseDlngReasonCode;
            param.disUseDlngReasonText = this.state.disUseDlngReasonText;
        }

        let memberInfo = JSON.parse(localStorage.getItem("memberInfo"));
        param.loginUserNo = memberInfo.user_no;
        //console.log(param);
        //return;
        $.ajax({
            url: REST_API_URL+"/assets/UpdateStatus",
            dataType: 'json',
            type: "post",
            xhrFields : {
                withCredentials : true
            },
            data: {paramJson : JSON.stringify(param)},
            success: function(result) {
               if (result.response == "SUCCESS") {
                    alert("변경되었습니다.");
                    this.hide();
                    return;
               } else {
                   alert("변경 중 오류발생.. 관리자에게 문의바랍니다.");
                   return;
               }
            }.bind(this),
                error: function(xhr, status, err) {
                console.log(xhr + " : " + status + " : " + err);
            }.bind(this)
        });
    }

    hide() {
        layer_close(".pop-stock-transform");
    }

    show() {
        layer_open(".pop-stock-transform");

        this.getAssetsDetail();
    }

    componentDidMount() {
        this.props.onRef(this)
		this.handleInitState();
    }
    
    componentWillUnmount() {
		this.props.onRef(null)
	}

    
    render() {

        const mapToTitle = (status) => {
            if (status == "notUse") {
                return (
                    <h1>{this.props.messages.assets_request_disuse_equipments}</h1>
                );
            } else {
                return (
                    <h1>{this.props.messages.assets_request_conversion_inventory}</h1>
                );
            }
        }

        const mapToNotUseRunUsr = (status) => {
            if (status == "notUse") {
                return (
                    <tr>
                        <th scope="row">{this.props.messages.assets_disuse_manager}</th>
                        <td>{this.state.runChargeUsrName}</td>
                    </tr>
                );
            } 
        }

        const mapToNotUseRunDate = (status) => {
            if (status == "notUse") {
                return (
                    <tr>
                        <th scope="row">{this.props.messages.assets_processing_date_for_disuse}</th>
                        <td>{this.state.runDt}</td>
                    </tr>
                );
            } 
        }

        const mapToReason = (status) => {
            // console.log("바꾸려는 status : " + status);
            // console.log("현재 status : " + this.state.assetStatusCode);
            //재고전환 일 때
            if (status == "stockchange") {
                //현재상태가 불용일 때만 사유적음.
                if (this.state.assetsCurStatusSeCode == "notUse") {
                    return (
                        <tr>
                            <th scope="row">{this.props.messages.assets_conversion_reason} <span className="tc_red">*</span></th>
                            <td className="input">
                                <ul className="ip_list">
                                    <li>
                                        <span className="input_ico_box">
                                            <input type="radio" name="invntryConvReasonCode" id="stock-rdo-2-1" defaultChecked="true" value="R" onChange={this.handleChange}/>
                                            <label htmlFor="stock-rdo-2-1">{this.props.messages.assets_repair_completion}</label>
                                        </span>
                                    </li>
                                    <li>
                                        <span className="input_ico_box">
                                            <input type="radio" name="invntryConvReasonCode" id="stock-rdo-2-2" value="E" onChange={this.handleChange}/>
                                            <label htmlFor="stock-rdo-2-2">{this.props.messages.assets_replacement_completion}</label>
                                        </span>
                                    </li>
                                    <li>
                                        <span className="input_ico_box">
                                            <input type="radio" name="invntryConvReasonCode" id="stock-rdo-2-3" value="D" onChange={this.handleChange}/>
                                            <label htmlFor="stock-rdo-2-3">{this.props.messages.assets_service_termination}</label>
                                        </span>
                                    </li>
                                    
                                    <li className="f_clear direct_input">
                                        <span className="input_ico_box">
                                            <input type="radio" name="invntryConvReasonCode" id="stock-rdo-2-4" value="I" onChange={this.handleChange}/>
                                            <label htmlFor="stock-rdo-2-4">{this.props.messages.assets_direct_input}</label>
                                        </span>
                                        <input type="text" maxLength="100" name="invntryConvReasonText" disabled className="ui_input" onChange={this.handleChange}/>
                                    </li>
                                </ul>
                            </td>
                        </tr>
                    );
                }
            } else {
                return (
                    <tr>

                        <th scope="row">{this.props.messages.assets_reason_disuse_equipments} <span className="tc_red">*</span></th>
                        <td className="input">
                            <ul className="ip_list">
                                <li>
                                    <span className="input_ico_box">
                                        <input type="radio" name="disUseDlngReasonCode" id="stock-rdo-2-1" defaultChecked="true" value="O" onChange={this.handleChange}/>
                                        <label htmlFor="stock-rdo-2-1">{this.props.messages.assets_obsolescence_equipment}</label>
                                    </span>
                                </li>
                                <li>
                                    <span className="input_ico_box">
                                        <input type="radio" name="disUseDlngReasonCode" id="stock-rdo-2-2" value="C" onChange={this.handleChange}/>
                                        <label htmlFor="stock-rdo-2-2">{this.props.messages.assets_power_faulity}</label>
                                    </span>
                                </li>
                                <li>
                                    <span className="input_ico_box">
                                        <input type="radio" name="disUseDlngReasonCode" id="stock-rdo-2-3" value="E" onChange={this.handleChange}/>
                                        <label htmlFor="stock-rdo-2-3">{this.props.messages.assets_end_of_service}</label>
                                    </span>
                                </li>
                                
                                <li className="f_clear direct_input">
                                    <span className="input_ico_box">
                                        <input type="radio" name="disUseDlngReasonCode" id="stock-rdo-2-4" value="I" onChange={this.handleChange}/>
                                        <label htmlFor="stock-rdo-2-4">{this.props.messages.assets_direct_input}</label>
                                    </span>
                                    <input type="text" maxLength="100" name="disUseDlngReasonText" disabled className="ui_input" onChange={this.handleChange}/>
                                </li>
                            </ul>
                        </td>
                    </tr>
                );
            }
        }

        return(
            <div className="lpopup">
                <div className="dimmed"></div>
                <div className="popup_layer pop_stock_transform pop-stock-transform mid">
                    <div className="pop_container">
                        <div className="pop_header">
                            {mapToTitle(this.props.checkedAssetsStatus)}
                        </div>
                        <div className="pop_contents">
                            <div className="pop_inner">
                                <table className="tbl_row">
                                    <colgroup>
                                        <col style={{width: '130px'}}/>    
                                        <col style={{width: 'auto'}}/>    
                                    </colgroup>
                                    <tbody>
                                        <tr>
                                            <th scope="row">{this.props.messages.assets_possesion}</th>
                                            <td>{this.state.assetsOwnerSeNm}</td>
                                        </tr>
                                        <tr>
                                            <th scope="row">{this.props.messages.assets_model_name}</th>
                                            <td>{this.state.equipModelName}</td>
                                        </tr>
                                        <tr>
                                            <th scope="row">{this.props.messages.assets_serial_no}</th>
                                            <td>{this.state.assetsNatvNoValue}</td>
                                        </tr>
                                        {mapToNotUseRunUsr(this.state.assetsCurStatusSeCode)}
                                        {mapToNotUseRunDate(this.state.assetsCurStatusSeCode)}
                                        {mapToReason(this.props.checkedAssetsStatus)}
                                        
                                        {/* <tr>
                                            <th scope="row">{this.props.messages.assets_requester} <span className="tc_red">*</span></th>
                                            <td>{this.props.memberInfo.user_name}</td>
                                        </tr>
                                        <tr>
                                            <th scope="row">{this.props.messages.assets_request_date} <span className="tc_red">*</span></th>
                                            <td className="input">

                                                <div className="date_box">
                                                    <Calendar className="ui_cal" 
                                                    dateFormat="YYYY-MM-DD"
                                                    onChange={(data) => this.setState({reqDate: data})}/>
                                                </div>
                                               
                                            </td>
                                        </tr> */}
                                        <tr>
                                            <th scope="row">{this.props.messages.assets_desc}</th>
                                            
                                            <td className="input">
                                                <textarea className="ui_textarea" maxLength="4000" name="assetsDesc" value={this.state.assetsDesc} onChange={this.handleChange}></textarea>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>

                        <div className="pop_bottom">
                            <button type="button" className="pbtn_pos" onClick={() => {this.hide();}}>{this.props.messages.assets_cancel}</button>
                            <button type="button" className="pbtn_black" onClick={() => {this.complete();}}>{this.props.messages.assets_ok}</button>
                        </div>
                        <a href="javascript:;" onClick={() => {this.hide();}} className="btn_pop_close"><span className="offscreen">{this.props.messages.assets_close}</span></a>
                    </div>
                </div>
            </div>
        );
    }
}


export default connect(mapStateToProps)(AssetsStatusChange);