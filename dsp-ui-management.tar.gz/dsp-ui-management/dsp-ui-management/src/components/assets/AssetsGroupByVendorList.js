import React from 'react';

import { Link } from 'react-router';
import { browserHistory } from 'react-router';

import PagingView from '../common/PagingView';

import {REST_API_URL} from '../../config/api-config.js';

/*다국어 모듈 시작*/
import { connect } from 'react-redux';
import { changeLangauge, mapStateToProps } from '../../language/Actions';
/*다국어 모듈 종료*/


class AssetsGroupByVendorList extends React.Component {

  constructor(props) {
    super(props);

    this.state = {
      searchKeyWord : "",
      list : [],
      pageInfo:{
        //totalCount : 0,
        //perPageNum : 0,
        //page : 0
      }

    }
    this.handleSearch = this.handleSearch.bind(this);
    this.handlePageChange = this.handlePageChange.bind(this);
    this.handleChange = this.handleChange.bind(this);
    
  }

  handleChange(e) {
    let nextState = {};
    nextState[e.target.name]=e.target.value;
    this.setState(nextState);
  }

  getList() {
    
    $.ajax({
      url: REST_API_URL+"/assets/getAssetsGroupByVendorList",
      dataType: 'json',
      type: "post",
      data: this.state.pageInfo,
      xhrFields : {
        withCredentials : true
      },
      success: function(result) {
        this.setState({
          list: result.response.list,
          pageInfo : result.response.pageInfo
        });
      }.bind(this),
      error: function(xhr, status, err) {
        console.log(xhr + " : " + status + " : " + err);
      }.bind(this)
    });
  }

  handleSearch() {
    let pageInfo = this.state.pageInfo;
    pageInfo.searchKeyWord = this.state.searchKeyWord;
    this.setState({
      pageInfo : pageInfo
    })
    this.getList();
  }
  //페이지 변경 및 페이지 출력 갯수 변경
  handlePageChange(perPageNum, page) {

    let changePage = this.state.pageInfo;
    changePage.perPageNum = perPageNum;
    changePage.page = page;
    this.setState({
      pageInfo:changePage
    })


    this.getList();

  }

  //페이지 로딩 시 목록 조회
  componentDidMount() {
    this.props.onRef(this)
    this.getList();
  }

  componentWillUnmount() {
    this.props.onRef(null)
  }

  render() {
      const mapToComponent = (data) => {
        if(data.length > 0) {
          return data.map((assets, i) => {//map
            return(<tr key={i}>
              <td>{assets.equipVendorName}</td>
              <td>{assets.icnt}</td>
              <td>{assets.rcnt}</td>
              <td>{assets.icnt}</td>
              <td>{assets.ccnt}</td>
            </tr>);
          });
        } else {
          return (
            <tr>
              <td className="noresults" colSpan={5}>
                <div className="box_noresults">
                  <div className="ver_mid">
                    <i className="ico ico_no_result"></i>
                    <span className="lb">{this.props.messages.common_no_data}</span>
                  </div>
                </div>
              </td>
            </tr>
          );
        }
      }

      return (
          <div id="tab-cont1" className="tab_content tab-cont" >

            <div className="content_body">

              <div className="content_inner">


                <div className="box_com term_wrap">
                    {/* <Search onSearch={this.handleSearch}/> */}
                  
                  <div className="fl">
										<span className="input_search_box">
                      <input type="text" className="ui_input" name="searchKeyWord" value={this.state.searchKeyWord} onChange={this.handleChange}/>
                      <a id="searchAssets" className="btn_search" href="javascript:void(0);"
                      onClick={this.handleSearch}><span className="offscreen">검색</span></a>
                    </span>
		
									</div>
                </div>


                <table className="tbl_col">
                  <caption>벤더 별 장비 보유 현황 목록</caption>
                  <colgroup>
										<col style={{width : "20%"}}/>
										<col style={{width : "20%"}}/>
                    <col style={{width : "20%"}}/>
                    <col style={{width : "20%"}}/>
                    <col style={{width : "20%"}}/>
									</colgroup>
                  <thead>

										<tr>
											<th scope="col" rowSpan={2}>{this.props.messages.vendor_vendor_name}</th>
											<th scope="col" colSpan={3}>{this.props.messages.byvendor_infosec}</th>
											<th scope="col">Customer</th>
										</tr>
										<tr>

											<th scope="col" className="th_line_left">{this.props.messages.byvendor_buy}</th>
											<th scope="col">{this.props.messages.byvendor_rent}</th>
											<th scope="col">{this.props.messages.byvendor_total_count}</th>
											<th scope="col">{this.props.messages.byvendor_buy}</th>
										</tr>
									</thead>

                  <tbody>

                    {mapToComponent(this.state.list)}


                  </tbody>
                </table>

              </div>

            </div>

            <PagingView pageInfo={this.state.pageInfo} onPageChange={this.handlePageChange}/>
            
          </div>

      );
    }
}

export default connect(mapStateToProps)(AssetsGroupByVendorList);
