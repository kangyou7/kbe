/**
 * http://usejsdoc.org/
 */
/*jshint esversion: 6 */
import React from 'react';
import { bindActionCreators } from 'redux';
import Header from './Header';
import Login from './login/DspLogin';
import { ACTIVE } from './../config/api-config.js';

/*다국어 모듈 시작*/
import { connect } from 'react-redux';
import { changeLangauge, mapStateToProps, actionlogin } from '../language/Actions';
import { browserHistory } from 'react-router';

/*다국어 모듈 종료*/
let memberInfo = {
      user_no :-1,
      user_name : "",
      user_id : "",
      login_time : "",
      user_dstnct_code : "",
      dspDefaultTZ :"",
      menus : [],
};

let authorize = false;
class App extends React.Component{
    
    static fetchData(dispatch){
		let cl = bindActionCreators(actionlogin, dispatch);
		return Promise.all([ cl.loginAction ]);
    }

    componentWillMount(){

        memberInfo = storage.get('memberInfo');

        if(memberInfo === null){
            return ;
        }else{
            this.props.actionlogin('LOG_IN');
        }

        if(this.props.children.props.location.pathname == "/") {
            $("body").attr('class','main_height');
        } else {
            $("body").attr('class','full_height');
        }

        let _location = window.location.pathname;
        let menus =[];

        authorize = false;

        if(memberInfo != null) {
            menus = memberInfo.menus;
            menus.map((item, i)=>{
                let subMenus =[];
                subMenus = item.subMenu;
                subMenus.map((sub,j)=>{
                    if(sub.uri == _location){
                        authorize = true;
                    }
                });
            });
        }

        if(_location == '/'
            ||_location == '/usercreate'
            ||_location == '/userdetail'
            ||_location == '/user'
            ||_location == '/providerNotice'){   //||_location =='/providerNotice'
            authorize = true;
        }

        if(!authorize){
            alert('해당하는 메뉴에 대한 접근 권한이 없습니다.');
            browserHistory.push('/');
        }
    }

    componentWillReceiveProps(nextProps) {

        if(nextProps.children.props.location.pathname.match(/user/gi)!='user'){
            sessionStorage.clear();
        }
        if(nextProps.children.props.location.pathname == "/") {
            $("body").attr('class','main_height');
        } else {
            $("body").attr('class','full_height');
        }
    }

	render(){
        return (
            <div style={{height:"100%"}}>
            { 
                (!memberInfo)?
                <Login/>
                :
                <div style={{height:"100%"}}>
                    <Header />
                    {this.props.children}
                </div>
            }
            </div>
        );
	}
} 
let mapDispatchToProps = (dispatch) => {
    return {
        actionlogin: (event) => dispatch(actionlogin(memberInfo))
    };
}
export default connect(undefined, mapDispatchToProps)(App);