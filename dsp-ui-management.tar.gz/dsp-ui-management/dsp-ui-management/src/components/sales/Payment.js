import React from 'react';

import {REST_API_URL, SITE_URL} from '../../config/api-config.js';

/*다국어 모듈 시작*/
import { connect } from 'react-redux';
import { changeLangauge, mapStateToProps } from '../../language/Actions';
/*다국어 모듈 종료*/

class Payment extends React.Component {
    constructor(props) {
        super(props);
        //170622040674
        this.state = {
            setleNumShortClasCode : "",
            saleUsrProviderAgreYn : "N",
            collectUtilAgreYn : "N",
            setleMethodName : "01",     /*결제방식(단일결제:01)*/

            cnSvcid        : this.props.cardSetleSvcId,                      /*카드결제 서비스아이디*/
            raSvcid        : this.props.acctSetleSvcId,                      /*계좌이체 서비스아이디*/
            prdtnm          : "",                                 /*상품명*/
            prdtprice       : 0,                                 /*결제요청금액*/
            tradeid         : '',                                 /*가맹점거래번호*/
            siteurl         : "http://secuiot",                 /*가맹점도메인*/
            notiurl         : SITE_URL + "/paymentNoti",     /*결과통보 처리 url*/
            okurl           : SITE_URL + "/paymentOk",       /*성공URL*/
            closeurl        : "",    /*취소/닫기 시 이동 url*/
            failurl         : "",     /*실패 시 이동 url*/
            
            userid          : "",                                 /*사용자 ID*/
            payeremail      : "",                                 /*결제자 이메일*/
            cashGb          : "",                                 /*결제수단 구분*/
            payMode         : "10",                               /*거래종류*/
            callType        : "P",                                /*결제창 호출방식*/
            iframeName      : "",                                 /*iframe 명칭*/
            mstr            : "",                                 /*가맹점 콜백 변수*/
            cryptyn         : "N",                                /*암호화 사용 여부*/
            cryptstring     : "",                                 /*암호화 검증 값*/

            cnInstall       : "",                                 /*최대할부개월수*/
            billtype        : "",                                 /*과세/비과세/복합과세*/
            tax             : "",                                 /*부가세*/
            taxfree         : "",                                 /*비과세*/

            prdtcd          : "",                                 /*상품코드*/
            notiemail       : "",                                 /*Noti 알림E-mail*/
            infoareaYn      : "N",                                /*결제창 안내문 표시 여부*/
            footerYn        : "N",                                /*결제창 하단 안내 표시 여부*/
            height          : "",                                 /*결제창 높이*/
            prdtHidden      : "N",                                /*상품명 숨김 여부*/
            emailHidden     : "N",                                /*결제자 이메일 숨김 여부*/
            contractHidden  : "N",                                /*이용약관 숨김 여부*/
            logoYn          : "N",                                /*가맹점 로고 사용여부*/
            item            : ""                                  /*아이템*/
        }


        this.handleChange = this.handleChange.bind(this);
        this.handlePayment = this.handlePayment.bind(this);
        
    }

    componentDidMount() {
        console.log(this.state);
    }


    componentWillReceiveProps(nextProps){
        this.setState({
            prdtnm : nextProps.productName,
            prdtprice : nextProps.thmonFeeSumAmt,
            userid : nextProps.userNo == null ? '' : nextProps.userNo,
            payeremail : nextProps.userEmail == null ? '' : nextProps.userEmail
        });
    }


    handleChange(e) {
        let nextState = {};
        if(e.target.name === 'saleUsrProviderAgreYn') {
            nextState[e.target.name]=this.state.saleUsrProviderAgreYn==='Y'? 'N' : 'Y';
        } else if(e.target.name === 'collectUtilAgreYn') {
            nextState[e.target.name]=this.state.collectUtilAgreYn==='Y'? 'N' : 'Y';
        } else {
            nextState[e.target.name]=e.target.value;

            if(e.target.value == 'credit_card') {
                nextState['cashGb'] = 'CN';
                nextState['payMode'] = '10';
            } else if(e.target.value == 'account_transfer') {
                nextState['cashGb'] = 'RA';
                nextState['payMode'] = '00'; //테스트 결제 운영시 10으로 변경해야함.
            }
        }
        this.setState(nextState);

    }
    
    handlePayment() {
        
        if(this.state.setleNumShortClasCode == '') {
            alert("결제수단을 선택하세요.");
            return;
        }

        if(this.state.saleUsrProviderAgreYn != 'Y') {
            alert("개인 정보 판매자 제공에 동의하지 않았습니다.");
            return;
        }

        if(this.state.collectUtilAgreYn != 'Y') {
            alert("개인 정보 수집 및 이용에 동의하지 않았습니다.");
            return;
        }

        
        

        let paymentInfo; 
        if(this.state.setleNumShortClasCode == 'credit_card') {
            
            if(this.state.cnSvcid == undefined || this.state.cnSvcid == "" || this.state.cnSvcid == null) {
                alert("프로바이더의 서비스 결제ID가 없습니다. 관리자에게 문의바랍니다.");
                return;
            }
            paymentInfo = {
                salesSeq      : this.props.salesSeq,
                cnSvcid      : this.state.cnSvcid,             //서비스ID
                prdtnm       : this.state.prdtnm,              //상품명
                prdtprice    : this.state.prdtprice,           //거래금액
                tradeid      : this.state.tradeid,             //가맹점거래번호
                siteurl      : this.state.siteurl,             //가맹점도메인
                notiurl      : this.state.notiurl,             //결제처리URL
                okurl        : this.state.okurl,               //성공URL
                closeurl     : this.state.closeurl,            //결제취소URL
                failurl      : this.state.failurl,             //실패URL
                userid       : this.state.userid,              //사용자ID
                payeremail   : this.state.payeremail,          //결제자E-mail
                cashGb       : this.state.cashGb,              //결제수단구분
                payMode      : this.state.payMode,             //거래모드
                callType     : this.state.callType,            //결제창 호출 방식
                iframeName   : this.state.iframeName,          //IFRAME 명
                //mstr         : $("#creditcardpayform[name=mstr]").val(),                //가맹점콜백변수
                //mstr         : this.state.mstr,
                cryptyn      : this.state.cryptyn,             //암호화사용여부
                cryptstring  : this.state.cryptstring,         //암호화문자열
                cnInstall    : this.state.cnInstall,           //최대할부개월수
                billtype     : this.state.billtype,            //과세/비과세/복합과세
                tax          : this.state.tax,                 //부가세
                taxfree      : this.state.taxfree,             //비과세
                setleMethodName : this.state.setleMethodName,
                saleUsrProviderAgreYn :this.state.saleUsrProviderAgreYn,
                collectUtilAgreYn :this.state.collectUtilAgreYn
            };

            /*paymentInfo.mstr = JSON.stringify(paymentInfo);
            this.setState({
                mstr : paymentInfo.mstr
            });*/
        } else if(this.state.setleNumShortClasCode == 'account_transfer') {
            if(this.state.raSvcid == undefined || this.state.raSvcid == "" || this.state.raSvcid == null) {
                alert("프로바이더의 결제 ID가 없습니다. 관리자에게 문의바랍니다.");
                return;
            }
            paymentInfo = {
                salesSeq         : this.props.salesSeq,
                raSvcid         : this.state.raSvcid,          //서비스아이디
                prdtnm          : this.state.prdtnm,           //상품명
                prdtprice       : this.state.prdtprice,        //결제요청금액
                tradeid         : this.state.tradeid,          //가맹점거래번호
                siteurl         : this.state.siteurl,          //가맹점도메인
                notiurl         : this.state.notiurl,          //결과통보 처리 url
                okurl           : this.state.okurl,            //성공URL
                closeurl        : this.state.closeurl,         //취소/닫기 시 이동 url
                failurl         : this.state.failurl,          //실패 시 이동 url
                userid          : this.state.userid,           //사용자 ID
                payeremail      : this.state.payeremail,       //결제자 이메일
                cashGb          : this.state.cashGb,           //결제수단구분
                payMode         : this.state.payMode,          //거래종류
                callType        : this.state.callType,         //결제창 호출방식
                iframeName      : this.state.iframeName,       //iframe 명칭
                //mstr            : $("#creditcardpayform[name=mstr]").val(),             //가맹점 콜백 변수
                //mstr            : this.state.mstr,
                cryptyn         : this.state.cryptyn,          //암호화 사용 여부
                cryptstring     : this.state.cryptstring,      //암호화 검증 값
                prdtcd          : this.state.prdtcd,           //상품코드
                notiemail       : this.state.notiemail,        //Noti 알림E-mail
                infoareaYn      : this.state.infoareaYn,       //결제창 안내문 표시 여부
                footerYn        : this.state.footerYn,         //결제창 하단 안내 표시 여부
                height          : this.state.height,           //결제창 높이
                prdtHidden      : this.state.prdtHidden,       //상품명 숨김 여부
                emailHidden     : this.state.emailHidden,      //결제자 이메일 숨김 여부
                contractHidden  : this.state.contractHidden,   //이용약관 숨김 여부
                logoYn          : this.state.logoYn,           //가맹점 로고 사용여부
                item            : this.state.item,             //아이템
                setleMethodName : this.state.setleMethodName,
                saleUsrProviderAgreYn :this.state.saleUsrProviderAgreYn,
                collectUtilAgreYn :this.state.collectUtilAgreYn
            }

            /*paymentInfo.mstr = JSON.stringify(paymentInfo);
            this.setState({
                mstr : paymentInfo.mstr
            });*/
        }
        
        $.ajax({
            url: REST_API_URL + "/sales/SetleTrans",
            dataType: 'json',
            type: "post",
            data:  paymentInfo,
            cache: false,
            success: function(result) {
                
                //paymentInfo.tradeid = 'skinfosec_' + result.response.setleTrans.tradeid;
                paymentInfo.tradeid = result.response.setleTrans.tradeid;
                paymentInfo.setleSeq = result.response.setleTrans.tradeid;

                let mstr = JSON.stringify(paymentInfo);
                mstr = mstr.replace(/\"/g,"\|");

                this.setState({
                    //tradeid : 'skinfosec_' + result.response.setleTrans.tradeid,
                    tradeid : result.response.setleTrans.tradeid,
                    mstr : mstr
                });
                

                if(this.state.setleNumShortClasCode == 'credit_card') {
                    //$("#creditCardPayForm").append("<input type='text' name='Tradeid'         id='Tradeid'      value='" + result.response.setleTrans.tradeid + "" + "'/>");
                    MCASH_PAYMENT(document.creditCardPayForm);
                } else if(this.state.setleNumShortClasCode == 'account_transfer') {
                    //$("#accountTransferPayForm").append("<input type='text' name='Tradeid'         id='Tradeid'      value='" + this.state.tradeid + "'/>");
                    MCASH_PAYMENT(document.accountTransferPayForm);
                }
            }.bind(this),
                error: function(xhr, status, err) {
                console.log(xhr + " : " + status + " : " + err);
            }.bind(this),
			xhrFields: {
			  withCredentials: true
			}
        });
        
    }

    //payment() {
    //    window.open("/test2","PAY_WIN","width=480,height=620,toolbar=no,menubar=no,scrollbars=no,resizable=yes");
    //}

    render() {
        return (
            <span>
                <div style={{height:'17px'}}></div>
                <div className="box_com">
                    <div className="fl">
                        <h3 className="ctitle">{this.props.messages.sales_payment}</h3>
                    </div>
                    <div className="fr">
                        <a href="javascript:;" className="btn_black" onClick={this.handlePayment}>{this.props.messages.sales_payment}</a>
                        {/*<button id="open" onClick={()=>this.payment()}>결제하기</button>*/}
                    </div>
                </div>




                
                <table className="tbl_row">
                    <caption>결제하기</caption>
                    <colgroup>
                        <col style={{width:'10%'}}/>
                        <col style={{width:'40%'}}/>
                        <col style={{width:'10%'}}/>
                        <col style={{width:'40%'}}/>
                    </colgroup>
                    <tbody>
                        <tr>
                            <th scope="row">{this.props.messages.sales_payment_method}</th>
                            <td className="input">
                                <ul className="ip_list">
                                    <li>
										<span className="input_ico_box">
                                            <input type="radio" name="setleNumShortClasCode" id="setleNumShortClasCode_1" value="credit_card" checked={this.state.setleNumShortClasCode === 'credit_card'} onChange={this.handleChange}/>
                                            <label htmlFor="setleNumShortClasCode_1">{this.props.messages.sales_credit_card}</label>
                                        </span>
                                    </li>
                                    <li>
										<span className="input_ico_box">
                                            <input type="radio" name="setleNumShortClasCode" id="setleNumShortClasCode_2" value="account_transfer" checked={this.state.setleNumShortClasCode === 'account_transfer'} onChange={this.handleChange}/>
                                            <label htmlFor="setleNumShortClasCode_2">{this.props.messages.sales_bank_transfer}</label>
                                        </span>
                                    </li>
                                </ul>
                            </td>
                            <th scope="row">{this.props.messages.sales_payment_method_2}</th>
                            <td>{this.props.messages.sales_single_payment}</td>
                        </tr>
                        <tr>
                            <th className="row">{this.props.messages.sales_final_payment}</th>
                            <td colSpan='3'>{this.props.thmonCgSum}</td>
                        </tr>
                    </tbody>
                </table>

                <div className="box_com">
                    <div className="fr">
                        <span className="input_ico_box black">
                            <input type="checkbox" name="saleUsrProviderAgreYn" id="saleUsrProviderAgreYn" value="Y" checked={this.state.saleUsrProviderAgreYn === 'Y'} onChange={this.handleChange} />
                            <label htmlFor="saleUsrProviderAgreYn">{this.props.messages.sales_usr_provider_agre_yn}</label>
                        </span>
                    </div>
                </div>
                <div className="privacy_agree_box">
                    {/*<p>정보통신망법 규정에 따라 네이버에 회원가입 신청하시는 분께 수집하는 개인정보의 항목, 개인정보의 수집 및 이용목적, 개인정보의 보유 및 이용기간을 안내 드리오니 자세히 읽은 후 동의하여 주시기 바랍니다.</p>
                    <ol>
                        <li>
                            <strong className="agree_title">1. 수집하는 개인정보</strong>
                            <p>이용자는 회원가입을 하지 않아도 정보 검색, 뉴스 보기 등 대부분의 네이버 서비스를 회원과 동일하게 이용할 수 있습니다. 이용자가 메일, 캘린더, 카페, 블로그 등과 같이 개인화 혹은 회원제 서비스를 이용하기 위해 회원가입을 할 경우, 네이버는 서비스 이용을 위해 필요한 최소한의 개인정보를 수집합니다.</p>
                            <p>회원가입 시점에 네이버가 이용자로부터 수집하는 개인정보는 아래와 같습니다.</p>
                            <ul>
                                <li>- 회원 가입 시에 ‘아이디, 비밀번호, 이름, 생년월일, 성별, 가입인증 휴대폰번호’를 필수항목으로 수집합니다. 만약 이용자가 입력하는 생년월일이 만14세 미만 아동일 경우에는 법정대리인 정보(법정대리인의 이름, 생년월일, 성별, 중복가입확인정보(DI), 휴대폰번호)를 추가로 수집합니다. 그리고 선택항목으로 이메일 주소를 수집합니다.</li>
                                <li>- 단체아이디로 회원가입 시 단체아이디, 비밀번호, 단체이름, 이메일주소, 가입인증 휴대폰번호를 필수항목으로 수집합니다. 그리고 단체 대표자명, 비밀번호 발급용 멤버 이름 및 이메일주소를 선택항목으로 수집합니다. <br />서비스 이용 과정에서 이용자로부터 수집하는 개인정보는 아래와 같습니다.
                                    <p>NAVER 내의 개별 서비스 이용, 이벤트 응모 및 경품 신청 과정에서 해당 서비스의 이용자에 한해 추가 개인정보 수집이 발생할 수 있습니다. 추가로 개인정보를 수집할 경우에는 해당 개인정보 수집 시점에서 이용자에게 ‘수집하는 개인정보 항목, 개인정보의 수집 및 이용목적, 개인정보의 보관기간’에 대해 안내 드리고 동의를 받습니다.</p>
                                </li>
                            </ul>
                        </li>
                    </ol>*/}

                    <p>고객님께서는 아래 내용에 대하여 동의를 거부하실 수 있으며, 거부시 결제/환불이 제한됩니다.</p>
                    <br/>
                    <table className="tbl_row" style={{width:'500px', borderLeft:'1px solid #dadada', borderRight: '1px solid #dadada'}}>
                        <caption>동의</caption>
                        <colgroup>
                            <col style={{width:'30%'}}/>
                            <col style={{width:'70%'}}/>
                        </colgroup>
                        <tbody>
                            <tr>
                                <td className="input" style={{borderLeft:'1px solid #dadada', borderRight: '1px solid #dadada'}}>제공받는자</td>
                                <td className="input" style={{borderLeft:'1px solid #dadada', borderRight: '1px solid #dadada'}}>KG모빌리언스</td>
                            </tr>
                            <tr>
                                <td className="input" style={{borderLeft:'1px solid #dadada', borderRight: '1px solid #dadada'}}>목적</td>
                                <td className="input" style={{borderLeft:'1px solid #dadada', borderRight: '1px solid #dadada'}}>결제 수단 대행</td>
                            </tr>
                            <tr>
                                <td className="input" style={{borderLeft:'1px solid #dadada', borderRight: '1px solid #dadada'}}>항목</td>
                                <td className="input" style={{borderLeft:'1px solid #dadada', borderRight: '1px solid #dadada'}}>성명, 주소, 전화번호, 휴대폰번호</td>
                            </tr>
                            <tr>
                                <td className="input" style={{borderLeft:'1px solid #dadada', borderRight: '1px solid #dadada'}}>보유기간</td>
                                <td className="input" style={{borderLeft:'1px solid #dadada', borderRight: '1px solid #dadada'}}>수취확인 후 3개월까지</td>
                            </tr>
                        </tbody>
                    </table>

                </div>
                
                
                <div className="box_com">
                    <div className="fr">
                        <span className="input_ico_box black">
                            <input type="checkbox" name="collectUtilAgreYn" id="collectUtilAgreYn" value="Y" checked={this.state.collectUtilAgreYn === 'Y'} onChange={this.handleChange} />
                            <label htmlFor="collectUtilAgreYn">{this.props.messages.sales_collect_util_agre_yn}</label>
                        </span>
                    </div>
                </div>
                <div className="privacy_agree_box">
                    {/*<p>정보통신망법 규정에 따라 네이버에 회원가입 신청하시는 분께 수집하는 개인정보의 항목, 개인정보의 수집 및 이용목적, 개인정보의 보유 및 이용기간을 안내 드리오니 자세히 읽은 후 동의하여 주시기 바랍니다.</p>
                    <ol>
                        <li>
                            <strong className="agree_title">1. 수집하는 개인정보</strong>
                            <p>이용자는 회원가입을 하지 않아도 정보 검색, 뉴스 보기 등 대부분의 네이버 서비스를 회원과 동일하게 이용할 수 있습니다. 이용자가 메일, 캘린더, 카페, 블로그 등과 같이 개인화 혹은 회원제 서비스를 이용하기 위해 회원가입을 할 경우, 네이버는 서비스 이용을 위해 필요한 최소한의 개인정보를 수집합니다.</p>
                            <p>회원가입 시점에 네이버가 이용자로부터 수집하는 개인정보는 아래와 같습니다.</p>
                            <ul>
                                <li>- 회원 가입 시에 ‘아이디, 비밀번호, 이름, 생년월일, 성별, 가입인증 휴대폰번호’를 필수항목으로 수집합니다. 만약 이용자가 입력하는 생년월일이 만14세 미만 아동일 경우에는 법정대리인 정보(법정대리인의 이름, 생년월일, 성별, 중복가입확인정보(DI), 휴대폰번호)를 추가로 수집합니다. 그리고 선택항목으로 이메일 주소를 수집합니다.</li>
                                <li>- 단체아이디로 회원가입 시 단체아이디, 비밀번호, 단체이름, 이메일주소, 가입인증 휴대폰번호를 필수항목으로 수집합니다. 그리고 단체 대표자명, 비밀번호 발급용 멤버 이름 및 이메일주소를 선택항목으로 수집합니다. <br />서비스 이용 과정에서 이용자로부터 수집하는 개인정보는 아래와 같습니다.
                                    <p>NAVER 내의 개별 서비스 이용, 이벤트 응모 및 경품 신청 과정에서 해당 서비스의 이용자에 한해 추가 개인정보 수집이 발생할 수 있습니다. 추가로 개인정보를 수집할 경우에는 해당 개인정보 수집 시점에서 이용자에게 ‘수집하는 개인정보 항목, 개인정보의 수집 및 이용목적, 개인정보의 보관기간’에 대해 안내 드리고 동의를 받습니다.</p>
                                </li>
                            </ul>
                            
                        </li>
                    </ol>*/}
                    <p>고객님께서는 아래 내용에 대하여 동의를 거부하실 수 있으며, 거부 시 구매 및 결제가 제한됩니다.</p>
                    <br/>
                    <table className="tbl_row" style={{width:'500px', borderLeft:'1px solid #dadada', borderRight: '1px solid #dadada'}}>
                        <caption>동의</caption>
                        <colgroup>
                            <col style={{width:'30%'}}/>
                            <col style={{width:'45%'}}/>
                            <col style={{width:'25%'}}/>
                        </colgroup>
                        <tbody>
                            <tr>
                                <td className="input" style={{borderLeft:'1px solid #dadada', borderRight: '1px solid #dadada'}}>수집이용목적</td>
                                <td className="input" style={{borderLeft:'1px solid #dadada', borderRight: '1px solid #dadada'}}>수집 항목</td>
                                <td className="input" style={{borderLeft:'1px solid #dadada', borderRight: '1px solid #dadada'}}>보유기간</td>
                            </tr>
                            <tr>
                                <td className="input" style={{borderLeft:'1px solid #dadada', borderRight: '1px solid #dadada'}}>결제/환불 서비스 제공</td>
                                <td className="input" style={{borderLeft:'1px solid #dadada', borderRight: '1px solid #dadada'}}>전자상거래법 준수 등 신용카드 정보, 계좌 정보, 거래 내역</td>
                                <td className="input" style={{borderLeft:'1px solid #dadada', borderRight: '1px solid #dadada'}}>회원탈퇴 시 까지</td>
                            </tr>
                        </tbody>
                    </table>
                    <br/>
                    <p>단, 관계 법령의 규정에 따라 보존할 의무가 있으면 해당 기간 동안 보존</p>
                    <p>이용계약(이용약관)이 존속중인 탈퇴하지 않은 회원의 경우 보유기간은 보존의무기간 이상 보관할 수 있으며 이 기간이 경과된 기록에 대해서 파기요청이 있는 경우 파기함</p>
                    <p>결제수단에 따르 개인정보 수집이용 항목이 상이할 수 있음</p>
                </div>


                <form name="creditCardPayForm" id="creditCardPayForm" acceptCharset='euc-kr'>
                    
                    <input type="hidden" name="CN_SVCID"        id="CN_SVCID"     readOnly value={this.state.cnSvcid} /> {/*서비스ID*/}
                    <input type="hidden" name="Prdtnm"          id="Prdtnm"       readOnly value={this.state.prdtnm} /> {/*상품명*/}
                    <input type="hidden" name="Prdtprice"       id="Prdtprice"    readOnly value={this.state.prdtprice}/> {/*거래금액*/}
                    <input type="hidden" name="Tradeid"         id="Tradeid"      readOnly value={this.state.tradeid}/> {/*가맹점거래번호*/}
                    <input type="hidden" name="Siteurl"         id="Siteurl"      readOnly value={this.state.siteurl}/> {/*가맹점도메인*/}
                    <input type="hidden" name="Notiurl"         id="Notiurl"      readOnly value={this.state.notiurl}/> {/*결제처리URL*/}
                    <input type="hidden" name="Okurl"           id="Okurl"        readOnly value={this.state.okurl}/> {/*성공url*/}
                    <input type="hidden" name="Closeurl"        id="Closeurl"     readOnly value={this.state.closeurl}/> {/*결제취소URL*/}
                    <input type="hidden" name="Failurl"         id="Failurl"      readOnly value={this.state.failurl}/> {/*실패url*/}
                    <input type="hidden" name="Userid"          id="Userid"       readOnly value={this.state.userid}/> {/*사용자id*/}
                    <input type="hidden" name="Payeremail"      id="Payeremail"   readOnly value={this.state.payeremail}/> {/*결제자E-mail*/}
                    <input type="hidden" name="CASH_GB"         id="CASH_GB"      readOnly value={this.state.cashGb}/> {/*결제수단구분*/}
                    <input type="hidden" name="PAY_MODE"        id="PAY_MODE"     readOnly value={this.state.payMode}/> {/*거래모드*/}
                    <input type="hidden" name="CALL_TYPE"       id="CALL_TYPE"    readOnly value={this.state.callType}/> {/*결제창 호출 방식*/}
                    <input type="hidden" name="IFRAME_NAME"     id="IFRAME_NAME"  readOnly value={this.state.iframeName}/> {/*ifraME 명*/}
                    <input type="hidden" name="MSTR"            id="MSTR"         readOnly value={this.state.mstr}/> {/*가맹점콜백변수*/}
                    <input type="hidden" name="Cryptyn"         id="Cryptyn"      readOnly value={this.state.cryptyn}/> {/*암호화사용여부*/}
                    <input type="hidden" name="Cryptstring"     id="Cryptstring"  readOnly value={this.state.cryptstring}/> {/*암호화문자열*/}
                    
                    <input type="hidden" name="CN_Install"      id="CN_Install"   readOnly value={this.state.cnInstall}/>{/*최대할부개월수*/}
                    <input type="hidden" name="billType"        id="billType"     readOnly value={this.state.billtype}/>{/*과세/비과세/복합과세*/}
                    <input type="hidden" name="tax"             id="tax"          readOnly value={this.state.tax}/>{/*부가세*/}
                    <input type="hidden" name="taxFree"         id="taxFree"      readOnly value={this.state.taxfree}/>{/*비과세*/}
                </form>



                <form name="accountTransferPayForm" id="accountTransferPayForm" acceptCharset='euc-kr'>
                    <input type="hidden" name="RA_SVCID"        id="RA_SVCID"        readOnly value={this.state.raSvcid}/> {/*서비스아이디*/}
                    <input type="hidden" name="Prdtnm"          id="Prdtnm"          readOnly value={this.state.prdtnm}/> {/*상품명*/}
                    <input type="hidden" name="Prdtprice"       id="Prdtprice"       readOnly value={this.state.prdtprice}/> {/*결제요청금액*/}
                    <input type="hidden" name="Tradeid"         id="Tradeid"         readOnly value={this.state.tradeid}/> {/*가맹점거래번호*/}
                    <input type="hidden" name="Siteurl"         id="Siteurl"         readOnly value={this.state.siteurl}/> {/*가맹점도메인*/}
                    <input type="hidden" name="Notiurl"         id="Notiurl"         readOnly value={this.state.notiurl}/> {/*결과통보 처리 url*/}
                    <input type="hidden" name="Okurl"           id="Okurl"           readOnly value={this.state.okurl}/> {/*성공url*/}
                    <input type="hidden" name="Closeurl"        id="Closeurl"        readOnly value={this.state.closeurl}/> {/*취소/닫기 시 이동 url*/}
                    <input type="hidden" name="Failurl"         id="Failurl"         readOnly value={this.state.failurl}/> {/*실패 시 이동 url*/}
                    <input type="hidden" name="Userid"          id="Userid"          readOnly value={this.state.userid}/> {/*사용자 ID*/}
                    <input type="hidden" name="Payeremail"      id="Payeremail"      readOnly value={this.state.payeremail}/> {/*결제자 이메일*/}
                    <input type="hidden" name="CASH_GB"         id="CASH_GB"         readOnly value={this.state.cashGb}/> {/*결제수단 구분*/}
                    <input type="hidden" name="PAY_MODE"        id="PAY_MODE"        readOnly value={this.state.payMode}/> {/*거래종류*/}
                    <input type="hidden" name="CALL_TYPE"       id="CALL_TYPE"       readOnly value={this.state.callType}/> {/*결제창 호출방식*/}
                    <input type="hidden" name="IFRAME_NAME"     id="IFRAME_NAME"     readOnly value={this.state.iframeName}/> {/*iframe 명칭*/}
                    <input type="hidden" name="MSTR"            id="MSTR"            readOnly value={this.state.mstr}/> {/*가맹점 콜백 변수*/}
                    <input type="hidden" name="Cryptyn"         id="Cryptyn"         readOnly value={this.state.cryptyn}/> {/*암호화 사용 여부*/}
                    <input type="hidden" name="Cryptstring"     id="Cryptstring"     readOnly value={this.state.cryptstring}/> {/*암호화 검증 값*/}
                    
                    <input type="hidden" name="Prdtcd"          id="Prdtcd"          readOnly value={this.state.prdtcd}/>{/*상품코드*/}
                    <input type="hidden" name="Notiemail"       id="Notiemail"       readOnly value={this.state.notiemail}/>{/*noti 알림E-mail*/}
                    <input type="hidden" name="INFOAREA_YN"     id="INFOAREA_YN"     readOnly value={this.state.infoareaYn}/>{/*결제창 안내문 표시 여부*/}
                    <input type="hidden" name="FOOTER_YN"       id="FOOTER_YN"       readOnly value={this.state.footerYn}/>{/*결제창 하단 안내 표시 여부*/}
                    <input type="hidden" name="HEIGHT"          id="HEIGHT"          readOnly value={this.state.height}/>{/*결제창 높이*/}
                    <input type="hidden" name="PRDT_HIDDEN"     id="PRDT_HIDDEN"     readOnly value={this.state.prdtHidden}/>{/*상품명 숨김 여부*/}
                    <input type="hidden" name="EMAIL_HIDDEN"    id="EMAIL_HIDDEN"    readOnly value={this.state.emailHidden}/>{/*결제자 이메일 숨김 여부*/}
                    <input type="hidden" name="CONTRACT_HIDDEN" id="CONTRACT_HIDDEN" readOnly value={this.state.contractHidden}/>{/*이용약관 숨김 여부*/}
                    <input type="hidden" name="LOGO_YN"         id="LOGO_YN"         readOnly value={this.state.logoYn}/>{/*가맹점 로고 사용여부*/}
                    <input type="hidden" name="Item"            id="Item"            readOnly value={this.state.item}/>{/*아이템*/}
                </form>

            </span>



        );
    }
}

export default connect(mapStateToProps)(Payment);
