import React from 'react';

/*다국어 모듈 시작*/
import { connect } from 'react-redux';
import { changeLangauge, mapStateToProps } from '../../language/Actions';
/*다국어 모듈 종료*/

class BulkUpload extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            uploadButtonClick : false,
            viewFileName : ""
        }
        this.handleChange = this.handleChange.bind(this);
    }

    //컴포넌트가 만들어지고 첫 렌더링을 다 마친 후 실행되는 메소드입니다.
	componentDidMount() {
		this.props.onRef(this)
	}

	//컴포넌트가 DOM 에서 사라진 후 실행되는 메소드입니다.
	componentWillUnmount() {
		this.props.onRef(null)
	}

    hide() {
        layer_close(".pop-big-register");
    }

    show() {
        layer_open(".pop-big-register");
        this.setState({
            uploadButtonClick : false,
            viewFileName : ""
        })
        $("#bulkFileUpload").val("");
    }

    bulkUpload() {
        this.props.onBulkUpload();
    }

    uploadButtonToggle() {
        this.setState({
            uploadButtonClick : !this.state.uploadButtonClick
        });
    }

    handleChange(e) {
        console.log(e.target.files[0]);
        if(e.target.files[0] === undefined) {
            this.props.onFileChange(e.target.files[0]);
            this.setState({
                viewFileName : ""
            })
        } else {
            this.props.onFileChange(e.target.files[0]);
            this.setState({
                viewFileName : e.target.files[0].name
            })
        }
	}


    render() {

        return (

            <div className="lpopup">
                <div className="dimmed"></div>
                <div className="popup_layer pop_big_register pop-big-register mid">
                    <div className="pop_container">
                        <div className="pop_header">
                            <h1>{this.props.messages.contract_batch_registration}</h1>
                        </div>
                        {/* pop_contents */}
                        <div className="pop_contents">
                            <div className="pop_inner">
                                <div className="guide_box">
                                    <strong className="g_title"><i className="ico_alert"></i><span>{this.props.messages.contract_batch_registration_way}</span></strong>
                                    <ul className="down_step">
                                        <li>{this.props.messages.contract_download_form}</li>
                                        <li>{this.props.messages.contract_fill_excel_form}</li>
                                        <li>{this.props.messages.contract_file_upload}</li>
                                        <li><span className="point">{this.props.messages.contract_register}</span> {this.props.messages.contract_chick_button}</li>
                                    </ul>
                                </div>

                                <table className="tbl_row">
                                    <caption>대량 등록 목록</caption>
                                    <colgroup>
                                        <col style={{width: '130px'}}/>
                                        <col style={{width: 'auto'}}/>
                                    </colgroup>
                                    <tbody>
                                        <tr>
                                            <th scope="row">{this.props.messages.contract_download_form}</th>
                                            <td className="input"><a href="javascript:;" className="tbtn_pos" onClick={this.props.onBulkUploadSample}>{this.props.messages.contract_download}</a></td>
                                        </tr>
                                        <tr>
                                            <th scope="row">{this.props.messages.contract_file_upload}</th>
                                            <td className="input">
                                                <span className="file-upload file_wrap">
                                                    <input className="file-name file_ip_name" disabled="disabled" value={this.state.viewFileName}/>
                                                    <label htmlFor={"bulkFileUpload"} className="tbtn_pos">{this.props.messages.contract_browser}</label> 
                                                    <input type="file" id="bulkFileUpload" className="file-hidden ui_hidden" name="fileUpload" onChange={this.handleChange}/> 
                                                </span>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>	
                        {/*// pop_contents*/}
                        <div className="pop_bottom">
                            <button type="button" className="pbtn_pos" onClick={() => {this.hide()}}>{this.props.messages.contract_cancel}</button>
                            <button type="button" className="pbtn_black" onClick={() => {this.bulkUpload()}} disabled={this.state.uploadButtonClick}>{this.props.messages.contract_register}</button>
                        </div>
                    </div>{/*// pop_container */}
                    <a href="javascript:;" onClick={() => {this.hide()}} className="btn_pop_close"><span className="offscreen">{this.props.messages.assets_close}</span></a>
                </div>{/*// popup_layer */}
            </div>

        );
    }
}

export default connect(mapStateToProps)(BulkUpload);