import React from 'react'
import { Link } from 'react-router';
import { browserHistory } from 'react-router';

import ContractDetail from '../contract/ContractDetail';
import ProductDetail from '../product/Detail';

/*다국어 모듈 시작*/
import { connect } from 'react-redux';
import { changeLangauge, mapStateToProps } from '../../language/Actions';
/*다국어 모듈 종료*/

class PopupDetail extends React.Component{

	constructor(props) {
		super(props);

	}

	componentDidMount() {

        
	}
			
	

	render(){

		

		return (
			<section className="body">
				<div className="wrapper">
					<div className="content_wrap">
						<div className="content_outbox">
                            <div className="tab_wrap tab-wrap">
								{
									this.props.location.query.item == "product" 
									?
										<ProductDetail popupDetail={this.props.location.query.productNo}/>
									:
										this.props.location.query.item == "contract" 
										?
											<ContractDetail popupDetail={this.props.location.query.ctrtNo}/>
										:
										''
								}
							</div>
						</div>
					</div>
				</div>
			</section>
		);
	}

};

//export default Header;
export default connect(mapStateToProps)(PopupDetail);