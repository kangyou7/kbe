/*jshint esversion: 6 */
import React from 'react';

import {REST_API_URL} from '../../config/api-config.js';

/*다국어 모듈 시작*/
import { connect } from 'react-redux';
import { changeLangauge, mapStateToProps, actionlogin } from '../../language/Actions';
import { parse } from 'query-string';
/*다국어 모듈 종료*/

const initialState ={
    custmNo : 0,
    custmBnofNo : 0,
    bnofName : "",
    bnofAddr : "",
    bnofTel : "",
};

class BnofCreate extends React.Component {

	constructor(props) {
		super(props);

        this.state = $.extend(true, {}, initialState);
		this.handleChange = this.handleChange.bind(this);
        this.handleSave = this.handleSave.bind(this);

    }

    //컴포넌트가 만들어지고 첫 렌더링을 다 마친 후 실행되는 메소드입니다.
	componentDidMount() {
        this.props.onRef(this);
	}

	//컴포넌트가 DOM 에서 사라진 후 실행되는 메소드입니다.
	componentWillUnmount() {
		this.props.onRef(null);
	}

    handleSave() {

        if(this.validationChecke()){
            this.props.onBnofAdd(this.state);

            this.hide();
        }

        // let data = {
        //     custmNo : this.state.custmNo,
        //     custmBnofNo : this.state.custmBnofNo,
        //     bnofName : this.state.bnofName,
        //     bnofAddr : this.state.bnofAddr,
        //     bnofTel : this.state.bnofTel,
        //     loginUserNo : this.props.memberInfo.user_no
        // };

		// $.ajax({
		// 	url: REST_API_URL + "/customer/bnof_save",
		// 	dataType: 'json',
		// 	type: "post",
		// 	data:  data,
		// 	cache: false,
		// 	processData : true, /*querySTring make false*/
		// 	success: function(result) {
        //         this.complete();
		// 	}.bind(this),
		// 		error: function(xhr, status, err) {
		// 		console.log(xhr + " : " + status + " : " + err);
		// 	}.bind(this),
        //     xhrFields: {
        //       withCredentials: true
        //     }
		// });
    }

	validationChecke() {

        if(!this.state.bnofName) {
            alert("지점명을 입력하세요.");
            return false;
        }

        if(!this.state.bnofAddr) {
            alert("주소를 입력하세요.");
            return false;
        }
		return true;

	}

	handleChange(e) {
        let nextState = {};
        nextState[e.target.name]=e.target.value;
        this.setState(nextState);
    }

    complete() {
        this.props.onBnofComplete();
        this.hide();
    }

    hide() {
        layer_close(".pop-pvmanager-register");
    }

    show() {
        this.state = $.extend(true, {}, initialState);


        let nextState = ({
            custmNo : this.props.custmNo,
        });

        this.setState(nextState);

        
        layer_open(".pop-pvmanager-register");
    }

    maxLengthCheck(e){
        e.target.value = e.target.value.replace(/[^0-9]/g,"");
    
        if(e.target.value.length > e.target.maxLength){
          e.target.value = e.target.value.slice(0, e.target.maxLength);
        }
    }

    render() {
        return (
            <div className="lpopup">
                <div className="dimmed" />
                <div className="popup_layer pop_manager_register pop-pvmanager-register mid">
                    <div className="pop_container">
                        <div className="pop_header">
                            <h1>지점 등록 팝업</h1>
                        </div>
                        { /* pop_contents */ }
                        <div className="pop_contents">
                            <div className="pop_inner">
                                <table className="tbl_row">
                                    <caption>지점 정보 목록</caption>
                                    <colGroup>
                                        <col style={{width:"130px"}}/>
                                        <col style={{width:"auto"}}/>
                                    </colGroup>
                                    <tbody>
                                        <tr>
                                            <th scope="row">지점명 <span className="tc_red">*</span></th>
                                            <td className="input">
                                                <input type="text" 
                                                    className="ui_input" 
                                                    name="bnofName" 
                                                    value={this.state.bnofName}  
                                                    onChange={this.handleChange}
                                                    maxLength={100}
                                                />
                                            </td>
                                        </tr>
                                        <tr>
                                            <th scope="row">주소<span className="tc_red">*</span></th>
                                            <td className="input">
                                                <input type="text" 
                                                    className="ui_input" 
                                                    name="bnofAddr" 
                                                    value={this.state.bnofAddr}  
                                                    onChange={this.handleChange}
                                                    maxLength={500}
                                                />
                                            </td>
                                        </tr>
                                        <tr>
                                            <th scope="row">전화번호</th>
                                            <td className="input">
                                                <input type="text" 
                                                    className="ui_input" 
                                                    name="bnofTel" 
                                                    value={this.state.bnofTel}
                                                    onChange={this.handleChange}
                                                    onInput={this.maxLengthCheck.bind(this)}
                                                    maxLength ={20}
                                                />
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>	
                        { /*// pop_contents*/ }
                        <div className="pop_bottom">
                            <button type="button" className="pbtn_pos" onClick={() => {this.hide();}} >취소</button>
                            <button type="button" className="pbtn_black" onClick={this.handleSave}>확인</button>
                        </div>
                    </div>{ /*// pop_container */ }
                    <a onClick={() => {this.hide()}} className="btn_pop_close"><span className="offscreen">닫기</span></a>
                </div>
                { /*// popup_layer */ }
            </div>
        );
    }
}

export default connect(mapStateToProps)(BnofCreate);

