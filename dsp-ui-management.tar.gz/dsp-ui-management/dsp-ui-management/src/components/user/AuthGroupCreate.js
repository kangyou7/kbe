/*jshint esversion: 6 */
import React from 'react';

import {REST_API_URL} from '../../config/api-config.js';

/*다국어 모듈 시작*/
import { connect } from 'react-redux';
import { changeLangauge, mapStateToProps, actionlogin } from '../../language/Actions';
/*다국어 모듈 종료*/

const initialState ={
    groupName : "",
    groupDesc : "",
    confirm : false,
}

class AuthGroupCreate extends React.Component {

	constructor(props) {
		super(props);

        this.state = $.extend(true, {}, initialState);

		this.handleChange = this.handleChange.bind(this);
        this.handleSave = this.handleSave.bind(this);
        this.handleCheck = this.handleCheck.bind(this);

    }

    handleCheck(){
        let groupName = "";
        groupName = this.state.groupName;
        groupName = groupName.trim();

        if(!groupName){
            alert("그룹명을 입력하세요.");
            return false;
        }
        $.ajax({
			url: REST_API_URL + "/user/group/check",
			dataType: 'json',
			type: "post",
			data:  {groupName : groupName},
			cache: false,
			processData : true, /*querySTring make false*/
			success: function(result) {
                console.log(JSON.stringify(result));

                if(result.response){
                    alert('사용 가능한 그룹명 입니다.');
                    this.setState({
                        confirm : true
                    });
                }else{
                    alert('중복된 그룹명 입니다.');
                }
    
			}.bind(this),
				error: function(xhr, status, err) {
				console.log(xhr + " : " + status + " : " + err);
			}.bind(this),
            xhrFields: {
              withCredentials: true
            }
		});
    }

    //컴포넌트가 만들어지고 첫 렌더링을 다 마친 후 실행되는 메소드입니다.
	componentDidMount() {
        this.props.onRef(this);
	}

	//컴포넌트가 DOM 에서 사라진 후 실행되는 메소드입니다.
	componentWillUnmount() {
		this.props.onRef(null);
	}

    handleSave() {

        if(!this.validationCheck()){
            return false;
        }
        
        const memberInfo = storage.get('memberInfo');

        let _param = {
            groupName : this.state.groupName,
            groupDesc : this.state.groupDesc,
            loginUserNo : memberInfo.user_no,
        };

		$.ajax({
			url: REST_API_URL + "/user/group/create",
			dataType: 'json',
			type: "post",
			data:  _param,
			cache: false,
			processData : true, /*querySTring make false*/
			success: function(result) {
                this.complete();
			}.bind(this),
				error: function(xhr, status, err) {
				console.log(xhr + " : " + status + " : " + err);
			}.bind(this),
            xhrFields: {
              withCredentials: true
            }
		});
    }

	validationCheck() {
        if(!this.state.groupName.trim()) {
            alert("그룹명을 입력하세요.");
            return false;
        }

        if(!this.state.confirm){
            alert("중복 체크를 해주세요.");
            return false;
        }
		return true;
	}

	handleChange(e) {

        if(e.target.name=='groupName'){
            console.log('이름변경이 반영되는가?');
            let nextState = {};
            nextState[e.target.name]=e.target.value;
            nextState['confirm']=false;
            this.setState(nextState);
        }else{
            let nextState = {};
            nextState[e.target.name]=e.target.value;
            this.setState(nextState);
        }
    }

    complete() {
        this.props.onAuthGroupComplete();
        this.hide();
    }

    hide() {
        layer_close(".pop-pvmanager-register");
    }

    show() {
        this.state = $.extend(true, {}, initialState);


        let nextState = ({
            custmNo : this.props.custmNo,
        });

        this.setState(nextState);

        
        layer_open(".pop-pvmanager-register");
    }

    getListProviderUsr() {
        $.ajax({
            url: REST_API_URL + "/manage/provider/chargeUsrList",
            dataType: 'json',
            type: "post",
            data: this.props.pageInfo,
            cache: false,
            xhrFields: {
                withCredentials: true
            },
            success: function(result) {
                this.props.onPageInfoChange(result.response.pageInfo, false);
                this.setState({ list: result.response.list });
            }.bind(this),
            error: function(xhr, status, err) {
                console.log(xhr + " : " + status + " : " + err);
            }.bind(this),
        });
    }
    
    render() {
        const {confirm} = this.state;
        const enabled = confirm;
        return (
            <div className="lpopup">
                <div className="dimmed" />
                <div className="popup_layer pop_manager_register pop-pvmanager-register mid">
                    <div className="pop_container">
                        <div className="pop_header">
                            <h1>{this.props.messages.auth_group_registration}</h1>
                        </div>
                        { /* pop_contents */ }
                        <div className="pop_contents">
                            <div className="pop_inner">
                                <table className="tbl_row">
                                    <caption>그룹 정보 목록</caption>
                                    <colGroup>
                                        <col style={{width:"130px"}}/>
                                        <col style={{width:"auto"}}/>
                                    </colGroup>
                                    <tbody>
                                        <tr>
                                            <th scope="row">{this.props.messages.user_group_registrant}<span className="tc_red">*</span></th>
                                            <td className="input">
                                                {this.props.memberInfo.user_name}
                                            </td>
                                        </tr>
                                        <tr>
                                            <th scope="row">{this.props.messages.auth_group_name}<span className="tc_red">*</span></th>
                                            <td className="input">
                                                <span className="input_btn_box">
                                                    <input type="text" 
                                                        className="ui_input" 
                                                        name="groupName" 
                                                        value={this.state.groupName}  
                                                        onChange={this.handleChange}
                                                        maxLength="32"
                                                    />
                                                    <button type="button" className="tbtn_pos" onClick={this.handleCheck}>{this.props.messages.auth_validity_check}</button>
                                                </span>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th scope="row">{this.props.messages.user_group_information}</th>
                                            <td className="input">
                                                <textarea className="ui_textarea" name="groupDesc" value={this.state.groupDesc}  onChange={this.handleChange} maxLength="4000"></textarea>
                                            </td>
                                        </tr>
                                        
                                    </tbody>
                                </table>
                            </div>
                        </div>	
                        { /*// pop_contents*/ }
                        <div className="pop_bottom">
                            <button type="button" className="pbtn_pos" onClick={() => {this.hide();}} >{this.props.messages.user_cancel}</button>
                            <button type="button" className="pbtn_black" onClick={this.handleSave} disabled={!enabled} >{this.props.messages.user_ok}</button>
                        </div>
                    </div>{ /*// pop_container */ }
                    <a onClick={() => {this.hide()}} className="btn_pop_close"><span className="offscreen">{this.props.messages.main_close}</span></a>
                </div>
                { /*// popup_layer */ }
            </div>
        );
    }
}

export default connect(mapStateToProps)(AuthGroupCreate);

