import React from 'react';

import { browserHistory } from 'react-router';

import ApprovalLineSetting from '../common/ApprovalLineSetting';

import Calendar from '../common/Calendar';
import CodeSelect from '../common/CodeSelect';
import AttachFile from '../common/AttachFile';

import {REST_API_URL} from '../../config/api-config.js';

import axios from 'axios';

import CKEditor from "react-ckeditor-component";

import NoticeTargetSearch from '../common/NoticeTargetSearch';

/*다국어 모듈 시작*/
import { connect } from 'react-redux';
import { changeLangauge, mapStateToProps } from '../../language/Actions';
/*다국어 모듈 종료*/

import validator from 'validator';

class ProviderNoticeCreate extends React.Component {

	constructor(props) {
		super(props);

		this.state = {
			noticeTitle : "",
			noticeContent : "",
			noticeStrDate : "",
			noticeClasCode : "02",
			noticeTargtClasCode : "ALL",
			emailNtceYn : "Y",
			smsNtceRecvYn : "Y",
			selectedTarget : [],
			attachFile: []
		}

		this.handleChange = this.handleChange.bind(this);

		this.handleSave = this.handleSave.bind(this);

		this.handleFileChange = this.handleFileChange.bind(this);

		this.handleNoticeSave = this.handleNoticeSave.bind(this);

		this.editorBlur = this.editorBlur.bind(this);

		this.editorAfterPaste = this.editorAfterPaste.bind(this);

		this.editorChange = this.editorChange.bind(this);

		this.handleInitState = this.handleInitState.bind(this);

		this.handleTargetComplete = this.handleTargetComplete.bind(this);
		
	}

	handleInitState() {
		
		this.setState({
			noticeTitle : "",
			noticeContent : "",
			noticeStrDate : "",
			noticeTargtClasCode : "ALL",
			emailNtceYn : "Y",
			smsNtceRecvYn : "Y",
			selectedTarget : [],
			attachFile: []
		});

		CKEDITOR.instances.editor1.setData("");
	}

	handleFileChange(attachFile) {
		this.setState({
			attachFile : attachFile
		})
	}

	handleNoticeSave(attachFile) {

		//if (this.validationCheck()) {

			this.setState({
				attachFile : attachFile
			});

	
			let data = this.state;

			let memberInfo = JSON.parse(localStorage.getItem("memberInfo"));
        	data.loginUserNo = memberInfo.user_no;

			//if (confirm("등록하시겠습니까?")) {
				$.ajax({
					url: REST_API_URL+"/notice/Create",
					dataType: 'json',
					type: "post",
					data: {paramJson : JSON.stringify(data)},
					xhrFields : {
						withCredentials : true
					},
		
					success: function(result) {

						console.log(JSON.stringify(result));
						
						if (result.code == "SUC_PROC_0000") {
							alert("등록되었습니다.");
							location.href="/providerNotice";
						} else {
							alert("등록 도중 오류가 발생하였습니다. 관리자에게 문의바랍니다.");
							return;
						}
		
					}.bind(this),
						error: function(xhr, status, err) {
						console.log(xhr + " : " + status + " : " + err);
					}.bind(this)
				});
			//}		
		//}
	}

	handleSave() {
		if(!this.validationCheck()) {
			return;
		}
		if (confirm("등록하시겠습니까?")) {
			if(this.state.attachFile.length > 0) {
				this.attachFile.fileUpload();
			} else {
				this.handleNoticeSave(null);
			}
		}
	}

	validationCheck() {
		
		if(validator.trim(this.state.noticeTitle) == "") {
			alert("제목을 입력해 주세요.");
			return false;
		} else {
			if (!validator.isLength(this.state.noticeTitle,{min:0, max: 300})) {
				alert("제목은 300자 이내로 입력바랍니다.");
				return false;
			}
		}

		if(validator.trim(this.state.noticeContent) == "") {
			alert("내용을 입력해 주세요.");
			return false;
		} else {
			if (!validator.isLength(this.state.noticeContent,{min:0, max: 1000})) {
				alert("내용은 1000자 이내로 입력바랍니다.");
				return false;
			}
		}

		if(this.state.noticeTargtClasCode == "TARGET" && this.state.selectedTarget.length == 0) {
			alert("공지대상을 선택하세요.");
			return false;
		}

		//selectedTarget
		
		// if(this.state.attachFile.length == 0) {
		// 	alert("파일을 첨부해 주세요.");
		// 	return false;
		// }
		
		return true;
	}

	handleChange(e) {
		

		if (e.target.name === "noticeTargtClasCode") {
			if (e.target.value == "TARGET") {
				$("#btnTargetSearch").show();
			} else {
				$("#btnTargetSearch").hide();
			}

			let nextState = {};
			nextState[e.target.name]=e.target.value;
			this.setState(nextState);

		} else if(e.target.type == "checkbox") {
			let nextState = {};
			if(e.target.name == "emailNtceYn") {
				nextState[e.target.name]=this.state.emailNtceYn === 'Y' ? 'N': 'Y';
			} else {
				nextState[e.target.name]=this.state.smsNtceRecvYn === 'Y' ? 'N': 'Y';
			}
			this.setState(nextState);
		} else {
			let nextState = {};
			nextState[e.target.name]=e.target.value;
			this.setState(nextState);
		}
	}

	goList() {
		if (confirm("이 페이지에서 나가시겠습니까?\n작성중인 내용이 저장되지 않습니다.")) {
			location.href="/providerNotice";
		}
	}

	editorBlur(evt) {
		//console.log("editorBlur: ", evt);
		var newContent = evt.editor.getData();
		this.setState({
			noticeContent: newContent
		})
	}
	editorAfterPaste(evt) {
		//console.log("editorAfterPaste: ", evt);
		var newContent = evt.editor.getData();
		this.setState({
			noticeContent: newContent
		})
	}
	editorChange(evt) {
		//console.log("editorChange: ", evt);
		var newContent = evt.editor.getData();
		this.setState({
			noticeContent: newContent
		})
	}

	handleTargetComplete(target) {

		// console.log(target);
		// let strCheckedTarget = "";

		// for (var i=0; i<target.length; i++) {
		// 	target[i].state = "";
		// 	strCheckedTarget += target[i].custmNo;
		// 	if (i != target.length-1) {
		// 		strCheckedTarget += "|";
		// 	}
		// }

		this.setState({
			selectedTarget : target
		});
	}

	componentDidMount() {
		$("#tab-cont1").show();

		$.ajax({
			url: REST_API_URL + "/code/getCurrentTimestamp",
			dataType: 'json',
			type: "post",
			cache: false,
			success: function(result) {
				this.setState({
					noticeStrDate: result.response.currentTimestamp.nowYear + "-" + result.response.currentTimestamp.nowMonth + "-" + result.response.currentTimestamp.nowDay
				})
			}.bind(this),
				error: function(xhr, status, err) {
				console.log(xhr + " : " + status + " : " + err);
			}.bind(this),
            xhrFields: {
              withCredentials: true
            }
		});

		setTimeout(function() {
			CKEDITOR.on('instanceCreated', function(event) {
				var editor = event.editor;
				editor.on('instanceReady', function(e) {
					$(e.editor.element.$).find("a").removeAttr("title");
					$("#cke_24").remove();
				});
			});
			
		}, 500);
	}
	
    render() {

		const removeT = (key) => {
			let selectedTarget = this.state.selectedTarget;

			selectedTarget.splice(key, 1);
			//selectedTarget[key].state = 'D';

			this.setState({
				selectedTarget : selectedTarget
			})
		}

		const mapToCustomer = (data) => {
			return data.map((item, i) => {//map
				
				// if(item.state != 'D') {
				return(
					<li key={i} id={item.custmNo}>
						<span className="title">{item.coName}</span>
						<a href="javascript:;" className="ibtn_del" onClick={() => {removeT(i)}}>
							<i className="ico_del"><span className="offscreen">{this.props.messages.notice_delete}</span></i>
						</a>
					</li>
				);
				// }
            });
		}
		
        return (
			<section className="body">

				{/* S:wrapper */}
				<div className="wrapper">

					{/* S:page_header */}
					<div className="page_header">
						<h2 className="ptitle">{this.props.messages.notice_provider_notice_registration}</h2>
						<div className="page_nav">
							{/*<ul>
								<li><a href="/">Home</a></li>
								<li><a href="/monitoringNotice">{this.props.messages.notice_management}</a></li>
								<li className="here">{this.props.messages.notice_provider_notice_registration}</li>
							</ul>*/}
						</div>
					</div>
					{/* E:page_header */}

					{/* S:content_wrap */}
					<div className="content_wrap">
						{/* S:content_outbox */}
						<div className="content_outbox">
							{/* S:tab_wrap */}
							<div className="tab_wrap tab-wrap">
								{/* S:tab_header */}
								<div className="box_both tab_header">
									<div className="fl">
										<ul className="tabs">
											<li className="tab_item tab-item">
												<a href="#tab-cont1" className="tab-link" onClick={() => {this.goList()}}><span>{this.props.messages.common_list}</span></a>
											</li>
											<li className="tab_item tab-item on">
												<a href="#tab-cont1" className="tab-link"><span>{this.props.messages.common_detail}</span></a>
											</li>
										</ul>
									</div>
									<div className="fr">
										<div className="btn_group">
											<button type="button" className="btn_pos" onClick={() => {this.handleInitState()}}>{this.props.messages.common_reset}</button>
											{/* <button type="button" className="btn_pos" onClick={() => {this.handleSave('T')}}>임시저장</button> */}
											<button type="button" className="btn_black" onClick={() => {this.handleSave()}}>{this.props.messages.notice_ok}</button>
										</div>
									</div>
								</div>
								{/* E:tab_header */}

								{/* S:tab_content 활성화시 display:block/none  */}
								<div id="tab-cont1" className="tab_content tab-cont" >
									{/* S:content_body */}
									<div className="content_body">
										{/* S:content_inner */}
										<div className="content_inner">

											<div className="box_com">
												<div className="fl">
													<h3 className="ctitle">{this.props.messages.notice_information}</h3>
												</div>
												<div className="fr">
													<div className="desc">
														<span className="tc_red">*</span> {this.props.messages.assets_required}
													</div>
												</div>
											</div>

											{/* S:Table */}
											<table className="tbl_row">
												<caption>Provider 공지 등록</caption>
												<colgroup>
													<col style={{width:'10%'}}/>
													<col style={{width:'40%'}}/>
													<col style={{width:'10%'}}/>
													<col style={{width:'40%'}}/>
												</colgroup>
												<tbody>
												<tr>
													<th scope="row">{this.props.messages.notice_registrant}</th>
													<td colSpan={3}>{this.props.memberInfo.user_name}</td>
													{/* <th scope="row">{this.props.messages.notice_registration_date}</th>
													<td>오늘날짜표시</td> */}
												</tr>
												<tr>
													<th scope="row">{this.props.messages.notice_dept_name}</th>
													<td></td>
													<th scope="row">{this.props.messages.notice_post_date}</th>
													<td className="input">
														{/* <!-- s: 캘린더폼 --> */}
														<div className="date_box">
															{/* <input type="text" data-role="datepicker" className="ui_cal" /> */}
															<Calendar className="ui_cal" 
															dateFormat="YYYY-MM-DD"
															selected={this.state.noticeStrDate}
															name="noticeStrDate"
															onChange={(data) => this.setState({noticeStrDate: data})}/>
														</div>
														{/* <!-- e: 캘린더폼 --> */}
													</td>
												</tr>
												<tr>
													<th scope="row">{this.props.messages.notice_target}</th>
													<td className="input">
														<ul className="ip_list">
															<li>
																<span className="input_ico_box">
																<input type="radio" name="noticeTargtClasCode" id="rdobox-rdo-2-1" value="ALL" defaultChecked="true" onChange={this.handleChange}/>
																<label htmlFor="rdobox-rdo-2-1">{this.props.messages.notice_target_all}</label>
																</span>
															</li>
															<li>
																<span className="input_ico_box">
																<input type="radio" name="noticeTargtClasCode" id="rdobox-rdo-2-2" value="TARGET" onChange={this.handleChange}/>
																<label htmlFor="rdobox-rdo-2-2">{this.props.messages.notice_target_select}</label>
																</span>
																<span className="input_btn_box">
																
																	<button id="btnTargetSearch" className="tbtn_pos" style={{display: 'none'}} onClick={() => {this.noticeTargetSearch.show();}}>{this.props.messages.notice_search}</button>
																</span>
															</li>
														</ul>

														<ul className="search_result_list">
															{mapToCustomer(this.state.selectedTarget)}
														</ul>
													</td>
													<th scope="row">{this.props.messages.notice_notify}</th>
													<td className="input">
														<ul className="ip_list">
															<li>
																<span className="input_ico_box">
																	<input type="checkbox" name="emailNtceYn" id="ip-chk-1" value="Y" checked={this.state.emailNtceYn === 'Y' ? true : false} onChange={this.handleChange}/>
																	<label htmlFor="ip-chk-1">E-Mail</label>
																</span>
															</li>
															<li>
																<span className="input_ico_box">
																	<input type="checkbox" name="smsNtceRecvYn" id="ip-chk-2" value="Y" checked={this.state.smsNtceRecvYn === 'Y' ? true : false} onChange={this.handleChange}/>
																	<label htmlFor="ip-chk-2">SMS</label>
																</span>
															</li>
														</ul>
													</td>
												</tr>
												<tr>
													<th scope="row">{this.props.messages.notice_title} <span className="tc_red">*</span></th>
													<td className="input" colSpan={3}>
														<input type="text" className="ui_input w_100" name="noticeTitle" onChange={this.handleChange} value={this.state.noticeTitle}/>
													</td>
												</tr>
												<tr>
													<th scope="row">{this.props.messages.notice_content} <span className="tc_red">*</span></th>
													<td className="input" colSpan={3}>
													<CKEditor 
														activeClass="editor" 
														content={this.state.noticeContent} 
														value={this.state.noticeContent} 
														onChange={this.editorChange}
														events={{
															"blur": this.editorBlur,
															"afterPaste": this.editorAfterPaste,
															"change": this.editorChange
														}}
														config={{
															image_previewText:" "
															,baseFloatZIndex:99999
															, toolbarGroups : [
																{ name: 'clipboard',   groups: [ 'clipboard', 'undo' ] }
																,{ name: 'editing',     groups: [ 'find', 'selection', 'spellchecker' ] }
																//,{ name: 'forms' }
																,{ name: 'links' }
																,{ name: 'insert' }
																,'/'
																,{ name: 'basicstyles', groups: [ 'basicstyles', 'cleanup' ] }
																,{ name: 'paragraph',   groups: [ 'list', 'indent', 'blocks', 'align', 'bidi' ] }
																//,{ name: 'styles' }
																//,{ name: 'colors' }
																,{ name: 'tools' }
																//,{ name: 'others' }
																,{ name: 'about' }
																//,{ name: 'document',    groups: [ 'mode', 'document', 'doctools' ] }
															],
															removeButtons : 'Image,Flash,Table,HorizontalRule,SpecialChar,Smiley,PageBreak,Iframe,Blockquote,Scayt,About,Link,Unlink',
															title : false
														}}  
														/>
														{/* <textarea className="ui_textarea h_large" name="scheMsg" onChange={this.handleChange} value={this.state.scheMsg}></textarea> */}
													</td>
												</tr>
												<tr>
													<th scope="row">{this.props.messages.notice_attached}</th>
													<td className="input" colSpan={3}>
														<AttachFile onRef={ref => (this.attachFile = ref)}
															attachFileId={this.state.attachFileId}
															files={this.state.attachFile} 
															onChange={this.handleFileChange} 
															onUploadResult={this.handleNoticeSave}
															isFileSearch={true}/>
													</td>
												</tr>
												</tbody>
											</table>
											{/* E:Table */} 
										</div>
										{/* E:content_inner */}
									</div>
									{/* E:content_body */}
								</div>
							
							{/* E:tab_content  */}
							</div>
						{/* E:tab_wrap */}
						</div>
					</div>
				</div>

				<NoticeTargetSearch onRef={ref => (this.noticeTargetSearch = ref)} onTargetComplete={this.handleTargetComplete}/>

			</section>
        );
    }
}

export default connect(mapStateToProps)(ProviderNoticeCreate);