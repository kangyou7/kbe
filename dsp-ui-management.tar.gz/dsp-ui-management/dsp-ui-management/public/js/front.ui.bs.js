/*
 * 파일명:		front.ui.bs.js
 * 설  명 :		공통 자바스크립트
 * 작성자:		glim
 * 최초작성일:	2018/01/15
 * 최종수정일:	2018/03/05 (datepicker dateformat 수정)
*/

var _gnb;
var _mnbSelectId = [];// = [1,2];/*활성화된 메뉴 0 부터 카운트됨*/

$(document).ready( function(){
	
	try {
		$.datepicker.setDefaults({
			dateFormat: 'yy-mm-dd', /* 20180305 수정 */
			showOn: "button",
			buttonImage : "/images/ui/ico_btn_cal.png",
			buttonImageOnly: false,
			currentText: "Now",
			showOtherMonths: true,
			dayNamesMin: ['S', 'M', 'T', 'W', 'T', 'F', 'S'],
			monthNames:['January,', 'February,', 'March,', 'April,', 'May,', 'June,', 'July,', 'August,', 'September,', 'October,', 'November,', 'December,'],
			beforeShow : function(){
				if ( $(this).prop("disabled") == true ){return false;}
				//disable add
				$(this).siblings('.ui-datepicker-trigger').css("background-position","-16px 0");
			},
			onClose:function(){
				$(this).siblings('.ui-datepicker-trigger').css("background-position","0 0");
			}
		});
	}
	catch(exception){
		//catchStatements
	}
	
	//페이지로딩시 공통실행 메서드
	if ( $(".gnb").length > 0  ){//gnb 초기화
		_gnb = new GnbObj('.gnb');
		_gnb.name = '_gnb';
		_gnb.init();
	}
	
	$( window ).resize( function() { resize(); });
	resize();
	
	let option = {year:"numeric", month:"2-digit", day:"2-digit", hour:"2-digit", minute:"2-digit", second:"2-digit", hour12: false}
	setInterval( () => {
		$("#curTime").text(new Date().toLocaleString('ko-KR', option));
	},1000);
	
})
	
	
function resize (){
	
}	


/*
 * date : 20180119
 * last : 20180119
 * name : tabsOnOff( 선택자, 상위 선택자, 보여지는 컨텐츠 선택자, 콜백함수 )
 * pram :  el (target) / container (parent) / tg (target ele selector)
 */
function tabsOnOff (el, container, callback) {
   /* console.log ('tabsOnOff'); */
	
	var tabitem = $(container).find(el).parent('.tab-item');
	var tg = $($(tabitem).find('.tab-link').attr("href"));//target container
	if ( $(tabitem).hasClass ("on") ){//클릭된타겟 활성화일경우 return
		return false;
	}
	
	//off
	var oldTabitem = $(container).find('.tab-item.on');
	/* console.log ( "@@ ", oldTabitem, "~") */
	if ( oldTabitem.length > 0 ){
		//기존 활성화탭 off
		$(oldTabitem).removeClass('on');
		$($(oldTabitem).find('.tab-link').attr("href")).hide();
		console.log ( $(oldTabitem).find('.tab-link').attr("href") )
	}
	
	//on
	tabitem.addClass('on');//tab active
	$(tg).show(0, function(){//tab show
		if ( callback != null && typeof callback === "function" ){
			callback.apply ( null, []);
		}
	});
}

	

/****************************************
* GNB
GNB 활성화 방법 (0 부터 카운트됨)
_mnbSelectId = [0,0]; << 해당 부분이 상단에 선언되어있을시 _gnb.mnbFocus(); 별도 호출하지않아도 작동
실행 초기화는 front.ui.js 
*****************************************/
function GnbObj (id){
	this.getElement = $(id);
	this.len = this.getElement.find("li").length;
	this.bdTimer = null;
}
GnbObj.prototype.init = function(){

	//console.log ( _mnbSelectId, this.name )
	$('>li',this.getElement).each(function(i) {
		$(this).attr("id","gnb_"+i);
		$(this).find('.gnb_sub_item').each(function(j) {
			$(this).attr("id","gnb_"+i+"_"+j);
		});
		
		//hover
		$(this).mouseover(function(e){	
			var tgId = $(e.currentTarget).attr('id');
			//console.log ( tgId, this.getElement);
			
			$('> li',$(this).parent()).removeClass("active");
				
			$('#'+tgId).addClass("active");
			
		});
		
	});
	$(this.getElement).mouseover(this.delegate(this,this.bdStop));
	$(this.getElement).mouseleave(this.delegate(this, this.mouseLeave));
	//최초 메뉴 활성화 실행 
	this.bdStop();
	//this.bdTimer = setTimeout(this.name + ".mnbFocus()", 100);	
	
}

GnbObj.prototype.mnbFocus = function(){
	if ( this.bdTimer == null ) { return false;}
	//console.log ("mnbFocus", _mnbSelectId)

	$('>li',this.getElement).removeClass("active");
	if (_mnbSelectId[0] != -1){
		$('#gnb_'+_mnbSelectId[0]).addClass("active");
	}
	if ( _mnbSelectId[1] != -1 ){
		$('#gnb_'+_mnbSelectId[0]+'_'+_mnbSelectId[1]).addClass("active");
	}
}

GnbObj.prototype.mouseLeave = function(e){
	/* console.log ( "@@@ mouseLeave ") */
	this.bdStop();
	//this.bdTimer = setTimeout(this.name + ".mnbFocus()", 1000);	//메뉴에서 마우스 빠지면 계약관리로 이동 제거
}
GnbObj.prototype.bdStop = function(){ clearTimeout(this.bdTimer); this.bdTimer=null; }
GnbObj.prototype.delegate = function(target,func){return function(e){return func.call(target,e);}}
	
	
/*
 * date : 20180220
 * last : 20180220
 * name : main 프로세스 변경 안내 slide
 * pram :  container (parent) / target (slide element target) / time (ms)
 */
function prevNextRollingBanner(container, target, time){ 
	var $container = $(container);
	var $target = $container.find(target);
	var $prev = $container.find('.controls .prev');
	var $next = $container.find('.controls .next');
	var $cntCurrent = $container.find('.controls .num-current');
	var $cntTotal = $container.find('.controls .num-total');
	var len = $target.children().length;
	var gap = $target.children().outerHeight();
	var _thisTimer;
	var _changeTime = time;
	var cnt = 0;
	
	$cntCurrent.text(cnt + 1);
	$cntTotal.text(len);
	
	$prev.bind('click',function(){
		cnt = (cnt-1+len)%len;
		$target.css('top', -(gap*cnt));
		$cntCurrent.text(cnt + 1);
		return false;
	});
	$next.bind('click',function(){
		cnt = (cnt+1+len)%len;
		$target.css('top', -(gap*cnt));
		$cntCurrent.text(cnt + 1);
		return false;
	});
	
	$container.bind('mouseenter',function(e){
		clearTimeout( _thisTimer );
		_thisTimer = null;
	}).bind('mouseleave',function(e){
		_thisTimer = setInterval(rollingTimerComplete, _changeTime);
	});
	
	function rollingTimerComplete (){
		cnt = (cnt+1+len)%len;
		$target.css('top', -(gap*cnt));
		$cntCurrent.text(cnt + 1);
		return false;
		
	}
	_thisTimer = setInterval(rollingTimerComplete, _changeTime);
	
}
	