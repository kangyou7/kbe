import React from 'react';
import axios from 'axios';

import {REST_API_URL, REST_AUTH_URL} from '../../config/api-config.js';

import { browserHistory } from 'react-router';

/*다국어 모듈 시작*/
import { connect } from 'react-redux';
import { changeLangauge, mapStateToProps } from '../../language/Actions';
/*다국어 모듈 종료*/

class UserInfoPopup extends React.Component{

    constructor(props) {
        super(props);

        this.state = {
        }
    }

    componentDidMount(){
        this.state = JSON.parse(localStorage.getItem("memberInfo"));

        this.forceUpdate();
    }

    openNoticeDetailPopup(e) {
        layer_open('.pop-layer-notice-detail');
    }

    logout(){
        if(confirm("정말 로그아웃 하시겠습니까?")) {
            $.ajax({
                url: REST_AUTH_URL+"/log_out",
                dataType: 'json',
                type: "post",
                data: "",
                xhrFields : {
                withCredentials : true
                },
                success: function(result) {
                
                this.setState({
                    processNoticeList : result.response.list,
                    processNoticeCnt : result.response.list.length
                });
                }.bind(this),
                error: function(xhr, status, err) {
                alert(JSON.stringify(xhr.responseJSON.message));
                console.log(JSON.stringify(xhr) + " : " + status + " : " + err);
                }.bind(this)
            });
        
            localStorage.clear(); 

            browserHistory.push("/login");
        }
    }

    render(){
        
        return(
            <div className="util_drop_box util_user_drop_box util-drop-box" style={{zIndex:9999}}>

                <span className="arrow"></span>
                <div className="title">My Account</div>
                <p className="desc" style={{wordBreak:'break-all'}}>{this.state.user_id}({this.state.user_name}, {this.state.posit_name})</p>
                <div className="title">Log-in</div>
                <p className="desc">{this.state.login_time}</p>
                <a className="btn_black" href="javascript:;" onClick={this.logout.bind(this)} >Logout</a>
            </div>
        );
    }

}

export default connect(mapStateToProps)(UserInfoPopup);