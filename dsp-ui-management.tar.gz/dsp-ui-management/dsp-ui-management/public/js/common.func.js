/*
 * 파일명:		common.func.js
 * 설  명 :		페이지내 공통 실행필요한 함수 include 
 * 작성자:		glim
 * 최초작성일:	2018/01/19
 * 최종수정일:	2018/04/03 (spinner 실행 추가)
 * Comment
 * 초기실행시 공통으로 필요한 함수들
 * 공통으로 들어갈경우 추후 페이지내 수정이 너무 많아질 것 같아서 임시 실행 호출 파일 입니다.)
 * 각 페이지에서만 필요한 스크립트는 각 페이지내에 작성예정
*/
 
// $(window).on("beforeunload", function(e){
//     alert('탭 closed 감지');
//     debugger
//     if (!validNavigation) {
//         endSession();
//     }
// });

//$(window).on("load", function (e) {
$(document).ready( function(){

 
	// jquery datepicker 실행함수
	if ( $("[data-role=datepicker]").length > 0 ){
		$("[data-role=datepicker]").datepicker();
	}  
	
	//파일찾기 form 
	if ( $(".file-upload").length > 0 ){
		
		var fileTarget = $('.file-upload'); 
		$(fileTarget).each(function(){
			var a = $(this).find('.file-hidden');
			$(a).on('change', function(){ // 값이 변경되면 
				if(window.FileReader){ // modern browser 
					var filename = $(this)[0].files[0].name;
				}else { // old IE 
					var filename = $(this).val().split('/').pop().split('\\').pop(); // 파일명만 추출 
				} // 추출한 파일명 삽입 
				$(this).siblings('.file-name').val(filename); 
			});
			
		});
	}
	
	// select 실행 20180208
	if ( $('.ui-sel').length > 0 ){
		$('.ui-sel').each(function(){
			$(this).selectric();//초기화
		});	
	}
	
	//spinner 실행 20180403
	if ( $('.number-counter > .ip-spinner').length > 0 ){
		$('.number-counter > .ip-spinner').each(function(){
			$('.number-counter > .ip-spinner').spinner({alignment: 'horizontal', decreseText: '수량 줄이기', increseText: '수량 늘리기', min: 1});
		});
    }
    
    $(document).ajaxStart(function() {
        console.log("로딩바 보여주기");
        $('#loading').show();

    }).ajaxComplete(function() {
        console.log("로딩바 감추기");
        $('#loading').hide();
    }).ajaxError(function() {
        console.log("에러났어요. 로딩바 감춰요.");
        $('#loading').hide();
    });

});





function endSession() {
    // Browser or broswer tab is closed
    // Do sth here ...
    // alert("bye");
    console.log("endSession");
    alert("bye");
    
    // if(confirm("bye")){
    //     return false;
    // }
}

$(function() {

	//다국어 변경 dropmenu 열려있을때 focus 잃으면 off 20180319 add
	$(document).click(function(e){
		if ( !$(e.target).hasClass('btn-open')  ){
			funcLangsDropMenuClose();
        }
        
        if ( !$(e.target).parents().hasClass('util-item')  ){
			funcUtilDropBoxClose();
		}
	});
	
});
  

/*
* date : 20180319
* last : 20180319 
* name : funcLangsDropMenu 
* Desc : 다국어 dropmenu toggle
*/ 
function funcLangsDropMenu(){
	$('.dropbox-menu').toggleClass('on');
}


/*
* date : 20180319
* last : 20180319 
* name : funcLangsDropMenuClose 
* Desc : 다국어 dropmenu 강제 close
*/ 
function funcLangsDropMenuClose(){
	$('.dropbox-menu').removeClass('on');
}


/*
* date : 20180319
* last : 20180319 
* name : funcLangsDropMenuChange 
* Desc : 다국어 dropmenu 변경시
*/ 
function funcLangsDropMenuChange(tg){
	var val = $(tg).text();
	$('.dropbox-menu .btn-open').text(val);
	$('.dropbox-menu .menu_list li').removeClass('active');
	$(tg).parent().addClass('active');
	funcLangsDropMenuClose();
}

var Cookie =
{
    cookie_arr : null,
 
    set : function (name,value,options)
    {
        options = options || {};
 
        this.cookie_arr = [escape(name) + '=' + escape(value)];
 
        //-- expires
        if (options.expires)
        {
            if( typeof options.expires === 'object' && options.expires instanceof Date )
            {
                var date = options.expires;
                var expires = "expires=" + date.toUTCString();
                this.cookie_arr.push (expires);
            }
        }
        else if (options.expires_day)
        {
            this.set_expires_date (options.expires_day , 24*60*60);
        }
        else if (options.expires_hour)
        {
            this.set_expires_date (options.expires_hour , 60*60);
        }
 
        //-- domain
        if (options.domain)
        {
            var domain = "domain=" + options.domain;
            this.cookie_arr.push (domain);
        }
 
        //-- path
        if (options.path)
        {
            var path = 'path=' + options.path;
            this.cookie_arr.push (path);
        }
 
        //-- secure
        if( options.secure === true )
        {
            var secure = 'secure';
            this.cookie_arr.push (secure);
        }
 
        document.cookie = this.cookie_arr.join('; ');
        //console.log (this.cookie_arr.join('; '));
    },
 
    get : function (name)
    {
        var nameEQ = escape(name) + "=";
        var ca = document.cookie.split(';');
 
        for(var i=0;i < ca.length;i++)
        {
            var c = ca[i];
            while (c.charAt(0)==' ') c = c.substring(1,c.length);
            if (c.indexOf(nameEQ) == 0) return unescape(c.substring(nameEQ.length,c.length));
        }
        return null;
    },
 
    del : function (name , options)
    {
        options = options || {};
        options.expires_day = -1;
        this.set ( name , '' , options );
    },
    set_expires_date : function (expires , time)
    {
        var date = new Date();
        date.setTime(date.getTime()+(expires*time*1000));
        var expires = "expires=" + date.toUTCString();
        this.cookie_arr.push (expires);
        
    }
};

var storage = {
    _key: '',
    _value : '',
    set : function(key, value){
        this._key = key;
        this._value = value;
        if(!Cookie.get('expiration_timestamp')){
            return null;
        }
        return localStorage.setItem(key, JSON.stringify(this._value));
    },
    get : function(key){
        var item = JSON.parse(localStorage.getItem(key));
        if(!Cookie.get('expiration_timestamp')){
            this.del();
            return null;
        }
        return item;
    },
    del : function(){
        return localStorage.clear();
    }
};




/*
* date : 20180416
* last : 20180416
* name : funcUtilDropBox 
* pram : el (click target)
* Desc : util 공통
*/ 
function funcUtilDropBox(el, child){
	var el = $(el);
	$(el).parent().siblings(child).removeClass('on');
	$(el).parent().toggleClass('on');
}
 
/*
* date : 20180416
* last : 20180416 
* name : funcUtilDropBoxClose 
* Desc : util 공통 강제 Close
*/ 
function funcUtilDropBoxClose(){
	$('.util-item').removeClass('on');
}

Date.prototype.format = function(f){
    if(!this.valueOf()) return;
    var weekKorName = ["일요일", "월요일", "화요일", "수요일", "목요일", "금요일", "토요일"];
    var weekKorShortName = ["일", "월", "화", "수", "목", "금", "토"];
    var weekEngName = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
    var weekEngShortName = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
    var d = this;

    return f.replace(/(yyyy|yy|MM|dd|KS|KL|ES|EL|HH|hh|mm|ss|a\/p)/gi, function ($1) {
        switch ($1) {
            case "yyyy": return d.getFullYear(); // 년 (4자리)
            case "yy": return (d.getFullYear() % 1000).zf(2); // 년 (2자리)
            case "MM": return (d.getMonth() + 1).zf(2); // 월 (2자리)
            case "dd": return d.getDate().zf(2); // 일 (2자리)
            case "KS": return weekKorShortName[d.getDay()]; // 요일 (짧은 한글)
            case "KL": return weekKorName[d.getDay()]; // 요일 (긴 한글)
            case "ES": return weekEngShortName[d.getDay()]; // 요일 (짧은 영어)
            case "EL": return weekEngName[d.getDay()]; // 요일 (긴 영어)
            case "HH": return d.getHours().zf(2); // 시간 (24시간 기준, 2자리)
            case "hh": return ((h = d.getHours() % 12) ? h : 12).zf(2); // 시간 (12시간 기준, 2자리)
            case "mm": return d.getMinutes().zf(2); // 분 (2자리)
            case "ss": return d.getSeconds().zf(2); // 초 (2자리)
            case "a/p": return d.getHours() < 12 ? "오전" : "오후"; // 오전/오후 구분
            default: return $1;
        }
    });
};

String.prototype.string = function (len) { var s = '', i = 0; while (i++ < len) { s += this; } return s; };
String.prototype.zf = function (len) { return "0".string(len - this.length) + this; };
Number.prototype.zf = function (len) { return this.toString().zf(len); };

function getTimezoneName() {
	tmSummer = new Date(Date.UTC(2005, 6, 30, 0, 0, 0, 0));
	so = -1 * tmSummer.getTimezoneOffset();
	tmWinter = new Date(Date.UTC(2005, 12, 30, 0, 0, 0, 0));
	wo = -1 * tmWinter.getTimezoneOffset();
    if (-660 == so && -660 == wo) return 'Pacific/Midway';
    if (-600 == so && -600 == wo) return 'Pacific/Tahiti';
    if (-570 == so && -570 == wo) return 'Pacific/Marquesas';
    if (-540 == so && -600 == wo) return 'America/Adak';
    if (-540 == so && -540 == wo) return 'Pacific/Gambier';
    if (-480 == so && -540 == wo) return 'US/Alaska';
    if (-480 == so && -480 == wo) return 'Pacific/Pitcairn';
    if (-420 == so && -480 == wo) return 'US/Pacific';
    if (-420 == so && -420 == wo) return 'US/Arizona';
    if (-360 == so && -420 == wo) return 'US/Mountain';
    if (-360 == so && -360 == wo) return 'America/Guatemala';
    if (-360 == so && -300 == wo) return 'Pacific/Easter';
    if (-300 == so && -360 == wo) return 'US/Central';
    if (-300 == so && -300 == wo) return 'America/Bogota';
    if (-240 == so && -300 == wo) return 'US/Eastern';
    if (-240 == so && -240 == wo) return 'America/Caracas';
    if (-240 == so && -180 == wo) return 'America/Santiago';
    if (-180 == so && -240 == wo) return 'Canada/Atlantic';
    if (-180 == so && -180 == wo) return 'America/Montevideo';
    if (-180 == so && -120 == wo) return 'America/Sao_Paulo';
    if (-150 == so && -210 == wo) return 'America/St_Johns';
    if (-120 == so && -180 == wo) return 'America/Godthab';
    if (-120 == so && -120 == wo) return 'America/Noronha';
    if (-60 == so && -60 == wo) return 'Atlantic/Cape_Verde';
    if (0 == so && -60 == wo) return 'Atlantic/Azores';
    if (0 == so && 0 == wo) return 'Africa/Casablanca';
    if (60 == so && 0 == wo) return 'Europe/London';
    if (60 == so && 60 == wo) return 'Africa/Algiers';
    if (60 == so && 120 == wo) return 'Africa/Windhoek';
    if (120 == so && 60 == wo) return 'Europe/Amsterdam';
    if (120 == so && 120 == wo) return 'Africa/Harare';
    if (180 == so && 120 == wo) return 'Europe/Athens';
    if (180 == so && 180 == wo) return 'Africa/Nairobi';
    if (240 == so && 180 == wo) return 'Europe/Moscow';
    if (240 == so && 240 == wo) return 'Asia/Dubai';
    if (270 == so && 210 == wo) return 'Asia/Tehran';
    if (270 == so && 270 == wo) return 'Asia/Kabul';
    if (300 == so && 240 == wo) return 'Asia/Baku';
    if (300 == so && 300 == wo) return 'Asia/Karachi';
    if (330 == so && 330 == wo) return 'Asia/Calcutta';
    if (345 == so && 345 == wo) return 'Asia/Katmandu';
    if (360 == so && 300 == wo) return 'Asia/Yekaterinburg';
    if (360 == so && 360 == wo) return 'Asia/Colombo';
    if (390 == so && 390 == wo) return 'Asia/Rangoon';
    if (420 == so && 360 == wo) return 'Asia/Almaty';
    if (420 == so && 420 == wo) return 'Asia/Bangkok';
    if (480 == so && 420 == wo) return 'Asia/Krasnoyarsk';
    if (480 == so && 480 == wo) return 'Australia/Perth';
    if (540 == so && 480 == wo) return 'Asia/Irkutsk';
    if (540 == so && 540 == wo) return 'Asia/Seoul';
    if (570 == so && 570 == wo) return 'Australia/Darwin';
    if (570 == so && 630 == wo) return 'Australia/Adelaide';
    if (600 == so && 540 == wo) return 'Asia/Yakutsk';
    if (600 == so && 600 == wo) return 'Australia/Brisbane';
    if (600 == so && 660 == wo) return 'Australia/Sydney';
    if (630 == so && 660 == wo) return 'Australia/Lord_Howe';
    if (660 == so && 600 == wo) return 'Asia/Vladivostok';
    if (660 == so && 660 == wo) return 'Pacific/Guadalcanal';
    if (690 == so && 690 == wo) return 'Pacific/Norfolk';
    if (720 == so && 660 == wo) return 'Asia/Magadan';
    if (720 == so && 720 == wo) return 'Pacific/Fiji';
    if (720 == so && 780 == wo) return 'Pacific/Auckland';
    if (765 == so && 825 == wo) return 'Pacific/Chatham';
    if (780 == so && 780 == wo) return 'Pacific/Enderbury';
    if (840 == so && 840 == wo) return 'Pacific/Kiritimati';
	return 'US/Pacific';
}