/*jshint esversion: 6 */
import React from 'react';

import {REST_API_URL} from '../../config/api-config.js';

/*다국어 모듈 시작*/
import { connect } from 'react-redux';
import { changeLangauge, mapStateToProps, actionlogin } from '../../language/Actions';
/*다국어 모듈 종료*/

const initialState ={
    userNo : 0,
    userStatusCode : "04",
    userDesc : "",
}

class Refusal extends React.Component {

	constructor(props) {
		super(props);

        this.state = $.extend(true, {}, initialState);

		this.handleChange = this.handleChange.bind(this);
        this.handleSave = this.handleSave.bind(this);

    }


    //컴포넌트가 만들어지고 첫 렌더링을 다 마친 후 실행되는 메소드입니다.
	componentDidMount() {
        this.props.onRef(this);
	}

	//컴포넌트가 DOM 에서 사라진 후 실행되는 메소드입니다.
	componentWillUnmount() {
		this.props.onRef(null);
	}

    handleSave() {

        if(this.state.userDesc == "") {
            alert("반려사유를 입력하세요.");
            return false;
        }

        const _param = {
            userNo : this.state.userNo,
            loginUserNo : this.props.memberInfo.user_no,
            userStatusCode : '04',
            userDesc : this.state.userDesc
        };

        console.log(JSON.stringify(_param));

		$.ajax({
			url: REST_API_URL + "/user/update_status",
			dataType: 'json',
			type: "post",
			data:  {paramJson : JSON.stringify(_param)},
			cache: false,
			processData : true, /*querySTring make false*/
			success: function(result) {
                alert('반려 처리 되었습니다.');
                this.complete();
			}.bind(this),
				error: function(xhr, status, err) {
				console.log(xhr + " : " + status + " : " + err);
			}.bind(this),
            xhrFields: { withCredentials: true }
		});
    }

	handleChange(e) {
        let nextState = {};
        nextState[e.target.name]=e.target.value;
        this.setState(nextState);
    }

    complete() {
        this.props.onRefusalComplete();
        this.hide();
    }

    hide() {
        layer_close(".pop-pvmanager-register");
    }

    show(userNo) {
        this.state = $.extend(true, {}, initialState);

        console.log(JSON.stringify(userNo));

        let nextState = ({
            userNo : userNo,
        });

        this.setState(nextState);

        
        layer_open(".pop-pvmanager-register");
    }

    render() {
        const {confirm} = this.state;

        let date = new Date(); 
        let year = date.getFullYear(); 
        let month = new String(date.getMonth()+1); 
        let day = new String(date.getDate()); 

        // 한자리수일 경우 0을 채워준다. 
        if(month.length == 1){ 
        month = "0" + month; 
        } 
        if(day.length == 1){ 
        day = "0" + day; 
        } 

        let today = year + "/" + month + "/" + day;
        return (
            <div className="lpopup">
                <div className="dimmed" />
                <div className="popup_layer pop_manager_register pop-pvmanager-register mid">
                    <div className="pop_container">
                        <div className="pop_header">
                            <h1>반려사유</h1>
                        </div>
                        { /* pop_contents */ }
                        <div className="pop_contents">
                            <div className="pop_inner">
                                <div className="guide_box">
                                    <strong className="g_title"><i className="ico_alert"></i><span>반려처리 하시겠습니까?</span></strong>
                                    <p className="desc">사유를 입력하세요. 반려 시, 사용자 상태는 Reject 로 변경됩니다.</p>
                                </div>
                                <table className="tbl_row">
                                    <caption>반려사유 목록</caption>
                                    <colGroup>
                                        <col style={{width:"130px"}}/>
                                        <col style={{width:"auto"}}/>
                                    </colGroup>
                                    <tbody>
                                        <tr>
                                            <th scope="row">담당자<span className="tc_red">*</span></th>
                                            <td className="input">
                                                {this.props.memberInfo.user_name}
                                            </td>
                                        </tr>
                                        <tr>
                                            <th scope="row">반려일<span className="tc_red">*</span></th>
                                            <td className="input">
                                                {today}
                                            </td>
                                        </tr>
                                        <tr>
                                            <th scope="row">내용<span className="tc_red">*</span></th>
                                            <td className="input">
                                                <textarea className="ui_textarea" name="userDesc" value={this.state.userDesc}  onChange={this.handleChange}></textarea>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        { /*// pop_contents*/ }
                        <div className="pop_bottom">
                            <button type="button" className="pbtn_pos" onClick={() => {this.hide();}} >취소</button>
                            <button type="button" className="pbtn_black" onClick={this.handleSave}>확인</button>
                        </div>
                    </div>{ /*// pop_container */ }
                    <a onClick={() => {this.hide()}} className="btn_pop_close"><span className="offscreen">닫기</span></a>
                </div>
                { /*// popup_layer */ }
            </div>
        );
    }
}

export default connect(mapStateToProps)(Refusal);

