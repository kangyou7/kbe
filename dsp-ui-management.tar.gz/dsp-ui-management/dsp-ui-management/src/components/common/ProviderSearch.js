import React from 'react';

import {REST_API_URL} from '../../config/api-config.js';

/*다국어 모듈 시작*/
import { connect } from 'react-redux';
import { changeLangauge, mapStateToProps } from '../../language/Actions';
/*다국어 모듈 종료*/

class ProviderSearch extends React.Component {

    constructor(props) {
        super(props);

        this.state = {
            searchName:"",
            selectKey:-1,
            providers : []
        }

        this.handleChange = this.handleChange.bind(this);
        this.handleSearch = this.handleSearch.bind(this); 
    }

    //컴포넌트가 만들어지고 첫 렌더링을 다 마친 후 실행되는 메소드입니다.
	componentDidMount() {
		this.props.onRef(this)
	}

	//컴포넌트가 DOM 에서 사라진 후 실행되는 메소드입니다.
	componentWillUnmount() {
		this.props.onRef(null)
	}

    handleChange(e) {
        let nextState = {};
        nextState[e.target.name]=e.target.value;
        this.setState(nextState);
    }

    handleProviderSelect(key) {
        $("#providerBody tr").removeClass();
        $("#providerBody tr").eq(key).addClass('selected');
    }

    handleSearch() {
        this.getProvider();
    }

    
    getProvider() {
        $.ajax({
            url: REST_API_URL + "/provider/getProviderSearch",
            dataType: 'json',
            type: "post",
            data: {
                searchName:this.state.searchName
            },
            cache: false,
            success: function(result) {
                this.setState({
                    selectKey : -1,
                    providers: result.response.providers
                });
            }.bind(this),
                error: function(xhr, status, err) {
                console.log(xhr + " : " + status + " : " + err);
            }.bind(this),
            xhrFields: {
              withCredentials: true
            }
        });
    }

    complete() {
        if(this.state.selectKey < 0) {
            alert("선택하세요");
            return
        }
        let provider = this.state.providers[this.state.selectKey];
        this.props.onProviderComplete(provider);
        this.hide();
    }

    hide() {
        layer_close(".pop-search-provider");
    }

    show() {
        this.setState({
            searchName:"",
            selectKey:-1,
            providers : []
        })
        layer_open(".pop-search-provider");
    }

    

    render() {

        const mapToProvider = (data) => {
            if(data.length > 0) {
                return data.map((item, i) => {//map
                    return(
                        <tr key={i} onClick={() => {this.setState ({selectKey : i}); this.handleProviderSelect(i)}}>

                            <td>{item.coName}</td>
                            <td>{item.bizno}</td>
                        </tr>
                    );
                });
            } else {
                return (
                    <tr>
                        <td className="noresults" colSpan={2}>
                            <div className="box_noresults">
                                <div className="ver_mid">													
                                    <i className="ico ico_no_result"></i>
                                    <span className="lb">{this.props.messages.contract_there_are_no_results}</span>
                                </div>
                            </div>
                        </td>
                    </tr>
                );
            }
        }

        return(
            <div className="lpopup">
                <div className="dimmed"></div>
                <div className="popup_layer pop_search_provider pop-search-provider mid">
                    <div className="pop_container">
                        <div className="pop_header">
                            <h1>{this.props.messages.contract_provider_searching}</h1>
                        </div>
                        {/*pop_contents */}
                        <div className="pop_contents scroll_wrap search_form">
                            {/*pop_inner */}
                            <div className="pop_inner">
                                <div className="psearch_form">
                                    <input type="text" className="ui_input" name="searchName" value={this.state.searchName} onChange={this.handleChange}/>
                                    <a href="javascript:;" className="btn_pos" onClick={this.handleSearch}>{this.props.messages.contract_search_2}</a>
                                </div>
                                
                                <table className="tbl_col">
                                    <caption>Provider 검색 목록</caption>
                                    <colgroup>
                                        <col style={{width:'50%'}} />
                                        <col style={{width:'50%'}} />
                                    </colgroup>
                                    
                                    <thead>
                                        <tr>
                                            <th scope="col">{this.props.messages.contract_company_name_2}</th>
                                            <th scope="col">{this.props.messages.contract_business_number}</th>
                                        </tr>
                                    </thead>
                                    
                                    <tbody id="providerBody">
                                        {/*S : 리스트 */}
                                        {mapToProvider(this.state.providers)}
                                        {/*E : 리스트 */}
                                        
                                    </tbody>
                                </table>
                            </div>
                            {/*// pop_inner */}
                        </div>	
                        {/*// pop_contents*/}
                        <div className="pop_bottom">
                            <button type="button" className="pbtn_black" onClick={() => {this.complete();}}>{this.props.messages.contract_ok}</button>
                        </div>
                    </div>{/*// pop_container */}
                    <a href="javascript:;" onClick={() => {this.hide();}} className="btn_pop_close"><span className="offscreen">{this.props.messages.ticket_close}</span></a>
                </div>{/*// popup_layer */}
            </div>
        );
    }
}

export default connect(mapStateToProps)(ProviderSearch);