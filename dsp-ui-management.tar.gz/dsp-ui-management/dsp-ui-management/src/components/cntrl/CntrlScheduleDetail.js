import React from 'react';

import { browserHistory } from 'react-router';

import ApprovalLineSetting from '../common/ApprovalLineSetting';

import Calendar from '../common/Calendar';
import CodeSelect from '../common/CodeSelect';
import AttachFile from '../common/AttachFile';

import {REST_API_URL} from '../../config/api-config.js';

import axios from 'axios';

/*다국어 모듈 시작*/
import { connect } from 'react-redux';
import { changeLangauge, mapStateToProps } from '../../language/Actions';
/*다국어 모듈 종료*/

import validator from 'validator';

class CntrlScheduleDetail extends React.Component {

	constructor(props) {
		super(props);

		this.state = {
			cntrlScheNo : "",
			scheTitle : "",
			scheMsg : "",
			attachFile: []
		}

		this.handleChange = this.handleChange.bind(this);

		this.handleFileChange = this.handleFileChange.bind(this);

		this.handleScheduleSave = this.handleScheduleSave.bind(this);

		this.handleInitState = this.handleInitState.bind(this);
		
	}

	handleInitState() {
		
		this.setState({
			cntrlScheNo : "",
			scheTitle : "",
			scheMsg : "",
			attachFile: []
		});
	}

	handleFileChange(attachFile) {
		this.setState({
			attachFile : attachFile
		})
	}

	handleScheduleSave(attachFile) {

		if (this.validationCheck()) {
			
			this.setState({
				attachFile : attachFile
			});
	
			let data = this.state;

			let memberInfo = JSON.parse(localStorage.getItem("memberInfo"));
        	data.loginUserNo = memberInfo.user_no;
			
			$.ajax({
				url: REST_API_URL+"/cntrl/Update",
				dataType: 'json',
				type: "post",
				data: {paramJson : JSON.stringify(data)},
				xhrFields : {
					withCredentials : true
				},
	
				success: function(result) {
					
					if (result.response == "SUCCESS") {
						alert("변경되었습니다.");
						location.href="/cntrlSchedule";
					} else {
						alert("변경 도중 오류가 발생하였습니다. 관리자에게 문의바랍니다.");
						return;
					}
	
				}.bind(this),
					error: function(xhr, status, err) {
					console.log(xhr + " : " + status + " : " + err);
				}.bind(this)
			});	
		}
	}

	handleSave() {

		if (confirm("변경하시겠습니까?")) {
			if(this.state.attachFile.length > 0) {
				this.attachFile.fileUpload();
			} else {
				this.handleScheduleSave("");
			}
		}
	}

	validationCheck() {

		if(validator.trim(this.state.scheTitle) == "") {
			alert("제목을 입력해 주세요.");
			return false;
		} else {
			if (!validator.isLength(this.state.scheTitle,{min:0, max: 300})) {
				alert("제목은 300자 이내로 입력바랍니다.");
				return false;
			}
		}

		if(validator.trim(this.state.scheMsg) == "") {
			alert("내용을 입력해 주세요.");
			return false;
		} else {
			if (!validator.isLength(this.state.scheMsg,{min:0, max: 1000})) {
				alert("내용은 1000자 이내로 입력바랍니다.");
				return false;
			}
		}
		
		// if(this.state.attachFile.length == 0) {
		// 	alert("파일을 첨부해 주세요.");
		// 	return false;
		// }
		
		return true;
	}

	handleChange(e) {
		// if(e.target.name === "fileUpload") {
		// 	let files = this.state.files;

		// 	files.push(e.target.files[0]);
		// 	this.setState({
		// 		files : files
		// 	})
			
		// } else {
			let nextState = {};
			nextState[e.target.name]=e.target.value;
			this.setState(nextState);
		// }
	}

	getSchedule(cntrlScheNo) {
        $.ajax({
            url: REST_API_URL+"/cntrl/Detail",
            dataType: 'json',
            type: "post",
            data: {
                cntrlScheNo:cntrlScheNo
            },
            xhrFields : {
				withCredentials : true
			},
            success: function(result) {
				
				this.handleInitState();
                this.setState(result.response);
            }.bind(this),
                error: function(xhr, status, err) {
                console.log(xhr + " : " + status + " : " + err);
            }.bind(this)
        });
    }

	componentDidMount() {
		this.props.onRef(this)
		$("#tab-cont1").show();
	}
	componentWillUnmount() {
		this.props.onRef(null)
	  }
	
    render() {

        return (
							
				<div id="tab-cont2" className="tab_content tab-cont no_paging">
					{/* S:content_body */}
					<div className="content_body">
						{/* S:content_inner */}
						<div className="content_inner">

							<div className="box_com">
								<div className="fl">
									<h3 className="ctitle">{this.props.messages.cntrl_monitoring_schedule_registration}</h3>
								</div>
								<div className="fr">
									<div className="desc">
										<span className="tc_red">*</span> {this.props.messages.cntrl_required}
									</div>
								</div>
							</div>

							{/* S:Table */}
							<table className="tbl_row">
								<caption>스케줄 작성 목록</caption>
								<colgroup>
									<col style={{width:'150px'}}/>
									<col style={{width:'auto'}}/>
								</colgroup>
								<tbody>
								<tr>
									<th scope="row">{this.props.messages.cntrl_registrant}</th>
									<td>{this.state.regUsrSeq}</td>
								</tr>
								<tr>
									<th scope="row">{this.props.messages.cntrl_registration_date}</th>
							
									<td>{this.state.regDate}</td>
								</tr>
								<tr>
									<th scope="row">{this.props.messages.cntrl_title} <span className="tc_red">*</span></th>
									<td className="input">
										<input type="text" className="ui_input" maxLength="300" name="scheTitle" onChange={this.handleChange} value={this.state.scheTitle}/>
									</td>
								</tr>
								<tr>
									<th scope="row">{this.props.messages.cntrl_content} <span className="tc_red">*</span></th>
									<td className="input">
										<textarea className="ui_textarea h_large" maxLength="1000" name="scheMsg" onChange={this.handleChange} value={this.state.scheMsg}></textarea>
									</td>
								</tr>
								<tr>
									<th scope="row">{this.props.messages.cntrl_attached}</th>
									<td className="input">
										<AttachFile onRef={ref => (this.attachFile = ref)}
										attachFileId={this.state.attachFileId}
										files={this.state.attachFile} 
										onChange={this.handleFileChange} 
										onUploadResult={this.handleScheduleSave}
										isFileSearch={true}/>
									</td>
								</tr>
								</tbody>
							</table>
							{/* E:Table */}
						</div>
						{/* E:content_inner */}
					</div>
					{/* E:content_body */}
				</div>
			

				

	
        );
    }
}

export default connect(mapStateToProps)(CntrlScheduleDetail);
