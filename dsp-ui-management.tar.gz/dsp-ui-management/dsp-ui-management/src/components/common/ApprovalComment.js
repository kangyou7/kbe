import React from 'react';

import AttachFile from './AttachFile';

import axios from 'axios';

import {REST_API_URL} from '../../config/api-config.js';

/*다국어 모듈 시작*/
import { connect } from 'react-redux';
import { changeLangauge, mapStateToProps } from '../../language/Actions';
/*다국어 모듈 종료*/

class ApprovalComment extends React.Component {
    constructor(props) {
        super(props);
    }

    //컴포넌트가 만들어지고 첫 렌더링을 다 마친 후 실행되는 메소드입니다.
	componentDidMount() {
		this.props.onRef(this)
	}

	//컴포넌트가 DOM 에서 사라진 후 실행되는 메소드입니다.
	componentWillUnmount() {
		this.props.onRef(null)
	}

    hide() {
        layer_close(".pop-view-opinion");
    }

    show() {
        layer_open(".pop-view-opinion");
    }

    render() {
        return (
            <div className="lpopup">
                <div className="dimmed"></div>
                <div className="popup_layer pop_view_opinion pop-view-opinion mid">{/* 가변 사이즈 지정*/}
                    <div className="pop_container">
                        <div className="pop_header">
                            <h1>{this.props.messages.contract_view_comments}</h1>
                        </div>
                        {/* pop_contents */}
                        <div className="pop_contents">
                            <div className="pop_inner">
                                <table className="tbl_row">
                                    <caption>의견보기 목록</caption>
                                    <colgroup>
                                        <col style={{width:'130px'}}/>
                                        <col style={{width:'auto'}}/>
                                    </colgroup>
                                    <tbody>
                                        <tr>
                                            <th scope="row">{this.props.messages.contract_writer}</th>
                                            <td>{this.props.approvalInfo.userName}</td>
                                        </tr>
                                        <tr>
                                            <th scope="row">{this.props.messages.contract_comment}</th>
                                            <td>{(this.props.approvalInfo.hdlOpinText + "").replace(/(\n|\r\n)/g, '<br/>')}</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        {/*// pop_contents*/}
                        <div className="pop_bottom">
                            <button type="button" className="pbtn_black" onClick={()=>this.hide()}>{this.props.messages.contract_ok}</button>
                        </div>
                        <a href="javascript:;" onClick={()=>this.hide()} className="btn_pop_close"><span className="offscreen">{this.props.messages.ticket_close}</span></a>
                    </div>{/*// pop_container */}
                </div>{/*// popup_layer */}
            </div>
        );
    }
}

class ManagerComment extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
        }

        this.handleFileChange = this.handleFileChange.bind(this);
        this.handleChange = this.handleChange.bind(this);
    }

    //컴포넌트가 만들어지고 첫 렌더링을 다 마친 후 실행되는 메소드입니다.
	componentDidMount() {
		this.props.onRef(this)
	}

	//컴포넌트가 DOM 에서 사라진 후 실행되는 메소드입니다.
	componentWillUnmount() {
		this.props.onRef(null)
	}

    hide() {
        layer_close(".pop-opinion-register");
    }

    show() {
        layer_open(".pop-opinion-register");
    }

    
    handleFileChange(files) {
		this.setState({
			files : files
		})
    }

    handleChange(e) {
        let nextState = {};
        nextState[e.target.name]=e.target.value;
        this.setState(nextState);
	}
    
    componentWillReceiveProps(nextProps){

        if(nextProps.approvalInfo != this.state) {
            this.state = nextProps.approvalInfo;
        }
    }

    save() {
        let formData = new FormData();

        formData.append("tcktNo", this.state.tcktNo);
        formData.append("aprvLineOrder", this.state.aprvLineOrder);
        formData.append("hdlOpinText", this.state.hdlOpinText);
        formData.append("aprvResultCode", 'A');
        formData.append("modUsrNo", 3);//로그인아이디로 변경

        //formData.append("attachFileId", this.state.attachFileId);
        if(this.state.files != null) {
            this.state.files.map(file => {
                if(file.state == "I"){ //|| file.state == "D") {
                    formData.append("file", file.file, encodeURI(file.fileName));
                }
            });
        }

        if(!confirm("티켓을 처리하시겠습니까?")) {
            return;
        }

		axios.post(REST_API_URL + "/ticket/commentSave", formData, {withCredentials : true}, {
			headers: { "X-Requested-With": "XMLHttpRequest" },
		})
		.then( response => { 
            this.props.onCommentResult();
            this.hide()
		})
		.catch( response => { console.log(response) } );
    }

    

    render() {
        
        return (
            <div className="lpopup">
                <div className="dimmed"></div>
                <div className="popup_layer pop_opinion_register pop-opinion-register mid">
                    <div className="pop_container">
                        <div className="pop_header">
                            <h1>{this.state.hdlDt == null ? this.props.messages.ticket_comment_2 : "처리 내용 보기"}</h1>
                        </div>
                        {/* pop_contents */}
                        <div className="pop_contents scroll_wrap">
                            {/* pop_inner */}
                            <div className="pop_inner">
                                <table className="tbl_row">
                                    <caption>처리 내용 등록 목록</caption>
                                    <colgroup>
                                        <col style={{width:'130px'}}/>
                                        <col style={{width:'auto'}}/>
                                    </colgroup>
                                    <tbody>
                                        <tr>
                                            <th scope="row">{this.props.messages.ticket_manager_3} <span className="tc_red">*</span></th>
                                            <td>{this.state.userName}</td>
                                        </tr>
                                        <tr>
                                            <th scope="row">{this.props.messages.ticket_transaction_date}</th>
                                            {/* Com : 오늘 날짜 표기 */}
                                            <td>{this.state.hdlDt == null ? "" : this.state.hdlDt}</td>
                                        </tr>
                                        <tr>
                                            <th scope="row">{this.props.messages.ticket_comment_1} <span className="tc_red">*</span></th>
                                            <td className="input">
                                                {this.state.hdlDt == null 
                                                ? (
                                                    <textarea className="ui_textarea" name="hdlOpinText" onChange={this.handleChange} maxLength={1000}></textarea>
                                                  )
                                                : this.state.hdlOpinText
                                                }
                                            </td>
                                        </tr>
                                        <tr>
                                            <th scope="row">{this.props.messages.ticket_attached}</th>
                                            <td className="input">
                                                <AttachFile onRef={ref => (this.attachFile = ref)} 
                                                            files={this.state.files} 
                                                            onChange={this.handleFileChange} 
                                                            onUploadResult={this.handleContractSave}
                                                            isFileSearch={this.state.hdlDt == null ? true : false}/>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                            {/* // pop_inner */}
                        </div>	
                        {/*// pop_contents*/}
                        
                        {this.state.hdlDt == null 
                            ? (
                                <div className="pop_bottom">
                                    <a href="javascript:;" className="pbtn_pos" onClick={()=>this.hide()}>{this.props.messages.ticket_cancel}</a>
                                    <a href="javascript:;" className="pbtn_black" onClick={()=>this.save()}>{this.props.messages.ticket_ok}</a>
                                </div>
                               )
                            : (
                                <div className="pop_bottom">
                                    <a href="javascript:;" className="pbtn_black" onClick={()=>this.hide()}>{this.props.messages.ticket_close}</a>
                                </div>
                        )}

                    </div>{/*// pop_container */}
                    <a href="javascript:;" onClick={()=>this.hide()} className="btn_pop_close"><span className="offscreen">{this.props.messages.ticket_close}</span></a>
                </div>{/*// popup_layer */}
            </div>   
        );
    }
}

module.exports = {
    ApprovalComment : connect(mapStateToProps)(ApprovalComment),
    ManagerComment : connect(mapStateToProps)(ManagerComment)
};