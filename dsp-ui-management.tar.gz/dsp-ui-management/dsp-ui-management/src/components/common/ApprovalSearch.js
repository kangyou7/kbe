import React from 'react';

import {REST_API_URL} from '../../config/api-config.js';

/*다국어 모듈 시작*/
import { connect } from 'react-redux';
import { changeLangauge, mapStateToProps } from '../../language/Actions';
/*다국어 모듈 종료*/

class ApprovalLineSearch extends React.Component {

    constructor(props) {
        super(props);

        this.state = {
            searchName:"",
            userSelectKey:-1,
            approvalSelectKey:-1,
            users : [],
            approvalLine : this.props.approvalLine
        }

        this.handleChange = this.handleChange.bind(this);
        this.handleSearch = this.handleSearch.bind(this);
        this.handleUserSelect = this.handleUserSelect.bind(this);

        this.handleApprovalSelect = this.handleApprovalSelect.bind(this);
        this.handleApprovalRemove = this.handleApprovalRemove.bind(this);
        this.handleApprovalorderChange = this.handleApprovalorderChange.bind(this);
    }

    //컴포넌트가 만들어지고 첫 렌더링을 다 마친 후 실행되는 메소드입니다.
    componentDidMount() {
        this.props.onRef(this)
    }

    //컴포넌트가 DOM 에서 사라진 후 실행되는 메소드입니다.
    componentWillUnmount() {
        this.props.onRef(null)
    }

    handleUserSelect(key) {
       $("#approvalLiseSearch li").removeClass();
       $("#approvalLiseSearch li").eq(key).addClass('selected');
    }

    handleApprovalSelect(key) {
        $("#approvalList li").removeClass();
        $("#approvalList li").eq(key).addClass('selected');
     }

    handleUserSelectApprovalAdd(code, event) {
        if(this.state.userSelectKey < 0) {
            alert("선택하세요");
            return;
        }

        if(code == 'A' && this.state.users[this.state.userSelectKey].aprvConfYn != 'Y') {
            alert("승인 권한이 없는 사용자입니다.");
            return;
        }

        let approvalLine = this.state.approvalLine;

        let approval = {
            aprvChargeUsrNo : this.state.users[this.state.userSelectKey].userNo,
            aprvStepCode : code,
            aprvStepCodeName : event.target.name,
            userName : this.state.users[this.state.userSelectKey].userName,
            userEmail : this.state.users[this.state.userSelectKey].userEmail,
            deptName : this.state.users[this.state.userSelectKey].deptName,
            positName : this.state.users[this.state.userSelectKey].positName
        } 

        //중복 체크
        let check = false;
        
        $.each(approvalLine, function(i, el){
            if(el.aprvChargeUsrNo === approval.aprvChargeUsrNo) {
                check = true;
            }
        });
        
        if(check) {
            alert("결제선에 등록되어있습니다.");
            return;
        }

        //승인자 마지막 체크
        if(approvalLine[approvalLine.length - 1].aprvStepCode == "A") {
            alert("승인자는 한명만 추가할 수 있으며, \n승인자 다음에 검토/협조 설정할 수 없습니다.");
            return;
        }

        //결재선 10개 이상 등록 제한
        if(approvalLine.length >= 10) {
            alert("결재선은 10개 이상 등록 할 수 없습니다.");
            return;
        }
        
        approvalLine.push(approval);
        
        this.setState({
            approvalLine : approvalLine
        });
    }

    handleApprovalRemove(e) {

        if(this.state.approvalSelectKey < 1) {
            return;
        }

        let approvalLine = this.state.approvalLine;

        approvalLine.splice(this.state.approvalSelectKey, 1);

        this.setState({
            approvalSelectKey : -1,
            approvalLine : approvalLine
        })

        this.handleApprovalSelect(-1)
    }

    handleApprovalorderChange(e) {
        

        let approvalLine = this.state.approvalLine;

        let approval = approvalLine[this.state.approvalSelectKey];

        if(approval.aprvStepCode == "A") {
            alert("승인자는 순서 변경할 수 없습니다.");
            return;
        }

        if(e.target.name === "up") {
            if(this.state.approvalSelectKey <= 1) {
                return;
            } 

            approvalLine.splice(this.state.approvalSelectKey, 1);

            approvalLine.splice(this.state.approvalSelectKey - 1, 0, approval);

            this.setState({
                approvalSelectKey : this.state.approvalSelectKey - 1,
                approvalLine : approvalLine
            });

            this.handleApprovalSelect(this.state.approvalSelectKey - 1);

        } else {
            if((this.state.approvalSelectKey >= approvalLine.length - 1) || (this.state.approvalSelectKey === 0)) {
                return;
            } 

            if(approvalLine[this.state.approvalSelectKey + 1].aprvStepCode == "A") {
                alert("승인자 다음으로 변경할 수 없습니다.");
                return;
            }

            approvalLine.splice(this.state.approvalSelectKey, 1);

            approvalLine.splice(this.state.approvalSelectKey + 1, 0, approval);

            this.setState({
                approvalSelectKey : this.state.approvalSelectKey + 1,
                approvalLine : approvalLine
            });

            this.handleApprovalSelect(this.state.approvalSelectKey + 1);
        }
       
    }

    handleChange(e) {
        let nextState = {};
        nextState[e.target.name]=e.target.value;
        this.setState(nextState);
    }

    handleSearch() {
        this.getUsers();
    }

    getUsers() {
        
        $.ajax({
            url: REST_API_URL + "/approval/getApprovalUsersSearch",
            dataType: 'json',
            type: "post",
            data: {
                searchName:this.state.searchName,
                authotPath:this.props.menuPath
            },
            cache: false,
            success: function(result) {
                this.setState({
                    userSelectKey:-1,
                    users: result.response.users
                });
            }.bind(this),
            error: function(xhr, status, err) {
                console.log(xhr + " : " + status + " : " + err);
            }.bind(this),
            xhrFields: {
              withCredentials: true
            }
        });
    
      }

    complete() {

        this.props.onComplete(this.state.approvalLine);
        this.hide();
    }

    hide() {
        layer_close(".pop-approval-line");
    }

    show() {
        let approvalLine = this.props.approvalLine;
        let approvalLineDraft = {
            aprvChargeUsrNo : this.props.memberInfo.user_no,
            aprvStepCode : 'D',
            userName : this.props.memberInfo.user_name,
            userEmail : '',
            deptName : this.props.memberInfo.dept_name,
            positName : this.props.memberInfo.posit_name
        };

        if(approvalLine.length  == 0){
            approvalLine.splice(0, 0, approvalLineDraft); // 현재 로그인자로 기안자 설정
        } else {
            approvalLine.splice(0, 1);  //기존 기안자 제거
            approvalLine.splice(0, 0, approvalLineDraft); // 현재 로그인자로 기안자 설정
        }

        this.setState({
            searchName:"",
            userSelectKey:-1,
            approvalSelectKey:-1,
            users : [],
            approvalLine : approvalLine
        })
        layer_open(".pop-approval-line");
    }

    

    render() {

        const mapToUser = (data) => {
            if(data.length > 0) {
                return data.map((item, i) => {//map
                    return(
                        <li key={i}><a href="javascript:void(0)" onClick={() => {this.setState ({userSelectKey : i}); this.handleUserSelect(i);}}>{item.userName} {item.positName} ({item.userEmail})</a></li>
                    );
                });
            } else {
                return (
                    <li className="noresults">
                        <div className="box_noresults">
                            <div className="ver_mid">													
                                <i className="ico ico_no_result"></i>
                                <span className="lb">{this.props.messages.contract_there_are_no_results}</span>
                            </div>
                        </div>
                    </li>
                );
            }
        }

        const mapToApprovalLine = (data) => {
            if(data.length > 0) {
                return data.map((item, i) => {//map

                    let aprvStepCodeName = '';
                    if(item.aprvStepCode === 'D') {
                        aprvStepCodeName = this.props.messages.contract_draft;
                    } else if(item.aprvStepCode === 'R') {
                        aprvStepCodeName = this.props.messages.contract_review;
                    } else if(item.aprvStepCode === 'C') {
                        aprvStepCodeName = this.props.messages.contract_cooperation;
                    } else if(item.aprvStepCode === 'A') {
                        aprvStepCodeName = this.props.messages.contract_approval;
                    }
                    
                    return(
                        <li className={item.aprvStepCode === "D" ? "tc_gray" : ""} key={i}><a href="javascript:;" onClick={() => {this.setState ({approvalSelectKey : i}); this.handleApprovalSelect(i);}}>
                            <span className="col1">{aprvStepCodeName}</span>
                            <span className="col2">{item.userName}</span>
                            <span className="col3">{item.deptName}</span>
                            <span className="col4">{item.positName}</span>
                        </a></li>
                    );
                });
            } else {
                return (
                    <li className="noresults">
                        <div className="box_noresults">
                            <div className="ver_mid">													
                                <i className="ico ico_no_result"></i>
                                <span className="lb">결재선을 지정하세요.</span>
                            </div>
                        </div>
                    </li>
                );
            }
        }

        return(
            <div className="lpopup">
                <div className="dimmed"></div>
                <div className="popup_layer pop_approval_line pop-approval-line lg">
                    <div className="pop_container">
                        <div className="pop_header">
                            <h1>{this.props.messages.contract_approval_line}</h1>
                        </div>
                        {/* pop_contents */}
                        <div className="pop_contents">
                            <div className="pop_inner">
                                <div className="confirm_wrap">
                                    <div className="search_group">
                                        <div className="psearch_form">
                                            <input type="text" className="ui_input" placeholder={this.props.messages.contract_name} name="searchName" value={this.state.searchName} onChange={this.handleChange} />
                                            <a href="javascript:void(0)" className="btn_pos" onClick={this.handleSearch}>{this.props.messages.contract_search_2}</a>
                                        </div>
                                        <ul className="result_list" id="approvalLiseSearch">
                                            {/* S:사용자 검색 */}
         
                                            {mapToUser(this.state.users)}
         
                                            {/* E:사용자 검색 */}
                                        </ul>
                                    </div>
                                    <div className="btn_group">
                                        <ul>
                                            <li><button type="button" name="검토" className="btn_black" onClick={this.handleUserSelectApprovalAdd.bind(this, 'R')}>{this.props.messages.contract_review}<i className="ico_btn_rright" name="검토"></i></button></li>
                                            <li><button type="button" name="협조" className="btn_black" onClick={this.handleUserSelectApprovalAdd.bind(this, 'C')}>{this.props.messages.contract_cooperation}<i className="ico_btn_rright" name="협조"></i></button></li>
                                            <li><button type="button" name="승인" className="btn_black" onClick={this.handleUserSelectApprovalAdd.bind(this, 'A')}>{this.props.messages.contract_approval}<i className="ico_btn_rright" name="승인"></i></button></li>
                                            <li><button type="button" className="btn_pos" onClick={this.handleApprovalRemove}>{this.props.messages.contract_delete}<i className="ico_btn_del"></i></button></li>
                                        </ul>
                                    </div>
                                    <div className="selected_group">
                                        <div className="row_title">
                                            <span className="col1">{this.props.messages.contract_method}</span>
                                            <span className="col2">{this.props.messages.contract_name}</span>
                                            <span className="col3">{this.props.messages.contract_manager_department}</span>
                                            <span className="col4">{this.props.messages.contract_position}</span>
                                        </div>
                                        <ul id="approvalList" className="row_body scroll_wrap">
                                            {/* S:결재라인 */}
                                            {mapToApprovalLine(this.state.approvalLine)}
                                            {/* E:결재라인 */}	
                                        </ul>
                                        <div className="control_box">
                                            <button type="button" className="prev" name="up" onClick={this.handleApprovalorderChange}><span className="offscreen">이전</span></button>
                                            <button type="button" className="next" name="down" onClick={this.handleApprovalorderChange}><span className="offscreen">다음</span></button>
                                        </div>
                                    </div>
                                </div>
                            </div>{/* pop_inner */}
                        </div>	
                        {/*// pop_contents*/}
                        <div className="pop_bottom">
                            <button type="button" className="pbtn_pos" onClick={() => {this.hide();}}>{this.props.messages.ticket_cancel}</button>
                            <button type="button" className="pbtn_black" onClick={() => {this.complete();}}>{this.props.messages.ticket_ok}</button>
                        </div>
                    </div>{/*// pop_container */}
                    <a href="javascript:;" onClick={() => {this.hide();}} className="btn_pop_close"><span className="offscreen">{this.props.messages.ticket_close}</span></a>
                </div>
                {/*// popup_layer */}
            </div>
        );
    }
}

class ApprovalSearch extends React.Component {

    constructor(props) {
        super(props);

        this.state = {
            searchName:"",
            userSelectKey : -1,
            users : []
        }

        this.handleChange = this.handleChange.bind(this);
        this.handleSearch = this.handleSearch.bind(this);
        this.handleUserSelect = this.handleUserSelect.bind(this);
    }

    //컴포넌트가 만들어지고 첫 렌더링을 다 마친 후 실행되는 메소드입니다.
    componentDidMount() {
        this.props.onRef(this)
    }

    //컴포넌트가 DOM 에서 사라진 후 실행되는 메소드입니다.
    componentWillUnmount() {
        //this.props.onRef(null)
    }
    handleChange(e) {
        let nextState = {};
        nextState[e.target.name]=e.target.value;
        this.setState(nextState);
    }

    handleSearch() {

        $.ajax({
            url: REST_API_URL + "/approval/getApprovalUsersSearch",
            dataType: 'json',
            type: "post",
            data: {
                searchName:this.state.searchName,
                authotPath:this.props.menuPath
            },
            cache: false,
            success: function(result) {
              this.setState({
                userSelectKey:-1,
                users: result.response.users
    
              });
            }.bind(this),
            error: function(xhr, status, err) {
              console.log(xhr + " : " + status + " : " + err);
            }.bind(this),
            xhrFields: {
              withCredentials: true
            }
            });
    }

    handleUserSelect(key) {
        $("#managerSearch li").removeClass();
        $("#managerSearch li").eq(key).addClass('selected');
    }

    
    complete() {
        if(this.state.userSelectKey < 0) {
            alert("승인 담당자를 선택하세요.");
            return;
        }

        if(this.state.users[this.state.userSelectKey].aprvConfYn != 'Y') {
            alert("승인 권한이 없는 사용자입니다.");
            return;
        }

        this.props.onComplete(this.state.users[this.state.userSelectKey]);
        this.hide();
    }

    hide() {
        layer_close(".pop-search-approver");
    }

    show() {
        this.setState({
            searchName:"",
            userSelectKey : -1,
            users : []
        })
        layer_open(".pop-search-approver");
    }

    

    render() {

        const mapToUser = (data) => {
            if(data.length > 0) {
                return data.map((item, i) => {//map
                    return(
                        <li key={i}><a href="javascript:void(0)" 
                                        onClick={() => {this.setState ({userSelectKey : i}); this.handleUserSelect(i);}}
                                        onDoubleClick={() => {this.setState ({userSelectKey : i}); this.complete();}}
                                    >
                                        {item.userName}{item.positName} ({item.userEmail})
                                    </a>
                        </li>
                    );
                });
            } else {
                return (
                    <li className="noresults">
                        <div className="box_noresults">
                            <div className="ver_mid">													
                                <i className="ico ico_no_result"></i>
                                <span className="lb">{this.props.messages.contract_there_are_no_results}</span>
                            </div>
                        </div>
                    </li>
                );
            }
        }

        

        return(
            <div className="lpopup">
                <div className="dimmed"></div>
                <div className="popup_layer pop_search_approver pop-search-approver sm">
                    <div className="pop_container">
                        <div className="pop_header">
                            <h1>승인 담당자 검색</h1>
                        </div>
                        {/* pop_contents */}
                        <div className="pop_contents">
                            <div className="pop_inner">
                                <div className="search_group">
                                    <div className="psearch_form">
                                        <input type="text" className="ui_input" placeholder={this.props.messages.contract_name} name="searchName" onChange={this.handleChange}/>
                                        <a href="javascript:;" className="btn_pos" onClick={this.handleSearch}>{this.props.messages.contract_search_2}</a>
                                    </div>
                                    <ul className="result_list" id="managerSearch">
                                        {/* S:리스트 있는 경우 */}
                                        {mapToUser(this.state.users)}
                                        {/* E:리스트 있는 경우 */}
                                        
                                    </ul>
                                </div>
                            </div>
                            {/* pop_inner */}
                        </div>	
                        {/*// pop_contents*/}
                        <div className="pop_bottom">
                            <a href="javascript:;" className="pbtn_pos" onClick={() => {this.hide()}}>{this.props.messages.contract_cancel}</a>
                            <a href="javascript:;" className="pbtn_black" onClick={() => {this.complete();}}>{this.props.messages.contract_ok}</a>
                        </div>
                    </div>{/*// pop_container */}
                    <a href="javascript:;" onClick={() => {this.hide()}} className="btn_pop_close"><span className="offscreen">{this.props.messages.ticket_close}</span></a>
                </div>{/*// popup_layer */}
            </div>
        );
    }
}
/*
module.exports = {
    ApprovalLineSearch,
    ApprovalSearch
};
export default connect(mapStateToProps)(ApprovalLineSearch);
 module.exports = connect(mapStateToProps)({
     ApprovalLineSearch,
     ApprovalSearch
 });
*/
module.exports = {
    ApprovalLineSearch : connect(mapStateToProps)(ApprovalLineSearch),
    ApprovalSearch : connect(mapStateToProps)(ApprovalSearch)
};

