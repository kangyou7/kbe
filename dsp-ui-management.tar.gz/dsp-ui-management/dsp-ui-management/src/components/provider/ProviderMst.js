/*jshint esversion: 6 */
import React from 'react';
import { Link } from 'react-router';
import { browserHistory } from 'react-router';

import ProviderList from './ProviderList';
import ProviderDetail from './ProviderDetail';
import ProviderCreate from './ProviderCreate';

import {REST_API_URL} from '../../config/api-config.js';

/*다국어 모듈 시작*/
import { connect } from 'react-redux';
import { changeLangauge, mapStateToProps, changeToken, actionlogin } from '../../language/Actions';
/*다국어 모듈 종료*/

class ProviderMst extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      displadyState : "L",
      custmNo : "",
      listThead : [
        {name:props.messages.provider_no,                   sort:false, sortColumn:"", view:true, target:false, width:'4%'},
        {name:props.messages.provider_custm_no,             sort:true, sortColumn:"custm_no", view:true, target:true, width:'12%'},
        {name:props.messages.provider_custm_name,           sort:true, sortColumn:"co_name", view:true, target:true, width:'12%'},
        {name:props.messages.provider_bizno,                sort:false, sortColumn:"bizno", view:true, target:true, width:'12%'},
        {name:props.messages.provider_charge_usr_name,      sort:false, sortColumn:"charge_usr_name", view:true, target:true, width:'12%'},
        {name:props.messages.provider_charge_usr_mobile_no, sort:false, sortColumn:"charge_usr_mobile_no", view:true, target:true, width:'12%'},
        {name:props.messages.provider_charge_usr_email,     sort:false, sortColumn:"charge_usr_email", view:true, target:true, width:'12%'},
        {name:props.messages.provider_reg_user_name,        sort:true, sortColumn:"reg_user_name", view:true, target:true, width:'12%'},
        {name:props.messages.provider_reg_user_date,        sort:true, sortColumn:"reg_date", view:true, target:true, width:'12%'},
      ],
      searchSelectOption : [
        {value:'', text: props.messages.provider_search_select},
        {value:'1', text : props.messages.provider_search_type1},
        {value:'2', text : props.messages.provider_search_type2},
      ],
      pageInfo:{
      },
    };

    this.handleDisplaySetting = this.handleDisplaySetting.bind(this);
    this.handlePageInfoChange = this.handlePageInfoChange.bind(this);
    this.handleDetailView = this.handleDetailView.bind(this);

    this.handleExcelDownload = this.handleExcelDownload.bind(this);
  }

  //컴포넌트가 prop 을 새로 받았을 때 실행됩니다.
  componentWillReceiveProps(nextProps) {
    if(this.props.locale !== nextProps.locale) {
      let listThead = this.state.listThead;

      listThead[0].name = nextProps.messages.provider_no;
      listThead[1].name = nextProps.messages.provider_custm_no;
      listThead[2].name = nextProps.messages.provider_custm_name;
      listThead[3].name = nextProps.messages.provider_bizno;
      listThead[4].name = nextProps.messages.provider_charge_usr_name;
      listThead[5].name = nextProps.messages.provider_charge_usr_mobile_no;
      listThead[6].name = nextProps.messages.provider_charge_usr_email;
      listThead[7].name = nextProps.messages.provider_reg_user_name;
      listThead[8].name = nextProps.messages.provider_reg_user_date;

      let searchSelectOption = this.state.searchSelectOption;
      
      searchSelectOption[0].text = nextProps.messages.provider_search_select;
      searchSelectOption[1].text = nextProps.messages.provider_search_type1;
      searchSelectOption[2].text = nextProps.messages.provider_search_type2;
    }

    this.handleDisplaySetting('L');
  }

  handleDisplaySetting(state) {
    this.setState({displadyState : state});
  }

  handlePageInfoChange(pageInfo, reload) {

    console.log("전달 받은 페이지 정보 "+JSON.stringify(pageInfo));

    this.setState({
        pageInfo : pageInfo
    });

    if(reload) {
        this.providerList.getList();
    }
  }

  handleDetailView(custmNo) {
    this.state.custmNo = custmNo;
    this.handleDisplaySetting('D');
  }

  handleExcelDownload() {
    this.providerList.getExcelDownload();
  }

  handleTabsChange(tab) {

    if(tab === 'Detail') {
      if(this.state.custmNo === "") {
        alert("리스트의 Provider를 선택하세요.");
      } else {
        $("#tab-cont1").hide();
        //$(".fr").hide();
        $("#tab-cont2").show();

        $("#groupList").hide();
        $("#groupCreate").show();

        $(".tabs li").eq(0).removeClass('on');
        $(".tabs li").eq(1).addClass('on');
      }
    } else {
      if (confirm("이 페이지에서 나가시겠습니까?\n작성중인 내용이 저장되지 않습니다.")) {
        this.setState({displadyState:'L'});
      }
    }
  }

  componentDidMount() {
    $("#tab-cont1").show();
    $(".fr").show();
    $("#tab-cont2").hide();
  }
  

  render() {
    const fncBtnInfo = this.props.memberInfo.dspUserFncBtnInfo;
        return (
          <section className="body">
            <div className="wrapper">
              <div className="page_header">
                <h2 className="ptitle">{this.state.displadyState == 'C' ? this.props.messages.provider_registration : this.props.messages.provider_status}</h2>
                <div className="page_nav">
                  {/*<ul>
                    <li><Link to="/">Home</Link></li>
                    <li><a href="javascript:;" onClick={() => this.setState({displadyState:'L'})}>{this.props.messages.provider_management}</a></li>
                    <li className="here">{this.state.displadyState == 'C' ? this.props.messages.provider_registration : this.props.messages.provider_status}</li>
                  </ul>*/}
                </div>
              </div>
              <div className="content_wrap">

                <div className="content_outbox">

                  <div className="tab_wrap tab-wrap">

                    <div className="box_both tab_header">
                      <div className="fl">
                        <ul className="tabs">
                          <li  className={this.state.displadyState == 'L' ? "tab_item tab-item on" : "tab_item tab-item"}>
                            <a href="javascript:;" onClick={() => {this.handleTabsChange('List')}} className="tab-link"><span>{this.props.messages.common_list}</span></a>
                          </li>
                          <li className={this.state.displadyState != 'L' ? "tab_item tab-item on" : "tab_item tab-item"}>
                            <a href="javascript:;" className={this.state.displadyState == 'L' ? "tab-link disabled" : "tab-link"}><span>{this.props.messages.common_detail}</span></a>
                          </li>
                        </ul>
                      </div>
                      <div className="fr">
                        <div className="btn_group" style={this.state.displadyState === 'L' ? {} : {display:'none'}}>
                          <button disabled={fncBtnInfo['funcXlxDwldYn']=='N'} type="button" className="ibtn_pos" onClick={this.handleExcelDownload}><i className="ico_btn_xls"></i>{this.props.messages.common_excel_download}</button>
                        </div>
                        <div className="btn_group" style={this.state.displadyState === 'C' ? {} : {display:'none'}}>
                          <button type="button" className="btn_pos" onClick={() => {this.providerCreate.handleInitState()}}>{this.props.messages.common_reset}</button>
                          <button disabled={fncBtnInfo['funcModYn']=='N'} type="button" className="btn_black" onClick={() => { this.providerCreate.handleSave('')} }>{this.props.messages.provider_ok}</button>
                        </div>
                        <div className="btn_group" style={this.state.displadyState === 'R' ? {} : {display:'none'}}>
                        <button type="button" className="btn_black" onClick={() => this.setState({displadyState:'L'})}>{this.props.messages.common_cancel}</button>
                          <button disabled={fncBtnInfo['funcModYn']=='N'} type="button" className="btn_black" onClick={() => {this.providerDetail.handleSave('R')}}>{this.props.messages.provider_ok}</button>
                        </div>
                      </div>
                    </div>
                    {this.state.displadyState == 'L' 
                                    ? <ProviderList onRef={ref => (this.providerList = ref)} onDisplaySetting={this.handleDisplaySetting} 
                                                    onDetailView={this.handleDetailView}
                                                    pageInfo={this.state.pageInfo}
                                                    onPageInfoChange={this.handlePageInfoChange}
                                                    listThead = {this.state.listThead}
                                                    searchSelectOption = {this.state.searchSelectOption}
                                                    /> 
                                    : this.state.displadyState == 'C' 
                                        ? <ProviderCreate onRef={ref => (this.providerCreate = ref)} onDisplaySetting={this.handleDisplaySetting}/>
                                        : <ProviderDetail onRef={ref => (this.providerDetail = ref)} onDisplaySetting={this.handleDisplaySetting} custmNo={this.state.custmNo}/>
                    }

                  </div>

                </div>

              </div>

            </div>
          </section>
        );
    }
}

export default connect(mapStateToProps)(ProviderMst);
