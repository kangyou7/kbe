import React from 'react';

import {REST_API_URL} from '../../config/api-config.js';

import CustomSelect from '../common/CustomSelect';

/*다국어 모듈 시작*/
import { connect } from 'react-redux';
import { changeLangauge, mapStateToProps } from '../../language/Actions';
/*다국어 모듈 종료*/



class Search extends React.Component {

    constructor(props) {
        super(props);

        this.state = {
            adjustYmStr : "",
            adjustYmEnd : "",
            splyUsrNo : "",
            demndUsrNo : "",
            rcvStatusCode : "",
            setleWayClasCode : "",
            searchKeyCode : "",
            searchKeyWord: "",
            adjustStrY : "",
            adjustStrM : "",
            adjustEndY : "",
            adjustEndM : ""
        }

        this.handleChange = this.handleChange.bind(this);
        this.handleSearch = this.handleSearch.bind(this);
    }

    handleChange(e) {
        let nextState = {};
        nextState[e.target.name]=e.target.value;
        this.setState(nextState);
    }

    handleSearch() {
        if(this.state.searchKeyCode === "" && this.state.searchKeyWord !== "") {
            alert("검색 항목을 선택하세요.");
        } else {
            
                this.state.adjustYmStr = this.state.adjustStrY + "-" + this.state.adjustStrM;
                this.state.adjustYmEnd = this.state.adjustEndY + "-" + this.state.adjustEndM;
           
            this.props.onSearch(this.state);
        }
    }

    componentDidMount() {
        if(this.props.searchInfo.adjustYmStr == undefined || this.props.searchInfo.adjustYmStr == '') {
            this.adjustYm(2, true);
        } else {
            this.state = this.props.searchInfo;
            
            this.state.adjustStrY = this.props.searchInfo.adjustYmStr.substring(0, 4);
            this.state.adjustStrM = this.props.searchInfo.adjustYmStr.substring(5);
            this.state.adjustEndY = this.props.searchInfo.adjustYmEnd.substring(0, 4);
            this.state.adjustEndM = this.props.searchInfo.adjustYmEnd.substring(5);

            this.forceUpdate();
        }
        
        let self = this;
        //$("#searchKeyCode").on("change", function(obj){
        $("select").on("change", function(obj){
            self.handleChange(obj);
        })
	}

    componentWillReceiveProps(nextProps) {

        if(nextProps.searchInfo != undefined) {
            
            if(nextProps.searchInfo.adjustYmStr != null && nextProps.searchInfo.adjustYmStr != undefined) {
                this.setState({
                    adjustYmStr : nextProps.searchInfo.adjustYmStr,
                    adjustStrY : nextProps.searchInfo.adjustYmStr.substring(0, 4),
                    adjustStrM : nextProps.searchInfo.adjustYmStr.substring(5)
                    
                });
            }
            if(nextProps.searchInfo.adjustYmEnd != null && nextProps.searchInfo.adjustYmEnd != undefined) {
                this.setState({
                    adjustYmEnd : nextProps.searchInfo.adjustYmEnd,
                    adjustEndY : nextProps.searchInfo.adjustYmEnd.substring(0, 4),
                    adjustEndM : nextProps.searchInfo.adjustYmEnd.substring(5)
                });
            }
            if(nextProps.searchInfo.splyUsrNo != null) {
                this.setState({
                    splyUsrNo : nextProps.searchInfo.splyUsrNo
                });
            }
            if(nextProps.searchInfo.demndUsrNo != null) {
                this.setState({
                    demndUsrNo : nextProps.searchInfo.demndUsrNo
                });
            }
            
            if(nextProps.searchItem == undefined) {
                if(nextProps.searchInfo.rcvStatusCode != null) {
                    this.setState({
                        rcvStatusCode : nextProps.searchInfo.rcvStatusCode
                    });
                }
            } else {
                if(nextProps.searchInfo.setleWayClasCode != null) {
                    this.setState({
                        setleWayClasCode : nextProps.searchInfo.setleWayClasCode
                    });
                }
            }
            if(nextProps.searchInfo.searchKeyCode != null) {
                this.setState({
                    searchKeyCode : nextProps.searchInfo.searchKeyCode
                });
            }
            if(nextProps.searchInfo.searchKeyWord != null) {
                this.setState({
                    searchKeyWord : nextProps.searchInfo.searchKeyWord
                });
            }

            if(nextProps.searchInfo.adjustYmStr == null || nextProps.searchInfo.adjustYmStr == undefined || nextProps.searchInfo.adjustYmStr == '') {
                this.adjustYm(2, true);
            }

        } 
    }

    adjustYm(months, autoGetList) {

        let key = 0;
        switch(months) {
            case 0 : key = 0; break;
            case 2 : key = 1; break;
            case 5 : key = 2; break;
            case 11 : key = 3; break;
        }

        $("#adjustYmUL li").removeClass();
        $("#adjustYmUL li").eq(key).addClass('active');

        $.ajax({
            url: REST_API_URL + "/sales/SearchAdjustYm",
            dataType: 'json',
            type: "post",
            data: { months : months },
            cache: false,
            success: function(result) {
                let adjust_ym_str = result.response.adjustYm.adjust_ym_str;
                let adjust_ym_end = result.response.adjustYm.adjust_ym_end;
                this.setState({
                    adjustYmStr : adjust_ym_str,
                    adjustYmEnd : adjust_ym_end,
                    adjustStrY : adjust_ym_str.substring(0, 4),
                    adjustStrM : adjust_ym_str.substring(5),
                    adjustEndY : adjust_ym_end.substring(0, 4),
                    adjustEndM : adjust_ym_end.substring(5)
                });

                $("#adjustStrY").prop('selectValue', this.state.adjustStrY).selectric('refresh');
                $("#adjustStrM").prop('selectValue', this.state.adjustStrM).selectric('refresh');
                $("#adjustEndY").prop('selectValue', this.state.adjustEndY).selectric('refresh');
                $("#adjustEndM").prop('selectValue', this.state.adjustEndM).selectric('refresh');

                if(autoGetList) {
                    this.handleSearch();
                }
            }.bind(this),
            error: function(xhr, status, err) {
                console.log(xhr + " : " + status + " : " + err);
            }.bind(this),
			xhrFields: {
			  withCredentials: true
			}
        });
    }

    render() {

        const mapToOption = (data, thead) => {
            if(data.length > 0) {
                return data.map((item, i) => {//map
                    return(
                        <option key={i} value={item.value}>{item.text}</option>
                    );
                });
            }
        };

        const mapToSearchDateOption = (data) => {
            if(data.length > 0) {
                return data.map((item, i) => {//map
                    return(
                        <option key={i} value={item}>{item}</option>
                    );
                });
            }
        };
        
        let startYear = 2017;
        const searchYear = [];
        while(startYear <= new Date().getFullYear()) {
            searchYear.push(startYear++);
        }
        const searchMonth = ["01","02","03","04","05","06","07","08","09","10","11","12"];

        return(
            <div className="term_gray_box">
                <div className="box_com row_opt">
                    <div className="opt_group">
                        <label htmlFor="val_month" className="title">{this.props.messages.sales_term}</label>
                        {/*<input type="text" className="ui_input" name="adjustYmStr" value={this.state.adjustYmStr}/> */}
                        <select className="ui-sel sel_white w_mid" id="adjustStrY" name="adjustStrY" value={this.state.adjustStrY}>
                            {mapToSearchDateOption(searchYear)}
                        </select>
                        <select className="ui-sel sel_white w_sm" id="adjustStrM" name="adjustStrM" value={this.state.adjustStrM}>
                            {mapToSearchDateOption(searchMonth)}
                        </select>
                        <span className="tt"> ~ </span>
                        {/*<input type="text" className="ui_input" name="adjustYmEnd" value={this.state.adjustYmEnd}/>*/}
                        <select className="ui-sel sel_white w_mid" id="adjustEndY" name="adjustEndY" value={this.state.adjustEndY}>
                            {mapToSearchDateOption(searchYear)}
                        </select>
                        <select className="ui-sel sel_white w_sm" id="adjustEndM" name="adjustEndM" value={this.state.adjustEndM}>
                            {mapToSearchDateOption(searchMonth)}
                        </select>

                        <ul className="sort_wrap" id="adjustYmUL">
                            <li><a href="javascript:;" onClick={() => this.adjustYm(0, false)}>{this.props.messages.sales_this_month}</a></li>
                            <li><a href="javascript:;" onClick={() => this.adjustYm(2, false)}>{this.props.messages.sales_3_months}</a></li>
                            <li><a href="javascript:;" onClick={() => this.adjustYm(5, false)}>{this.props.messages.sales_6_months}</a></li>
                            <li><a href="javascript:;" onClick={() => this.adjustYm(11, false)}>{this.props.messages.sales_12_months}</a></li>
                        </ul>
                    </div>
                    
                    <div className="opt_group">
                        <label htmlFor="val_provider" className="title">{this.props.messages.sales_provider}</label>
                        <CustomSelect className="ui-sel sel_white" 
                                                            name="splyUsrNo" 
                                                            value={this.state.splyUsrNo} 
                                                            onChange={this.handleChange} 
                                                            custmClasCode="01"/>
                    </div>
                    <div className="opt_group">
                        <label htmlFor="val_patner" className="title">{this.props.messages.sales_customer}</label>
                        <CustomSelect className="ui-sel sel_white" 
                                        name="demndUsrNo" 
                                        value={this.state.demndUsrNo} 
                                        onChange={this.handleChange} 
                                        custmClasCode="02"
                                        prvdrNo={this.state.splyUsrNo}/>
                    </div>
                </div>

                <div className="box_com row_opt">
                    <div className="fl">
                    {
                    this.props.searchItem == undefined 
                    ?
                        <div className="opt_group">
                            <label htmlFor="val_patner" className="title">{this.props.messages.sales_purchasing_status}</label>
                            <ul className="ip_list">
                                <li>
                                    <span className="input_ico_box">
                                        <input type="radio" name="rcvStatusCode" id="rcvStatusCode_1" value="" checked={this.state.rcvStatusCode === ''} onChange={this.handleChange}/>
                                        <label htmlFor="rcvStatusCode_1">{this.props.messages.sales_total}</label>
                                    </span>
                                </li>
                                <li>
                                    <span className="input_ico_box">
                                        <input type="radio" name="rcvStatusCode" id="rcvStatusCode_2" value="01" checked={this.state.rcvStatusCode === '01'} onChange={this.handleChange}/>
                                        <label htmlFor="rcvStatusCode_2">{this.props.messages.sales_waiting}</label>
                                    </span>
                                </li>
                                <li>
                                    <span className="input_ico_box">
                                        <input type="radio" name="rcvStatusCode" id="rcvStatusCode_3" value="02" checked={this.state.rcvStatusCode === '02'} onChange={this.handleChange}/>
                                        <label htmlFor="rcvStatusCode_3">{this.props.messages.sales_unpaid}</label>
                                    </span>
                                </li>
                                <li>
                                    <span className="input_ico_box">
                                        <input type="radio" name="rcvStatusCode" id="rcvStatusCode_4" value="03" checked={this.state.rcvStatusCode === '03'} onChange={this.handleChange}/>
                                        <label htmlFor="rcvStatusCode_4">{this.props.messages.sales_purchasing}</label>
                                    </span>
                                </li>
                                <li>
                                    <span className="input_ico_box">
                                        <input type="radio" name="rcvStatusCode" id="rcvStatusCode_5" value="04" checked={this.state.rcvStatusCode === '04'} onChange={this.handleChange}/>
                                        <label htmlFor="rcvStatusCode_5">{this.props.messages.sales_delayed}</label>
                                    </span>
                                </li>
                                <li>
                                    <span className="input_ico_box">
                                        <input type="radio" name="rcvStatusCode" id="rcvStatusCode_6" value="05" checked={this.state.rcvStatusCode === '05'} onChange={this.handleChange}/>
                                        <label htmlFor="rcvStatusCode_6">{this.props.messages.sales_cancel}</label>
                                    </span>
                                </li>
                            </ul>
                        </div>
                    :
                        <div className="opt_group">
                            <label htmlFor="val_patner" className="title">{this.props.messages.sales_payment_method}</label>
                            <ul className="ip_list">
                                <li>
                                    <span className="input_ico_box">
                                        <input type="radio" name="setleWayClasCode" id="setleWayClasCode_1" value="" checked={this.state.setleWayClasCode === ''} onChange={this.handleChange}/>
                                        <label htmlFor="setleWayClasCode_1">{this.props.messages.sales_total}</label>
                                    </span>
                                </li>
                                <li>
                                    <span className="input_ico_box">
                                        <input type="radio" name="setleWayClasCode" id="setleWayClasCode_2" value="CN" checked={this.state.setleWayClasCode === 'CN'} onChange={this.handleChange}/>
                                        <label htmlFor="setleWayClasCode_2">{this.props.messages.sales_credit_card}</label>
                                    </span>
                                </li>
                                <li>
                                    <span className="input_ico_box">
                                        <input type="radio" name="setleWayClasCode" id="setleWayClasCode_3" value="RA" checked={this.state.setleWayClasCode === 'RA'} onChange={this.handleChange}/>
                                        <label htmlFor="setleWayClasCode_3">{this.props.messages.sales_bank_transfer}</label>
                                    </span>
                                </li>
                            </ul>
                        </div>
                    }

                        <span className="gap"></span>
                        <div className="opt_group">
                            <label htmlFor="val_search" className="title">{this.props.messages.contract_search_2}</label>
                            {/*<select className="ui-sel sel_white" name="searchKeyCode" value={this.state.searchKeyCode} onChange={this.handleChange} >*/}
                            <select className="ui-sel sel_white w_wide" id="searchKeyCode" name="searchKeyCode" value={this.state.searchKeyCode}  >
                                {mapToOption(this.props.searchSelectOption)}
                            </select>
                            <span className="input_search_box">
                                <input type="text" className="ui_input" name="searchKeyWord" value={this.state.searchKeyWord} onChange={this.handleChange}/>
                                <a id="searchContract" className="btn_search" href="javascript:void(0);"
                                onClick={this.handleSearch}><span className="offscreen">{this.props.messages.contract_search_2}</span></a>
                            </span>
                        </div>
                    </div>
                    <div className="fr">
                        <a href="javascript:;" className="btn_pos">{this.props.messages.contract_reset}</a>
                        <a href="javascript:;" className="btn_black" onClick={this.handleSearch}>{this.props.messages.contract_search_2}</a>
                    </div>
                </div>
            </div>
        );
    }
}

export default connect(mapStateToProps)(Search);
