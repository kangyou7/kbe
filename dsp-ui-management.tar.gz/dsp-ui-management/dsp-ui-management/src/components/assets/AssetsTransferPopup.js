import React from 'react';
import Calendar from '../common/Calendar';

import {REST_API_URL} from '../../config/api-config.js';

/*다국어 모듈 시작*/
import { connect } from 'react-redux';
import { changeLangauge, mapStateToProps } from '../../language/Actions';
/*다국어 모듈 종료*/

class AssetsTransferPopup extends React.Component {

    constructor(props) {
        super(props);

        this.state = {
            assetsDesc : "",
            equipTransferDate : "",
            equipChgContent : "",
            equipTransferDstinctCode : "position"
        }
        
        this.handleChange = this.handleChange.bind(this);
    }

    handleChange(e) {
		let nextState = {};
		nextState[e.target.name]=e.target.value;
		this.setState(nextState);
    }
    
    handleInitState() {
		
		this.setState({
            assetsDesc : "",
			equipTransferDate : "",
            equipChgContent : "",
            equipTransferDstinctCode : "position"
        });
        this.forceUpdate();
	}
    
    getAssetsDetail() {
        $.ajax({
            url: REST_API_URL+"/assets/Detail",
            dataType: 'json',
            type: "post",
            data: {
                assetsNo:this.props.assetsNo
            },
            xhrFields : {
                withCredentials : true
            },
            success: function(result) {
                this.setState(result.response);
            }.bind(this),
                error: function(xhr, status, err) {
                console.log(xhr + " : " + status + " : " + err);
            }.bind(this)
        });
    }

    complete() {
        let param = new Object();

        param.assetsNo = this.props.assetsNo;
        param.equipTransferDate = this.state.equipTransferDate;
        param.equipChgContent = this.state.equipChgContent;
        param.equipTransferDstinctCode = this.state.equipTransferDstinctCode;
        param.assetsDesc = this.state.assetsDesc;

        let memberInfo = JSON.parse(localStorage.getItem("memberInfo"));
        param.loginUserNo = memberInfo.user_no;
       
        $.ajax({
            url: REST_API_URL+"/assets/createAssetsTransfer",
            dataType: 'json',
            type: "post",
            xhrFields : {
                withCredentials : true
            },
            data: {paramJson : JSON.stringify(param)},
            success: function(result) {
               if (result.response == "SUCCESS") {
                    alert("신청되었습니다.");
                    this.hide();
                    return;
               } else {
                   alert("신청 중 오류발생.. 관리자에게 문의바랍니다.");
                   return;
               }
            }.bind(this),
                error: function(xhr, status, err) {
                console.log(xhr + " : " + status + " : " + err);
            }.bind(this)
        });
    }

    hide() {
        layer_close(".pop_device_transfer");
    }

    show() {
        
        layer_open(".pop_device_transfer");
        this.handleInitState();
        this.getAssetsDetail();

        $.ajax({
			url: REST_API_URL + "/code/getCurrentTimestamp",
			dataType: 'json',
			type: "post",
			cache: false,
			success: function(result) {
				this.setState({
					equipTransferDate: result.response.currentTimestamp.nowYear + "-" + result.response.currentTimestamp.nowMonth + "-" + result.response.currentTimestamp.nowDay
				})
			}.bind(this),
				error: function(xhr, status, err) {
				console.log(xhr + " : " + status + " : " + err);
			}.bind(this),
            xhrFields: {
              withCredentials: true
            }
		});
    }

    componentDidMount() {
        this.props.onRef(this)
		this.handleInitState();
    }
    
    //컴포넌트가 DOM 에서 사라진 후 실행되는 메소드입니다.
	componentWillUnmount() {
		this.props.onRef(null)
    }
    
    
    
    render() {
        return(
            <div className="lpopup">
                <div className="dimmed"/>
                <div className="popup_layer pop_device_transfer pop-device-transfer mid">
                    <div className="pop_container">
                        <div className="pop_header">
                            <h1>{this.props.messages.assets_transfer_equipments}</h1>
                        </div>

                        <div className="pop_contents">
                            <div className="pop_inner">
                                <table className="tbl_row">
                                    <caption>장비 이관 목록</caption>
                                    <colgroup>
                                        <col style={{width: '130px'}}/>    
                                        <col style={{width: 'auto'}}/>    
                                    </colgroup>
                                    <tbody>
                                        <tr>
                                            <th scope="row">{this.props.messages.assets_possesion}</th>
                                            <td>{this.state.assetsOwnerSeNm}</td>
                                        </tr>
                                        <tr>
                                            <th scope="row">{this.props.messages.assets_model_name}</th>
                                            <td>{this.state.equipModelName}</td>
                                        </tr>
                                        <tr>
                                            <th scope="row">{this.props.messages.assets_serial_no}</th>
                                            <td>{this.state.assetsNatvNoValue}</td>
                                        </tr>
                                        <tr>
                                            <th scope="row">{this.props.messages.assets_transfer_equipments_division} <span className="tc_red">*</span></th>
                                            <td className="input">
                                                <ul className="ip_list">
                                                    <li>
                                                        <span className="input_ico_box">
                                                            <input type="radio" name="equipTransferDstinctCode" id="transfer-rdo-2-1" value="position" defaultChecked="true" onChange={this.handleChange}/>
                                                            <label htmlFor="transfer-rdo-2-1">{this.props.messages.assets_transfer_position}</label>
                                                        </span>
                                                    </li>
                                                    <li>
                                                        <span className="input_ico_box">
                                                            <input type="radio" name="equipTransferDstinctCode" id="transfer-rdo-2-2" value="ownership" onChange={this.handleChange}/>
                                                            <label htmlFor="transfer-rdo-2-2">{this.props.messages.assets_transfer_proprietary}</label>
                                                        </span>
                                                    </li>
                                                </ul>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th scope="row">{this.props.messages.assets_transfer_comment} <span className="tc_red">*</span></th>
                                            <td className="input"><input type="text" maxLength="1000" className="ui_input" name="equipChgContent" onChange={this.handleChange} value={this.state.equipChgContent}/></td>
                                        </tr>
                                        <tr>
                                            <th scope="row">{this.props.messages.assets_transferring_date}</th>
                                            <td className="input">
                                                <div className="date_box">
                                                    {/* <input type="text" data-role="datepicker" className="ui_cal" /> */}
                                                    <Calendar className="ui_cal" 
                                                    dateFormat="YYYY-MM-DD"
                                                    name="equipTransferDate"
                                                    selected={this.state.equipTransferDate}
                                                    onChange={(data) => this.setState({equipTransferDate: data})}
                                                    init={false}/>
                                                </div>
                                            </td>
                                        </tr>
                                        {/* <tr>
                                            <th scope="row">{this.props.messages.assets_requester} <span className="tc_red">*</span></th>
                                            <td>{this.props.memberInfo.user_name}</td>
                                        </tr>
                                        <tr>
                                            <th scope="row">{this.props.messages.assets_request_date} <span className="tc_red">*</span></th>
                                            <td className="input">
                                                <div className="date_box">
                                                    <Calendar className="ui_cal" 
                                                    dateFormat="YYYY-MM-DD"
                                                    onChange={(data) => this.setState({equipTransferReqDate: data})}/>
                                                </div>
                                            </td>
                                        </tr> */}
                                        <tr>
                                            <th scope="row">{this.props.messages.assets_desc}</th>
                                            
                                            <td className="input">
                                                <textarea className="ui_textarea" maxLength="4000" name="assetsDesc" value={this.state.assetsDesc} onChange={this.handleChange}></textarea>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div className="pop_bottom">
                            <button type="button" className="pbtn_pos" onClick={() => {this.hide();}}>{this.props.messages.assets_cancel}</button>
                            <button type="button" className="pbtn_black" onClick={() => {this.complete();}}>{this.props.messages.assets_ok}</button>
                        </div>
                        <a href="javascript:;" onClick={() => {this.hide();}} className="btn_pop_close"><span className="offscreen">{this.props.messages.assets_close}</span></a>
                    </div>
                </div>
            </div>
        );
    }
}

export default connect(mapStateToProps)(AssetsTransferPopup);