import React, { Component } from 'react';
import { Link, browserHistory } from 'react-router';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { Map, List } from 'immutable';


// import * as service from './ServiceApi';
class UserClasRadio extends Component {
  constructor(props) {
    super(props);

    this.state = {
        selected : '03',
        user_dstnct_code : ''
    };
    this.handleChange = this.handleChange.bind(this);
  }

  handleChange(e){

    const {value} = e.target;
    const {data} = this.state;

    this.setState({
      data: data.set('selected', value)
    });

    console.log("state 설정 완료");

  }

  update() {
    if(this.state.selectKey < 0) {
        alert("선택하세요");
        return;
    }
    let provider = this.state.providers[this.state.selectKey];
    this.props.onProviderComplete(provider);
    this.hide();
  }

  componentDidMount(){
    let {data} = this.state;
    let memberInfo = JSON.parse(localStorage.getItem('memberInfo'));

    this.setState({
      data : data.set('user_dstnct_code', memberInfo.user_dstnct_code).set('selected','03')
    });
    
  }

  // changeHandler(e){
  //   this.setState({ selected: e.target.value });
  // }

  /* component LifeCycle API */
  // componentWillMount(){
  //   console.log("컴포넌트가 DOM 위에 만들어지기 전에 실행 componentWillMount");
  // }

  // componentDidMount(){
  //   console.log("컴포넌트가 만들어지고 첫 렌더링을 다 마친 후 실행 componentDidMount");
  // }

  // componentWillReceiveProps(nextProps){
  //   console.log("컴포넌트가 prop 을 새로 받았을 때 실행 componentWillReceiveProps: " + JSON.stringify(nextProps));
  // }

  // shouldComponentUpdate(nextProps, nextState){
  //   console.log("prop 혹은 state 가 변경 되었을 때, 리렌더링을 할지 말지 정하는 메소드 shouldComponentUpdate: " + JSON.stringify(nextProps) + " : " + JSON.stringify(nextState));
  //   return this.props !== nextState;
  // }

  // componentWillUpdate(nextProps, nextState){
  //   console.log("컴포넌트가 업데이트 되기 전에 실행됩니다. componentWillUpdate: " + JSON.stringify(nextProps) + " " + JSON.stringify(nextState));
  // }

  // componentDidUpdate(prevProps, prevState){
  //   console.log("컴포넌트가 리렌더링을 마친 후 실행됩니다. componentDidUpdate: " + JSON.stringify(prevProps) + " " + JSON.stringify(prevState));
  // }

  // componentWillUnmount(){
  //   console.log("컴포넌트가 DOM 에서 사라진 후 실행되는 메소드 componentWillUnmount");
  // }
  render(){
    const { data } = this.state;
    const selected = data.get('selected');
    const { handleChange } = this;

    return(
      <td colSpan="3" className="input">
        <ul className="ip_list">
          <li>
            <span className="input_ico_box" style={data.get('user_dstnct_code')=='02'?{display:'none'}:{}}>
              <input type="radio" id="userClasCode1" name="userClasCode" value="03" checked={this.props.value === '03'} onChange={this.props.onChange}/>
              <label htmlFor="userClasCode1">인포섹</label>
            </span>
          </li>
          <li>
            <span className="input_ico_box">
              <input type="radio" id="userClasCode2" name="userClasCode" value="01" checked={this.props.value === '01'} onChange={this.props.onChange}/>
              <label htmlFor="userClasCode2">Provider</label>
            </span>
          </li>
          <li>
            <span className="input_ico_box">
              <input type="radio" id="userClasCode3" name="userClasCode" value="02" checked={this.props.value === '02'} onChange={this.props.onChange}/>
              <label htmlFor="userClasCode3">Customer</label>
            </span>
          </li>
        </ul>
      </td>
    );
  }
}

export default UserClasRadio;