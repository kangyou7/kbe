Git placeholder file





Provider 관리	Provider Management
Provider 현황	Provider Status
Provider 명	Provider Name
No	No
사업자번호	Business Number
담당자명	Manager
담당자 연락처	Contacts
담당자 E-mail	E-Mail
등록자	Registrant
등록일	Registration Date
Provider 등록	Provider Registration
검색 결과가 없습니다.	There are no results
대용량등록방법	Batch Registration
양식다운로드	Download Form
엑셀파일작성	Save as xls
파일업로드	Upload
[등록] 버튼 클릭	Click [Register]
다운로드	Download
파일찾기	Browser
취소	Cancel
첨부하신 파일에서 잘못된 정보가 입력 되었습니다. 파일 수정 후 다시 등록 해 주세요.	"Incorrection information was entered in the attached.
Please correct it and re-register."
(오류 : 15행, 17행, 34행)	(Error lines:       )
확인	Ok
BM 분류	Business Model
초기화	Reset
확인	Ok
일반	General
White Label1	White Label 1
White Label2	White Label 2
White Label3	White Label 3
Provider명	Provider Name
대표자이름	Representative
사업자번호	Business Number
주소	Address
Web URL	Web URL
대표 E-mail	E-Mail
대표 전화번호	Phone
FAX	FAX
계약기간	Contract Term
파일첨부	Attachments
파일첨부는 최대 3개, 각 용량이 20m 이하의 jpeg, pdf만 등록 가능합니다.	You can attach up to 3 files and JPEG or PDF files with 20MB or less each.
파일찾기	Browser
등록되었습니다.	Provider is registered.
이 페이지에서 나가시겠습니까? 작성중인 내용이 저장되지 않습니다.	"Are you sure want to leave this page?
The content is not saved."
당당자 정보	Manager
대표지정	Set Primary Contact
삭제	Delete
담당자 등록	Set Manager
이름	Name
당당부서	Division
직위	Position
전화번호	Phone
휴대폰 번호	Cell Phone
E-mail	E-Mail
담당업무	Task
등록된 담당자가 없습니다.	There is no registered manager.
담당자 정보	Manager
담당자 이름	Manager Name
부서	Division
직위	Position
담당자 E-mail	E-Mail
전화번호	Phone
휴대폰번호	Cell Phone
담당업무	Task
대표자지정	Set Primary Contact
취소	Cancel
확인	Ok
선택	Select
계약	Contract
정산	Billing
영업	Sales
관리	Management
필수 입력 항목	Required
선택하신 담당자를 대표 담당자로 지정하시겠습니까?	Do you want to set the selected contact as primary contact?
Customer 현황	Customer Status
고객명	Customer Name
담당Provider	Provider
등록자	Registrant
계약건수	Number of Contracts
구분	Division
고객명	Customer Name
사업자번호	Business Number
담당 Provider	Provider
등록자	Registrant
등록일	Registration Date
검색 결과가 없습니다.	There are no results
목록 항목 선택	Select Item
ALL	All
Customer 등록	Register Customer
기본 정보	Basic Information
고객(사)명	Customer Name
고객구분	Division
법인	Company
개인사업자	Personal Business
대표자 이름	Representative
사업자번호	Business Number
주소	Address
WEB URL	Web URL
담당자이름	Manager
담당자 E-mail	E-Mail
부서	Division
직위	Position
전화번호	Phone
휴대폰번호	Cell Phone
파일첨부	Attachments
파일첨부는 최대 3개, 각 용량이 20m 이항의 jpeg, pdf만 등록 가능합니다.	You can attach up to 3 files and JPEG or PDF files with 20MB or less each.
파일찾기	Browser
계약 정보	Contract Information
계약 건수	Number of Contracts
등록자	Registrant
등록일	Registration Date
요청자	Requester
요청일	Date Requested
필수 입력 항목	Required
계약 담당자 정보	Contact Manager Information
프로바이더명	Provider Name
