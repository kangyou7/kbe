    /*jshint esversion: 6 */
    import React, { PureComponent  } from 'react';
    import { Link, browserHistory } from 'react-router';
    import PropTypes from 'prop-types';

    import UserClasRadio from './UserClasRadio';

    import PopupCustm from '../common/PopupCustm';
    import PopupGroup from '../common/PopupGroup';
    import PagingView from '../common/PagingView';
    
    import Calendar from '../common/Calendar';
    import Refusal from './Refusal';

    import { REST_API_URL, REST_AUTH_URL } from '../../config/api-config.js';
    
    /*다국어 모듈 시작*/
    import { connect } from 'react-redux';
    import { changeLangauge, mapStateToProps, actionlogin } from '../../language/Actions';
    /*다국어 모듈 종료*/

    const initializationState = {
            mode : "view",
            userNo : 0,
            userName : "",
            userClasCode : "",
            userEmail : "",
            pwd : "",
            newPwd : "",
            custmNo : 0,
            coName : "",
            dept  : "",
            posit  : "",
            title  : "",
            coTel  : "",
            mobileNo  : "",
            userStatusCode  : "",
            acsExpDate  : "",
            useYn  : "",
            regUsrNo  : "",
            userId  : "",
            ctrtStrDate :"",
            ctrtEndDate : "",
            modUsrName :"",
            modDate:"",
            regUsrName:"",
            regDate:"",
            userDesc:"",
            keyWorkd:"",
            updateState : "",
            updateModDate:"",

            expirationToken  : "",
            duplicate : "none",
            grpList : [],
            pageInfo : {
                page : 1,
                perPageNum : 30,
                userNo : 0,
            },
            history : [
                {loginDt: '2017/12/28 10:34:56',acsIp :'100.100.100.10'},
                {loginDt: '2017/12/28 10:34:56',acsIp :'100.100.100.10'},
                {loginDt: '2017/12/28 10:34:56',acsIp :'100.100.100.10'},
                {loginDt: '2017/12/28 10:34:56',acsIp :'100.100.100.10'},
                {loginDt: '2017/12/28 10:34:56',acsIp :'100.100.100.10'},
                {loginDt: '2017/12/28 10:34:56',acsIp :'100.100.100.10'},
                {loginDt: '2017/12/28 10:34:56',acsIp :'100.100.100.10'},
                {loginDt: '2017/12/28 10:34:56',acsIp :'100.100.100.10'},
                {loginDt: '2017/12/28 10:34:56',acsIp :'100.100.100.10'},
                {loginDt: '2017/12/28 10:34:56',acsIp :'100.100.100.10'},
            ]
    };

class UserDetail extends PureComponent {

    constructor(props) {
        super(props);
        this.state = $.extend(true, {}, initializationState);
        this.handleChange = this.handleChange.bind(this);
        this.handleSave = this.handleSave.bind(this);
        this.handleuserClasRadioChange = this.handleuserClasRadioChange.bind(this);
        this.handleCustmComplete = this.handleCustmComplete.bind(this);
        this.handleUserSave = this.handleUserSave.bind(this);
        this.handleCreateComplete = this.handleCreateComplete.bind(this);
        this.handleDelete = this.handleDelete.bind(this);
        this.handleGroupComplete = this.handleGroupComplete.bind(this);
        this.handlerUpdate = this.handlerUpdate.bind(this);
        this.handlePageChange = this.handlePageChange.bind(this);
    }

    handlePageChange(perPageNum, page) {
        if(!perPageNum){
            perPageNum = 30;
        }
        if(!page){
            page = 1;
        }
        let changePage = this.state.pageInfo;
        changePage.perPageNum = perPageNum;
        changePage.page = page;
        changePage.userNo = this.props.location.state.userNo;
        this.handlePageInfoChange(changePage, true);
    }

    handlePageInfoChange(pageInfo, reload) {
        let nextState = this.state;
        nextState.pageInfo = pageInfo;

        this.setState(nextState);
    
        if(reload) {
          this.getUserInfo();
        }
    }

    handleDelete(authotGroupNo){
        console.log("delete");

        let { grpList } = this.state;

        if(grpList.length > 0){
            grpList.map((record, i)=>{
                if(record.authotGroupNo == authotGroupNo){
                    grpList.splice(i,1);
                }
            });

            let nextState = {};
            nextState['grpList'] = grpList;

            this.setState(nextState);

            this.forceUpdate();
        }
    }

    
    // 컴포넌트가 DOM 위에 만들어지기 전에 실행
    componentWillMount(){
        sessionStorage.setItem("_reset", true);

        console.log('출력 되면 값이 변경되야 하는데...');

        if(typeof(this.props.location.state) === 'undefined'){
            browserHistory.push({pathname: '/userlist'});
        } else{
            let pageInfo ={
                page : 1,
                perPageNum : 30,
                userNo : this.props.location.state.userNo,
            };

            // this.setState({
            //     pageInfo : pageInfo
            // });

            console.log('컴포넌트가 DOM 위에 만들어지기 전에 실행'+JSON.stringify(pageInfo));

            this.handlePageInfoChange(pageInfo, true);
        }
    }

    handleCustmComplete(response){
        this.setState({
          coName: response.coName,
          custmNo:response.custmNo
        });

        this.handlePageInfoChange(this.state.pageInfo, true);
    }

    handleGroupComplete(_params){

        let {grpList} = this.state;
        let add_flag = true;

        if(grpList.length > 0){
            grpList.map((record, i)=>{
                console.log(record.authotGroupNo +":"+_params.groupSeq);
                if(record.authotGroupNo == _params.groupSeq){
                    console.log("같은 경우");
                    add_flag = false;
                }
            });
        }

        if(add_flag) {
            let groupItem = { 
                authotGroupNo:_params.groupSeq, 
                groupName:_params.groupName, 
                userNo : this.state.userNo, 
                loginUserNo : this.props.memberInfo.user_no
            };
            grpList.push(groupItem);

            let nextState = {};
            nextState['grpList'] = grpList;

            this.setState(nextState);

            this.forceUpdate();
        }

    }

    getStateString(){
        console.log(JSON.stringify(this.state));
    }

    //  전달된 사용자 NO로 사용자 정보 조회
    getUserInfo(){

        console.log('전달된 pageInfo : '+ JSON.stringify(this.state.pageInfo));

        $.ajax({
            url: REST_API_URL + "/user/select",
            dataType: 'json',
            type: "post",
            data: this.state.pageInfo,
            cache: false,
            processData : true, /*querySTring make false*/
            success: function(result) {
                console.log(JSON.stringify(result));
                this.setState({
                    userName: result.response.userInfo.userName,
                    userId:result.response.userInfo.userId,
                    userClasCode:result.response.userInfo.userClasCode,
                    pwd: result.response.userInfo.pwd,
                    dept:result.response.userInfo.dept,
                    posit:result.response.userInfo.posit,
                    title:result.response.userInfo.title,
                    coTel:result.response.userInfo.coTel,
                    mobileNo:result.response.userInfo.mobileNo,
                    custmNo:result.response.userInfo.custmNo,
                    coName:result.response.userInfo.coName,
                    userStatusCode:result.response.userInfo.userStatusCode,
                    ctrtStrDate:result.response.userInfo.ctrtStrDate,
                    ctrtEndDate:result.response.userInfo.ctrtEndDate,
                    userNo:result.response.userInfo.userNo,
                    regUsrName:result.response.userInfo.regUsrName,
                    modUsrName:result.response.userInfo.modUsrName,
                    regDate:result.response.userInfo.regDate,
                    modDate:result.response.userInfo.modDate,
                    userDesc:result.response.userInfo.userDesc,
                    grpList :result.response.grpList,
                    history : result.response.history,
                    pageInfo : result.response.pageInfo
                });
            }.bind(this),
            error: function(xhr, status, err) {
                console.log(JSON.stringify(xhr) + " : " + status + " : " + err);
            }.bind(this),
            xhrFields: {
              withCredentials: true
            }
        });
    }
    

        //  담당자 등록 후 리스트 조회
    handleCreateComplete(){
        browserHistory.push({pathname: '/userlist'});
    }

    //  input 변경 
    handleChange(e){
        const {data} = this.state;

        if(e.target.name==='updateState'){
            console.log('updateState');
            if($('#updateState').is(':checked')){
                this.setState({
                    updateState:  '04',
                    mode:'update'
                });
            }else{
                console.log('unchecked');
                this.setState({
                    updateState: ''
                });
            }
        }else{

            let nextState = {};
			nextState[e.target.name]=e.target.value;
			this.setState(nextState);
        }
    }

    maxLengthCheck(e){
        e.target.value = e.target.value.replace(/[^0-9]/g,"");
    
        if(e.target.value.length > e.target.maxLength){
          e.target.value = e.target.value.slice(0, e.target.maxLength);
        }
      }

    //  사용자 구분 변경 
    handleuserClasRadioChange(userClasRadio){
        const { data } = this.state;

        this.setState({
           userClasCode:userClasRadio.props.data.get("selected")
        });
    }

    //  승인 or 반려
    handleUserSave() {
        if(!confirm()){
            return false;
        }
        console.log("전달 파라미터 : "+JSON.stringify(this.state));

        $.ajax({
            url: REST_AUTH_URL + "/update",
            dataType: 'json',
            type: "post",
            data:  this.state,
            cache: false,
            processData : true, /*querySTring make false*/
            success: function(result) {
                browserHistory.push("/userconfirm");
            }.bind(this),
            error: function(xhr, status, err) {
                console.log(JSON.stringify(xhr) + " : " + status + " : " + err);
            if(xhr.status === 200)
                browserHistory.push("/userconfirm");
            }.bind(this),
            xhrFields: {
                withCredentials: true
            }
        });
    }

    handleSave() {
        let _params = {};

        if(this.state.grpList==undefined||this.state.grpList.length<1){
            alert('승인 불가');
            return false;
        }

        _params = {
            userNo : this.state.userNo,
            userStatusCode : '02',
            grpList : this.state.grpList,
        };

		$.ajax({
			url: REST_API_URL + "/user/update_status",
			dataType: 'json',
			type: "post",
			data:  {paramJson : JSON.stringify(_params)},
			cache: false,
			processData : true, /*querySTring make false*/
			success: function(result) {
               browserHistory.push('/userlist');
			}.bind(this),
				error: function(xhr, status, err) {
				console.log(xhr + " : " + status + " : " + err);
			}.bind(this),
            xhrFields: {
              withCredentials: true
            }
		});
    }

    //  수정 항목 validationCheck
    validationChecke(){
        const {updateState, duplicate, mobileNo, coTel, custmNo, newPwd, pwd, email, userDesc, updateModDate} = this.state;

        const password_pattern = /^(?=(.*\d){1})(.*\S)(?=.*[a-zA-Z\S])[0-9a-zA-Z\S]{10,}$/;  // 영문 숫자 특수문자 1개 이상 10자리까지
        const consecutive_str = /(\w)\1\1\1/; //  연속된 3자리 (숫자 && 문자)
        const email_pattern = /^(([^<>()\[\]\.,;:\s@\"]+(\.[^<>()\[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()\.,;\s@\"]+\.{0,1})+[^<>()\.,;:\s@\"]{2,})$/; //  email 형식
        
        

        //  "", null, undefined, 0, NaN ==> false
        if(String(pwd).length!==88){
            if(!pwd){
                alert('비밀번호를 입력하세요.');
                return false;
            }
            else if(!newPwd){
                alert("입력하신 비밀번호를 확인하세요.");
                return false;
            }
            else{
                if(!password_pattern.test(pwd)){
                    alert("비밀번호는 연속된 숫자 또는 문자열을 사용하여 입력하실 수 없으며 10자리, 영문+숫자+특수문자 조합으로 ID와 다르게 입력해주시기 바랍니다.");
                    return false;
                }
                if(consecutive_str.test(pwd)){
                    alert("비밀번호는 연속된 숫자 또는 문자열을 사용하여 입력하실 수 없으며 10자리, 영문+숫자+특수문자 조합으로 ID와 다르게 입력해주시기 바랍니다.");
                    return false;
                }
                if(!this.stck(pwd, 3)){
                    alert("비밀번호는 연속된 숫자 또는 문자열을 사용하여 입력하실 수 없으며 10자리, 영문+숫자+특수문자 조합으로 ID와 다르게 입력해주시기 바랍니다.");
                    return false;
                }
                if(newPwd!==pwd){
                    alert("비밀번호와 비밀번호 확인 정보가 일치하지 않습니다.");
                    return false;
                }
            }
        }


        if(this.state.updateState == '04'){
            if(!userDesc){
                alert('반려 사유를 입력하세요.');
                return false;
            }
        }

        if(!mobileNo.trim()){
            alert("휴대폰 번호를 입력하세요.");
            return false;
        }

        return true;
    }

    //연속된 문자 카운트
    stck(str, limit) {
        let o, d, p, n = 0, l = limit == null ? 4 : limit;

        for (var i = 0; i < str.length; i++) {
        var c = str.charCodeAt(i);
        if (i > 0 && (p = o - c) > -2 && p < 2 && (n = p == d ? n + 1 : 0) > l - 3) 
            return false;
        d = p, o = c;
        }
        return true;
    }

    sendMail(userEmail){

        let sendMailInfo={
            fromEmail:userEmail,
            toEmail:"secudiumiot@secudiumiot.com",
            subtitle:"secudiumiot 사용자 승인을 알려드립니다.",
            content:"Secudium Iot 사용자로 등록되었습니다."
        };
        $.ajax({
            url: REST_API_URL + "/api/mail/certify",
            dataType: 'json',
            type: "post",
            data:  sendMailInfo,
            cache: false,
            processData : true, /*querySTring make false*/
            success: function(result) {
                alert("사용자에게 승인 메일이 발송되었습니다.");
            }.bind(this),
            error: function(xhr, status, err) {
                console.log(JSON.stringify(xhr) + " : " + status + " : " + err);
                
                if(xhr.status === 200)
                    browserHistory.push("/userconfirm");
            }.bind(this),
            xhrFields: {
                withCredentials: true
            }
        });
    }

    handlerUpdate(){
        let pwd = "";

        if(!this.validationChecke()){
            return false;
        }

        let updateState = '';

        if(this.state.updateState !== '04'){
            updateState = this.state.userStatusCode;
        }
        else{
            updateState = this.state.updateState;
        }

        let updateModDate = '';
        if(this.state.updateModDate !== ''){
            updateModDate = this.state.modDate;
        }

        const memberInfo = JSON.parse(localStorage.getItem('memberInfo'));

        let updateData = {
            userStatusCode : updateState,   //  상태변경 -> 반려
            userDesc : this.state.userDesc,
            userClasCode : this.state.userClasCode,
            pwd : this.state.pwd,
            custmNo : this.state.custmNo,
            dept : this.state.dept,
            title : this.state.title,
            posit : this.state.posit,
            coTel : this.state.coTel,
            mobileNo : this.state.mobileNo,
            grpList : this.state.grpList,
            userNo : this.state.userNo,
            loginUserNo : memberInfo.user_no,
        };

        // console.log(JSON.stringify(updateData));
        if(!confirm('변경된 내용을 저장하시겠습니까?')){
            return false;
        }

        console.log(JSON.stringify(updateData));

        $.ajax({
            url: REST_API_URL + "/user/user_update_detail",
            dataType: 'json',
            type: "post",
            data:  {paramJson : JSON.stringify(updateData)},
            cache: false,
            processData : true, /*querySTring make false*/
            xhrFields: { withCredentials: true },
            success: function(result) {
                alert("수정되었습니다.");
                browserHistory.push("/userlist");
            }.bind(this),
            error: function(xhr, status, err) {
                console.log(JSON.stringify(xhr) + " : " + status + " : " + err);
            }.bind(this)
        });
    }

    render(){
        const fncBtnInfo = this.props.memberInfo.dspUserFncBtnInfo;
        const data  = this.state;
        const { handleChange } = this;
        const { handleuserClasRadioChange } = this;
        const { handleUserSave } = this;
        const { handleSave } = this;
        const { handlerUpdate } = this;
        const memberInfo = JSON.parse(localStorage.getItem('memberInfo'));

        const mapToAuthots = (grpList) =>{
            if(grpList != null && grpList.length > 0){
                return grpList.map((record, i)=> {
                    return (
                        <li key={i}>
                            <span className="title">{record.groupName}</span>
                            <a className="ibtn_del" onClick={()=>{this.handleDelete(record.authotGroupNo)}}><i className="ico_del" ><span className="offscreen">삭제</span></i></a>
                        </li>
                    );
                });
            }
        }

        const mapToHistory = (history) =>{
            if(history != null && history.length > 0){
                return history.map((record, i)=>{
                    return (
                        <tr key={i}>
                            <td>{record.loginDt}</td>
                            <td>{record.acsIp}</td>
                        </tr>
                    );
                }); 
            }else{
                return (
                    <tr>
                        <td className="noresults" colSpan="2">
                            <div className="box_noresults">
                                <div className="ver_mid">													
                                    <i className="ico ico_no_result"></i>
                                    <span className="lb">접속 히스토리가 없습니다.</span>
                                </div>
                            </div>
                        </td>
                    </tr>
                );
            }
        }

        return(
            <section className="body">

            { /* S wrapper */ }
            <div className="wrapper">
        
                { /* S page_header */ }
                <div className="page_header">
                    <h2 className="ptitle">{this.props.messages.user_user_status}</h2>
                    <div className="page_nav">
                        {/*<ul>
                            <li><Link to="/">Home</Link></li>
                            <li><Link to="/userlist">{this.props.messages.user_management}</Link></li>
                            <li className="here">{this.props.messages.user_user_status}</li>
                        </ul>*/}
                    </div>
                </div>
                { /* E:page_header */ }
        
                { /* S content_wrap */ }
                <div className="content_wrap">
                    { /* S content_outbox */ }
                    <div className="content_outbox">
                        { /* S tab_wrap */ }
                        <div className="tab_wrap tab-wrap">
                            { /* S tab_header */ }
                            <div className="box_both tab_header">
                                <div className="fl">
                                    <ul className="tabs">
                                        <li className="tab_item tab-item">
                                            <Link to="/userlist"><span>{this.props.messages.user_list}</span></Link>
                                        </li>
                                        <li className="tab_item tab-item on">
                                            <Link className="tab-link"><span>{this.props.messages.user_detail}</span></Link>
                                        </li>
                                    </ul>
                                </div>
                                <div className="fr">
                                    <div className="btn_group">
                                        <button className="btn_pos" 
                                            style={ this.state.userStatusCode!=='04' ?{}:{display:'none'}} 
                                            onClick={this.handleCreateComplete}
                                        >{this.props.messages.user_cancel}</button>
                                        <button className="btn_pos"  
                                            onClick={() => {this.refusal.show(this.state.userNo)}}
                                            style={ this.state.userStatusCode==='01' ?{}:{display:'none'}} 
                                            disabled={fncBtnInfo['funcModYn']=='N'} 
                                        >{this.props.messages.user_reject}
                                        </button>
                                        <button className="btn_black"
                                            style={ this.state.userStatusCode==='01' ?{}:{display:'none'}} 
                                            onClick={handleSave}
                                            disabled={fncBtnInfo['funcAssignYn']=='N'} 
                                        >{this.props.messages.user_approval}</button>
                                        <button className="btn_pos" 
                                            style={ this.state.userStatusCode==='02' ?{}:{display:'none'}} 
                                            onClick={handlerUpdate}
                                            disabled={fncBtnInfo['funcModYn']=='N'}
                                        >{this.props.messages.user_ok}</button>
                                        <button className="btn_pos"
                                            style={ this.state.userStatusCode==='04' ?{}:{display:'none'}} 
                                            onClick={this.handleCreateComplete}
                                        >{this.props.messages.user_list}
                                        </button>
                                    </div>
                                </div>
                            </div>
                            { /* E:tab_header */ }
        
                            { /* E: tab_content 활성화시 display:block/none  */ }
                            <div className="tab_content tab-cont no_paging" style={{display:'block'}}>
                                { /* S content_body */ }
                                <div className="content_body">
                                    { /* S content_inner */ }
                                    <div className="content_inner">
                                        <div className="box_com">
                                            <div className="fl"
                                                style={ this.state.userStatusCode==='04' ?{}:{display:'none'}}
                                            >
                                                <h3 className="ctitle">{this.props.messages.user_user_state}</h3>
                                            </div>
                                        </div>

                                        { /* S Table 반려자 */ }
                                        <table className="tbl_row"
                                        style={ this.state.userStatusCode==='04' ?{}:{display:'none'}}
                                        >
                                            <caption>사용자 상태</caption>
                                            <colgroup>
                                                <col style={{width:'10%'}}/>
                                                <col style={{width:'40%'}}/>
                                                <col style={{width:'10%'}}/>
                                                <col style={{width:'40%'}}/>
                                            </colgroup>
                                            <tbody>
                                                <tr>
                                                    <th scope="row">{this.props.messages.user_status}</th>
                                                    <td colSpan="3" className="input">
                                                        Reject 
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <th scope="row">{this.props.messages.user_manager_1}</th>
                                                    <td className="input">
                                                        <input type="text" className="ui_input" value={this.state.modUsrName} disabled={true}/>
                                                    </td>
                                                    <th scope="row">{this.props.messages.ticket_transaction_date}</th>
                                                    <td className="input">
                                                        <input type="text" className="ui_input" value={this.state.modDate} disabled={true}/>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <th scope="row">{this.props.messages.user_reason_rejection} <span className="tc_red">*</span></th>
                                                    <td colSpan="3">
                                                        <textarea className="ui_textarea" value={this.state.userDesc } disabled={true}></textarea>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                        { /* E:Table */}
                                        <div className="box_com" style={this.state.userStatusCode=='02'?{}:{display:'none'}} >
                                            <div className="fl">
                                                <h3 className="ctitle">{this.props.messages.user_user_state}</h3>
                                            </div>
                                        </div>

                                        {/* S:Table */}
                                        <table className="tbl_row" style={this.state.userStatusCode=='02'?{}:{display:'none'}}>
                                            <caption>사용자 상태 목록</caption>
                                            <colgroup>
                                                <col style={{width:'10%'}}/>
                                                <col style={{width:'40%'}}/>
                                                <col style={{width:'10%'}}/>
                                                <col style={{width:'40%'}}/>
                                            </colgroup>
                                            <tbody>
                                                <tr>
                                                    <th scope="row">{this.props.messages.user_status} <span className="tc_red">*</span></th>
                                                    <td><span className="tc_gray tw_bold">{this.state.userStatusCode=='02'?'Active':'Waiting'}</span></td>
                                                    <th scope="row">{this.props.messages.user_change_status}</th>
                                                    <td className="input">
                                                        <ul className="ip_list">
                                                            <li>
                                                                <span className="input_ico_box">
                                                                <input 
                                                                    type="checkbox"
                                                                    id="updateState" 
                                                                    name="updateState" 
                                                                    className="ui_input" 
                                                                    checked={this.state.updateState=='04'} 
                                                                    value="04"
                                                                    onChange = {this.handleChange}/>
                                                                <label htmlFor="updateState">Reject</label>
                                                                </span>
                                                            </li>
                                                        </ul>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <th scope="row">{this.props.messages.user_approver} <span className="tc_red">*</span></th>
                                                    <td>{this.state.modUsrName}</td>
                                                    <th scope="row">{this.props.messages.user_approved_date} <span className="tc_red">*</span></th>
                                                    <td>{this.state.modDate}</td>
                                                </tr>
                                                { /*
                                                <tr>
                                                    <th scope="row">요청자 <span className="tc_red">*</span></th>
                                                    <td>{this.props.memberInfo.user_name}</td>
                                                    <th scope="row">요청일 <span className="tc_red">*</span></th>
                                                    <td className="input">
                                                        <div className="date_box">
                                                            <Calendar className="ui_cal" 
                                                            dateFormat="YYYY-MM-DD"
                                                            onChange={(_value) => this.setState({
                                                                updateModDate:  _value
                                                            })}
                                                            name="updateModDate"/>
                                                        </div>
                                                    </td>
                                                </tr>
                                                */ }
                                                <tr style={this.state.updateState=='04'?{}:{display:'none'}}>
                                                    <th scope="row">{this.props.messages.user_reason_for_rejection} <span className="tc_red">*</span></th>
                                                    <td colSpan="3" className="input">
                                                        <textarea className="ui_textarea" name="userDesc" onChange={handleChange}></textarea>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                        {/* E:Table */}
                                
                                        <div className="box_com">
                                            <div className="fl">
                                                <h3 className="ctitle">{this.props.messages.user_user_information}</h3>
                                            </div>
                                        </div>
        
                                        { /* S Table */ }
                                        <table className="tbl_row">
                                            <caption>사용자 정보 목록</caption>
                                            <colgroup>
                                                <col style={{width:'10%'}}/>
                                                <col style={{width:'40%'}}/>
                                                <col style={{width:'10%'}}/>
                                                <col style={{width:'40%'}}/>
                                            </colgroup>
                                            <tbody>
                                                <tr>
                                                    <th scope="row">{this.props.messages.user_division1} <span className="tc_red">*</span></th>
                                                    <td colSpan="3" className="input">
                                                        <ul className="ip_list">
                                                        <li style={memberInfo.user_dstnct_code=='01'?{display:'none'}:{}}>
                                                            <span className="input_ico_box">
                                                            <input type="radio" id="userClasCode1" name="userClasCode" 
                                                                value="03" checked={this.state.userClasCode=== '03'} 
                                                                onChange = {this.handleChange}
                                                                disabled = {this.state.userStatusCode=='04'?true:false}
                                                            />
                                                            <label htmlFor="userClasCode1">{this.props.messages.user_infosec}</label>
                                                            </span>
                                                        </li>
                                                        <li>
                                                            <span className="input_ico_box">
                                                            <input type="radio" id="userClasCode2" name="userClasCode" 
                                                                value="01" checked={this.state.userClasCode === '01'} 
                                                                onChange = {this.handleChange}
                                                                disabled = {this.state.userStatusCode=='04'?true:false}
                                                            />
                                                            <label htmlFor="userClasCode2">Provider</label>
                                                            </span>
                                                        </li>
                                                        <li>
                                                            <span className="input_ico_box">
                                                            <input type="radio" id="userClasCode3" name="userClasCode" 
                                                                value="02" checked={this.state.userClasCode === '02'} 
                                                                onChange = {this.handleChange}
                                                                disabled = {this.state.userStatusCode=='04'?true:false}
                                                            />
                                                            <label htmlFor="userClasCode3">Customer</label>
                                                            </span>
                                                        </li>
                                                        </ul>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <th scope="row">{this.props.messages.user_name}</th>
                                                    <td colSpan="3">{this.state.userName}</td>
                                                </tr>
                                                <tr>
                                                    <th scope="row">ID <span className="tc_red">*</span></th>
                                                    <td colSpan="3">{this.state.userId}</td>
                                                </tr>
                                                <tr style={this.state.userStatusCode=='04'?{display:'none'}:{}}>
                                                    <th scope="row">{this.props.messages.user_password} <span className="tc_red">*</span></th>
                                                    <td colSpan="3" className="input">
                                                        { /* Com : 비활성화시 disabled="disabled" 추가 */ }
                                                        <input type="password" 
                                                            name="pwd"
                                                            className="ui_input" 
                                                            placeholder={this.props.messages.user_password_message} 
                                                            value={this.state.pwd} 
                                                            onChange={handleChange} />
                                                    </td>
                                                </tr>
                                                <tr style={this.state.userStatusCode=='04'?{display:'none'}:{}}>
                                                    <th scope="row">{this.props.messages.user_confirm_password} <span className="tc_red">*</span></th>
                                                    <td colSpan="3" className="input">
                                                        { /* Com : 비활성화시 disabled="disabled" 추가 */ }
                                                        <input type="password" 
                                                            name="newPwd"
                                                            className="ui_input" 
                                                            placeholder={this.props.messages.user_re_enter_password} 
                                                            value={this.state.newPwd} 
                                                            onChange={handleChange} />
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <th scope="row">{this.props.messages.user_company_name}<span className="tc_red">*</span></th>
                                                    <td  className="input">
                                                        <span className="input_btn_box">
                                                            <input type="hidden" name="custmNo" value={this.state.custmNo} onChange={handleChange} />
                                                            <input type="text" className="ui_input" name="coName" value={this.state.coName} onChange={handleChange} disabled={this.state.duplicate === "false"?'disabled':''} value={this.state.coName}
                                                            disabled = {this.state.userStatusCode=='04'?true:false}
                                                            />
                                                            <button type="button" disabled={this.state.duplicate === "false"?'disabled':''}  className="tbtn_pos" onClick={() => {this.popupCustm.show()}}
                                                            disabled = {this.state.userStatusCode=='04'?true:false}
                                                            >{this.props.messages.contract_customer_searching_1}</button>
                                                        </span>
                                                    </td>
                                                    <th scope="row">{this.props.messages.user_division}</th>
                                                    <td className="input">
                                                        <input type="text" className="ui_input" value={this.state.dept} name="dept" onChange={handleChange}
                                                        disabled = {this.state.userStatusCode=='04'?true:false}
                                                        />
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <th scope="row">{this.props.messages.user_division2}</th>
                                                    <td className="input">
                                                        <input type="text" className="ui_input"  value={this.state.title} name="title" onChange={handleChange}
                                                        disabled = {this.state.userStatusCode=='04'?true:false}
                                                        />
                                                    </td>
                                                    <th scope="row">{this.props.messages.user_position}</th>
                                                    <td className="input">
                                                        <input type="text" className="ui_input"  value={this.state.posit} name="posit" onChange={handleChange}
                                                        disabled = {this.state.userStatusCode=='04'?true:false}
                                                        />
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <th scope="row">{this.props.messages.user_business_phone}</th>
                                                    <td className="input">
                                                        <input type="text" className="ui_input" placeholder="'-' 없이 입력"  
                                                        onInput={this.maxLengthCheck.bind(this)}
                                                        maxLength={20}
                                                        value={this.state.coTel} name="coTel" 
                                                        onChange={handleChange}
                                                        disabled = {this.state.userStatusCode=='04'?true:false}
                                                        />
                                                    </td>
                                                    <th scope="row">{this.props.messages.user_cell_phone} <span className="tc_red">*</span></th>
                                                    <td className="input">
                                                        <input type="text" className="ui_input" placeholder="'-' 없이 입력"  
                                                        onInput={this.maxLengthCheck.bind(this)}
                                                        maxLength={20}
                                                        value={this.state.mobileNo} name="mobileNo" 
                                                        onChange={handleChange}
                                                        disabled = {this.state.userStatusCode=='04'?true:false}
                                                        />
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                        { /* E:Table */}

                                        <div className="box_com"
                                            style={ this.state.userStatusCode==='02'?{}:this.state.userStatusCode==='01'?{}:{display:'none'}} 
                                        >
                                            <div className="fl">
                                                <h3 className="ctitle">{this.props.messages.user_access_information}</h3>
                                            </div>
                                        </div>

                                        { /* S:Table */}
                                        <table className="tbl_row"
                                        style={ this.state.userStatusCode==='02'?{}:this.state.userStatusCode==='01'?{}:{display:'none'}} 
                                        >
                                            <caption>접근 정보 목록</caption>
                                            <colgroup>
                                                <col style={{width:'10%'}}/>
                                                <col style={{width:'40%'}}/>
                                                <col style={{width:'10%'}}/>
                                                <col style={{width:'40%'}}/>
                                            </colgroup>
                                            <tbody>
                                                <tr>
                                                    <th scope="row">{this.props.messages.user_group_assignment} <span className="tc_red">*</span></th>
                                                    <td className="input" colSpan={3}>
                                                        <span className="input_btn_box">
                                                            <input type="text" className="ui_input" name="keyWorkd"/>
                                                            <button  className="tbtn_pos" 
                                                            onClick={() => {this.popupGroup.show(this.state.keyWorkd);}}>{this.props.messages.user_search}</button>
                                                        </span>
                                                        
                                                        { /* S: search_result_list */}
                                                        <ul className="search_result_list">
                                                        { mapToAuthots(this.state.grpList) }
                                                        </ul>
                                                        { /* E:search_result_list */}
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <th scope="row">{this.props.messages.user_contract_term}</th>
                                                    <td className="input" colSpan={3}>{this.state.ctrtStrDate} ~ {this.state.ctrtEndDate}</td>
                                                </tr>
                                            </tbody>
                                        </table>
                                        { /* E:Table */}
                                        <div className="box_com"
                                            style={ this.state.userStatusCode==='02'?{}:{display:'none'}} 
                                        >
                                            <div className="fl">
                                                <h3 className="ctitle">{this.props.messages.user_access_history}</h3>
                                            </div>
                                        </div>
                                        { /* S:Table */ }
                                        <table className="tbl_col tbl_noline_bottom"
                                        style={ this.state.userStatusCode==='02'?{}:{display:'none'}} 
                                        >
                                            <caption>접속 히스토리 목록</caption>
                                            <colgroup>
                                                <col style={{width:'50%'}}/>
                                                <col style={{width:'50%'}}/>
                                            </colgroup>
                                            <thead>
                                                <tr>
                                                    <th scope="col">{this.props.messages.user_login}</th>
                                                    <th scope="col">{this.props.messages.user_ip}</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                { /* S:리스트 있는 경우 */ }
                                                {mapToHistory(this.state.history)}
                                                { /* E:리스트 있는 경우 */ }
                                                { /* S:리스트 없는 경우 */ }
                                                { /*
                                                
                                                */ }
                                                { /* E:리스트 없는 경우 */ }
                                            </tbody>
                                        </table>
                                        { /* E:Table */ }
							        </div>
                                    { /* E:content_inner */}
                                </div>
                                { /* E:content_inner */ }
                            </div>
                            <PagingView pageInfo={this.state.pageInfo} onPageChange={this.handlePageChange}/>
                            { /* E:content_bttom */ }
                        </div>
                        { /* E:tab_wrap */ }
                    </div>
                    { /* E:content_outbox */ }
                </div>
                { /* E:content_wrap */ }
            </div>
            { /* E:wrapper */ }
            <PopupCustm 
                onRef={ref => (this.popupCustm = ref)}
                coName={this.state.coName}
                setUserClasCode={this.state.userClasCode}
                onCustmComplete={this.handleCustmComplete}/>
            <Refusal 
                onRef={ref => (this.refusal = ref)} 
                onRefusalComplete={this.handleCreateComplete} />
            <PopupGroup 
                onRef= {ref => (this.popupGroup = ref)} 
                onAuthotComplete={this.handleGroupComplete}  />
        </section>
        );
    }
}
export default connect(mapStateToProps)(UserDetail);