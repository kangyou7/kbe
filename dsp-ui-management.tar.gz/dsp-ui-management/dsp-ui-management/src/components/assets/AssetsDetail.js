import React from 'react';


import ApprovalLineSetting from '../common/ApprovalLineSetting';

import CustomerSearch from '../common/CustomerSearch';
import ModelSearch from '../common/ModelSearch';

import Calendar from '../common/Calendar';
import CodeSelect from '../common/CodeSelect';
import AttachFile from '../common/AttachFile';

import {REST_API_URL} from '../../config/api-config.js';

import axios from 'axios';

import { connect } from 'react-redux';
import { changeLangauge, mapStateToProps } from '../../language/Actions';

import validator from 'validator';


class AssetsDetail extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            equipModelNo : "",
			equipModelName : "",
			equipClasCode : "",
			equipClasName : "",
			equipVendorName : "",
			assetsOwnerSeCode : "",
			assetsNatvNoTypeCode : "",
			assetsNatvNoValue : "",
			getDate : "",
			firmwareVer : "",
			signatureVer : "",
			getPrice : "",
            assetsDesc : "",
            assetsCurStatusSeCode : "",
            updateAssetStatusCode : "",
            custmNo : "",
            assetsMgmtCode : "",
            assetsOwnerSeNm : "",
            licExpDate: "",
            runDt : "",
            disUseDlngReasonCode : "",
            disUseDlngReasonText : "",
            invntryConvReasonCode : "",
            invntryConvReasonText : "",
            cstmrNm : ""
        }

        this.handleChange = this.handleChange.bind(this);

		/*고객 찾기*/
		this.handleCustomerComplete = this.handleCustomerComplete.bind(this);

		/*모델 찾기*/
		this.handleModelComplete = this.handleModelComplete.bind(this);

        this.handleModelSave = this.handleModelSave.bind(this);
        
        this.handleInitState = this.handleInitState.bind(this);
        
    }

    handleInitState() {
		
		//this.setState(this.this.initState);
		this.setState({
            equipModelNo : "",
			equipModelName : "",
			equipClasCode : "",
			equipClasName : "",
			equipVendorName : "",
			assetsOwnerSeCode : "",
			assetsNatvNoTypeCode : "",
			assetsNatvNoValue : "",
			getDate : "",
			firmwareVer : "",
			signatureVer : "",
			getPrice : "",
            assetsDesc : "",
            updateAssetStatusCode : "",
            custmNo : "",
            assetsMgmtCode : "",
            assetsOwnerSeNm : "",
            licExpDate: "",
            disUseDlngReasonCode : "",
            disUseDlngReasonText : "",
            invntryConvReasonCode : "",
            invntryConvReasonText : "",
            cstmrNm : ""
		});

		$("#spanCstmrNm").hide();
	}

    handleChange(e) {
        console.log("handlechange");
		if(e.target.name == "assetsOwnerSeCode") {
			if (e.target.value == "I") {
				$("#spanCstmrNm").hide();
			} else {
				$("#spanCstmrNm").show();
			}
        }
        
        if (e.target.name == "updateAssetStatusCode") {

            if (e.target.value == "notUse") {
                this.setState({
                    disUseDlngReasonCode : "O"
                })

                $("#trNotUseReason").show();
            }

            //현재 상태가 불용일 때
            if (this.state.assetsCurStatusSeCode == "notUse") {
                //재고전환을 선택하면, 사유표기창 표출
                if (e.target.value == "stockchange") {
                    this.setState({
                        invntryConvReasonCode : "R"
                    })
                    $("#trStockChangeReason").show();
                }
            }
        }

        if (e.target.name == "disUseDlngReasonCode") {
            if (e.target.value == "I") {
                $("input[name='disUseDlngReasonText']").attr("disabled", false);
            } else {
                $("input[name='disUseDlngReasonText']").attr("disabled", "disabled");
            }
        }

        if (e.target.name == "invntryConvReasonCode") {
            if (e.target.value == "I") {
                $("input[name='invntryConvReasonText']").attr("disabled", false);
            } else {
                $("input[name='invntryConvReasonText']").attr("disabled", "disabled");
            }
        }

        // if (e.target.name == "reasonSeCode") {
        //     if (e.target.value == "I") {
		// 		$("input[name='runDtlContent']").attr("disabled", false);
		// 	} else {
		// 		$("input[name='runDtlContent']").attr("disabled", "disabled");
		// 	}
        // }
			
		let nextState = {};
		nextState[e.target.name]=e.target.value;
		this.setState(nextState);
	}
    
    getAssets(assetsNo) {
        $.ajax({
            url: REST_API_URL+"/assets/Detail",
            dataType: 'json',
            type: "post",
            data: {
                assetsNo:assetsNo
            },
            xhrFields : {
                withCredentials : true
            },
            success: function(result) {
                this.setState(result.response);

                if (result.response.assetsOwnerSeCode != "I") {
                    $("#spanCstmrNm").show();
                }
                
            }.bind(this),
                error: function(xhr, status, err) {
                console.log(xhr + " : " + status + " : " + err);
            }.bind(this)
        });
    }

	handleModelSave() {

		if (this.validationCheck()) {
            let data = this.state;
            
            let updateStatus = $("input[name='updateAssetStatusCode']:checked").val();
            let qStr;
            let aStr;
            if ( updateStatus == "stockchange" ) {
                qStr = "현재 자산을 재고상태로 전환하시겠습니까?";
                aStr = "재고상태로 전환되었습니다.";
            } else if ( updateStatus == "notUse" ) {
                qStr = "현재 자산을 불용상태로 전환하시겠습니까?";
                aStr = "불용상태로 전환되었습니다.";
            } else {
                qStr = "변경하시겠습니까?";
                aStr = "변경되었습니다.";
            }

			if (confirm(qStr)) {

                let memberInfo = JSON.parse(localStorage.getItem("memberInfo"));

                data.loginUserNo = memberInfo.user_no;
                
				$.ajax({
					url: REST_API_URL+"/assets/Update",
					dataType: 'json',
					type: "post",
					xhrFields : {
						withCredentials : true
					},
					data: {paramJson : JSON.stringify(data)},
		
					success: function(result) {
						
						if (result.response == "SUCCESS") {
							alert(aStr);
							location.href="/assets";
						} else {
							alert("등록 도중 오류가 발생하였습니다. 관리자에게 문의바랍니다.");
							return;
						}
		
					}.bind(this),
						error: function(xhr, status, err) {
						console.log(xhr + " : " + status + " : " + err);
					}.bind(this)
				});
			}		
		}
	}

	handleSave() {

		this.handleModelSave();
		
	}

	validationCheck() {
        
        // if(this.state.updateAssetStatusCode != "") {
        //     if (this.state.reqDate == "") {
        //         alert("요청일을 선택해 주세요.");
		// 	    return false;
        //     }
        // }

		if(this.state.equipModelNo == "") {
			alert("모델을 선택해 주세요.");
			return false;
		}

		if(this.state.assetsOwnerSeCode == "C" || this.state.assetsOwnerSeCode == "R") {
			if(this.state.custmNo == "") {
				alert("고객사를 선택해 주세요.");
				return false;
			}
		}

		if(this.state.assetsNatvNoTypeCode == "") {
			alert("고유 Code 종류를 선택 하세요.");
			return false;
		}

		if(this.state.assetsNatvNoValue == "") {
			alert("고유 Code No.를 입력 하세요.");
			return false;
		} else {
			if (!validator.isLength(this.state.assetsNatvNoValue,{min:0, max: 50})) {
				alert("고유 Code No.는 50자 이내로 입력바랍니다.");
				return false;
            }
            
            if (this.state.assetsNatvNoTypeCode == "IP") {
				if (!validator.isIP(this.state.assetsNatvNoValue)) {
					alert("IP 형태로 입력바랍니다.");
					return false;
				}
			} else if (this.state.assetsNatvNoTypeCode == "MAC") {
				if (!validator.isMACAddress(this.state.assetsNatvNoValue)) {
					alert("MAC Address 형태로 입력바랍니다.");
					return false;
				}
			}
		}

		if(this.state.licExpDate == "") {
			alert("License 만료일을 지정하세요.");
			return false;
        }
        
		if(this.state.getDate == "") {
			alert("취득일 지정하세요.");
			return false;
        }
        
        if(this.state.getPrice == "") {
			alert("취득가액을 입력하세요.");
			return false;
		} else {
			if (!validator.isNumeric(this.state.getPrice)) {
				alert("취득가액은 숫자만 입력바랍니다.");
				return false;
			}
		}

		if(this.state.firmwareVer == "") {
			alert("펌웨어 버전을 입력하세요.");
			return false;
		} else {
			if (!validator.isLength(this.state.firmwareVer,{min:0, max: 50})) {
				alert("펌웨어버전은 50자 이내로 입력바랍니다.");
				return false;
			}
		}

		if(this.state.signatureVer == "") {
			alert("Signature 버전을 입력하세요.");
			return false;
		} else {
			if (!validator.isLength(this.state.assetsNatvNoValue,{min:0, max: 50})) {
				alert("Signature 버전은 50자 이내로 입력바랍니다.");
				return false;
			}
		}
		
		return true;
	}

	handleModelComplete(model) {
	
		this.setState({
			equipModelNo : model.equipModelNo,
			equipModelName : model.equipModelName,
			equipClasCode : model.equipClasCode,
			equipClasName : model.equipClasName,
			equipVendorName : model.equipVendorName
		})
	}

	handleCustomerComplete(customer) {
		this.setState({
			custmNo : customer.custmNo,
			cstmrNm : customer.coName
		})
	}
    
    componentDidMount() {
        this.props.onRef(this)
		$("#tab-cont2").show();

		this.handleInitState();
	}

    //컴포넌트가 DOM 에서 사라진 후 실행되는 메소드입니다.
	componentWillUnmount() {
		this.props.onRef(null)
    }
    
    handleOnlyNumber(smallPoint, e) {

        if(smallPoint > 0 ) {
            //let regexp = /^\d*(\.\d{0,2})?$/;
            let regexp = new RegExp("^\\d*(\\.\\d{0," + smallPoint + "})?$");
            if(e.target.value.search(regexp) == -1) {
                e.target.value=e.target.value.substring(0, e.target.value.length -1);
            } else  {
                e.target.value=e.target.value;
            }
        } else {
            e.target.value = e.target.value.replace(/[^0-9]/g,"")
        }
    }

    render() {

        const mapToStatus = (status) => {
            console.log(status);
            //입고
            if (status == "join") {
                return (
                    <table className="tbl_row">
                        <colgroup>
                            <col style={{width: '10%'}}/>
                            <col style={{width: '40%'}}/>
                            <col style={{width: '10%'}}/>
                            <col style={{width: '40%'}}/>
                        </colgroup>
                        <tbody>
                            <tr>
                                <th scope="row">{this.props.messages.assets_status_now} <span className="tc_red">*</span></th>
                                <td>{this.props.messages.assets_warehousing} </td>
                                <th scope="row">{this.props.messages.assets_change}</th>
                                <td className="input">
                                    <ul className="ip_list">
                                        <li>
                                            <span className="input_ico_box">
                                                <input type="radio" name="updateAssetStatusCode" id="rdo-1" value="stockchange" onChange={this.handleChange}/>
                                                <label htmlFor="rdo-1">{this.props.messages.assets_conversion_inventory}</label>
                                            </span>
                                        </li>
                                    </ul>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">{this.props.messages.assets_registrant} <span className="tc_red">*</span></th>
                                <td>{this.state.regUsrNo}</td>
                                <th scope="row">{this.props.messages.assets_registration_date} <span className="tc_red">*</span></th>
                                <td>{this.state.regDate}</td>
                            </tr>
                            {/* <tr>
                                <th scope="row">{this.props.messages.assets_requester} <span className="tc_red">*</span></th>
                                <td>{this.props.memberInfo.user_name}</td>
                                <th scope="row">{this.props.messages.assets_request_date}<span className="tc_red">*</span></th>
                                <td className="input">

                                    <div className="date_box">
                                       
                                        <Calendar className="ui_cal" 
                                            dateFormat="YYYY-MM-DD"
                                            onChange={(data) => this.setState({reqDate: data})}/>
                                    </div>

                                </td>
                            </tr> */}
                        </tbody>
                    </table>
                );
            } else if (status == "service") {
                return (
                    <table className="tbl_row">
                        <colgroup>
                            <col style={{width: '10%'}}/>
                            <col style={{width: '40%'}}/>
                            <col style={{width: '10%'}}/>
                            <col style={{width: '40%'}}/>
                        </colgroup>
                        <tbody>
                            <tr>
                                <th scope="row">{this.props.messages.assets_status_now} <span className="tc_red">*</span></th>
                                <td>{this.props.messages.assets_service}</td>
                                <th scope="row">{this.props.messages.assets_change}</th>
                                <td className="input">
                                    <ul className="ip_list">
                                        <li>
                                            <span className="input_ico_box">
                                                <input type="radio" name="updateAssetStatusCode" id="rdo-1" value="stockchange" onChange={this.handleChange}/>
                                                {/*<label htmlFor="rdo-1">{this.props.messages.assets_conversion_inventory}</label>*/}
                                                <label htmlFor="rdo-1">{this.props.messages.assets_service_termination}</label>
                                            </span>
                                        </li>
                                    </ul>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">{this.props.messages.assets_registrant} <span className="tc_red">*</span></th>
                                <td>{this.state.regUsrNo}</td>
                                <th scope="row">{this.props.messages.assets_registration_date} <span className="tc_red">*</span></th>
                                <td>{this.state.regDate}</td>
                            </tr>
                            {/* <tr>
                                <th scope="row">{this.props.messages.assets_requester} <span className="tc_red">*</span></th>
                                <td>{this.props.memberInfo.user_name}</td>
                                <th scope="row">{this.props.messages.assets_request_date}<span className="tc_red">*</span></th>
                                <td className="input">

                                    <div className="date_box">
                                        <Calendar className="ui_cal" 
                                            dateFormat="YYYY-MM-DD"
                                            
                                            onChange={(data) => this.setState({reqDate: data})}/>
                                    </div>

                                </td>
                            </tr> */}
                        </tbody>
                    </table>
                );
            } else if (status == "stockchange") {
                return (
                    <table className="tbl_row">
                        <colgroup>
                            <col style={{width: '10%'}}/>
                            <col style={{width: '40%'}}/>
                            <col style={{width: '10%'}}/>
                            <col style={{width: '40%'}}/>
                        </colgroup>
                        <tbody>
                            <tr>
                                <th scope="row">{this.props.messages.assets_status_now} <span className="tc_red">*</span></th>
                                <td>{this.props.messages.assets_inventory}</td>
                                <th scope="row">{this.props.messages.assets_change}</th>
                                <td className="input">
                                    <ul className="ip_list">
                                        <li>
                                            <span className="input_ico_box">
                                                <input type="radio" name="updateAssetStatusCode" id="rdo-1" value="notUse" onChange={this.handleChange}/>
                                                <label htmlFor="rdo-1">{this.props.messages.assets_disuse}</label>
                                            </span>
                                        </li>
                                    </ul>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">{this.props.messages.assets_inventory_manager}<span className="tc_red">*</span></th>
                                <td>{this.state.runChargeUsrName}</td>
                                <th scope="row">{this.props.messages.assets_inventory_processing_date}<span className="tc_red">*</span></th>
                                <td>{this.state.runDt}</td>
                            </tr>
                            {
                                this.state.invntryConvReasonCode != undefined ?
                                    <tr>
                                        <th scope="row">{this.props.messages.assets_conversion_reason}</th>
                                        <td colSpan={3}>{this.state.invntryConvReasonText}</td>
                                    </tr>
                                :
                                    ''
                            }
                            {/* <tr>
                                <th scope="row">{this.props.messages.assets_requester} <span className="tc_red">*</span></th>
                                <td>{this.props.memberInfo.user_name}</td>
                                <th scope="row">{this.props.messages.assets_request_date}<span className="tc_red">*</span></th>
                                <td className="input">

                                    <div className="date_box">
                                        <Calendar className="ui_cal" 
                                            dateFormat="YYYY-MM-DD"
                                            
                                            onChange={(data) => this.setState({reqDate: data})}/>
                                    </div>

                                </td>
                            </tr> */}
                            <tr id="trNotUseReason" style={{display: 'none'}}>
                                <th scope="row">{this.props.messages.assets_reason_disuse_equipments} <span className="tc_red">*</span></th>
                                <td className="input" colSpan={3}>
                                    <ul className="ip_list">
                                        <li>
                                            <span className="input_ico_box">
                                                <input type="radio" name="disUseDlngReasonCode" id="rdo-3-1" defaultChecked="true" value="O" onChange={this.handleChange}/>
                                                <label htmlFor="rdo-3-1">{this.props.messages.assets_obsolescence_equipment}</label>
                                            </span>
                                        </li>
                                        <li>
                                            <span className="input_ico_box">
                                                <input type="radio" name="disUseDlngReasonCode" id="rdo-3-2" value="C" onChange={this.handleChange}/>
                                                <label htmlFor="rdo-3-2">{this.props.messages.assets_power_faulity}</label>
                                            </span>
                                        </li>
                                        <li>
                                            <span className="input_ico_box">
                                                <input type="radio" name="disUseDlngReasonCode" id="rdo-3-3" value="E" onChange={this.handleChange}/>
                                                <label htmlFor="rdo-3-3">{this.props.messages.assets_end_of_service}</label>
                                            </span>
                                        </li>
                                        <li>
                                            <span className="input_ico_box">
                                                <input type="radio" name="disUseDlngReasonCode" id="rdo-3-4" value="I" onChange={this.handleChange}/>
                                                <label htmlFor="rdo-3-4">{this.props.messages.assets_direct_input}</label>
                                            </span>
                                            <input type="text" name="disUseDlngReasonText" disabled className="ui_input" onChange={this.handleChange}/>
                                        </li>
                                    </ul>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                );
            } else if (status == "notUse") {
                return (
                    <table className="tbl_row">
                        <colgroup>
                            <col style={{width: '10%'}}/>
                            <col style={{width: '40%'}}/>
                            <col style={{width: '10%'}}/>
                            <col style={{width: '40%'}}/>
                        </colgroup>
                        <tbody>
                            <tr>
                                <th scope="row">{this.props.messages.assets_status_now} <span className="tc_red">*</span></th>
                                <td>{this.props.messages.assets_disuse}</td>
                                <th scope="row">{this.props.messages.assets_change}</th>
                                <td className="input">
                                    <ul className="ip_list">
                                        <li>
                                            <span className="input_ico_box">
                                                <input type="radio" name="updateAssetStatusCode" id="rdo-1" value="destroy" onChange={this.handleChange}/>
                                                <label htmlFor="rdo-1">{this.props.messages.assets_discard_equipments}</label>
                                            </span>
                                        </li>
                                        <li>
                                            <span className="input_ico_box">
                                                <input type="radio" name="updateAssetStatusCode" id="rdo-2" value="stockchange" onChange={this.handleChange}/>
                                                <label htmlFor="rdo-2">{this.props.messages.assets_conversion_inventory}</label>
                                            </span>
                                        </li>
                                    </ul>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">{this.props.messages.assets_disuse_manager} <span className="tc_red">*</span></th>
                                <td>{this.state.runChargeUsrName}</td>
                                <th scope="row">{this.props.messages.assets_processing_date_for_disuse} <span className="tc_red">*</span></th>
                                <td>{this.state.runDt}</td>
                            </tr>
                            <tr>
                                <th scope="row">{this.props.messages.assets_reason_disuse_equipments} <span className="tc_red">*</span></th>
                                <td colSpan={3}>{this.state.disUseDlngReasonText}</td>
                            </tr>
                            {/* <tr>
                                <th scope="row">{this.props.messages.assets_requester} <span className="tc_red">*</span></th>
                                <td>{this.props.memberInfo.user_name}</td>
                                <th scope="row">{this.props.messages.assets_request_date} <span className="tc_red">*</span></th>
                                <td className="input">
                                    <div className="date_box">
                                        <Calendar className="ui_cal" 
                                            dateFormat="YYYY-MM-DD"
                                            
                                            onChange={(data) => this.setState({reqDate: data})}/>
                                    </div>
                                </td>
                            </tr> */}
                            <tr id="trStockChangeReason" style={{display: 'none'}}>
                                <th scope="row">{this.props.messages.assets_conversion_reason}  <span className="tc_red">*</span></th>
                                <td className="input" colSpan={3}>
                                    <ul className="ip_list">
                                        <li>
                                            <span className="input_ico_box">
                                                <input type="radio" name="invntryConvReasonCode" id="rdo-3-1" defaultChecked="true" value="R" onChange={this.handleChange}/>
                                                <label htmlFor="rdo-3-1">{this.props.messages.assets_repair_completion}</label>
                                            </span>
                                        </li>
                                        <li>
                                            <span className="input_ico_box">
                                                <input type="radio" name="invntryConvReasonCode" id="rdo-3-2" value="E" onChange={this.handleChange}/>
                                                <label htmlFor="rdo-3-2">{this.props.messages.assets_replacement_completion}</label>
                                            </span>
                                        </li>
                                        <li>
                                            <span className="input_ico_box">
                                                <input type="radio" name="invntryConvReasonCode" id="rdo-3-3" value="D" onChange={this.handleChange}/>
                                                <label htmlFor="rdo-3-3">{this.props.messages.assets_service_termination}</label>
                                            </span>
                                        </li>
                                        <li>
                                            <span className="input_ico_box">
                                                <input type="radio" name="invntryConvReasonCode" id="rdo-3-4" value="I" onChange={this.handleChange}/>
                                                <label htmlFor="rdo-3-4">{this.props.messages.assets_direct_input}</label>
                                            </span>
                                            <input type="text" name="invntryConvReasonText" disabled className="ui_input" onChange={this.handleChange}/>
                                        </li>
                                    </ul>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                );
            }
        }

        return (
			<div id="tab-cont2" className="tab_content tab-cont no_paging">
  
                <div className="content_body">

                    <div className="content_inner">
                        <div className="box_com">
                            <div className="fl">
                                <h3 className="ctitle">{this.props.messages.assets_state}</h3>
                            </div>
                            <div className="fr">
                                <div className="desc">
                                    <span className="tc_red">*</span> {this.props.messages.assets_reguired}
                                </div>
                            </div>
                        </div>

                        {mapToStatus(this.state.assetsCurStatusSeCode)}

                        <div className="box_com">
                            <div className="fl">
                                <h3 className="ctitle">{this.props.messages.assets_information}</h3>
                            </div>
                            <div className="fr">
                                <div className="desc">
                                    <span className="tc_red">*</span> {this.props.messages.assets_reguired}
                                </div>
                            </div>
                        </div>

                        <table className="tbl_row">
                            <caption>자산 정보 목록</caption>
                            <colgroup>
                                <col style={{width: '10%'}}/>
                                <col style={{width: '40%'}}/>
                                <col style={{width: '10%'}}/>
                                <col style={{width: '40%'}}/>
                            </colgroup>
                            <tbody>
                                <tr>
                                    <th scope="row">{this.props.messages.assets_model_name} <span className="tc_red">*</span></th>
                                    <td className="input">
                                        <span className="input_btn_box">
                                            <input type="text" className="ui_input" readOnly name="equipModelName" value={this.state.equipModelName}  onChange={this.handleChange}/>
                                            <button type="button" className="tbtn_pos" onClick={() => {this.modelSearch.show();}}>{this.props.messages.assets_model_searching}</button>
                                        </span>
                                    </td>
                                    <th scope="row">{this.props.messages.assets_type} <span className="tc_red">*</span></th>
                                    <td className="input">
                                        <input type="text" className="ui_input" readOnly name="equipClasName" value={this.state.equipClasName} onChange={this.handleChange}/>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">{this.props.messages.assets_vendor_name} <span className="tc_red">*</span></th>
                                    <td className="input">
                                        <input type="text" className="ui_input" readOnly name="equipVendorName" value={this.state.equipVendorName} onChange={this.handleChange}/>
                                    </td>
                                    <th scope="row">{this.props.messages.assets_possesion} <span className="tc_red">*</span></th>
                                    <td className="input">
                                        <ul className="ip_list">
                                            <li>
                                                <span className="input_ico_box">
                                                    <input type="radio" name="assetsOwnerSeCode" id="assetsOwnerSeCode1" value="I" checked={this.state.assetsOwnerSeCode === "I"} onChange={this.handleChange}/>
                                                    <label htmlFor="assetsOwnerSeCode1">{this.props.messages.assets_owner_infosec}</label>
                                                </span>
                                            </li>
                                            <li>
                                                <span className="input_ico_box">
                                                    <input type="radio" name="assetsOwnerSeCode" id="assetsOwnerSeCode2" value="R" checked={this.state.assetsOwnerSeCode === "R"} onChange={this.handleChange}/>
                                                    <label htmlFor="assetsOwnerSeCode2">{this.props.messages.assets_owner_rent}</label>
                                                </span>
                                            </li>
                                            <li>
                                                <span className="input_ico_box">
                                                    <input type="radio" name="assetsOwnerSeCode" id="assetsOwnerSeCode3" value="C" checked={this.state.assetsOwnerSeCode === "C"} onChange={this.handleChange}/>
                                                    <label htmlFor="assetsOwnerSeCode3">{this.props.messages.assets_owner_customer}</label>
                                                </span>
                                               
                                                <span className="input_btn_box" id="spanCstmrNm" style={{display: 'inline-block'}}>
                                                    <input type="text" className="ui_input" readOnly name="cstmrNm" value={this.state.cstmrNm} onChange={this.handleChange}/>
													<a href="javascript:;" className="tbtn_pos" onClick={() => {this.customerSearch.show();}}>{this.props.messages.contract_customer_searching_1}</a>
                                                </span>
                                            </li>
                                        </ul>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">{this.props.messages.assets_serial_no} <span className="tc_red">*</span></th>
                                    <td className="input" colSpan={3}>
                                        <CodeSelect className="ui-sel sel_white" 
                                            name="assetsNatvNoTypeCode" 
                                            value={this.state.assetsNatvNoTypeCode} 
                                            onChange={this.handleChange} 
                                            groupCode="ASSETS_NATV_TYPE"/>
                                        <input type="text" className="ui_input" maxLength="50" name="assetsNatvNoValue" value={this.state.assetsNatvNoValue} onChange={this.handleChange}/>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">{this.props.messages.assets_license_termination_date} <span className="tc_red">*</span></th>
                                    <td className="input">
                                        <div className="date_box">
                                            <Calendar className="ui_cal" 
                                            dateFormat="YYYY-MM-DD"
                                            name="licExpDate"
                                            selected={this.state.licExpDate}
                                            onChange={(data) => this.setState({licExpDate: data})}/>
                                        </div>
                                       
                                    </td>
                                    <th scope="row">{this.props.messages.assets_acquisition_date} <span className="tc_red">*</span></th>
                                    <td className="input">
                                       
                                        <div className="date_box">
                                            <Calendar className="ui_cal" 
                                            name="getDate"
                                            dateFormat="YYYY-MM-DD"
                                            selected={this.state.getDate}
                                            onChange={(data) => this.setState({getDate: data})}/>
                                        </div>
                                      
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">{this.props.messages.assets_acquisition_cost} <span className="tc_red">*</span></th>
                                    <td className="input">
                                        <input type="number" className="ui_input" name="getPrice" value={this.state.getPrice} maxLength={20} onChange={this.handleChange} onInput={this.handleOnlyNumber.bind(this, 0)}/>
                                    </td>
                                    <th scope="row">{this.props.messages.assets_asset_code}</th>
                                    <td className="input">
                                        <input type="text" className="ui_input" maxLength="50" name="assetsMgmtCode" value={this.state.assetsMgmtCode} onChange={this.handleChange}/>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">{this.props.messages.assets_firmware_version} <span className="tc_red">*</span></th>
                                    <td className="input">
                                        <input type="text" className="ui_input" maxLength="50" name="firmwareVer" value={this.state.firmwareVer} onChange={this.handleChange}/>
                                    </td>
                                    <th scope="row">{this.props.messages.assets_signature_version} <span className="tc_red">*</span></th>
                                    <td className="input">
                                        <input type="text" className="ui_input" maxLength="50" name="signatureVer" value={this.state.signatureVer} onChange={this.handleChange}/>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">{this.props.messages.assets_remark}</th>
                                    <td className="input" colSpan={3}>
                                        <textarea className="ui_textarea" maxLength="4000" name="assetsDesc" value={this.state.assetsDesc} onChange={this.handleChange}></textarea>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>

                <CustomerSearch onRef={ref => (this.customerSearch = ref)} onCustomerComplete={this.handleCustomerComplete}/>
                <ModelSearch onRef={ref => (this.modelSearch = ref)} onModelComplete={this.handleModelComplete}/>
            </div>

        );
    }
}

export default connect(mapStateToProps)(AssetsDetail);